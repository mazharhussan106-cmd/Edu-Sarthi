# Speak Sarthi — Phase 5, feature-complete

Android app for spoken-English fluency. **All five phases are built.** What is
left before this can go in front of people is on
[docs/LAUNCH_CHECKLIST.md](docs/LAUNCH_CHECKLIST.md), and none of it is code.

- **Phase 1** — data layer, content pipeline, spaced repetition
- **Phase 2** — home, the three-part flashcard, study sessions, listening
- **Phase 3** — the audit engine: recording, pronunciation scoring, the score
  card, the speech budget, weak sounds
- **Phase 4** — placement test, search and bookmarks, mistake review, ten badges,
  reminders, settings, statistics, feedback
- **Phase 5** — an anonymous profile from first launch, backup and restore,
  Play Billing and the paywall, the privacy notice, the lesson path, and a
  written contract for the server that does not exist yet

The working name is not final. `namespace` and `applicationId` in
`app/build.gradle.kts` are a safe find-and-replace right up until the first Play
Store upload, after which the applicationId is permanent.

---

## What runs today

Install and launch. The app shows a short **privacy notice** — what stays on your
phone and what does not — then offers a **placement test**:
a dozen questions that climb while you get them right and stop when you do not.
It is skippable, and skipping costs nothing: you start at A1 and can change your
level in settings.

After that the app opens on a home screen showing what is due, today's progress
against the daily goal, and the current streak. Five things sit on the bottom bar
— Home, Words, Speak, Progress, Settings — and nothing else does, because an app
with a dozen screens that lists all of them starts feeling like a filing cabinet.

**Study session** — words come off the SM-2 due queue, twenty to a session. Each
card has three parts you swipe between:

1. **Recognise** — illustration, word, IPA, syllable stress, Devanagari
   pronunciation, etymology and memory hooks
2. **Understand** — meaning, the word in a sentence, similar and opposite words,
   the common mistake, word family, register and a mini conversation
3. **Practise** — collocations and patterns, then the five exercises: multiple
   choice (the only one graded), fill the blank, fix the sentence, say it in
   English, and write your own

Four grade buttons sit under every part — Again, Hard, Good, Easy — so a learner
who knows the word from part one does not have to swipe through two more pages to
say so. What they write in "write your own" is never marked; it is kept and shown
back at the next review.

**Listening practice** — a word is spoken and the learner picks which of four it
was, with slower playback and the same word inside a sentence on demand. The
wrong options are chosen by how close they sound to the target, not at random:
"accept" is offered against "except" and "expect", which is the exercise actually
worth doing.

**Speaking practice** — read a line, record it, hear yourself back, then choose to
score it. What comes back is not a percentage: it is a band, and one specific
sound to fix, in one specific word, described as a mouth movement. Raw numbers are
there behind a tap for anyone who wants them.

Nothing is sent automatically. Scoring is the only thing in the app that costs
money per use, so spending it is always a deliberate tap — and the recording is
kept whatever happens to the network, the budget or the configuration.

**Sounds to work on** — the phonemes the learner keeps missing, ranked by error
rate, each with a name, an example word you can hear, and what the mouth should
be doing. See [docs/PRONUNCIATION_SCORING.md](docs/PRONUNCIATION_SCORING.md).

**Search and bookmarks** — the whole library, reachable directly. Search by word,
by English meaning or by the Hindi one, filter by level, open any word on its own
three-part card. Nothing there grades the word: looking something up because you
heard it at work must not tell the scheduler you just reviewed it.

**Mistake review** — a study session over the words you keep getting wrong rather
than whatever is scheduled. Two sources feed it: words you keep rating "Again",
and words you were confident about and still missed in a quiz. They are different
failures and both belong here.

**Ten badges** — no points, no coins, no levels. Each one marks something worth
having done: the first time you recorded your voice, a week you did not break, a
sound you actually fixed. None can be earned by grinding, all are reachable
without paying, and **none is ever taken away** — losing "a full week" because you
were ill is how you lose the learner too.

**Reminders, settings and progress** — at most three daily reminders (the cap is
deliberate), a settings screen that can finally delete your recordings, and two
weeks of history with every empty day shown.

**Lessons** — a finishable path through the same 1,000 words, grouped by level
and topic. It exists because the review queue never ends, which is right for
remembering things and poor for feeling you are getting somewhere. The grouping
is generated and says so; a course written by a teacher would be better.

**Backup** — everything the app knows about your learning, exported to one file
you keep. Restore it on a new phone and it all comes back. No account, no server,
no upload. See "The thing that has been deferred twice" below.

**Subscription** — ₹249/month buys more AI scoring, and nothing else. All 1,000
words, every phrase, the flashcards, listening, recording and playing yourself
back, mistake review, lessons, badges and statistics are free forever.

Underneath that, the bundled library:

- **1,000 words** — CEFR-levelled, with Hindi meaning and pronunciation, IPA,
  syllable stress, mnemonics, common mistakes and word families
- **7,053 chunks** — collocations, phrasal expressions and grammar patterns,
  split out as individually learnable units
- **8,000 speaking prompts** — the sentences a learner reads aloud; these become
  the input to pronunciation scoring in phase 3
- **1,000 exercise sets** — all five practice-zone exercises per word: multiple
  choice, fill in the blank, sentence correction, translate from Hindi, and
  write your own sentence

Tap the theme button on the home screen to cycle system → light → dark → eye
protection. The library details button (ⓘ) opens the phase-1 status screen, which
reports exactly what landed in the database.

Illustrations are fetched on demand and cached, never bundled — so the card
reserves the frame and shows a text fallback until artwork is uploaded and a
host is configured.

The docs, in the order they become relevant:

| | |
|---|---|
| [DECISIONS.md](docs/DECISIONS.md) | **what was settled 2026-09-17**, and what it changes |
| [worker/README.md](worker/README.md) | the server — deploying it, and every endpoint |
| [FIRST_BUILD.md](docs/FIRST_BUILD.md) | **read this first** — getting it to compile, and the errors to expect |
| [LAUNCH_CHECKLIST.md](docs/LAUNCH_CHECKLIST.md) | everything left, and none of it is code |
| [SERVER_CONTRACT.md](docs/SERVER_CONTRACT.md) | the one endpoint that blocks launch, and the ones that do not |
| [PRIVACY_POLICY.md](docs/PRIVACY_POLICY.md) | draft, with the three blanks marked |
| [PRONUNCIATION_SCORING.md](docs/PRONUNCIATION_SCORING.md) | the audit engine |
| [CARD_SPEC.md](docs/CARD_SPEC.md) | the reference card, field by field |
| [ILLUSTRATIONS.md](docs/ILLUSTRATIONS.md) | the artwork brief |

---

## Build it

Requirements: Android Studio Ladybug or newer, JDK 17, an Android device or
emulator on API 24+.

```bash
git clone <this project>
cd SpeakSarthi
./gradlew assembleDebug          # APK at app/build/outputs/apk/debug/
./gradlew installDebug           # straight onto a connected device
```

Or open the folder in Android Studio and press Run. The first sync downloads the
Gradle distribution and the Android dependencies, so it needs a network
connection; after that everything works offline.

**This has never been compiled** — no Kotlin compiler has seen these files, so
the first build will almost certainly fail before it succeeds.
[docs/FIRST_BUILD.md](docs/FIRST_BUILD.md) walks through it: what you need, what
the first build is doing during the long silence, the errors to expect at each
stage and what each one means, and a ten-minute smoke test for when it runs.

### Tests

```bash
./gradlew test                   # 16 JVM test classes — SM-2, converters,
                                 # listening, WAV header, score reading, speech
                                 # budget, badges, placement, reminders, stats,
                                 # entitlement, backup merge, lesson planning
./gradlew connectedAndroidTest   # instrumented — real Room, real bundled assets
```

Two instrumented tests carry more weight than the rest.

`reimportingContentLeavesLearnerProgressUntouched` — WordMaster shipped an
importer that wiped every learner's review history whenever content was
re-imported. This project is built so that cannot happen, and the test proves it
on every build.

`anOverBudgetClipIsNeverSentToTheService` — scoring is the only thing here that
costs money per use, and the daily cap is the only thing between a few heavy free
users and a bill bigger than the revenue. The fake scorer counts how many times it
was actually called, so "the check is in there somewhere" is not good enough.

`restoringTheVerySameBackupTwiceChangesNothing` — backup exists to stop a learner
losing work, so a merge rule that loses work while restoring would be the most
embarrassing bug available. Every rule has a test naming which side wins and why.

`MigrationTest` — **skips on a fresh checkout**, and that is deliberate. Room
exports a schema only when the project is built at that version, and nothing here
has been built at version 1, so `app/schemas/1.json` does not exist yet. Build the
phase-3 source once, commit the file it writes, and these three tests start
running. A red test nobody can make green teaches a team to ignore red tests.

---

## How it is put together

```
app/src/main/java/com/speaksarthi/app/
├── data/
│   ├── analytics/      the event list, behind a no-op implementation
│   ├── backup/         export and restore, to a file the learner keeps
│   ├── billing/        Play Billing, behind an interface
│   ├── audio/          TTS, WAV capture, playback of the learner's own clips
│   ├── illustration/   on-demand artwork fetching, caching and prefetch
│   ├── local/          Room — entities, DAOs, converters, database, migrations
│   ├── preferences/    DataStore — theme, goal, level, reminders, speech budget
│   ├── reminder/       WorkManager scheduling and the notification
│   ├── repository/     repository implementations
│   ├── seed/           JSON importer + the "is content current?" check
│   └── speech/         pronunciation scoring — config, client, response parsing
├── domain/
│   ├── model/          plain Kotlin models, no Android types
│   ├── repository/     repository interfaces
│   └── usecase/        SM-2, listening, scoring, budget, badges, placement,
│                       reminders, statistics, entitlement, backup merge, lessons
├── di/                 Hilt modules
├── presentation/
│   ├── badges/         the ten badges, earned and not
│   ├── card/           the three card parts and the pieces they are built from
│   ├── feedback/       in-app feedback, sent as email
│   ├── home/           dashboard — due count, daily goal, streak
│   ├── lessons/        the lesson path
│   ├── listening/      listen-and-choose practice
│   ├── navigation/     routes, the NavHost and the bottom bar
│   ├── paywall/        what the subscription buys, stated plainly
│   ├── placement/      the skippable placement test
│   ├── privacy/        the notice, shown once and available after
│   ├── search/         search, bookmarks, recent, browse
│   ├── settings/       display, learning, audio, reminders, storage
│   ├── sounds/         the sounds to work on
│   ├── speaking/       record, score, score card
│   ├── stats/          two weeks of history
│   ├── study/          the study session, and mistake review
│   ├── theme/          colour, type, four display modes
│   ├── ui/             the phase-1 library status screen, now diagnostics
│   ├── util/           small Compose helpers
│   └── worddetail/     one word, opened deliberately, never graded
└── util/               Clock, behind an interface so time is testable
```

Kotlin, Jetpack Compose, MVVM, Room, DataStore, Hilt, Coroutines and Flow —
the same stack as WordMaster, at the same proven dependency versions.

### Two decisions worth knowing about

**Words are keyed on their natural id.** `wordId` ("VRB-001") is the primary
key, not an auto-generated row id. Progress, recordings and quiz attempts all
point at that string. A content correction updates the word in place and the
learner's history follows it. WordMaster keyed on an auto-generated id with a
unique index on the word text, so re-importing a corrected word resolved as a
conflict, replaced the row, and cascade-deleted the progress. Using the natural
key removes that failure mode by construction rather than by carefulness.

**Every import is an upsert with per-row validation.** A row that fails
validation is skipped and reported by id; it does not abort the import. One bad
entry in a content update cannot cost the learner the other 999 words.

---

## The thing that has been deferred twice

"Login last means data loss first" has been flagged in this project since the
planning questionnaire and deferred twice. A learner now accumulates a streak,
badges, bookmarks, weak sounds, their own written sentences and their own voice —
all in one database, on one phone.

Phase 5's answer is the part that needs no server:

- **Every install gets an anonymous profile on first launch.** A random id, not
  derived from the device. It exists so a learner's work belongs to *something*
  from the first minute, and `signIn` later **attaches** an account to that
  existing profile rather than replacing it. Retrofitting identity onto data that
  never had any is the version that does not work.
- **Backup exports everything to one file** the learner puts wherever they like.
  Restore merges rather than overwrites, and every merge rule keeps whichever
  side represents more learning — see `domain/usecase/backup/BackupMerge.kt`, and
  the tests that pin each one.

Accounts and sync are specified in [docs/SERVER_CONTRACT.md](docs/SERVER_CONTRACT.md)
and not built. The file backup solves the new-phone problem today for anyone who
thinks to use it; accounts solve it for everyone else.

---

## Switching on pronunciation scoring

Scoring is off in a fresh checkout and **off is a supported state** — recording,
playback, the score card's absence and everything else behave sensibly. To turn
it on, put one of these in `local.properties` (gitignored) and rebuild:

```properties
SPEECH_PROXY_URL=https://api.yourdomain.com/v1/pronunciation   # production
# or, development only:
AZURE_SPEECH_KEY=your-key-here
AZURE_SPEECH_REGION=centralindia
```

**A key compiled into an APK can be extracted from it in minutes, and the quota it
unlocks is billed to whoever published the app.** The direct-to-Azure route exists
so the feature can be tested against real audio before a server exists; it must
not be the route a released build uses. The in-app daily cap is a courtesy to the
learner, not a security control — only a server can actually stop a bill running
away.

[docs/PRONUNCIATION_SCORING.md](docs/PRONUNCIATION_SCORING.md) has the full
picture: the audio format and why it is hand-rolled, what the proxy has to do
(it is small), how a raw score becomes something a learner reads, and why the
band thresholds are set lower than a native-speaker product would use.

---

## Updating the content

The content pipeline lives in `content/`:

```bash
cd content
python3 build_seed.py            # workbook -> app/src/main/assets/seed/*.json
python3 verify_project.py        # static checks before you build
```

`build_seed.py` reads the 1000-word rich flashcard workbook and emits the four
seed files. It invents nothing — every field is lifted from the workbook; the
only transformations are splitting delimited cells, parsing the A/B/C/D option
block, and separating `**marker**` emphasis from clean sentence text.

To ship corrected or extra content:

1. Update the workbook.
2. Re-run `build_seed.py`.
3. Bump `ContentSeeder.CONTENT_VERSION`.
4. Release.

On launch the app compares the bundled version with the version last imported on
that device and re-runs the import if it is carrying newer content. Because the
import is an upsert, this corrects and extends the library in place while leaving
every review record, bookmark, recording and streak untouched. Shipping content
is a normal app update with a bumped constant — no migration, no special casing.

`verify_project.py` is the stand-in for a compiler. Nothing here can build an
Android project — `dl.google.com`, `repo.maven.apache.org` and `repo1.maven.org`
are all blocked by this environment's egress policy, so there is no Kotlin
compiler to be had — so it runs ten static checks over the source instead:

| | |
|---|---|
| 1 | Seed JSON keys match the serializable DTO fields exactly |
| 2 | Every column named in a Room `@Query` exists on that table's entity |
| 3 | Braces, parens and brackets balance, per file |
| 4 | Entities and DAOs are registered on the database |
| 5 | Every `import com.speaksarthi.app.…` resolves to a real declaration |
| 6 | No fully-qualified app types in code |
| 7 | Every `viewModel::method` a screen binds exists on that view model |
| 8 | Composable arguments: every named one exists, every required one is passed |
| 9 | Every interface Hilt injects has a `@Binds` or `@Provides` |
| 10 | No unused imports |

Check 1 matters more than it looks: kotlinx.serialization is configured to ignore
unknown keys, so a renamed field would not throw — it would silently import blank
strings for every word. Checks 5 to 9 catch a renamed method, a moved composable
or a forgotten binding: the mistakes that read perfectly well and compile
nowhere. Run it before every build; it takes under a second.

**Every check has been proved by injecting the fault it is meant to catch** —
a renamed view-model method, a bogus composable argument, a deleted Hilt binding,
an unbalanced brace, an unused import. A check nobody has watched fail is a check
nobody should trust.

### What it still cannot see

Type errors, and anything about a library rather than this codebase: a wrong
method name on `BillingClient`, a Compose parameter that changed between
versions, a Room annotation the processor rejects. Those need a real build, and
they are the reason the first `./gradlew assembleDebug` will not be silent.

---

## What is deliberately not here yet

Phases are built one at a time, so the following are absent by design, not
oversight:

| | |
|---|---|
| A server endpoint holding the speech key | before any public release |
| Accounts, and cloud sync | contract written, not built |
| Human review of recordings | v2 — and the privacy policy changes with it |
| An analytics backend behind the event list | your privacy decision |
| A real feedback inbox in place of the placeholder address | before the beta |
| Hand-written lessons in place of the generated ones | when there is a teacher to write them |
| Accounts, cloud sync, billing, privacy policy, lessons | phase 5 |
| Human teacher review | v2 |

The schema already carries the columns those phases need — recordings, weak
sounds, daily stats, badges and the speech budget all exist — so none of them
requires a migration later.

### One thing the schema anticipates

`RecordingEntity.uploadedAt` is unused in v1, when recordings never leave the
device. It exists because human teacher review in v2 needs an upload path, and
adding a nullable column now costs nothing while adding it later costs a
migration. When that feature ships, the privacy policy has to change with it.

---

## Known limitations

- **No compiled APK is included.** This sandbox cannot reach `dl.google.com` or
  `repo.maven.apache.org`, so Gradle cannot resolve the Android plugin here and
  nothing was compiled. The code is statically checked (see
  `content/verify_project.py`) but has not been through a Kotlin compiler. Expect
  to fix a small number of first-build issues in Android Studio.
- **No illustrations yet, and they need a network when there are.** The card
  reserves a 4:3 frame and falls back to the word's `visualAssociation` text.
  Artwork is fetched on demand rather than bundled, so it is the one part of
  the app that does not work offline. See docs/ILLUSTRATIONS.md.
- **The launcher icon is a placeholder.** A speech bubble with a level bar, drawn
  as a vector. Replace it once the name and brand are settled.
- **Typography uses the platform default family.** Swapping in a brand face means
  changing `brandFamily` in `Type.kt` and adding the font files.
- **`observeDueCount()` captures "now" when the flow is created.** The home
  screen works around this by re-subscribing on resume (`OnResume`), which is
  right for a number that changes once a day; a screen added later that shows the
  due count must do the same.
- **Speech is the phone's own text-to-speech engine.** It is free, works offline
  and needs nothing hosted, but voice quality varies by device — and this is a
  pronunciation app, so that matters. It is behind the `SpeechPlayer` interface
  so pre-generated neural audio can replace it without touching a screen. On a
  phone with no English voice installed, listening practice says so plainly and
  everything else carries on working.
- **Billing has never run.** It cannot be tested anywhere without a Play Store, a
  signed build and a configured product. The code handles owned, pending,
  cancelled, already-owned, no-Play and no-product-configured; none of those paths
  has executed. Test a real purchase, and especially a **pending** one, before
  trusting any of it.
- **Three things need a real value before the beta.** The feedback screen sends
  to `feedback@example.com`, analytics is a logcat stub with no backend, and the
  speech key still needs a server. All three are one-line changes in one file
  each — they are marked, not forgotten.
- **The lessons are generated, not written.** Grouped by level then topic from the
  existing library. It gives the app a finishable path on day one; a course
  someone designed would be better, and `LessonPlanner` is where it would slot in.
- **Room's exported schemas are not in the repository**, because nothing has been
  built here. Build once and commit `app/schemas/` — it is the only record of
  what a released database looked like, and the migration tests need it.
- **The database is at version 2.** Phase 4 added `daily_stats.mistakesReviewed`
  with a real migration, so a phase-3 install upgrades without losing anything.
  There is no `fallbackToDestructiveMigration` anywhere: a missing migration
  crashes in testing rather than wiping in the wild.
- **Listening distractors are chosen by spelling and shape, not phonetics.**
  `ListeningRoundBuilder.confusability` scores shared letters, word length and
  syllable count. It is a decent proxy and the tests pin the behaviour that
  matters, but real phoneme distance over the IPA column would be better, and is
  worth doing if listening becomes a paid feature.
- **Scoring has not been run against real audio.** Every path is implemented and
  the response parser is tested against hand-written JSON in the service's own
  shape, including its failure shapes — but no clip has been through the live
  service from here, because there is no key and this sandbox cannot reach one.
  The band thresholds in particular are reasoned from how the service is known to
  treat Indian English; they want checking against twenty real recordings and
  adjusting.
- **The speech key must move to a server before release.** See above. The app is
  built for it — set one property and no other code changes.
- **Recordings are never cleaned up automatically.** `deleteAllRecordings()`
  exists and works, but nothing calls it yet; a learner who practises daily for a
  year accumulates a few hundred megabytes of WAV. The settings screen in phase 4
  is where that button belongs.
