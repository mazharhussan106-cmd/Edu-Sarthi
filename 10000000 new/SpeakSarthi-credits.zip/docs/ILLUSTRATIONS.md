# Illustrations

The card reserves space for a drawing on part 1. The artwork does not exist yet;
this is the brief for making it and the mechanics for adding it.

Nothing in the app needs to change when the images arrive. Every word already
carries its filename (`words.illustration`, e.g. `VRB-001.webp`), the card
already reserves the frame, and `IllustrationLoader` already knows how to
fetch and cache. Upload the files, point the app at the host, they appear.

---

## The file spec

| | |
|---|---|
| Format | WebP, quality 80 |
| Aspect ratio | **4 : 3 landscape** |
| Dimensions | **1200 × 900 px** |
| Target size | 45 KB or less per file |
| Filename | `<WordId>.webp` — exactly, case-sensitive |
| Examples | `VRB-001.webp`, `PHR-042.webp`, `ADJ-250.webp` |

The word IDs are in `app/src/main/assets/seed/words.json` under `wordId`, and in
the source workbook's "Word ID" column. There are 1,000 of them: VRB-001…250,
PHR-001…150, ADJ-001…250, ADV-001…090, NUM-001…080, PRN-001…050, PRP-001…070,
CNJ-001…060.

1200 × 900 covers a 3× phone screen at the card's frame size with room to spare.
WebP rather than PNG because it is roughly a third the size at the same quality,
and the audience is on budget Android phones with limited storage.

## Style brief

- **One consistent world.** The same line weight, the same flat-colour
  treatment, the same level of detail across all 1,000. A thousand images that
  each look fine alone but different from each other reads as cheaper than no
  images at all.
- **No recurring character.** This started out asking for one and the
  requirement was dropped on purpose. A generative model will hold a *style*
  across a large set but not a *character* — the face drifts, and by image 200
  it is visibly a different person. Objects and scenes carry the memory hook
  just as well and are achievable at this scale. If a mascot is ever wanted, it
  needs a human illustrator, not a bigger prompt.
- **Use the app palette.** Teal `#146A62`, ochre `#D98324`, ink `#0E2A33`,
  paper `#F2F5F4`. Warm accent colours are fine; avoid purple, which belongs to
  WordMaster.
- **Show the meaning, not the word.** The drawing is a memory hook. The
  `visualAssociation` field already describes one per word — "A lightbulb
  switching on above someone's head" for *understand* — and is a good starting
  point for whoever draws.
- **Leave breathing room at the edges.** The frame has rounded corners; keep
  anything essential away from the outer 5%.

## One thing to decide before drawing starts

**No text inside the illustrations.** The reference card's drawing has "I'll do
it TOMORROW" written on a sticky note. It is charming, and it causes three
problems:

1. It ignores the learner's font-size setting, so someone using large text gets
   everything scaled up except the words baked into the picture.
2. A screen reader cannot read it.
3. It cannot be translated if the app ever adds another interface language.

The recommendation is to carry that idea through pose and expression instead —
the slumped posture and the clock already say "putting it off" without a word of
copy. If a scene genuinely needs text, put it in the caption below the frame,
where it is real text the app controls.

---

## How the app gets them: on demand, never bundled

Decided: **nothing ships inside the APK.** The app downloads each drawing the
first time a learner reaches that word and keeps it on disk afterwards.

Bundling all 1,000 would add roughly 40 MB to the download, and most learners
will only ever see a few hundred words. On-demand means the install stays small
and nobody pays for artwork they never see.

### Hosting

Upload the files to any static host — a bucket, a CDN, a folder on your server —
so that each one is reachable at `<base URL>/<filename>`:

```
https://cdn.example.com/art/VRB-001.webp
https://cdn.example.com/art/PHR-042.webp
```

Then set the base URL once, via `AppPreferences.setIllustrationBaseUrl(...)`. It
is stored rather than hardcoded, so the host can move — or point at a staging
bucket during testing — without shipping a new build.

Requirements on the host: plain HTTPS GET, no auth, permissive CORS not needed
(this is a native app, not a browser). Long cache headers are fine but not
required; the app caches on disk itself and does not re-validate.

### Caching

Coil holds the downloaded files in `cacheDir/illustrations`, capped at **64 MB**
— comfortably more than the whole library at the target file size, so in practice
nothing is ever evicted, while still bounding what the app takes from a phone
that is short on space.

### Prefetching

While a learner is reading one card, the next five cards' drawings are already
being fetched (`IllustrationLoader.prefetch`). That is what stops on-demand from
feeling like waiting. Five, not fifty: every unnecessary fetch spends the
learner's mobile data on a word they may never reach.

---

## The trade this makes

**Illustrations are the one part of this app that needs a network.** Words,
chunks, exercises and spaced repetition all work entirely offline; the artwork
does not.

A learner studying on a train with no signal sees the reserved frame with its
text fallback. That is a degraded card, never a broken one, and the drawing
appears the next time they are online. Worth knowing, because "works offline" is
otherwise true of everything else in the app.

## Before any artwork exists

Which is the state today, and for a while yet.

A word with no artwork — or the whole library, when no host is configured —
renders the reserved frame with the word's `visualAssociation` text set inside
it, in the card's own type. The frame is the same size either way, so the layout
never shifts and a half-illustrated library does not look half-finished.

The library-status screen shows how much artwork this device has cached, and says
plainly when no host is configured yet.
