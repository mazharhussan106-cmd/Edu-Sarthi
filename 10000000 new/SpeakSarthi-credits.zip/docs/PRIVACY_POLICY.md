# Privacy policy — DRAFT

**This is a draft written against what the app actually does as of phase 5. It is
not legal advice, and it must be reviewed by someone qualified before it is
published.** Three things have to be filled in before it can go anywhere:

- `[COMPANY NAME]` and `[ADDRESS]` — the entity that is legally the data
  controller
- `[CONTACT EMAIL]` — a real inbox someone reads
- The **effective date**, and the app's final name

The Play Store will not accept a data-collecting app without a published policy
at a public URL, and the Data Safety form has to match this document. Where they
disagree, Google believes the form — so fill the form in from this, not from
memory.

---

## What this app is

[APP NAME] helps you learn spoken English. You study words, practise sentences
aloud, and — optionally — send a recording to be scored for pronunciation.

The short version of this policy: **almost everything stays on your phone.** The
only thing that ever leaves it is a voice recording you explicitly choose to have
scored, and only at the moment you tap to score it.

---

## What is stored on your device

All of this lives in the app's own private storage. It is not readable by other
apps, it is not sent anywhere, and it is deleted when you uninstall the app.

| What | Why |
|---|---|
| Which words you have studied, and when they are next due | So spaced repetition can schedule them |
| Your bookmarks, your level, your daily goal | Your settings |
| Sentences you write in the "write your own" exercise | Shown back to you at the next review |
| Your streak and daily counts | Statistics and badges |
| Your voice recordings | So you can play yourself back |
| Pronunciation scores and which sounds you find hard | The "sounds to work on" list |
| An anonymous identifier for this installation | See below |

### The anonymous identifier

On first launch the app generates a random identifier for this installation. It
is a random number. It is **not** derived from your device, your phone number,
your Google account or anything else about you, and it cannot be linked back to
you by us or by anyone else.

It exists so your progress belongs to something, which is what makes it possible
to back it up and restore it later.

---

## What leaves your device

### Voice recordings sent for pronunciation scoring

When — and only when — you tap **Score it** on a recording, that audio clip is
sent to a speech-analysis service to be scored for pronunciation. What comes back
is a set of numbers: how accurate each sound was, how fluently you spoke, and how
much of the sentence you said.

- The clip is sent for scoring and is not used to train anything.
- We do not keep a copy on our servers.
- Recording a clip does **not** send it. Only scoring does.
- You can use the entire app, including recording and playing yourself back,
  without ever sending anything.

> **[TO COMPLETE BEFORE PUBLISHING]** Name the processor here — for example
> "Microsoft Azure Cognitive Services (Speech)" — and link their terms. If audio
> is routed through your own server first, say so and say which country it is
> hosted in. Under India's DPDP Act you have to be able to answer "who processed
> my voice and where", and a policy that cannot is not one.

### Subscription payments

If you subscribe, the payment is handled entirely by Google Play. **We never see
your card, your UPI id, or your bank details.** Google tells the app only whether
a subscription is active.

### Crash and usage information

> **[TO COMPLETE BEFORE PUBLISHING]** As shipped, the app collects **no** analytics
> and contains **no** third-party analytics SDK — the code is written for one but
> nothing is connected. If you connect Firebase, Amplitude or anything similar,
> this section has to describe it honestly: what is collected, who gets it, and
> how to opt out. Do not ship an SDK and leave this paragraph as-is.

---

## What we never collect

- Your name, phone number or address — the app never asks
- Your contacts, photos, location, or any other app's data
- Anything at all, if you never tap "Score it"

The microphone permission is used only while you are recording, and only after
you have granted it. Notification permission is asked for only when you switch on
a reminder.

---

## Backups

The app can export everything it knows about your learning to a single file that
**you** choose where to put — your own Drive, a memory card, anywhere.

That file is yours. We never see it and it is never uploaded anywhere by the app.
Where you put it, and who can then read it, is up to you. It contains your
progress, your streak, your badges and the sentences you wrote; it does **not**
contain your voice recordings.

---

## Children

This app is not directed at children under 13, and we do not knowingly collect
anything from them. If you believe a child has used the app and sent recordings,
write to `[CONTACT EMAIL]` and we will delete what we can.

---

## Your choices, and how to exercise them

| You want to | How |
|---|---|
| Delete your recordings | Settings → Your recordings → Delete all recordings |
| Stop sending anything anywhere | Simply do not tap "Score it" — everything else works |
| Delete everything | Uninstall the app. All of it is on your device, so it goes with it |
| Take your progress elsewhere | Settings → Backup → Export |
| Ask what we hold about you | `[CONTACT EMAIL]` — though the honest answer is: nothing tied to you |

Because the app holds no account and no identifier that points at a person, there
is in practice nothing on our side to send you, correct or delete. That is by
design, not by omission.

---

## Changes to this policy

If what the app does changes, this changes with it, and the app will show you the
notice again rather than quietly updating it.

**Two changes are already planned and will require exactly that:**

1. **Accounts and cloud sync.** Your progress would then be stored on a server,
   tied to an account. This document currently says it never leaves your phone,
   and that would stop being true.
2. **Human review of recordings.** A planned paid tier would have a real teacher
   listen to a clip and reply. A person hearing your voice is a materially
   different thing from a service scoring it, and it needs its own explicit
   consent — not a paragraph added quietly to this one.

---

## Contact

`[COMPANY NAME]`
`[ADDRESS]`
`[CONTACT EMAIL]`

**Effective:** `[DATE]`

---

## Notes for whoever finalises this

**The Play Data Safety form.** Fill it in from what the app does, and re-check it
every time the answer changes. As shipped: audio is collected and transferred for
app functionality, not linked to identity, not used for tracking, and users can
request deletion. If analytics is connected later, the form changes.

**India's DPDP Act, 2023.** Voice is personal data. What it asks of you that this
draft already anticipates: a clear purpose stated before collection (the app
states it at the point of recording), no collection beyond that purpose, a named
grievance contact, and the ability to withdraw consent as easily as it was given
— which here means the app must keep working when someone stops scoring, and it
does.

**If you add a server.** The moment progress leaves the device, most of this
document is wrong. Rewrite it then, rather than appending to it — a privacy
policy with three years of appended paragraphs is one nobody can follow, including
you.
