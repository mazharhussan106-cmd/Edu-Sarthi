import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.serialization")
    id("com.google.dagger.hilt.android")
    id("com.google.devtools.ksp")
}

/**
 * Speech-service credentials, read from `local.properties` (gitignored) or the
 * environment so nothing secret is ever committed.
 *
 * All three are blank by default and blank is a fully supported state: the app
 * records and plays back normally and simply says scoring is not set up.
 *
 * SPEECH_PROXY_URL is the one to use in a released build. A key compiled into an
 * APK can be extracted from it in minutes, and the quota it unlocks is billed to
 * whoever shipped the app — so the key belongs on a small server endpoint that
 * checks who is asking and how much they have already used, with the app holding
 * only that endpoint's address. The direct-to-Azure path exists for development
 * and for testing against real audio before that endpoint is written.
 */
val speechProperties = Properties().apply {
    val file = rootProject.file("local.properties")
    if (file.exists()) file.inputStream().use { load(it) }
}

fun speechConfig(name: String): String =
    (speechProperties.getProperty(name) ?: System.getenv(name) ?: "").trim()

android {
    // NOTE: the app name is not final. Changing `namespace` and `applicationId`
    // is a safe find-and-replace up until the first Play Store upload; after
    // that the applicationId is permanent. Decide the name before publishing.
    namespace = "com.speaksarthi.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.speaksarthi.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"

        testInstrumentationRunner = "com.speaksarthi.app.HiltTestRunner"
        vectorDrawables { useSupportLibrary = true }

        buildConfigField("String", "SPEECH_PROXY_URL", "\"${speechConfig("SPEECH_PROXY_URL")}\"")
        buildConfigField("String", "AZURE_SPEECH_KEY", "\"${speechConfig("AZURE_SPEECH_KEY")}\"")
        buildConfigField("String", "AZURE_SPEECH_REGION", "\"${speechConfig("AZURE_SPEECH_REGION")}\"")
        buildConfigField("String", "GOOGLE_OAUTH_CLIENT_ID", "\"${speechConfig("GOOGLE_OAUTH_CLIENT_ID")}\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")

            // The Azure key is blanked in release builds, unconditionally.
            //
            // `buildConfigField` values become `public static final String`
            // constants in the APK. R8 does not encrypt them, so anyone with
            // jadx and four minutes can read a key out of a released build and
            // spend the owner's Azure quota until the bill is noticed.
            //
            // The direct-to-Azure route exists for development against real
            // audio before the Worker is deployed, and every document in this
            // project says it must not ship. This makes that structural rather
            // than a rule someone has to remember: there is no longer a code
            // path that puts the key in a release APK, so forgetting is not
            // possible. Release builds score through SPEECH_PROXY_URL, where
            // the key lives server-side.
            buildConfigField("String", "AZURE_SPEECH_KEY", "\"\"")
        }
        debug {
            isMinifyEnabled = false
            applicationIdSuffix = ".debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // minSdk is 24 and the app uses java.time for every date boundary
        // (streaks, the daily goal, the speech meter). Desugaring makes those
        // APIs available below API 26 rather than forcing Calendar arithmetic.
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    androidResources {
        // The seed JSON is already minified; letting aapt compress it in the APK
        // takes ~4.8 MB of assets down to roughly a megabyte on disk.
        noCompress += listOf()
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }

    testOptions {
        unitTests { isIncludeAndroidResources = true }
    }

    sourceSets {
        // Room's exported schema JSON is used by the migration tests.
        getByName("androidTest").assets.srcDir("$projectDir/schemas")
    }
}

ksp {
    // Export the schema so future migrations can be written and tested against
    // the real previous version rather than a remembered one.
    arg("room.schemaLocation", "$projectDir/schemas")
}


// A release build does not use these, and one of them is actively discarded
// above. Say so rather than letting someone wonder why their key had no effect.
if (gradle.startParameter.taskNames.any { it.contains("Release", ignoreCase = true) }) {
    if (speechConfig("AZURE_SPEECH_KEY").isNotBlank()) {
        logger.warn(
            "\nNOTE: AZURE_SPEECH_KEY is set but is deliberately blanked in release " +
                "builds, so it will not ship. Release builds score through " +
                "SPEECH_PROXY_URL.\n"
        )
    }
    if (speechConfig("SPEECH_PROXY_URL").isBlank()) {
        logger.warn(
            "\nWARNING: release build with no SPEECH_PROXY_URL. Pronunciation " +
                "scoring will be switched off in this build. Everything else works, " +
                "and the speaking screen says so plainly.\n"
        )
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.4")

    // Core / Lifecycle
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")

    // Compose
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3:1.2.1")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")

    // Room
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    ksp("androidx.room:room-compiler:2.6.1")

    // DataStore — settings, theme mode, daily goal, speech meter
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // Hilt
    implementation("com.google.dagger:hilt-android:2.51.1")
    ksp("com.google.dagger:hilt-android-compiler:2.51.1")
    implementation("androidx.hilt:hilt-navigation-compose:1.2.0")
    implementation("androidx.hilt:hilt-work:1.2.0")
    ksp("androidx.hilt:hilt-compiler:1.2.0")

    // WorkManager — daily reminders (max 3, per product spec)
    implementation("androidx.work:work-runtime-ktx:2.9.1")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Serialization — seed import, and the speech-assessment response
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.1")

    // HTTP — the pronunciation-scoring call. One POST, but it carries an audio
    // body over a metered mobile connection, so it wants real timeouts and a
    // connection pool rather than HttpURLConnection.
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // Image loading — illustrations are fetched on demand and cached on disk,
    // never bundled. Coil brings async loading, a disk cache we can size and
    // clear, and prefetching, which would otherwise all be hand-rolled.
    implementation("io.coil-kt:coil-compose:2.6.0")

    // Splash screen
    implementation("androidx.core:core-splashscreen:1.0.1")

    // Play Billing — the ₹249/month subscription. The only thing behind a
    // paywall is AI pronunciation scoring; everything else is free forever.
    implementation("com.android.billingclient:billing-ktx:7.0.0")

    // Google sign-in, via Credential Manager rather than the long-deprecated
    // GoogleSignInClient. Asked for only when credits run low — never at first
    // launch, because someone nervous about their English, told to make an
    // account before they have seen anything work, simply leaves.
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")

    // Testing
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    testImplementation("com.google.truth:truth:1.4.4")
    testImplementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.1")

    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation(platform("androidx.compose:compose-bom:2024.06.00"))
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    androidTestImplementation("androidx.room:room-testing:2.6.1")
    androidTestImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
    androidTestImplementation("com.google.truth:truth:1.4.4")
    androidTestImplementation("com.google.dagger:hilt-android-testing:2.51.1")
    kspAndroidTest("com.google.dagger:hilt-android-compiler:2.51.1")
}
