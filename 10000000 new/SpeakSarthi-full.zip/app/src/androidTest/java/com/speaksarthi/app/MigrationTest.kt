package com.speaksarthi.app

import androidx.room.Room
import androidx.room.testing.MigrationTestHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.data.local.Migrations
import com.speaksarthi.app.data.local.SpeakSarthiDatabase
import kotlinx.coroutines.runBlocking
import org.junit.Assume.assumeTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/**
 * The migration test.
 *
 * This project has already been bitten once by a schema change that took a
 * learner's review history with it, which is why the database is built without
 * `fallbackToDestructiveMigration` and why this exists. The assertion that
 * matters is not that the migration runs — it is that the rows written before it
 * are still there afterwards, with their values intact.
 *
 * **These tests skip if `app/schemas/1.json` is missing**, and on a fresh
 * checkout it is, because Room exports a schema only when the project is built
 * at that version and nothing here has been built at version 1. To produce it:
 * check out the phase-3 source, run `./gradlew assembleDebug`, and commit the
 * `app/schemas/1.json` it writes. Exported schemas belong in version control —
 * they are the only record of what a released database actually looked like.
 *
 * Skipping rather than failing is deliberate: a red test that nobody can make
 * green teaches the team to ignore red tests.
 */
@RunWith(AndroidJUnit4::class)
class MigrationTest {

    @get:Rule
    val helper = MigrationTestHelper(
        InstrumentationRegistry.getInstrumentation(),
        SpeakSarthiDatabase::class.java,
        emptyList(),
        FrameworkSQLiteOpenHelperFactory()
    )

    @Before
    fun requireVersionOneSchema() {
        val assets = InstrumentationRegistry.getInstrumentation().context.assets
        val present = runCatching { assets.list("")?.contains(SCHEMA_DIR) == true }.getOrDefault(false)
        val hasVersionOne = present &&
            runCatching { assets.list(SCHEMA_DIR)?.contains(SCHEMA_V1) == true }.getOrDefault(false)

        assumeTrue(
            "No exported schema for version 1 — build the previous release once and " +
                "commit app/schemas/1.json. See this file's comment.",
            hasVersionOne
        )
    }

    @Test
    fun migrate1To2KeepsExistingDailyStats() {
        helper.createDatabase(TEST_DB, 1).apply {
            execSQL(
                """
                INSERT INTO daily_stats
                    (date, wordsStudied, chunksStudied, quizzesAnswered, quizzesCorrect,
                     recordingsMade, secondsGraded, studySeconds)
                VALUES ('2026-09-15', 12, 40, 5, 4, 2, 18, 600)
                """.trimIndent()
            )
            close()
        }

        val migrated = helper.runMigrationsAndValidate(TEST_DB, 2, true, Migrations.MIGRATION_1_2)

        migrated.query("SELECT * FROM daily_stats WHERE date = '2026-09-15'").use { cursor ->
            assertThat(cursor.moveToFirst()).isTrue()
            assertThat(cursor.getInt(cursor.getColumnIndexOrThrow("wordsStudied"))).isEqualTo(12)
            assertThat(cursor.getInt(cursor.getColumnIndexOrThrow("secondsGraded"))).isEqualTo(18)
            // The new column exists and defaults to zero for rows written before it.
            assertThat(cursor.getInt(cursor.getColumnIndexOrThrow("mistakesReviewed"))).isEqualTo(0)
        }
        migrated.close()
    }

    @Test
    fun migrate1To2KeepsLearnerProgress() {
        helper.createDatabase(TEST_DB, 1).apply {
            execSQL(
                """
                INSERT INTO progress
                    (wordId, easeFactor, intervalDays, repetitions, nextReviewAt,
                     lastReviewedAt, timesSeen, timesCorrect, isBookmarked, isKnown)
                VALUES ('VRB-001', 2.6, 15, 4, 1800000000000, 1700000000000, 9, 8, 1, 1)
                """.trimIndent()
            )
            close()
        }

        val migrated = helper.runMigrationsAndValidate(TEST_DB, 2, true, Migrations.MIGRATION_1_2)

        migrated.query("SELECT * FROM progress WHERE wordId = 'VRB-001'").use { cursor ->
            assertThat(cursor.moveToFirst()).isTrue()
            assertThat(cursor.getInt(cursor.getColumnIndexOrThrow("repetitions"))).isEqualTo(4)
            assertThat(cursor.getInt(cursor.getColumnIndexOrThrow("timesCorrect"))).isEqualTo(8)
            assertThat(cursor.getInt(cursor.getColumnIndexOrThrow("isKnown"))).isEqualTo(1)
        }
        migrated.close()
    }

    /**
     * Opens the migrated file through Room itself.
     *
     * `runMigrationsAndValidate` checks the schema; this checks that the real
     * database class can then use it, which is a different thing and the one the
     * learner actually experiences.
     */
    @Test
    fun theMigratedDatabaseOpensAndReads() {
        helper.createDatabase(TEST_DB, 1).close()
        helper.runMigrationsAndValidate(TEST_DB, 2, true, Migrations.MIGRATION_1_2).close()

        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val database = Room.databaseBuilder(context, SpeakSarthiDatabase::class.java, TEST_DB)
            .addMigrations(*Migrations.ALL)
            .build()

        runBlocking {
            database.dailyStatDao().increment(date = "2026-09-16", words = 1, mistakesReviewed = 1)
            val row = database.dailyStatDao().forDate("2026-09-16")

            assertThat(row).isNotNull()
            assertThat(row!!.mistakesReviewed).isEqualTo(1)
        }
        database.close()
    }

    private companion object {
        const val TEST_DB = "migration_test.db"

        /** Where the gradle `androidTest` sourceSet maps the exported schemas to. */
        const val SCHEMA_DIR = "com.speaksarthi.app.SpeakSarthiDatabase"
        const val SCHEMA_V1 = "1.json"
    }
}
