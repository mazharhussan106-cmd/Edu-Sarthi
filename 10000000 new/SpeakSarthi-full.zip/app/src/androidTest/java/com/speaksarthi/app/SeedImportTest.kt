package com.speaksarthi.app

import androidx.room.Room
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.data.local.SpeakSarthiDatabase
import com.speaksarthi.app.data.local.converter.Converters
import com.speaksarthi.app.data.local.entity.ProgressEntity
import com.speaksarthi.app.data.seed.SeedImporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Runs the real importer against the real bundled assets and a real (in-memory)
 * Room database.
 *
 * The last test here is the one that matters most. WordMaster shipped an
 * importer that wiped every learner's spaced-repetition history whenever content
 * was re-imported, because the word row was deleted and re-inserted and the
 * progress row cascaded away with it. That bug was found by reading the schema,
 * not by running anything — so this project gets a test that would have caught
 * it, and it runs on every build.
 */
@RunWith(AndroidJUnit4::class)
class SeedImportTest {

    private lateinit var database: SpeakSarthiDatabase
    private lateinit var importer: SeedImporter

    @Before
    fun setUp() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        database = Room.inMemoryDatabaseBuilder(context, SpeakSarthiDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        importer = SeedImporter(context, database.contentDao(), Dispatchers.IO)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun importsTheWholeBundledLibraryWithoutWarnings() = runTest {
        val report = importer.importBundledSeed()

        assertThat(report.isSuccess).isTrue()
        assertThat(report.wordsImported).isEqualTo(1000)
        assertThat(report.chunksImported).isGreaterThan(5000)
        assertThat(report.practiceItemsImported).isGreaterThan(5000)
        assertThat(report.questionsImported).isEqualTo(1000)
        assertThat(report.warnings).isEmpty()
    }

    @Test
    fun everyWordCarriesTheFieldsTheCardNeeds() = runTest {
        importer.importBundledSeed()
        val dao = database.contentDao()

        val word = dao.wordById("VRB-001")
        assertThat(word).isNotNull()
        requireNotNull(word)

        // Part one of the card — recognition.
        assertThat(word.word).isNotEmpty()
        assertThat(word.ipa).isNotEmpty()
        assertThat(word.syllableBreak).isNotEmpty()
        assertThat(word.hindiPronunciation).isNotEmpty()
        assertThat(word.partOfSpeech).isNotEmpty()
        assertThat(word.etymology).isNotEmpty()
        assertThat(word.level).isIn(listOf("A1", "A2", "B1", "B2"))

        // Part two — understanding and usage.
        assertThat(word.hindiMeaning).isNotEmpty()
        assertThat(word.simpleMeaning).isNotEmpty()
        assertThat(word.plainExplanation).isNotEmpty()
        assertThat(word.commonMistakeWrong).isNotEmpty()
        assertThat(word.commonMistakeCorrect).isNotEmpty()
        assertThat(word.miniConversation).isNotEmpty()

        // Part three — chunks and the practice zone.
        assertThat(dao.chunksForWord("VRB-001")).isNotEmpty()
        assertThat(dao.practiceItemsForWord("VRB-001")).isNotEmpty()
        assertThat(dao.exerciseForWord("VRB-001")).isNotNull()
    }

    @Test
    fun everyLevelHasWords() = runTest {
        importer.importBundledSeed()

        val counts = database.contentDao().countsByLevel().associate { it.level to it.total }
        assertThat(counts.keys).containsAtLeast("A1", "A2", "B1")
        counts.values.forEach { assertThat(it).isGreaterThan(0) }
        assertThat(counts.values.sum()).isEqualTo(1000)
    }

    @Test
    fun multipleChoiceAnswersAlwaysPointAtARealOption() = runTest {
        importer.importBundledSeed()

        val exercises = database.contentDao().randomExercises(limit = 1000)
        assertThat(exercises).isNotEmpty()
        exercises.forEach { exercise ->
            val options = exercise.mcqOptions
                .split(Converters.DELIMITER)
                .filter { it.isNotBlank() }
            assertThat(options.size).isAtLeast(2)
            assertThat(exercise.mcqAnswerIndex).isAtLeast(0)
            assertThat(exercise.mcqAnswerIndex).isLessThan(options.size)
        }
    }

    /**
     * Part three of the card is the practice zone, and the reference card shows
     * five exercises there. A word that imported only its multiple choice would
     * render a half-empty page, so the whole set is checked rather than assumed.
     */
    @Test
    fun everyWordCarriesAllFivePracticeZoneExercises() = runTest {
        importer.importBundledSeed()

        val exercises = database.contentDao().randomExercises(limit = 1000)
        assertThat(exercises).hasSize(1000)
        exercises.forEach { exercise ->
            assertThat(exercise.mcqQuestion).isNotEmpty()
            assertThat(exercise.fillBlankPrompt).isNotEmpty()
            assertThat(exercise.fillBlankAnswer).isNotEmpty()
            assertThat(exercise.findFixWrong).isNotEmpty()
            assertThat(exercise.findFixCorrected).isNotEmpty()
            assertThat(exercise.translatePrompt).isNotEmpty()
            assertThat(exercise.translateAnswer).isNotEmpty()
            assertThat(exercise.writeYourOwnPrompt).isNotEmpty()
        }
    }

    @Test
    fun theDueQueueStartsFullBecauseNothingHasBeenStudied() = runTest {
        importer.importBundledSeed()

        val queue = database.contentDao().dueQueue(now = System.currentTimeMillis(), limit = 20)
        assertThat(queue).hasSize(20)
        // No progress rows exist yet, so every entry is a brand-new word.
        queue.forEach { assertThat(it.progress).isNull() }
    }

    /**
     * The regression test for WordMaster's data-loss bug.
     */
    @Test
    fun reimportingContentLeavesLearnerProgressUntouched() = runTest {
        importer.importBundledSeed()

        val progressDao = database.progressDao()
        val studied = ProgressEntity(
            wordId = "VRB-001",
            easeFactor = 2.36,
            intervalDays = 15,
            repetitions = 4,
            nextReviewAt = 1_900_000_000_000L,
            lastReviewedAt = 1_800_000_000_000L,
            timesSeen = 7,
            timesCorrect = 6,
            isBookmarked = true,
            isKnown = true
        )
        progressDao.upsert(studied)

        // Simulate a content update: the same import runs again, as it would
        // after the learner installs a version with corrected words.
        val second = importer.importBundledSeed()
        assertThat(second.wordsImported).isEqualTo(1000)

        val after = progressDao.byWordId("VRB-001")
        assertThat(after).isEqualTo(studied)

        // And the word itself is still there exactly once — updated in place,
        // not deleted and re-inserted.
        assertThat(database.contentDao().wordCount()).isEqualTo(1000)
        assertThat(database.contentDao().wordById("VRB-001")).isNotNull()
    }
}
