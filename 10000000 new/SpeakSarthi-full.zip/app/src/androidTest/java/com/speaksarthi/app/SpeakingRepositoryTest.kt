package com.speaksarthi.app

import androidx.room.Room
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.data.audio.WavFile
import com.speaksarthi.app.data.local.SpeakSarthiDatabase
import com.speaksarthi.app.data.repository.SpeakingRepositoryImpl
import com.speaksarthi.app.data.speech.PronunciationScorer
import com.speaksarthi.app.domain.model.PhonemeScore
import com.speaksarthi.app.domain.model.PracticeItem
import com.speaksarthi.app.domain.model.PracticeType
import com.speaksarthi.app.domain.model.PronunciationReport
import com.speaksarthi.app.domain.model.CreditBalance
import com.speaksarthi.app.domain.model.EarnKind
import com.speaksarthi.app.domain.model.LinkOutcome
import com.speaksarthi.app.domain.model.RedeemOutcome
import com.speaksarthi.app.domain.model.ScoringOutcome
import com.speaksarthi.app.domain.repository.CreditsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import com.speaksarthi.app.domain.model.SpokenWordScore
import com.speaksarthi.app.util.FakeClock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.time.LocalDate

/**
 * The speaking repository against a real Room database and a fake scorer.
 *
 * The first three tests are the ones that matter. Scoring is the only thing in
 * this app that costs money per use, and the daily cap is the only thing
 * standing between a few heavy free users and a bill bigger than the revenue.
 * "The budget check is in there somewhere" is not good enough, so the fake
 * scorer counts how many times it was actually called.
 */
@RunWith(AndroidJUnit4::class)
class SpeakingRepositoryTest {

    /** Records whether it was called, so an over-budget clip can be proved unsent. */
    /**
     * A credits repository that only ever reports what it is told.
     *
     * Modelled on the real one in the single respect that matters: there is no
     * way to raise the balance from inside the app. The only mutator is
     * [recordServerBalance], which is what the server saying a number looks like.
     */
    private class FakeCredits(
        var configured: Boolean = true,
        var credits: Int = 50
    ) : CreditsRepository {
        var recordedBalances = mutableListOf<Int>()
            private set

        override fun isConfigured(): Boolean = configured

        override fun observeBalance(): Flow<CreditBalance> = flowOf(snapshot())

        override suspend fun balance(): CreditBalance = snapshot()

        override suspend fun refresh(): CreditBalance = snapshot()

        override suspend fun recordServerBalance(credits: Int) {
            recordedBalances += credits
            this.credits = credits
        }

        override suspend fun redeem(productId: String, purchaseToken: String) =
            RedeemOutcome.Failed("not used in this test")

        override suspend fun claimEarned(kind: EarnKind, reference: String) = Unit

        override suspend fun linkGoogleAccount(idToken: String) =
            LinkOutcome.Failed("not used in this test")

        private fun snapshot() = CreditBalance(
            credits = credits,
            source = if (configured) {
                CreditBalance.Source.Server
            } else {
                CreditBalance.Source.NotConfigured
            },
            checkedAt = 1L
        )
    }

    private class FakeScorer(
        var configured: Boolean = true,
        var outcome: ScoringOutcome = ScoringOutcome.Scored(sampleReport())
    ) : PronunciationScorer {
        var callCount = 0
            private set

        override fun isConfigured(): Boolean = configured

        override suspend fun score(audio: File, referenceText: String): ScoringOutcome {
            callCount++
            return outcome
        }
    }

    private lateinit var database: SpeakSarthiDatabase
    private lateinit var repository: SpeakingRepositoryImpl
    private lateinit var scorer: FakeScorer
    private lateinit var credits: FakeCredits
    private lateinit var clock: FakeClock

    private val prompt = PracticeItem(
        itemId = "VRB-001-1",
        wordId = "VRB-001",
        text = "I drink water every morning.",
        highlight = "drink",
        type = PracticeType.EXAMPLE,
        orderIndex = 0
    )

    @Before
    fun setUp() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext

        database = Room.inMemoryDatabaseBuilder(context, SpeakSarthiDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        clock = FakeClock(now = 1_700_000_000_000, date = LocalDate.of(2026, 9, 15))
        scorer = FakeScorer()
        credits = FakeCredits()

        repository = SpeakingRepositoryImpl(
            context = context,
            contentDao = database.contentDao(),
            recordingDao = database.recordingDao(),
            weakSoundDao = database.weakSoundDao(),
            dailyStatDao = database.dailyStatDao(),
            scorer = scorer,
            credits = credits,
            clock = clock,
            ioDispatcher = Dispatchers.IO
        )
    }

    @After
    fun tearDown() {
        database.close()
        repository.recordingDirectory().listFiles()?.forEach { it.delete() }
    }

    /** A one-second WAV of silence — enough to be a real file with a real length. */
    private fun clip(seconds: Int = 1): File {
        val file = repository.newRecordingFile("VRB-001")
        WavFile.writePlaceholderHeader(file)
        file.appendBytes(ByteArray(WavFile.bytesPerSecond() * seconds))
        WavFile.finalise(file)
        return file
    }

    // ---- the credit gate ---------------------------------------------------
    //
    // These cover the app's side only. The real gate is on the server, which
    // reserves a credit before calling the speech service and refunds it if that
    // call fails — a rooted device can defeat everything below and still not get
    // a free score. What is tested here is that the app does not waste a request
    // it already knows will be refused, and that it believes the server when the
    // two disagree.

    @Test
    fun aClipIsSentWhenThereAreCreditsToSpend() = runTest {
        credits.credits = 50

        val outcome = repository.scoreAndStore(clip(), "VRB-001", prompt, 1_000)

        assertThat(outcome).isInstanceOf(ScoringOutcome.Scored::class.java)
        assertThat(scorer.callCount).isEqualTo(1)
    }

    @Test
    fun anEmptyBalanceSkipsTheRequestEntirely() = runTest {
        credits.credits = 0

        val outcome = repository.scoreAndStore(clip(), "VRB-001", prompt, 1_000)

        assertThat(outcome).isInstanceOf(ScoringOutcome.NoCredits::class.java)
        // Not a security property — a courtesy. The server would have refused
        // it anyway; this saves a pointless round trip on a bad connection.
        assertThat(scorer.callCount).isEqualTo(0)
    }

    @Test
    fun aClipIsStillSavedWhenThereAreNoCreditsForIt() = runTest {
        credits.credits = 0

        repository.scoreAndStore(clip(), "VRB-001", prompt, 1_000)

        // The learner did the work and can hear themselves back. Taking the
        // recording away too would punish them for being broke.
        val stored = repository.observeRecordings("VRB-001").first()
        assertThat(stored).hasSize(1)
        assertThat(stored.single().isScored).isFalse()
    }

    @Test
    fun theBalanceFromAScoreResponseIsKept() = runTest {
        credits.credits = 50
        scorer.outcome = ScoringOutcome.Scored(sampleReport(), creditsRemaining = 49)

        repository.scoreAndStore(clip(), "VRB-001", prompt, 1_000)

        // Carried on the response, so nothing has to go and ask for it.
        assertThat(credits.recordedBalances).containsExactly(49)
    }

    @Test
    fun theServerIsBelievedWhenItSaysTheCachedBalanceIsWrong() = runTest {
        // The cache says there is credit; the server says there is not. This is
        // what a second device spending the last credit looks like.
        credits.credits = 5
        scorer.outcome = ScoringOutcome.NoCredits(balance = 0)

        val outcome = repository.scoreAndStore(clip(), "VRB-001", prompt, 1_000)

        assertThat(outcome).isInstanceOf(ScoringOutcome.NoCredits::class.java)
        assertThat(credits.recordedBalances).containsExactly(0)
        assertThat(credits.credits).isEqualTo(0)
    }

    @Test
    fun aFailedCallLeavesTheCachedBalanceAlone() = runTest {
        credits.credits = 30
        scorer.outcome = ScoringOutcome.Offline

        repository.scoreAndStore(clip(5), "VRB-001", prompt, 5_000)

        // The server refunds its own reservation; the app must not guess at a
        // new number in the meantime.
        assertThat(credits.recordedBalances).isEmpty()
        assertThat(credits.credits).isEqualTo(30)
    }

    @Test
    fun scoringIsAttemptedWhenThereIsNoServerToMeterAgainst() = runTest {
        // The direct-Azure development route. Unmetered on purpose, and the app
        // must not refuse to score just because it has no balance to consult.
        credits.configured = false
        credits.credits = 0

        val outcome = repository.scoreAndStore(clip(), "VRB-001", prompt, 1_000)

        assertThat(outcome).isInstanceOf(ScoringOutcome.Scored::class.java)
        assertThat(scorer.callCount).isEqualTo(1)
    }

    // ---- what gets stored --------------------------------------------------

    @Test
    fun aScoredClipKeepsTheRawServiceNumbers() = runTest {
        repository.scoreAndStore(clip(), "VRB-001", prompt, 1_000)

        val stored = repository.observeRecordings("VRB-001").first().single()
        assertThat(stored.isScored).isTrue()
        assertThat(stored.accuracy).isWithin(0.01f).of(62f)
        assertThat(stored.fluency).isWithin(0.01f).of(70f)
        assertThat(stored.overall).isWithin(0.01f).of(64f)
        // The weak phonemes survive the delimited round trip.
        assertThat(stored.weakPhonemes).containsExactly("v")
    }

    @Test
    fun scoringAClipCountsTowardsTodaysActivity() = runTest {
        repository.scoreAndStore(clip(3), "VRB-001", prompt, 3_000)

        val today = database.dailyStatDao().forDate("2026-09-15")
        assertThat(today).isNotNull()
        assertThat(today!!.recordingsMade).isEqualTo(1)
        assertThat(today.secondsGraded).isEqualTo(3)
    }

    @Test
    fun anUnscoredClipCountsAsPracticeButCostsNoSeconds() = runTest {
        repository.storeUnscored(clip(3), "VRB-001", prompt, 3_000)

        val today = database.dailyStatDao().forDate("2026-09-15")
        assertThat(today!!.recordingsMade).isEqualTo(1)
        assertThat(today.secondsGraded).isEqualTo(0)
    }

    // ---- weak sounds -------------------------------------------------------

    @Test
    fun weakPhonemesAreTalliedWithTheirAttemptCounts() = runTest {
        repository.scoreAndStore(clip(), "VRB-001", prompt, 1_000)

        val sounds = repository.observeWeakSounds(limit = 10).first().associateBy { it.phoneme }
        // "v" was weak once out of one attempt; "d" was fine once out of one.
        assertThat(sounds["v"]!!.errorCount).isEqualTo(1)
        assertThat(sounds["v"]!!.attemptCount).isEqualTo(1)
        // A sound that was fine still records the attempt, which is what makes the
        // list rank by rate rather than by how common the sound is in English.
        assertThat(database.weakSoundDao().byPhoneme("d")!!.attemptCount).isEqualTo(1)
        assertThat(database.weakSoundDao().byPhoneme("d")!!.errorCount).isEqualTo(0)
    }

    @Test
    fun tallesAccumulateAcrossRecordings() = runTest {
        repository.scoreAndStore(clip(), "VRB-001", prompt, 1_000)
        repository.scoreAndStore(clip(), "VRB-001", prompt, 1_000)

        val v = database.weakSoundDao().byPhoneme("v")
        assertThat(v!!.errorCount).isEqualTo(2)
        assertThat(v.attemptCount).isEqualTo(2)
    }

    @Test
    fun anUnscoredClipAddsNothingToTheWeakSounds() = runTest {
        repository.storeUnscored(clip(), "VRB-001", prompt, 1_000)

        assertThat(repository.observeWeakSounds(limit = 10).first()).isEmpty()
    }

    // ---- housekeeping ------------------------------------------------------

    @Test
    fun recordingFilesGoInPrivateStorageAndDoNotCollide() = runTest {
        val first = repository.newRecordingFile("VRB-001")
        clock.now += 5
        val second = repository.newRecordingFile("VRB-001")

        assertThat(first.absolutePath).isNotEqualTo(second.absolutePath)
        assertThat(first.parentFile!!.absolutePath).isEqualTo(
            repository.recordingDirectory().absolutePath
        )
    }

    @Test
    fun clearingRecordingsDeletesBothTheRowsAndTheFiles() = runTest {
        val file = clip()
        repository.scoreAndStore(file, "VRB-001", prompt, 1_000)
        assertThat(file.exists()).isTrue()

        repository.deleteAllRecordings()

        assertThat(repository.observeRecordings("VRB-001").first()).isEmpty()
        assertThat(file.exists()).isFalse()
    }

    @Test
    fun scoringConfigurationIsReportedFromTheScorer() {
        scorer.configured = false
        assertThat(repository.scoringIsConfigured()).isFalse()

        scorer.configured = true
        assertThat(repository.scoringIsConfigured()).isTrue()
    }

    private companion object {
        /**
         * A report with one clearly weak sound in it: the /v/ in "very", which is
         * the canonical Hindi-speaker difficulty and therefore the useful case to
         * test the tally and the fix-picking against.
         */
        fun sampleReport() = PronunciationReport(
            referenceText = "I drink water every morning.",
            accuracy = 62f,
            fluency = 70f,
            completeness = 100f,
            overall = 64f,
            recognisedText = "I drink water every morning.",
            words = listOf(
                SpokenWordScore(
                    word = "very",
                    accuracy = 38f,
                    errorType = "Mispronunciation",
                    phonemes = listOf(PhonemeScore("v", 25f))
                ),
                SpokenWordScore(
                    word = "drink",
                    accuracy = 91f,
                    errorType = "None",
                    phonemes = listOf(PhonemeScore("d", 93f))
                )
            )
        )
    }
}
