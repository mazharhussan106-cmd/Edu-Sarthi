package com.speaksarthi.app

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

/**
 * Application entry point.
 *
 * Deliberately does no work here beyond wiring: seeding the library is kicked
 * off from the first screen, where its progress can actually be shown to the
 * learner, rather than silently blocking startup.
 */
@HiltAndroidApp
class SpeakSarthiApplication : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()
}
