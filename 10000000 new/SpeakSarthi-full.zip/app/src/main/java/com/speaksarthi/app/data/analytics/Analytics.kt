package com.speaksarthi.app.data.analytics

import android.util.Log
import com.speaksarthi.app.BuildConfig
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The events worth watching from day one.
 *
 * A closed list rather than free-form strings, so the set of things being
 * measured can be read in one place — by whoever writes the privacy policy as
 * much as by whoever reads the dashboard.
 *
 * What is deliberately **not** here: anything identifying, anything the learner
 * typed, any word they got wrong, any recording, any score. The questions this
 * is meant to answer are "do people come back" and "which parts do they use",
 * and neither needs to know who anyone is.
 */
enum class AnalyticsEvent(val key: String) {
    AppOpened("app_opened"),
    OnboardingCompleted("onboarding_completed"),
    OnboardingSkipped("onboarding_skipped"),
    StudySessionStarted("study_session_started"),
    StudySessionFinished("study_session_finished"),
    ListeningRoundFinished("listening_round_finished"),
    RecordingMade("recording_made"),
    RecordingScored("recording_scored"),
    ScoringBlockedByBudget("scoring_blocked_by_budget"),
    MistakeReviewStarted("mistake_review_started"),
    SearchUsed("search_used"),
    ReminderSet("reminder_set"),
    ReminderOpened("reminder_opened"),
    BadgeEarned("badge_earned"),
    FeedbackSent("feedback_sent"),
    PaywallViewed("paywall_viewed"),
    PackPurchaseStarted("pack_purchase_started"),
    PackPurchased("pack_purchased"),
    PurchasesRestored("purchases_restored"),
    SignedIn("signed_in"),
    BackupExported("backup_exported"),
    BackupRestored("backup_restored")
}

/**
 * Analytics, behind an interface, with **nothing wired to it**.
 *
 * That is a deliberate choice, not an omission. Adding Firebase or Amplitude
 * means adding a third-party SDK that phones home from every install, and that
 * decision belongs to whoever owns this product and its privacy policy — not to
 * whoever wrote the screens. The call sites exist so that decision is one file
 * of work rather than a search through twenty.
 *
 * Until then, [LoggingAnalytics] prints to logcat in debug builds and does
 * nothing at all in release, which is honest about what is being collected:
 * nothing.
 *
 * The two numbers the product plan actually cares about — daily active users and
 * 30-day retention — are both derivable from [AnalyticsEvent.AppOpened] alone,
 * so a minimal implementation is a complete one for now.
 */
interface Analytics {
    fun track(event: AnalyticsEvent, properties: Map<String, Any?> = emptyMap())
}

@Singleton
class LoggingAnalytics @Inject constructor() : Analytics {

    override fun track(event: AnalyticsEvent, properties: Map<String, Any?>) {
        if (!BuildConfig.DEBUG) return

        val detail = if (properties.isEmpty()) {
            ""
        } else {
            properties.entries.joinToString(prefix = " ", separator = " ") { "${it.key}=${it.value}" }
        }
        Log.d(TAG, "${event.key}$detail")
    }

    private companion object {
        const val TAG = "SarthiAnalytics"
    }
}
