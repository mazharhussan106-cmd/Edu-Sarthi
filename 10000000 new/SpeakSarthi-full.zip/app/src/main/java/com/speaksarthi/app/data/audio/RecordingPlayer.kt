package com.speaksarthi.app.data.audio

import android.media.MediaPlayer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Plays back a clip the learner just recorded.
 *
 * Separate from [SpeechPlayer], which speaks text through the TTS engine. This
 * one plays a file, and it exists because hearing your own voice back is where
 * most of the learning in this feature actually happens: a score tells you that
 * something was wrong, hearing yourself immediately after the model
 * pronunciation tells you *what*.
 */
interface RecordingPlayer {
    val isPlaying: StateFlow<Boolean>

    fun play(file: File)

    fun stop()

    fun release()
}

@Singleton
class MediaRecordingPlayer @Inject constructor() : RecordingPlayer {

    private val _isPlaying = MutableStateFlow(false)
    override val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private var player: MediaPlayer? = null

    override fun play(file: File) {
        stop()
        if (!file.exists() || file.length() <= WavFile.HEADER_BYTES) return

        // Built into a local and assigned only once it is playing. Assigning the
        // field first and configuring it afterwards leaves a window where the
        // error callback nulls the field and the assignment then puts a released
        // player straight back into it.
        val fresh = MediaPlayer()
        player = fresh
        try {
            fresh.setDataSource(file.absolutePath)
            fresh.setOnCompletionListener { finished ->
                if (player === finished) {
                    _isPlaying.value = false
                    releasePlayer()
                }
            }
            fresh.setOnErrorListener { failed, _, _ ->
                if (player === failed) {
                    _isPlaying.value = false
                    releasePlayer()
                }
                true
            }
            fresh.prepare()
            fresh.start()
            _isPlaying.value = true
        } catch (error: Exception) {
            // A clip that will not play is not worth an error dialog — the
            // learner can simply record again.
            _isPlaying.value = false
            releasePlayer()
        }
    }

    override fun stop() {
        val current = player ?: return
        try {
            if (current.isPlaying) current.stop()
        } catch (error: IllegalStateException) {
            // Already stopped.
        }
        _isPlaying.value = false
        releasePlayer()
    }

    override fun release() = stop()

    private fun releasePlayer() {
        player?.release()
        player = null
    }
}
