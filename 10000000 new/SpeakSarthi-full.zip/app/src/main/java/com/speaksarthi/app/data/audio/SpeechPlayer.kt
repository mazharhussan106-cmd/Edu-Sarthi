package com.speaksarthi.app.data.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Says an English word or sentence out loud.
 *
 * Behind an interface on purpose. The implementation today is the phone's own
 * text-to-speech engine, which is free, works offline once a voice is installed,
 * and needs no audio files hosted or bundled — the same reasoning that kept the
 * illustrations out of the APK applies twice over to 2,000 audio clips.
 *
 * The cost is that voice quality varies by device, and this is a pronunciation
 * app, so that matters. If on-device speech proves too rough on cheap phones,
 * pre-generated neural audio can be swapped in behind this interface without
 * touching a single screen.
 */
interface SpeechPlayer {

    /** Whether speech is usable at all on this device. */
    val state: StateFlow<SpeechState>

    /**
     * Speaks [text], interrupting anything already playing.
     *
     * @param rate 0.5 = half speed, 1.0 = normal. Learners working on a hard
     *   word slow it down, which is why the setting exists at all.
     */
    fun speak(text: String, rate: Float = 1.0f)

    fun stop()

    /** Releases the engine. Called when the app is done with it. */
    fun release()

    companion object {
        const val RATE_MIN = 0.5f
        const val RATE_MAX = 1.5f

        /**
         * The speeds the app actually asks for. Slow is for a word being drilled
         * and is the single most-used control in listening practice.
         */
        const val RATE_SLOW = 0.6f
        const val RATE_NORMAL = 1.0f
        const val RATE_FAST = 1.25f
    }
}

sealed interface SpeechState {
    /** Engine still starting up. Speaker buttons should be disabled, not hidden. */
    data object Initialising : SpeechState

    data object Ready : SpeechState

    /** Currently speaking — used to show which speaker button is active. */
    data object Speaking : SpeechState

    /**
     * Speech is not available: no engine, or no English voice installed.
     * The card must still work; only the speaker buttons go away.
     */
    data class Unavailable(val reason: String) : SpeechState
}

@Singleton
class AndroidTtsPlayer @Inject constructor(
    @ApplicationContext private val context: Context
) : SpeechPlayer {

    private val _state = MutableStateFlow<SpeechState>(SpeechState.Initialising)
    override val state: StateFlow<SpeechState> = _state.asStateFlow()

    private var engine: TextToSpeech? = null
    private var currentRate: Float = 1.0f

    init {
        engine = TextToSpeech(context) { status ->
            if (status != TextToSpeech.SUCCESS) {
                _state.value = SpeechState.Unavailable("No text-to-speech engine on this device")
                return@TextToSpeech
            }
            _state.value = applyLanguage()
        }
        engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _state.value = SpeechState.Speaking
            }

            override fun onDone(utteranceId: String?) {
                _state.value = SpeechState.Ready
            }

            @Deprecated("Superseded by onError(String, Int)", ReplaceWith(""))
            override fun onError(utteranceId: String?) {
                _state.value = SpeechState.Ready
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                // A failed utterance is not a broken engine — the next one may
                // well work — so this returns to Ready rather than Unavailable.
                _state.value = SpeechState.Ready
            }
        })
    }

    /**
     * Prefers Indian English, falls back to UK then US.
     *
     * Indian English first because that is who is listening: a learner in Patna
     * matching their pronunciation against an accent they will actually hear
     * around them is being taught something useful, and one they will never hear
     * is being taught a standard nobody holds them to.
     */
    private fun applyLanguage(): SpeechState {
        val tts = engine ?: return SpeechState.Unavailable("Speech engine went away")

        val preferred = listOf(
            Locale("en", "IN"),
            Locale.UK,
            Locale.US
        )

        for (locale in preferred) {
            val result = tts.setLanguage(locale)
            if (result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED
            ) {
                return SpeechState.Ready
            }
        }
        return SpeechState.Unavailable("No English voice installed")
    }

    override fun speak(text: String, rate: Float) {
        val tts = engine ?: return
        if (_state.value is SpeechState.Unavailable) return
        if (text.isBlank()) return

        val clamped = rate.coerceIn(MIN_RATE, MAX_RATE)
        if (clamped != currentRate) {
            tts.setSpeechRate(clamped)
            currentRate = clamped
        }

        // QUEUE_FLUSH, not QUEUE_ADD: tapping a second speaker button means
        // "say that one instead", never "say it after this finishes".
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, text.hashCode().toString())
    }

    override fun stop() {
        engine?.stop()
        if (_state.value is SpeechState.Speaking) _state.value = SpeechState.Ready
    }

    override fun release() {
        engine?.stop()
        engine?.shutdown()
        engine = null
        _state.value = SpeechState.Unavailable("Speech engine released")
    }

    companion object {
        const val MIN_RATE = SpeechPlayer.RATE_MIN
        const val MAX_RATE = SpeechPlayer.RATE_MAX
    }
}
