package com.speaksarthi.app.data.audio

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.speaksarthi.app.di.ApplicationScope
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.abs
import kotlin.math.min

/** Where a recording is in its life. */
sealed interface RecorderState {
    data object Idle : RecorderState

    data class Recording(
        val elapsedMillis: Int,
        /** 0f–1f, for the level meter. Not a dB reading; only ever drives a bar. */
        val level: Float,
        val maxMillis: Int
    ) : RecorderState {
        val remainingMillis: Int get() = (maxMillis - elapsedMillis).coerceAtLeast(0)
    }

    data class Finished(val file: File, val durationMillis: Long) : RecorderState

    data class Failed(val reason: String) : RecorderState
}

/**
 * Records the learner's voice to a WAV file.
 *
 * Behind an interface so the speaking screen can be driven by a fake in tests
 * and so a future switch to a different capture API does not reach into the UI.
 */
interface VoiceRecorder {
    val state: StateFlow<RecorderState>

    /** True once the recorder has confirmed the device can actually capture audio. */
    fun isAvailable(): Boolean

    /**
     * Starts capturing into [outputFile], stopping itself at [maxMillis].
     *
     * The caller must already hold RECORD_AUDIO. Starting without it puts the
     * recorder into [RecorderState.Failed] rather than throwing, because a
     * permission the learner declined is a normal state, not a crash.
     */
    fun start(outputFile: File, maxMillis: Int = DEFAULT_MAX_MILLIS)

    /** Stops and finalises the file. */
    fun stop()

    /** Stops and deletes — the learner changed their mind mid-sentence. */
    fun cancel()

    fun release()

    companion object {
        /**
         * Fifteen seconds, which is the product cap and also the cost cap.
         *
         * Scoring is billed per minute of audio, so the length of a recording is
         * money. It is also pedagogy: one sentence said carefully scores better
         * and teaches more than a rambling paragraph, and a learner who is
         * nervous about speaking finds fifteen seconds far less frightening than
         * a minute.
         */
        const val DEFAULT_MAX_MILLIS = 15_000

        /** Below this there is nothing to score — usually a mis-tap. */
        const val MINIMUM_MILLIS = 700
    }
}

@Singleton
class AudioRecordVoiceRecorder @Inject constructor(
    @ApplicationContext private val context: Context,
    @ApplicationScope private val scope: CoroutineScope
) : VoiceRecorder {

    private val _state = MutableStateFlow<RecorderState>(RecorderState.Idle)
    override val state: StateFlow<RecorderState> = _state.asStateFlow()

    private var recorder: AudioRecord? = null
    private var captureJob: Job? = null

    @Volatile
    private var keepGoing = false

    override fun isAvailable(): Boolean =
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_MICROPHONE)

    // The permission is checked by the caller before this is reached; the
    // try/catch below is what actually handles it being absent, since
    // AudioRecord throws rather than returning a status in that case.
    @SuppressLint("MissingPermission")
    override fun start(outputFile: File, maxMillis: Int) {
        if (captureJob?.isActive == true) return

        val minimumBuffer = AudioRecord.getMinBufferSize(
            WavFile.SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (minimumBuffer <= 0) {
            _state.value = RecorderState.Failed("This phone cannot record at the quality needed")
            return
        }

        // Four times the minimum: a cheap phone under load can be slow to come
        // back for the next read, and a buffer that runs dry drops samples in the
        // middle of a word. Dropped samples score as mispronunciation.
        val bufferBytes = minimumBuffer * 4

        val device = try {
            AudioRecord(
                // VOICE_RECOGNITION rather than MIC: the platform applies noise
                // suppression tuned for speech and, importantly, does not apply
                // the automatic gain control that MIC does. AGC would flatten the
                // loudness differences the scoring service reads as fluency.
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                WavFile.SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferBytes
            )
        } catch (error: SecurityException) {
            _state.value = RecorderState.Failed("Microphone permission is not granted")
            return
        } catch (error: IllegalArgumentException) {
            _state.value = RecorderState.Failed("This phone cannot record at the quality needed")
            return
        }

        if (device.state != AudioRecord.STATE_INITIALIZED) {
            device.release()
            _state.value = RecorderState.Failed("The microphone is busy")
            return
        }

        recorder = device
        keepGoing = true
        val byteCap = WavFile.byteCountFor(maxMillis)

        captureJob = scope.launch {
            try {
                WavFile.writePlaceholderHeader(outputFile)
                device.startRecording()

                val buffer = ByteArray(bufferBytes)
                var written = 0

                FileOutputStream(outputFile, true).use { sink ->
                    while (keepGoing && written < byteCap) {
                        val wanted = min(buffer.size, byteCap - written)
                        val read = device.read(buffer, 0, wanted)
                        if (read <= 0) break

                        sink.write(buffer, 0, read)
                        written += read

                        _state.value = RecorderState.Recording(
                            elapsedMillis = written * 1000 / WavFile.bytesPerSecond(),
                            level = levelOf(buffer, read),
                            maxMillis = maxMillis
                        )
                    }
                }

                stopDevice()
                WavFile.finalise(outputFile)
                val duration = WavFile.durationMillis(outputFile)

                _state.value = if (duration < VoiceRecorder.MINIMUM_MILLIS) {
                    outputFile.delete()
                    RecorderState.Failed("That was too short to score — hold the button and say the whole sentence")
                } else {
                    RecorderState.Finished(outputFile, duration)
                }
            } catch (error: Exception) {
                stopDevice()
                outputFile.delete()
                _state.value = RecorderState.Failed(
                    error.message ?: "Something went wrong while recording"
                )
            }
        }
    }

    override fun stop() {
        keepGoing = false
    }

    override fun cancel() {
        keepGoing = false
        captureJob = null
        stopDevice()
        _state.value = RecorderState.Idle
    }

    override fun release() {
        cancel()
    }

    private fun stopDevice() {
        val device = recorder ?: return
        recorder = null
        try {
            if (device.recordingState == AudioRecord.RECORDSTATE_RECORDING) device.stop()
        } catch (error: IllegalStateException) {
            // Already stopped. Nothing to do, and nothing worth telling anyone.
        }
        device.release()
    }

    /**
     * Mean absolute amplitude of a buffer, normalised to 0f–1f.
     *
     * Mean rather than peak: a peak meter on a phone microphone spends most of
     * its time pinned by room noise and tells the learner nothing about whether
     * they are being heard. This is only ever drawn as a bar, so it does not
     * need to be a real dB measurement — it needs to move when they speak and
     * sit still when they do not.
     */
    private fun levelOf(buffer: ByteArray, length: Int): Float {
        if (length < 2) return 0f
        var total = 0L
        var samples = 0
        var index = 0
        while (index + 1 < length) {
            // Little-endian 16-bit sample.
            val sample = (buffer[index + 1].toInt() shl 8) or (buffer[index].toInt() and 0xFF)
            total += abs(sample.toShort().toInt())
            samples++
            index += 2
        }
        if (samples == 0) return 0f
        // Divided by a third of full scale rather than full scale: normal
        // speech into a phone held at arm's length never gets near Short.MAX,
        // so a full-scale divisor would leave the bar permanently near empty.
        return (total.toFloat() / samples / (Short.MAX_VALUE / 3f)).coerceIn(0f, 1f)
    }
}
