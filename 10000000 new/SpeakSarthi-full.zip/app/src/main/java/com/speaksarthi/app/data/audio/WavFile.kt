package com.speaksarthi.app.data.audio

import java.io.File
import java.io.RandomAccessFile

/**
 * Writes 16-bit PCM WAV files, by hand.
 *
 * Android's `MediaRecorder` is the easy way to record audio and it is the wrong
 * one here: it produces AAC or AMR in an MP4 or 3GP container, and the
 * pronunciation-assessment service wants uncompressed 16 kHz mono PCM. Sending
 * it anything else either fails outright or — worse — is transcoded somewhere
 * and scored against audio that is not quite what the learner said.
 *
 * So the app captures raw PCM with `AudioRecord` and this puts the 44-byte RIFF
 * header on it. There is no clever part; there is only the part that has to be
 * exactly right, because a header off by one field produces a file that plays
 * fine locally and is rejected by the service with a generic error.
 */
object WavFile {

    const val HEADER_BYTES = 44

    /** What the scoring service expects, and therefore what the recorder captures. */
    const val SAMPLE_RATE = 16_000
    const val CHANNELS = 1
    const val BITS_PER_SAMPLE = 16

    private const val PCM_FORMAT: Short = 1

    /**
     * Writes a placeholder header so PCM can be appended straight after it.
     *
     * The two length fields are not known until recording stops, so they are
     * written as zero here and corrected by [finalise]. Reserving the space up
     * front is what lets the audio stream to disk instead of being held in
     * memory — a 15-second cap makes that survivable either way, but a recorder
     * that buffers is a recorder that drops samples on a cheap phone under load.
     */
    fun writePlaceholderHeader(file: File) {
        RandomAccessFile(file, "rw").use { out ->
            out.setLength(0)
            out.write(header(dataBytes = 0))
        }
    }

    /**
     * Rewrites the two length fields now that the payload size is known, and
     * returns the number of audio bytes written.
     */
    fun finalise(file: File): Long {
        val total = file.length()
        if (total < HEADER_BYTES) return 0

        val dataBytes = total - HEADER_BYTES
        RandomAccessFile(file, "rw").use { out ->
            out.seek(0)
            out.write(header(dataBytes))
        }
        return dataBytes
    }

    /** Duration of a finished file, from its size — no decoding needed. */
    fun durationMillis(file: File): Long {
        val dataBytes = (file.length() - HEADER_BYTES).coerceAtLeast(0)
        return dataBytes * 1000 / bytesPerSecond()
    }

    fun bytesPerSecond(): Int = SAMPLE_RATE * CHANNELS * BITS_PER_SAMPLE / 8

    /** Bytes of PCM for [millis] of audio — the recorder's own length cap. */
    fun byteCountFor(millis: Int): Int = (bytesPerSecond().toLong() * millis / 1000).toInt()

    /**
     * The canonical 44-byte header. Every multi-byte field is little-endian,
     * which is the single most common way a hand-written WAV header goes wrong.
     */
    fun header(dataBytes: Long): ByteArray {
        val byteRate = bytesPerSecond()
        val blockAlign = (CHANNELS * BITS_PER_SAMPLE / 8).toShort()
        val out = ByteArray(HEADER_BYTES)
        var at = 0

        fun ascii(text: String) {
            for (character in text) out[at++] = character.code.toByte()
        }

        fun int32(value: Int) {
            out[at++] = (value and 0xFF).toByte()
            out[at++] = (value shr 8 and 0xFF).toByte()
            out[at++] = (value shr 16 and 0xFF).toByte()
            out[at++] = (value shr 24 and 0xFF).toByte()
        }

        fun int16(value: Short) {
            val raw = value.toInt()
            out[at++] = (raw and 0xFF).toByte()
            out[at++] = (raw shr 8 and 0xFF).toByte()
        }

        ascii("RIFF")
        // Everything after this field: the remaining header plus the payload.
        int32((dataBytes + HEADER_BYTES - 8).toInt())
        ascii("WAVE")

        ascii("fmt ")
        int32(16)                       // PCM fmt chunk is always 16 bytes
        int16(PCM_FORMAT)
        int16(CHANNELS.toShort())
        int32(SAMPLE_RATE)
        int32(byteRate)
        int16(blockAlign)
        int16(BITS_PER_SAMPLE.toShort())

        ascii("data")
        int32(dataBytes.toInt())

        return out
    }
}
