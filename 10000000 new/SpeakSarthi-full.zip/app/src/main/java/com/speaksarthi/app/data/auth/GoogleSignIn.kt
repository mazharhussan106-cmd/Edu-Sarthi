package com.speaksarthi.app.data.auth

import android.app.Activity
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.speaksarthi.app.BuildConfig
import javax.inject.Inject
import javax.inject.Singleton

/** What came back from asking Google who this is. */
sealed interface GoogleSignInResult {
    /** The ID token to hand to the server. Never trusted here — only forwarded. */
    data class Token(val idToken: String) : GoogleSignInResult

    /** The learner backed out. Not an error and never shown as one. */
    data object Cancelled : GoogleSignInResult

    /** No Google account on the device, or none the learner wants to use. */
    data object NoAccount : GoogleSignInResult

    /** No client id in this build — sign-in is simply off. */
    data object NotConfigured : GoogleSignInResult

    data class Failed(val reason: String) : GoogleSignInResult
}

/**
 * Google sign-in, behind an interface.
 *
 * It does exactly one thing: get an ID token and hand it over. It never decides
 * that someone is signed in, never reads the token's contents, and never grants
 * anything. The server verifies the signature against Google's published keys
 * and decides — because the payload of an ID token is plain base64, and an app
 * that reads it without checking the signature will believe whatever it is
 * handed.
 */
interface GoogleSignIn {

    fun isConfigured(): Boolean

    suspend fun requestIdToken(activity: Activity): GoogleSignInResult
}

@Singleton
class CredentialManagerGoogleSignIn @Inject constructor() : GoogleSignIn {

    override fun isConfigured(): Boolean = BuildConfig.GOOGLE_OAUTH_CLIENT_ID.isNotBlank()

    override suspend fun requestIdToken(activity: Activity): GoogleSignInResult {
        if (!isConfigured()) return GoogleSignInResult.NotConfigured

        val option = GetGoogleIdOption.Builder()
            // False, deliberately. Filtering to accounts already used with this
            // app means a first-time signer-in is shown an empty sheet and
            // concludes sign-in is broken.
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(BuildConfig.GOOGLE_OAUTH_CLIENT_ID)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(option)
            .build()

        return try {
            val response = CredentialManager.create(activity)
                .getCredential(activity, request)
            val credential = response.credential

            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                GoogleSignInResult.Token(
                    GoogleIdTokenCredential.createFrom(credential.data).idToken
                )
            } else {
                GoogleSignInResult.Failed("That sign-in did not return a Google account")
            }
        } catch (error: GetCredentialCancellationException) {
            GoogleSignInResult.Cancelled
        } catch (error: NoCredentialException) {
            GoogleSignInResult.NoAccount
        } catch (error: GetCredentialException) {
            GoogleSignInResult.Failed("Sign-in did not work. Try again in a moment.")
        }
    }
}
