package com.speaksarthi.app.data.backup

import android.content.Context
import android.net.Uri
import com.speaksarthi.app.BuildConfig
import com.speaksarthi.app.data.local.dao.BadgeDao
import com.speaksarthi.app.data.local.dao.ContentDao
import com.speaksarthi.app.data.local.dao.DailyStatDao
import com.speaksarthi.app.data.local.dao.LearnerSentenceDao
import com.speaksarthi.app.data.local.dao.ProgressDao
import com.speaksarthi.app.data.local.dao.WeakSoundDao
import com.speaksarthi.app.data.local.entity.BadgeEntity
import com.speaksarthi.app.data.local.entity.DailyStatEntity
import com.speaksarthi.app.data.local.entity.LearnerSentenceEntity
import com.speaksarthi.app.data.local.entity.ProgressEntity
import com.speaksarthi.app.data.local.entity.WeakSoundEntity
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.di.IoDispatcher
import com.speaksarthi.app.domain.repository.AccountRepository
import com.speaksarthi.app.domain.usecase.backup.BackupMerge
import com.speaksarthi.app.util.Clock
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Writes and reads the learner's backup file.
 *
 * Everything here goes through a [Uri] the learner chose with the system file
 * picker, which means no storage permission is needed and the file lands
 * somewhere they can actually find — Drive, Files, a memory card, a chat with
 * themselves. An app-private backup nobody can reach is not a backup.
 */
@Singleton
class BackupManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val contentDao: ContentDao,
    private val progressDao: ProgressDao,
    private val dailyStatDao: DailyStatDao,
    private val badgeDao: BadgeDao,
    private val weakSoundDao: WeakSoundDao,
    private val sentenceDao: LearnerSentenceDao,
    private val preferences: AppPreferences,
    private val account: AccountRepository,
    private val clock: Clock,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) {

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    /** `speak-sarthi-backup-2026-09-16.json`. */
    fun suggestedFileName(): String =
        "${BackupFile.FILE_PREFIX}-${clock.today().format(DateTimeFormatter.ISO_LOCAL_DATE)}.json"

    suspend fun build(): BackupFile = withContext(ioDispatcher) {
        BackupFile(
            version = BackupFile.CURRENT_VERSION,
            exportedAt = clock.nowMillis(),
            appVersion = BuildConfig.VERSION_NAME,
            localId = account.profile().localId,
            currentLevel = preferences.currentLevel.first(),
            dailyGoal = preferences.dailyGoal.first(),
            progress = progressDao.all().map { row ->
                BackupProgress(
                    wordId = row.wordId,
                    easeFactor = row.easeFactor,
                    intervalDays = row.intervalDays,
                    repetitions = row.repetitions,
                    nextReviewAt = row.nextReviewAt,
                    lastReviewedAt = row.lastReviewedAt,
                    timesSeen = row.timesSeen,
                    timesCorrect = row.timesCorrect,
                    isBookmarked = row.isBookmarked,
                    isKnown = row.isKnown
                )
            },
            dailyStats = dailyStatDao.all().map { row ->
                BackupDailyStat(
                    date = row.date,
                    wordsStudied = row.wordsStudied,
                    chunksStudied = row.chunksStudied,
                    quizzesAnswered = row.quizzesAnswered,
                    quizzesCorrect = row.quizzesCorrect,
                    recordingsMade = row.recordingsMade,
                    secondsGraded = row.secondsGraded,
                    studySeconds = row.studySeconds,
                    mistakesReviewed = row.mistakesReviewed
                )
            },
            badges = badgeDao.all().map { BackupBadge(it.badgeId, it.earnedAt) },
            weakSounds = weakSoundDao.all().map { row ->
                BackupWeakSound(row.phoneme, row.errorCount, row.attemptCount, row.lastSeenAt)
            },
            sentences = sentenceDao.all().map { row ->
                BackupSentence(row.wordId, row.text, row.updatedAt)
            }
        )
    }

    suspend fun writeTo(uri: Uri): Result<Int> = withContext(ioDispatcher) {
        runCatching {
            val backup = build()
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(json.encodeToString(BackupFile.serializer(), backup).toByteArray())
            } ?: error("Could not write to that location")
            backup.totalRows
        }
    }

    /**
     * Reads a backup and merges it in.
     *
     * Merged rather than replaced — see [BackupMerge] for why every rule keeps
     * whichever side represents more learning. The one thing this cannot restore
     * is the recordings, which are not in the file; the scores derived from them
     * are.
     */
    suspend fun restoreFrom(uri: Uri): RestoreReport = withContext(ioDispatcher) {
        val raw = runCatching {
            context.contentResolver.openInputStream(uri)?.use { it.readBytes().decodeToString() }
        }.getOrNull()

        if (raw.isNullOrBlank()) {
            return@withContext RestoreReport(error = "That file could not be read.")
        }

        val backup = runCatching { json.decodeFromString(BackupFile.serializer(), raw) }
            .getOrElse {
                return@withContext RestoreReport(
                    error = "That does not look like a Speak Sarthi backup."
                )
            }

        // A newer file is refused rather than partially read. Silently dropping
        // fields an older app does not understand would restore something that
        // looks complete and is not.
        if (backup.version > BackupFile.CURRENT_VERSION) {
            return@withContext RestoreReport(
                error = "That backup was made by a newer version of the app. " +
                    "Update, then restore it."
            )
        }

        val ownLocalId = account.profile().localId

        val progress = BackupMerge.mergeAll(
            local = progressDao.all().associate { row ->
                row.wordId to BackupProgress(
                    wordId = row.wordId,
                    easeFactor = row.easeFactor,
                    intervalDays = row.intervalDays,
                    repetitions = row.repetitions,
                    nextReviewAt = row.nextReviewAt,
                    lastReviewedAt = row.lastReviewedAt,
                    timesSeen = row.timesSeen,
                    timesCorrect = row.timesCorrect,
                    isBookmarked = row.isBookmarked,
                    isKnown = row.isKnown
                )
            },
            incoming = backup.progress,
            keyOf = { it.wordId },
            merge = BackupMerge::mergeProgress
        )

        val dailyStats = BackupMerge.mergeAll(
            local = dailyStatDao.all().associate { row ->
                row.date to BackupDailyStat(
                    date = row.date,
                    wordsStudied = row.wordsStudied,
                    chunksStudied = row.chunksStudied,
                    quizzesAnswered = row.quizzesAnswered,
                    quizzesCorrect = row.quizzesCorrect,
                    recordingsMade = row.recordingsMade,
                    secondsGraded = row.secondsGraded,
                    studySeconds = row.studySeconds,
                    mistakesReviewed = row.mistakesReviewed
                )
            },
            incoming = backup.dailyStats,
            keyOf = { it.date },
            merge = BackupMerge::mergeDailyStat
        )

        val badges = BackupMerge.mergeAll(
            local = badgeDao.all().associate { it.badgeId to BackupBadge(it.badgeId, it.earnedAt) },
            incoming = backup.badges,
            keyOf = { it.badgeId },
            merge = BackupMerge::mergeBadge
        )

        val sounds = BackupMerge.mergeAll(
            local = weakSoundDao.all().associate { row ->
                row.phoneme to BackupWeakSound(
                    row.phoneme, row.errorCount, row.attemptCount, row.lastSeenAt
                )
            },
            incoming = backup.weakSounds,
            keyOf = { it.phoneme },
            merge = BackupMerge::mergeWeakSound
        )

        val sentences = BackupMerge.mergeAll(
            local = sentenceDao.all().associate { row ->
                row.wordId to BackupSentence(row.wordId, row.text, row.updatedAt)
            },
            incoming = backup.sentences,
            keyOf = { it.wordId },
            merge = BackupMerge::mergeSentence
        )

        // Progress and sentences carry a foreign key to words, so rows for a word
        // this build does not have are dropped rather than failing the whole
        // restore: a backup from a later content version must still restore the
        // 990 words that do exist.
        val knownWords = contentDao.allWordIds().toSet()
        val usableProgress = progress.filter { it.wordId in knownWords }
        val usableSentences = sentences.filter { it.wordId in knownWords }

        val written = runCatching {
            progressDao.upsertAll(
                usableProgress.map { row ->
                    ProgressEntity(
                        wordId = row.wordId,
                        easeFactor = row.easeFactor,
                        intervalDays = row.intervalDays,
                        repetitions = row.repetitions,
                        nextReviewAt = row.nextReviewAt,
                        lastReviewedAt = row.lastReviewedAt,
                        timesSeen = row.timesSeen,
                        timesCorrect = row.timesCorrect,
                        isBookmarked = row.isBookmarked,
                        isKnown = row.isKnown
                    )
                }
            )
            dailyStatDao.upsertAll(
                dailyStats.map { row ->
                    DailyStatEntity(
                        date = row.date,
                        wordsStudied = row.wordsStudied,
                        chunksStudied = row.chunksStudied,
                        quizzesAnswered = row.quizzesAnswered,
                        quizzesCorrect = row.quizzesCorrect,
                        recordingsMade = row.recordingsMade,
                        secondsGraded = row.secondsGraded,
                        studySeconds = row.studySeconds,
                        mistakesReviewed = row.mistakesReviewed
                    )
                }
            )
            badgeDao.upsertAll(badges.map { BadgeEntity(it.badgeId, it.earnedAt) })
            weakSoundDao.upsertAll(
                sounds.map { WeakSoundEntity(it.phoneme, it.errorCount, it.attemptCount, it.lastSeenAt) }
            )
            sentenceDao.upsertAll(
                usableSentences.map { LearnerSentenceEntity(it.wordId, it.text, it.updatedAt) }
            )

            if (backup.currentLevel.isNotBlank()) preferences.setCurrentLevel(backup.currentLevel)
            if (backup.dailyGoal > 0) preferences.setDailyGoal(backup.dailyGoal)
            // Restoring means they have been here before, whatever this install
            // thinks — so the placement test is not offered again.
            preferences.setOnboardingComplete(true)
        }

        written.exceptionOrNull()?.let { error ->
            return@withContext RestoreReport(
                error = error.message ?: "Something went wrong while restoring."
            )
        }

        RestoreReport(
            progressRestored = usableProgress.size,
            daysRestored = dailyStats.size,
            badgesRestored = badges.size,
            soundsRestored = sounds.size,
            sentencesRestored = usableSentences.size,
            wasFromThisDevice = backup.localId.isNotBlank() && backup.localId == ownLocalId
        )
    }
}
