package com.speaksarthi.app.data.backup

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * The backup file format.
 *
 * One JSON file the learner can put anywhere — Drive, WhatsApp to themselves, a
 * memory card. This exists because of a failure that has been flagged in this
 * project twice and deferred twice: someone practises for three weeks, changes
 * phone, and loses everything at exactly the moment they were starting to feel
 * confident.
 *
 * A server would solve it too, and there is no server. A file solves it today,
 * costs nothing to run, works offline, and belongs to the learner rather than to
 * anyone's infrastructure. When sync does arrive this format is still the export
 * path, which every app that holds someone's work should have anyway.
 *
 * **What is deliberately not in here: the recordings.** The audio is tens of
 * megabytes, it would make the file unshareable, and restoring rows that point
 * at files which no longer exist is worse than not restoring them. The scores
 * derived from those recordings — weak sounds, daily counters — are all here.
 */
@Serializable
data class BackupFile(
    /** Bumped when the shape changes. An unknown version is refused, not guessed at. */
    @SerialName("version") val version: Int = CURRENT_VERSION,
    @SerialName("exportedAt") val exportedAt: Long = 0L,
    @SerialName("appVersion") val appVersion: String = "",
    /** The profile this came from, so a restore can tell "mine" from "someone else's". */
    @SerialName("localId") val localId: String = "",
    @SerialName("currentLevel") val currentLevel: String = "",
    @SerialName("dailyGoal") val dailyGoal: Int = 0,
    @SerialName("progress") val progress: List<BackupProgress> = emptyList(),
    @SerialName("dailyStats") val dailyStats: List<BackupDailyStat> = emptyList(),
    @SerialName("badges") val badges: List<BackupBadge> = emptyList(),
    @SerialName("weakSounds") val weakSounds: List<BackupWeakSound> = emptyList(),
    @SerialName("sentences") val sentences: List<BackupSentence> = emptyList()
) {
    val totalRows: Int
        get() = progress.size + dailyStats.size + badges.size + weakSounds.size + sentences.size

    companion object {
        const val CURRENT_VERSION = 1

        /** `speak-sarthi-backup-2026-09-16.json` — dated, so two are never confused. */
        const val FILE_PREFIX = "speak-sarthi-backup"
        const val MIME_TYPE = "application/json"
    }
}

@Serializable
data class BackupProgress(
    @SerialName("wordId") val wordId: String,
    @SerialName("easeFactor") val easeFactor: Double = 2.5,
    @SerialName("intervalDays") val intervalDays: Int = 0,
    @SerialName("repetitions") val repetitions: Int = 0,
    @SerialName("nextReviewAt") val nextReviewAt: Long = 0L,
    @SerialName("lastReviewedAt") val lastReviewedAt: Long = 0L,
    @SerialName("timesSeen") val timesSeen: Int = 0,
    @SerialName("timesCorrect") val timesCorrect: Int = 0,
    @SerialName("isBookmarked") val isBookmarked: Boolean = false,
    @SerialName("isKnown") val isKnown: Boolean = false
)

@Serializable
data class BackupDailyStat(
    @SerialName("date") val date: String,
    @SerialName("wordsStudied") val wordsStudied: Int = 0,
    @SerialName("chunksStudied") val chunksStudied: Int = 0,
    @SerialName("quizzesAnswered") val quizzesAnswered: Int = 0,
    @SerialName("quizzesCorrect") val quizzesCorrect: Int = 0,
    @SerialName("recordingsMade") val recordingsMade: Int = 0,
    @SerialName("secondsGraded") val secondsGraded: Int = 0,
    @SerialName("studySeconds") val studySeconds: Int = 0,
    @SerialName("mistakesReviewed") val mistakesReviewed: Int = 0
)

@Serializable
data class BackupBadge(
    @SerialName("badgeId") val badgeId: String,
    @SerialName("earnedAt") val earnedAt: Long = 0L
)

@Serializable
data class BackupWeakSound(
    @SerialName("phoneme") val phoneme: String,
    @SerialName("errorCount") val errorCount: Int = 0,
    @SerialName("attemptCount") val attemptCount: Int = 0,
    @SerialName("lastSeenAt") val lastSeenAt: Long = 0L
)

@Serializable
data class BackupSentence(
    @SerialName("wordId") val wordId: String,
    @SerialName("text") val text: String = "",
    @SerialName("updatedAt") val updatedAt: Long = 0L
)

/** What a restore did, so the learner is told rather than left guessing. */
data class RestoreReport(
    val progressRestored: Int = 0,
    val daysRestored: Int = 0,
    val badgesRestored: Int = 0,
    val soundsRestored: Int = 0,
    val sentencesRestored: Int = 0,
    val wasFromThisDevice: Boolean = false,
    val error: String? = null
) {
    val isSuccess: Boolean get() = error == null

    val totalRestored: Int
        get() = progressRestored + daysRestored + badgesRestored + soundsRestored + sentencesRestored
}
