package com.speaksarthi.app.data.billing

import android.app.Activity
import com.speaksarthi.app.domain.model.CreditPack
import kotlinx.coroutines.flow.StateFlow

/** One pack as Play describes it, with Play's own localised price. */
data class PackOffer(
    val pack: CreditPack,
    /**
     * Already localised and formatted by Play.
     *
     * Never build this yourself. Play knows the learner's currency, their
     * country's tax display rules and the right symbol placement; an app that
     * formats "₹99" by hand shows the wrong thing the moment somebody opens it
     * abroad.
     */
    val formattedPrice: String
) {
    val productId: String get() = pack.productId
}

/**
 * What the app knows about buying credits right now.
 *
 * Every non-purchasable case is a named state rather than an error, because each
 * one has a different thing to say and the differences matter. "Play is not
 * installed" and "this build has no products configured" are both "you cannot
 * buy right now", and telling a learner the wrong one wastes their afternoon.
 */
sealed interface BillingState {
    /** Connecting to Play, or reading what it says. */
    data object Loading : BillingState

    /**
     * No products configured in this build.
     *
     * A supported state, not a bug: the app works completely, the paywall says
     * credits are not for sale yet rather than showing a broken button, and
     * whatever credits the learner already has still work.
     */
    data object NotConfigured : BillingState

    /**
     * Play is unavailable on this device — no Play Store, or an old one.
     *
     * Common enough in India to be worth its own state rather than a generic
     * error, and there is nothing the learner can do about it.
     */
    data object Unavailable : BillingState

    /** Packs Play will actually sell, cheapest first. */
    data class Ready(val offers: List<PackOffer>) : BillingState

    data class Failed(val reason: String) : BillingState
}

/** What came back from asking to buy. */
sealed interface PurchaseResult {
    /** Paid, verified by the server, and the credits are on the account. */
    data class Credited(val balance: Int) : PurchaseResult

    /**
     * Play has the purchase; the money has not arrived.
     *
     * Normal in India rather than an edge case — a UPI mandate can sit
     * unconfirmed for hours and may never complete. Nothing is granted and
     * nothing is consumed; the next `start()` picks it up if it completes.
     */
    data object Pending : PurchaseResult

    /** The learner backed out. Not an error, and never shown as one. */
    data object Cancelled : PurchaseResult

    data class Failed(val reason: String) : PurchaseResult
}

/**
 * Play Billing, behind an interface.
 *
 * Behind one because billing cannot be tested in any environment that does not
 * have a Play Store, a signed build and configured products — which is every
 * environment except a real device attached to a real Play Console. Everything
 * that depends on buying is therefore written against this, and can be driven by
 * a fake.
 */
interface BillingRepository {

    val state: StateFlow<BillingState>

    /**
     * Connects, reads the catalogue, and redeems anything already paid for.
     *
     * Safe to call repeatedly, and worth calling on every launch: a purchase
     * made just before the app was killed is still sitting in Play waiting to be
     * redeemed, and this is what finds it.
     */
    fun start()

    /** Launches Play's purchase sheet. Needs a real Activity, which is Play's rule. */
    suspend fun purchase(activity: Activity, pack: CreditPack): PurchaseResult

    /**
     * Re-reads purchases from Play and redeems any that were missed.
     *
     * Every paid app needs this and most bury it. A learner who paid and did not
     * see the credits arrive has one question — "where is the thing I paid for"
     * — and this is the answer.
     */
    suspend fun restorePurchases(): Boolean

    fun stop()
}
