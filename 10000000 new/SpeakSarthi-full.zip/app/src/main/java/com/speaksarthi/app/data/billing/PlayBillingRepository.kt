package com.speaksarthi.app.data.billing

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ConsumeParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.android.billingclient.api.consumePurchase
import com.android.billingclient.api.queryProductDetails
import com.android.billingclient.api.queryPurchasesAsync
import com.speaksarthi.app.di.ApplicationScope
import com.speaksarthi.app.domain.model.CreditPack
import com.speaksarthi.app.domain.model.RedeemOutcome
import com.speaksarthi.app.domain.repository.CreditsRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The real Play Billing client, selling consumable credit packs.
 *
 * Four things here are easy to get wrong and expensive when you do:
 *
 *  1. **Grant before consuming.** A consumed purchase is gone from Play. If the
 *     app consumes first and then fails to reach the server, the learner has
 *     paid and there is no longer any record to redeem — they bought nothing.
 *     So the server grants the credits first, and only then is the purchase
 *     consumed. Doing it in that order can grant twice; the server's unique
 *     index on the purchase token makes the second one a no-op, which is the
 *     cheap failure rather than the expensive one.
 *  2. **Consuming at all.** A consumable that is never consumed can never be
 *     bought again. Forgetting this is how a learner ends up unable to buy a
 *     second pack, with Play insisting they already own one.
 *  3. **Pending purchases.** In India a large share of payments are UPI mandates
 *     or net banking, which sit `PENDING` for minutes or hours. Granting on
 *     `PENDING` gives credits away to a payment that may never complete;
 *     treating it as a failure tells a learner who did everything right that
 *     they did something wrong. It is its own state, and nothing is consumed
 *     until it clears.
 *  4. **Play is not the authority on what was bought.** It says a purchase
 *     happened; the server says what it was worth. The app never decides, which
 *     is why no credit count appears anywhere in this file.
 */
@Singleton
class PlayBillingRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val credits: CreditsRepository,
    @ApplicationScope private val scope: CoroutineScope
) : BillingRepository {

    private val _state = MutableStateFlow<BillingState>(BillingState.Loading)
    override val state: StateFlow<BillingState> = _state.asStateFlow()

    private var client: BillingClient? = null
    private var catalogue: Map<String, ProductDetails> = emptyMap()

    private val purchaseListener = PurchasesUpdatedListener { result, purchases ->
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK ->
                scope.launch { purchases.orEmpty().forEach { redeem(it) } }

            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED ->
                // An earlier pack was never consumed. Redeeming it clears the
                // way for this one, so ask Play what is outstanding.
                scope.launch { restorePurchases() }

            BillingClient.BillingResponseCode.USER_CANCELED -> Unit

            else -> _state.value = BillingState.Failed(describe(result))
        }
    }

    override fun start() {
        if (client?.isReady == true) {
            scope.launch { refresh() }
            return
        }

        val fresh = BillingClient.newBuilder(context)
            .setListener(purchaseListener)
            .enablePendingPurchases()
            .build()
        client = fresh

        fresh.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    scope.launch { refresh() }
                } else {
                    _state.value = BillingState.Unavailable
                }
            }

            override fun onBillingServiceDisconnected() {
                // Not retried in a loop here: the next start() reconnects, and a
                // reconnect loop on a device with no Play Store is a battery
                // drain nobody will ever attribute to this app.
                _state.value = BillingState.Unavailable
            }
        })
    }

    private suspend fun refresh() {
        val active = client?.takeIf { it.isReady } ?: run {
            _state.value = BillingState.Unavailable
            return
        }

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(
                CreditPack.entries.map { pack ->
                    QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(pack.productId)
                        // INAPP, not SUBS. A credit pack is bought once and
                        // consumed; there is nothing to renew and nothing to
                        // cancel, which is most of why this model was chosen.
                        .setProductType(BillingClient.ProductType.INAPP)
                        .build()
                }
            )
            .build()

        val found = active.queryProductDetails(params).productDetailsList.orEmpty()
        catalogue = found.associateBy { it.productId }

        _state.value = if (found.isEmpty()) {
            // Nothing configured in the Play Console for this build. A real
            // state, not a failure — the app still works and existing credits
            // still spend.
            BillingState.NotConfigured
        } else {
            BillingState.Ready(
                offers = CreditPack.entries.mapNotNull { pack ->
                    catalogue[pack.productId]?.let { details ->
                        PackOffer(pack = pack, formattedPrice = details.formattedPrice())
                    }
                }
            )
        }

        // Anything paid for but not yet redeemed — the app killed mid-purchase,
        // or a pending payment that has since cleared.
        restorePurchases()
    }

    override suspend fun purchase(activity: Activity, pack: CreditPack): PurchaseResult {
        val active = client?.takeIf { it.isReady }
            ?: return PurchaseResult.Failed("Play Billing is not available right now")
        val details = catalogue[pack.productId]
            ?: return PurchaseResult.Failed("That pack is not for sale right now")

        val params = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(
                listOf(
                    BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(details)
                        .build()
                )
            )
            .build()

        val result = active.launchBillingFlow(activity, params)
        return when (result.responseCode) {
            BillingClient.BillingResponseCode.OK ->
                // Play answers through purchaseListener, not here. The sheet is
                // open; what happens next arrives asynchronously.
                PurchaseResult.Pending

            BillingClient.BillingResponseCode.USER_CANCELED -> PurchaseResult.Cancelled

            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> {
                restorePurchases()
                PurchaseResult.Failed("That purchase is still being processed")
            }

            else -> PurchaseResult.Failed(describe(result))
        }
    }

    override suspend fun restorePurchases(): Boolean {
        val active = client?.takeIf { it.isReady } ?: return false

        val params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP)
            .build()

        val owned = active.queryPurchasesAsync(params).purchasesList
        owned.forEach { redeem(it) }
        return owned.isNotEmpty()
    }

    /**
     * Turns one Play purchase into credits.
     *
     * Order matters and is the whole point: the server grants first, the
     * purchase is consumed second. Consuming first would mean a dropped
     * connection leaves a learner who has paid with no record left to redeem.
     */
    private suspend fun redeem(purchase: Purchase) {
        if (purchase.purchaseState == Purchase.PurchaseState.PENDING) {
            // Nothing granted, nothing consumed. It stays in Play, and the next
            // start() finds it if the payment clears.
            return
        }
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return

        val productId = purchase.products.firstOrNull() ?: return
        if (CreditPack.forProductId(productId) == null) return

        when (credits.redeem(productId, purchase.purchaseToken)) {
            // AlreadyRedeemed counts: it means an earlier attempt got through
            // and only the consume step was missed, which is exactly the
            // situation this needs to finish.
            is RedeemOutcome.Granted, is RedeemOutcome.AlreadyRedeemed -> consume(purchase)

            // Left unconsumed on purpose. It is still in Play, still owed, and
            // restorePurchases() will come back for it.
            RedeemOutcome.Pending,
            RedeemOutcome.Offline,
            is RedeemOutcome.Failed -> Unit
        }
    }

    private suspend fun consume(purchase: Purchase) {
        val active = client?.takeIf { it.isReady } ?: return
        val params = ConsumeParams.newBuilder()
            .setPurchaseToken(purchase.purchaseToken)
            .build()
        // Consuming also acknowledges, which is what stops Play automatically
        // refunding the purchase after three days.
        active.consumePurchase(params)
    }

    override fun stop() {
        client?.endConnection()
        client = null
        catalogue = emptyMap()
    }

    private fun ProductDetails.formattedPrice(): String =
        oneTimePurchaseOfferDetails?.formattedPrice.orEmpty()

    private fun describe(result: BillingResult): String = when (result.responseCode) {
        BillingClient.BillingResponseCode.BILLING_UNAVAILABLE ->
            "Play Billing is not available on this device"
        BillingClient.BillingResponseCode.ITEM_UNAVAILABLE ->
            "That pack is not available in your country"
        BillingClient.BillingResponseCode.SERVICE_DISCONNECTED,
        BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE ->
            "Could not reach Play. Check your connection."
        BillingClient.BillingResponseCode.DEVELOPER_ERROR ->
            // Always a configuration mistake, never the learner's. Worth being
            // specific so it is obvious in a bug report.
            "Billing is misconfigured in this build"
        else -> result.debugMessage.ifBlank { "Purchase failed" }
    }
}
