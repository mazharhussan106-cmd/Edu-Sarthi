package com.speaksarthi.app.data.illustration

import android.content.Context
import coil.ImageLoader
import coil.request.CachePolicy
import coil.request.ImageRequest
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.di.IoDispatcher
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Illustrations are fetched on demand and cached — never bundled in the APK.
 *
 * Bundling all 1,000 would add roughly 40 MB to the download, which is a lot to
 * ask of the budget Android phones this app targets, and most learners will only
 * ever see a few hundred words. So the app ships with no artwork at all and
 * pulls each drawing the first time it is needed, keeping it on disk afterwards.
 *
 * The trade this makes, stated plainly: **illustrations are the one part of this
 * app that needs a network.** Everything else — words, chunks, exercises,
 * spaced repetition — works entirely offline. A learner studying with no signal
 * gets the reserved frame with its text fallback, which is a degraded card but
 * never a broken one, and the artwork appears the next time they are online.
 *
 * [prefetch] is what keeps that from being felt in practice: while the learner is
 * reading card one, the next few cards' drawings are already being fetched.
 */
@Singleton
class IllustrationLoader @Inject constructor(
    @ApplicationContext private val context: Context,
    private val imageLoader: ImageLoader,
    private val preferences: AppPreferences,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) {

    /**
     * The URL to load, or null when there is nothing to load — either the word
     * has no artwork assigned or no image host is configured yet. Null is the
     * normal case today and the card must render properly for it.
     */
    suspend fun urlFor(illustration: String): String? {
        val name = illustration.trim()
        if (name.isEmpty()) return null

        val baseUrl = preferences.illustrationBaseUrl.first().trim()
        if (baseUrl.isEmpty()) return null

        return baseUrl.trimEnd('/') + "/" + name
    }

    /**
     * Warms the cache for cards the learner is about to reach.
     *
     * Fire and forget: failures are silent because a missed prefetch is not an
     * error, it just means that card falls back to its text until the image
     * arrives. Called with the next few words in the study queue.
     */
    suspend fun prefetch(illustrations: List<String>) = withContext(ioDispatcher) {
        val baseUrl = preferences.illustrationBaseUrl.first().trim()
        if (baseUrl.isEmpty()) return@withContext

        illustrations
            .asSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .take(PREFETCH_LIMIT)
            .forEach { name ->
                val request = ImageRequest.Builder(context)
                    .data(baseUrl.trimEnd('/') + "/" + name)
                    // Decoding into memory is pointless here — the goal is only
                    // to get the bytes onto disk before the card is reached.
                    .memoryCachePolicy(CachePolicy.DISABLED)
                    .build()
                imageLoader.enqueue(request)
            }
    }

    /** Bytes of artwork currently held on disk. */
    fun cacheBytes(): Long = runCatching { imageLoader.diskCache?.size ?: 0L }.getOrDefault(0L)

    /** Ceiling the cache will grow to before old drawings are evicted. */
    fun cacheLimitBytes(): Long =
        runCatching { imageLoader.diskCache?.maxSize ?: 0L }.getOrDefault(0L)

    /** Frees the downloaded artwork. Everything re-downloads when next needed. */
    suspend fun clearCache() = withContext(ioDispatcher) {
        runCatching {
            imageLoader.diskCache?.clear()
            imageLoader.memoryCache?.clear()
        }
        Unit
    }

    companion object {
        /**
         * How many cards ahead to fetch. Five covers the next couple of minutes
         * of study without pulling artwork the learner may never reach — every
         * unnecessary fetch costs them mobile data.
         */
        const val PREFETCH_LIMIT = 5
    }
}
