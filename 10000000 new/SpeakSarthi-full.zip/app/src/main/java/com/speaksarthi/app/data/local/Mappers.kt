package com.speaksarthi.app.data.local

import com.speaksarthi.app.data.local.converter.Converters
import com.speaksarthi.app.data.local.entity.ChunkEntity
import com.speaksarthi.app.data.local.entity.DailyStatEntity
import com.speaksarthi.app.data.local.entity.ExerciseEntity
import com.speaksarthi.app.data.local.entity.PracticeItemEntity
import com.speaksarthi.app.data.local.entity.ProgressEntity
import com.speaksarthi.app.data.local.entity.RecordingEntity
import com.speaksarthi.app.data.local.entity.WeakSoundEntity
import com.speaksarthi.app.data.local.entity.WordEntity
import com.speaksarthi.app.data.local.entity.WordWithProgressRow
import com.speaksarthi.app.domain.model.AnswerablePrompt
import com.speaksarthi.app.domain.model.CefrLevel
import com.speaksarthi.app.domain.model.Chunk
import com.speaksarthi.app.domain.model.ChunkType
import com.speaksarthi.app.domain.model.DailyStat
import com.speaksarthi.app.domain.model.Exercise
import com.speaksarthi.app.domain.model.McqQuestion
import com.speaksarthi.app.domain.model.PracticeItem
import com.speaksarthi.app.domain.model.PracticeType
import com.speaksarthi.app.domain.model.Progress
import com.speaksarthi.app.domain.model.Recording
import com.speaksarthi.app.domain.model.WeakSound
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.domain.model.WordWithProgress

/**
 * Entity to domain mapping, kept in one file so the boundary is easy to audit.
 * The database layer deals in delimited strings and raw enum names; the domain
 * layer never sees either.
 */

fun WordEntity.toDomain(): Word = Word(
    wordId = wordId,
    word = word,
    partOfSpeech = partOfSpeech,
    category = category,
    level = CefrLevel.fromCode(level),
    frequency = frequency,
    importance = importance,
    register = register,
    ipa = ipa,
    syllableBreak = syllableBreak,
    hindiPronunciation = hindiPronunciation,
    hindiMeaning = hindiMeaning,
    simpleMeaning = simpleMeaning,
    plainExplanation = plainExplanation,
    etymology = etymology,
    mnemonic = mnemonic,
    quickTip = quickTip,
    pronunciationTip = pronunciationTip,
    spellingTip = spellingTip,
    wordFamily = Converters.stringToList(wordFamily),
    prefixRootSuffix = prefixRootSuffix,
    visualAssociation = visualAssociation,
    tone = tone,
    typicalContexts = Converters.stringToList(typicalContexts),
    miniConversation = miniConversation,
    confusingWords = confusingWords,
    relatedWords = Converters.stringToList(relatedWords),
    synonyms = Converters.stringToList(synonyms),
    antonyms = Converters.stringToList(antonyms),
    emotionFeel = emotionFeel,
    commonMistakeWrong = commonMistakeWrong,
    commonMistakeCorrect = commonMistakeCorrect,
    quickRecallPrompt = quickRecallPrompt,
    illustration = illustration,
    orderIndex = orderIndex
)

fun ChunkEntity.toDomain(): Chunk = Chunk(
    chunkId = chunkId,
    wordId = wordId,
    text = text,
    type = ChunkType.fromRaw(type),
    orderIndex = orderIndex
)

fun PracticeItemEntity.toDomain(): PracticeItem = PracticeItem(
    itemId = itemId,
    wordId = wordId,
    text = text,
    highlight = highlight,
    type = PracticeType.fromRaw(type),
    orderIndex = orderIndex
)

fun ExerciseEntity.toMcq(): McqQuestion = McqQuestion(
    wordId = wordId,
    question = mcqQuestion,
    options = Converters.stringToList(mcqOptions),
    answerIndex = mcqAnswerIndex
)

fun ExerciseEntity.toDomain(): Exercise = Exercise(
    wordId = wordId,
    mcq = toMcq(),
    fillBlank = AnswerablePrompt(fillBlankPrompt, fillBlankAnswer),
    // Sentence correction is the same shape as the others: the wrong sentence is
    // the prompt, the fixed one is the answer.
    findFix = AnswerablePrompt(findFixWrong, findFixCorrected),
    translate = AnswerablePrompt(translatePrompt, translateAnswer),
    writeYourOwnPrompt = writeYourOwnPrompt
)

fun ProgressEntity.toDomain(): Progress = Progress(
    wordId = wordId,
    easeFactor = easeFactor,
    intervalDays = intervalDays,
    repetitions = repetitions,
    nextReviewAt = nextReviewAt,
    lastReviewedAt = lastReviewedAt,
    timesSeen = timesSeen,
    timesCorrect = timesCorrect,
    isBookmarked = isBookmarked,
    isKnown = isKnown
)

fun Progress.toEntity(): ProgressEntity = ProgressEntity(
    wordId = wordId,
    easeFactor = easeFactor,
    intervalDays = intervalDays,
    repetitions = repetitions,
    nextReviewAt = nextReviewAt,
    lastReviewedAt = lastReviewedAt,
    timesSeen = timesSeen,
    timesCorrect = timesCorrect,
    isBookmarked = isBookmarked,
    isKnown = isKnown
)

/**
 * A word with no progress row has never been studied, so it maps to a default
 * [Progress]. That keeps "new word" and "studied word" the same shape upstream
 * and means the study queue never has to null-check.
 */
fun WordWithProgressRow.toDomain(): WordWithProgress = WordWithProgress(
    word = word.toDomain(),
    progress = progress?.toDomain() ?: Progress(wordId = word.wordId)
)

fun DailyStatEntity.toDomain(): DailyStat = DailyStat(
    date = date,
    wordsStudied = wordsStudied,
    chunksStudied = chunksStudied,
    quizzesAnswered = quizzesAnswered,
    quizzesCorrect = quizzesCorrect,
    recordingsMade = recordingsMade,
    secondsGraded = secondsGraded,
    studySeconds = studySeconds,
    mistakesReviewed = mistakesReviewed
)

fun RecordingEntity.toDomain(): Recording = Recording(
    id = id,
    wordId = wordId,
    practiceItemId = practiceItemId,
    filePath = filePath,
    durationMillis = durationMillis,
    recordedAt = recordedAt,
    accuracy = scoreAccuracy,
    fluency = scoreFluency,
    completeness = scoreCompleteness,
    overall = scoreOverall,
    weakPhonemes = Converters.stringToList(weakPhonemes)
)

fun WeakSoundEntity.toDomain(): WeakSound = WeakSound(
    phoneme = phoneme,
    errorCount = errorCount,
    attemptCount = attemptCount,
    lastSeenAt = lastSeenAt
)
