package com.speaksarthi.app.data.local

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Schema migrations.
 *
 * The database is built **without** `fallbackToDestructiveMigration`, which means
 * a version bump with no migration here is a crash on launch rather than a quiet
 * wipe. That is the right way round: losing a learner's review history on a
 * schema change is exactly the failure this project has already been bitten by
 * once, and a crash gets noticed in testing while a wipe gets noticed in a
 * one-star review.
 *
 * Schemas are exported to `app/schemas/`, so every migration can be written and
 * tested against the real previous schema rather than a remembered one.
 */
object Migrations {

    /**
     * 1 → 2: `daily_stats.mistakesReviewed`.
     *
     * Added for the "faced the hard ones" badge. Mistake review needed its own
     * counter rather than being folded into `wordsStudied`, because going back
     * to what you got wrong is the part almost everyone skips and is worth being
     * able to recognise separately.
     *
     * `NOT NULL DEFAULT 0` matches the Kotlin default, which is what keeps Room's
     * schema validation happy — a nullable column here would fail validation at
     * runtime with an unhelpful message about an expected column.
     */
    val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "ALTER TABLE daily_stats ADD COLUMN mistakesReviewed INTEGER NOT NULL DEFAULT 0"
            )
        }
    }

    /** Every migration, in order, handed to the database builder. */
    val ALL: Array<Migration> = arrayOf(MIGRATION_1_2)
}
