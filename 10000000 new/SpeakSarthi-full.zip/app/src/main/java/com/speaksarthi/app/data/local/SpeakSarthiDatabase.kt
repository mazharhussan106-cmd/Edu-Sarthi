package com.speaksarthi.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.speaksarthi.app.data.local.converter.Converters
import com.speaksarthi.app.data.local.dao.BadgeDao
import com.speaksarthi.app.data.local.dao.ContentDao
import com.speaksarthi.app.data.local.dao.DailyStatDao
import com.speaksarthi.app.data.local.dao.LearnerSentenceDao
import com.speaksarthi.app.data.local.dao.ProgressDao
import com.speaksarthi.app.data.local.dao.QuizAttemptDao
import com.speaksarthi.app.data.local.dao.RecordingDao
import com.speaksarthi.app.data.local.dao.WeakSoundDao
import com.speaksarthi.app.data.local.entity.BadgeEntity
import com.speaksarthi.app.data.local.entity.ChunkEntity
import com.speaksarthi.app.data.local.entity.DailyStatEntity
import com.speaksarthi.app.data.local.entity.ExerciseEntity
import com.speaksarthi.app.data.local.entity.LearnerSentenceEntity
import com.speaksarthi.app.data.local.entity.PracticeItemEntity
import com.speaksarthi.app.data.local.entity.ProgressEntity
import com.speaksarthi.app.data.local.entity.QuizAttemptEntity
import com.speaksarthi.app.data.local.entity.RecordingEntity
import com.speaksarthi.app.data.local.entity.WeakSoundEntity
import com.speaksarthi.app.data.local.entity.WordEntity

/**
 * The single local database. Everything works offline once seeded; the network
 * is only ever needed for pronunciation scoring, which is an optional per-clip
 * call and never a prerequisite for studying.
 *
 * Schema files are exported (see the ksp `room.schemaLocation` argument in
 * build.gradle.kts) so migrations can be written and tested against a real
 * previous schema rather than from memory.
 */
@Database(
    entities = [
        // content
        WordEntity::class,
        ChunkEntity::class,
        PracticeItemEntity::class,
        ExerciseEntity::class,
        // learner
        ProgressEntity::class,
        RecordingEntity::class,
        WeakSoundEntity::class,
        QuizAttemptEntity::class,
        DailyStatEntity::class,
        BadgeEntity::class,
        LearnerSentenceEntity::class
    ],
    version = 2,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class SpeakSarthiDatabase : RoomDatabase() {

    abstract fun contentDao(): ContentDao
    abstract fun progressDao(): ProgressDao
    abstract fun recordingDao(): RecordingDao
    abstract fun weakSoundDao(): WeakSoundDao
    abstract fun quizAttemptDao(): QuizAttemptDao
    abstract fun dailyStatDao(): DailyStatDao
    abstract fun badgeDao(): BadgeDao
    abstract fun learnerSentenceDao(): LearnerSentenceDao

    companion object {
        const val NAME = "speak_sarthi.db"
    }
}
