package com.speaksarthi.app.data.local.converter

import androidx.room.TypeConverter

/**
 * List-to-string conversion for the handful of columns that hold short lists
 * (synonyms, antonyms, word family, contexts, MCQ options).
 *
 * The delimiter is a unit separator (U+001F) rather than a comma, because the
 * content itself is full of commas — "understand clearly, fully understand" is a
 * single collocation string, and splitting it on a comma would silently shred
 * the data. The list is already split correctly upstream by the seed builder;
 * this converter only has to survive a round trip.
 */
object Converters {

    const val DELIMITER = "\u001F"

    @TypeConverter
    @JvmStatic
    fun listToString(values: List<String>?): String =
        values?.filter { it.isNotBlank() }?.joinToString(DELIMITER) ?: ""

    @TypeConverter
    @JvmStatic
    fun stringToList(raw: String?): List<String> =
        if (raw.isNullOrBlank()) emptyList()
        else raw.split(DELIMITER).map { it.trim() }.filter { it.isNotEmpty() }
}
