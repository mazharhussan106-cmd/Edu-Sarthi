package com.speaksarthi.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Upsert
import com.speaksarthi.app.data.local.entity.ChunkEntity
import com.speaksarthi.app.data.local.entity.ExerciseEntity
import com.speaksarthi.app.data.local.entity.PracticeItemEntity
import com.speaksarthi.app.data.local.entity.WordEntity
import com.speaksarthi.app.data.local.entity.WordWithProgressRow
import kotlinx.coroutines.flow.Flow

/**
 * Reads and writes the shipped library.
 *
 * Every write is an [Upsert] keyed on the natural id, which is what makes a
 * content update non-destructive: an existing word is updated in place, its row
 * identity is unchanged, and the learner's progress row keeps pointing at it.
 */
@Dao
interface ContentDao {

    // ---- words -------------------------------------------------------------

    @Upsert
    suspend fun upsertWords(words: List<WordEntity>)

    @Query("SELECT COUNT(*) FROM words")
    suspend fun wordCount(): Int

    @Query("SELECT COUNT(*) FROM words")
    fun observeWordCount(): Flow<Int>

    @Query("SELECT * FROM words WHERE wordId = :wordId")
    suspend fun wordById(wordId: String): WordEntity?

    @Query("SELECT * FROM words ORDER BY orderIndex ASC")
    fun observeAllWords(): Flow<List<WordEntity>>

    @Query("SELECT * FROM words WHERE level = :level ORDER BY orderIndex ASC")
    fun observeWordsByLevel(level: String): Flow<List<WordEntity>>

    /**
     * Free-text search over the word, its English meaning and its Hindi meaning.
     *
     * `ESCAPE '\'` is required because the repository escapes `%` and `_` before
     * calling: without it a learner searching for "100%" would match every row.
     * Exact prefix matches sort first so typing "under" puts "understand" above
     * words that merely contain it in a definition.
     */
    @Query(
        """
        SELECT * FROM words
        WHERE word LIKE '%' || :query || '%' ESCAPE '\'
           OR simpleMeaning LIKE '%' || :query || '%' ESCAPE '\'
           OR hindiMeaning LIKE '%' || :query || '%' ESCAPE '\'
        ORDER BY
            CASE WHEN word LIKE :query || '%' ESCAPE '\' THEN 0 ELSE 1 END,
            orderIndex ASC
        LIMIT :limit
        """
    )
    suspend fun searchWords(query: String, limit: Int = 50): List<WordEntity>

    /**
     * A random sample of words the learner has actually met.
     *
     * Listening practice draws from this first. Playing a word the learner has
     * never seen and asking them to pick it from four options is a vocabulary
     * test wearing a listening test's clothes — the ear is not what fails.
     */
    @Query(
        """
        SELECT w.* FROM words w
        INNER JOIN progress p ON p.wordId = w.wordId
        WHERE p.lastReviewedAt > 0
        ORDER BY RANDOM()
        LIMIT :limit
        """
    )
    suspend fun randomStudiedWords(limit: Int): List<WordEntity>

    /**
     * A random sample of the whole library, optionally one CEFR band.
     *
     * Two jobs: it stands in for the studied pool on a first run, and it supplies
     * the wrong options — which do not have to be words the learner knows, only
     * words that sound close enough to be worth confusing.
     */
    @Query(
        """
        SELECT * FROM words
        WHERE (:level = '' OR level = :level)
        ORDER BY RANDOM()
        LIMIT :limit
        """
    )
    suspend fun randomWords(level: String = "", limit: Int = 40): List<WordEntity>

    /** Bookmarked words, in library order so the list is stable between visits. */
    @Query(
        """
        SELECT w.* FROM words w
        INNER JOIN progress p ON p.wordId = w.wordId
        WHERE p.isBookmarked = 1
        ORDER BY w.orderIndex ASC
        """
    )
    fun observeBookmarkedWords(): Flow<List<WordEntity>>

    /** Most recently reviewed first — the "where was I?" list. */
    @Query(
        """
        SELECT w.* FROM words w
        INNER JOIN progress p ON p.wordId = w.wordId
        WHERE p.lastReviewedAt > 0
        ORDER BY p.lastReviewedAt DESC
        LIMIT :limit
        """
    )
    suspend fun recentlyStudiedWords(limit: Int): List<WordEntity>

    /** Just the ids, for checks that do not need whole rows — the restore uses this. */
    @Query("SELECT wordId FROM words")
    suspend fun allWordIds(): List<String>

    @Query("SELECT level, COUNT(*) as total FROM words GROUP BY level ORDER BY level ASC")
    suspend fun countsByLevel(): List<LevelCount>

    // ---- words joined to progress ------------------------------------------

    @Transaction
    @Query("SELECT * FROM words WHERE wordId = :wordId")
    suspend fun wordWithProgress(wordId: String): WordWithProgressRow?

    @Transaction
    @Query("SELECT * FROM words ORDER BY orderIndex ASC")
    fun observeWordsWithProgress(): Flow<List<WordWithProgressRow>>

    @Transaction
    @Query("SELECT * FROM words WHERE level = :level ORDER BY orderIndex ASC")
    fun observeWordsWithProgressByLevel(level: String): Flow<List<WordWithProgressRow>>

    /**
     * The study queue: everything due now, hardest-scheduled first, with words
     * never seen before treated as due (their progress row does not exist yet,
     * so the LEFT JOIN leaves nextReviewAt null).
     */
    @Transaction
    @Query(
        """
        SELECT w.* FROM words w
        LEFT JOIN progress p ON p.wordId = w.wordId
        WHERE (p.nextReviewAt IS NULL OR p.nextReviewAt <= :now)
          AND (:level = '' OR w.level = :level)
        ORDER BY
            CASE WHEN p.nextReviewAt IS NULL THEN 1 ELSE 0 END,
            p.nextReviewAt ASC,
            w.orderIndex ASC
        LIMIT :limit
        """
    )
    suspend fun dueQueue(now: Long, level: String = "", limit: Int = 30): List<WordWithProgressRow>

    @Query(
        """
        SELECT COUNT(*) FROM words w
        LEFT JOIN progress p ON p.wordId = w.wordId
        WHERE p.nextReviewAt IS NULL OR p.nextReviewAt <= :now
        """
    )
    fun observeDueCount(now: Long): Flow<Int>

    // ---- chunks ------------------------------------------------------------

    @Upsert
    suspend fun upsertChunks(chunks: List<ChunkEntity>)

    @Query("SELECT COUNT(*) FROM chunks")
    suspend fun chunkCount(): Int

    @Query("SELECT * FROM chunks WHERE wordId = :wordId ORDER BY type ASC, orderIndex ASC")
    suspend fun chunksForWord(wordId: String): List<ChunkEntity>

    @Query("SELECT * FROM chunks WHERE wordId = :wordId ORDER BY type ASC, orderIndex ASC")
    fun observeChunksForWord(wordId: String): Flow<List<ChunkEntity>>

    @Query("SELECT type, COUNT(*) as total FROM chunks GROUP BY type")
    suspend fun countsByChunkType(): List<TypeCount>

    // ---- practice items ----------------------------------------------------

    @Upsert
    suspend fun upsertPracticeItems(items: List<PracticeItemEntity>)

    @Query("SELECT COUNT(*) FROM practice_items")
    suspend fun practiceItemCount(): Int

    @Query("SELECT * FROM practice_items WHERE wordId = :wordId ORDER BY orderIndex ASC")
    suspend fun practiceItemsForWord(wordId: String): List<PracticeItemEntity>

    // ---- practice-zone exercises -------------------------------------------

    @Upsert
    suspend fun upsertExercises(exercises: List<ExerciseEntity>)

    @Query("SELECT COUNT(*) FROM exercises")
    suspend fun exerciseCount(): Int

    /** All five exercises for one word — what part three of the card renders. */
    @Query("SELECT * FROM exercises WHERE wordId = :wordId")
    suspend fun exerciseForWord(wordId: String): ExerciseEntity?

    /** Quiz mode: a random set, optionally restricted to one CEFR band. */
    @Query(
        """
        SELECT e.* FROM exercises e
        INNER JOIN words w ON w.wordId = e.wordId
        WHERE (:level = '' OR w.level = :level)
        ORDER BY RANDOM()
        LIMIT :limit
        """
    )
    suspend fun randomExercises(level: String = "", limit: Int = 10): List<ExerciseEntity>

    // ---- destructive, used only by a full content reset --------------------

    @Query("DELETE FROM words")
    suspend fun deleteAllWords()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWordsRaw(words: List<WordEntity>)
}

data class LevelCount(val level: String, val total: Int)

data class TypeCount(val type: String, val total: Int)
