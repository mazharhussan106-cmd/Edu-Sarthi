package com.speaksarthi.app.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.speaksarthi.app.data.local.entity.BadgeEntity
import com.speaksarthi.app.data.local.entity.DailyStatEntity
import com.speaksarthi.app.data.local.entity.LearnerSentenceEntity
import com.speaksarthi.app.data.local.entity.ProgressEntity
import com.speaksarthi.app.data.local.entity.QuizAttemptEntity
import com.speaksarthi.app.data.local.entity.RecordingEntity
import com.speaksarthi.app.data.local.entity.WeakSoundEntity
import kotlinx.coroutines.flow.Flow

/** Spaced-repetition state, bookmarks and the known/unknown split. */
@Dao
interface ProgressDao {

    @Upsert
    suspend fun upsert(progress: ProgressEntity)

    @Upsert
    suspend fun upsertAll(progress: List<ProgressEntity>)

    @Query("SELECT * FROM progress WHERE wordId = :wordId")
    suspend fun byWordId(wordId: String): ProgressEntity?

    @Query("SELECT * FROM progress")
    fun observeAll(): Flow<List<ProgressEntity>>

    /** Every row at once, for the backup writer. */
    @Query("SELECT * FROM progress")
    suspend fun all(): List<ProgressEntity>

    @Query("SELECT COUNT(*) FROM progress WHERE isKnown = 1")
    fun observeKnownCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM progress WHERE lastReviewedAt > 0")
    fun observeStartedCount(): Flow<Int>

    @Query("SELECT * FROM progress WHERE isBookmarked = 1")
    fun observeBookmarked(): Flow<List<ProgressEntity>>

    @Query("UPDATE progress SET isBookmarked = :bookmarked WHERE wordId = :wordId")
    suspend fun setBookmarked(wordId: String, bookmarked: Boolean)

    /**
     * Words answered wrong more often than right, worst first — the backing
     * query for mistake review. Requires at least two attempts so a single
     * unlucky tap does not brand a word as a weak spot.
     */
    @Query(
        """
        SELECT * FROM progress
        WHERE timesSeen >= 2 AND (timesCorrect * 1.0 / timesSeen) < :threshold
        ORDER BY (timesCorrect * 1.0 / timesSeen) ASC, timesSeen DESC
        LIMIT :limit
        """
    )
    suspend fun weakestWords(threshold: Float = 0.6f, limit: Int = 30): List<ProgressEntity>

    @Query("DELETE FROM progress")
    suspend fun deleteAll()
}

/** Voice recordings and their scores. Device-local; never uploaded in v1. */
@Dao
interface RecordingDao {

    @Upsert
    suspend fun upsert(recording: RecordingEntity): Long

    @Query("SELECT * FROM recordings WHERE wordId = :wordId ORDER BY recordedAt DESC")
    fun observeForWord(wordId: String): Flow<List<RecordingEntity>>

    @Query("SELECT * FROM recordings ORDER BY recordedAt DESC LIMIT :limit")
    fun observeRecent(limit: Int = 50): Flow<List<RecordingEntity>>

    @Query("SELECT * FROM recordings WHERE id = :id")
    suspend fun byId(id: Long): RecordingEntity?

    @Query("SELECT COUNT(*) FROM recordings")
    fun observeCount(): Flow<Int>

    @Query("SELECT AVG(scoreOverall) FROM recordings WHERE scoreOverall IS NOT NULL AND recordedAt >= :since")
    suspend fun averageScoreSince(since: Long): Float?

    /**
     * Recordings whose *accuracy* cleared the bar for the top band.
     *
     * Accuracy rather than the service's overall, for the same reason the score
     * card reads it that way: the overall folds in fluency, and fluency punishes
     * the careful delivery of someone nervous about speaking.
     */
    @Query("SELECT COUNT(*) FROM recordings WHERE scoreAccuracy >= :threshold")
    fun observeClearRecordingCount(threshold: Float): Flow<Int>

    @Query("DELETE FROM recordings WHERE id = :id")
    suspend fun deleteById(id: Long)

    /** Used when the learner clears their recordings; the files are deleted separately. */
    @Query("SELECT filePath FROM recordings")
    suspend fun allFilePaths(): List<String>

    @Query("DELETE FROM recordings")
    suspend fun deleteAll()
}

/** Per-phoneme error tallies behind "the sounds to work on". */
@Dao
interface WeakSoundDao {

    @Upsert
    suspend fun upsert(sound: WeakSoundEntity)

    @Query("SELECT * FROM weak_sounds WHERE phoneme = :phoneme")
    suspend fun byPhoneme(phoneme: String): WeakSoundEntity?

    @Query(
        """
        SELECT * FROM weak_sounds
        WHERE attemptCount >= :minAttempts
        ORDER BY (errorCount * 1.0 / attemptCount) DESC, errorCount DESC
        LIMIT :limit
        """
    )
    fun observeWeakest(minAttempts: Int = 3, limit: Int = 10): Flow<List<WeakSoundEntity>>

    /**
     * Sounds the learner used to get wrong and now mostly gets right.
     *
     * The attempt minimum is what stops one lucky recording counting as having
     * fixed a sound — changing how you make a sound is slow, and a badge that
     * can be won by accident is not worth having.
     */
    @Query(
        """
        SELECT COUNT(*) FROM weak_sounds
        WHERE attemptCount >= :minAttempts
          AND (errorCount * 1.0 / attemptCount) < :maxRate
        """
    )
    fun observeFixedSoundCount(minAttempts: Int, maxRate: Float): Flow<Int>

    @Query("SELECT * FROM weak_sounds")
    suspend fun all(): List<WeakSoundEntity>

    @Upsert
    suspend fun upsertAll(sounds: List<WeakSoundEntity>)

    @Query("DELETE FROM weak_sounds")
    suspend fun deleteAll()
}

/** Answered quiz questions. */
@Dao
interface QuizAttemptDao {

    @Upsert
    suspend fun upsert(attempt: QuizAttemptEntity)

    @Query("SELECT COUNT(*) FROM quiz_attempts WHERE answeredAt >= :since")
    suspend fun countSince(since: Long): Int

    @Query("SELECT COUNT(*) FROM quiz_attempts WHERE wasCorrect = 1 AND answeredAt >= :since")
    suspend fun correctCountSince(since: Long): Int

    @Query("SELECT DISTINCT wordId FROM quiz_attempts WHERE wasCorrect = 0 ORDER BY answeredAt DESC LIMIT :limit")
    suspend fun recentlyMissedWordIds(limit: Int = 30): List<String>

    @Query("DELETE FROM quiz_attempts")
    suspend fun deleteAll()
}

/**
 * Daily counters — streaks, the daily goal, and the speech budget.
 *
 * The increment queries use `INSERT … ON CONFLICT DO UPDATE` so a day's row is
 * created on first activity and bumped thereafter, without a read-modify-write
 * that could lose a concurrent update.
 */
@Dao
interface DailyStatDao {

    @Upsert
    suspend fun upsert(stat: DailyStatEntity)

    @Query("SELECT * FROM daily_stats WHERE date = :date")
    suspend fun forDate(date: String): DailyStatEntity?

    @Query("SELECT * FROM daily_stats WHERE date = :date")
    fun observeForDate(date: String): Flow<DailyStatEntity?>

    @Query("SELECT * FROM daily_stats ORDER BY date DESC LIMIT :limit")
    fun observeRecent(limit: Int = 30): Flow<List<DailyStatEntity>>

    @Query("SELECT * FROM daily_stats ORDER BY date ASC")
    suspend fun all(): List<DailyStatEntity>

    @Upsert
    suspend fun upsertAll(stats: List<DailyStatEntity>)

    /** Dates with any activity, newest first — the streak calculation reads this. */
    @Query(
        """
        SELECT date FROM daily_stats
        WHERE wordsStudied > 0 OR quizzesAnswered > 0 OR recordingsMade > 0
        ORDER BY date DESC
        LIMIT :limit
        """
    )
    suspend fun activeDates(limit: Int = 400): List<String>

    @Query(
        """
        INSERT INTO daily_stats (date, wordsStudied, chunksStudied, quizzesAnswered, quizzesCorrect, recordingsMade, secondsGraded, studySeconds, mistakesReviewed)
        VALUES (:date, :words, :chunks, :quizzes, :quizzesCorrect, :recordings, :secondsGraded, :studySeconds, :mistakesReviewed)
        ON CONFLICT(date) DO UPDATE SET
            wordsStudied = wordsStudied + :words,
            chunksStudied = chunksStudied + :chunks,
            quizzesAnswered = quizzesAnswered + :quizzes,
            quizzesCorrect = quizzesCorrect + :quizzesCorrect,
            recordingsMade = recordingsMade + :recordings,
            secondsGraded = secondsGraded + :secondsGraded,
            studySeconds = studySeconds + :studySeconds,
            mistakesReviewed = mistakesReviewed + :mistakesReviewed
        """
    )
    suspend fun increment(
        date: String,
        words: Int = 0,
        chunks: Int = 0,
        quizzes: Int = 0,
        quizzesCorrect: Int = 0,
        recordings: Int = 0,
        secondsGraded: Int = 0,
        studySeconds: Int = 0,
        mistakesReviewed: Int = 0
    )

    /**
     * Lifetime totals across every day.
     *
     * Badges are about a learner's whole history, not today, so they read these
     * rather than summing a page of daily rows in Kotlin.
     */
    @Query("SELECT COALESCE(SUM(wordsStudied), 0) FROM daily_stats")
    fun observeTotalWordsStudied(): Flow<Int>

    @Query("SELECT COALESCE(SUM(chunksStudied), 0) FROM daily_stats")
    fun observeTotalChunksStudied(): Flow<Int>

    @Query("SELECT COALESCE(SUM(mistakesReviewed), 0) FROM daily_stats")
    fun observeTotalMistakesReviewed(): Flow<Int>

    @Query("SELECT COALESCE(SUM(studySeconds), 0) FROM daily_stats WHERE date >= :since")
    suspend fun studySecondsSince(since: String): Int

    /** How many seconds of audio have been sent for scoring today. The cost cap reads this. */
    @Query("SELECT COALESCE(secondsGraded, 0) FROM daily_stats WHERE date = :date")
    suspend fun secondsGradedOn(date: String): Int?

    @Query("DELETE FROM daily_stats")
    suspend fun deleteAll()
}

/** Earned badges. */
@Dao
interface BadgeDao {

    @Upsert
    suspend fun upsert(badge: BadgeEntity)

    @Query("SELECT * FROM badges ORDER BY earnedAt DESC")
    fun observeAll(): Flow<List<BadgeEntity>>

    @Query("SELECT * FROM badges")
    suspend fun all(): List<BadgeEntity>

    @Upsert
    suspend fun upsertAll(badges: List<BadgeEntity>)

    @Query("SELECT EXISTS(SELECT 1 FROM badges WHERE badgeId = :badgeId)")
    suspend fun isEarned(badgeId: String): Boolean

    @Query("DELETE FROM badges")
    suspend fun deleteAll()
}

/** Sentences the learner wrote for themselves, one per word. */
@Dao
interface LearnerSentenceDao {

    @Upsert
    suspend fun upsert(sentence: LearnerSentenceEntity)

    @Query("SELECT * FROM learner_sentences WHERE wordId = :wordId")
    suspend fun forWord(wordId: String): LearnerSentenceEntity?

    @Query("SELECT * FROM learner_sentences")
    suspend fun all(): List<LearnerSentenceEntity>

    @Upsert
    suspend fun upsertAll(sentences: List<LearnerSentenceEntity>)

    @Query("SELECT COUNT(*) FROM learner_sentences")
    fun observeCount(): Flow<Int>

    @Query("DELETE FROM learner_sentences WHERE wordId = :wordId")
    suspend fun delete(wordId: String)

    @Query("DELETE FROM learner_sentences")
    suspend fun deleteAll()
}
