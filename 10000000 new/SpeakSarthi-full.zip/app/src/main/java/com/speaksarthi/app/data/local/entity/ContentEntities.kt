package com.speaksarthi.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * Content tables — the shipped library. These are replaced wholesale by a
 * content update; nothing a learner does is stored here.
 *
 * Every row is keyed on the workbook's `Word ID` ("VRB-001"), which is stable
 * across content revisions. WordMaster learned this the hard way: it keyed words
 * on an auto-generated row id with a unique index on the word text, so
 * re-importing a corrected word resolved as a conflict, replaced the row, and
 * cascade-deleted the learner's spaced-repetition history. Using the natural key
 * as the primary key removes that whole failure mode by construction — an
 * updated word keeps its identity, and progress rows keep pointing at it.
 */

@Entity(
    tableName = "words",
    indices = [
        Index(value = ["level"]),
        Index(value = ["partOfSpeech"]),
        Index(value = ["category"]),
        Index(value = ["orderIndex"])
    ]
)
data class WordEntity(
    @PrimaryKey val wordId: String,
    val word: String,
    val partOfSpeech: String,
    val category: String,
    /** CEFR code as stored: A1, A2, B1, B2. */
    val level: String,
    val frequency: String,
    val importance: String,
    val register: String,
    val ipa: String,
    val syllableBreak: String,
    val hindiPronunciation: String,
    val hindiMeaning: String,
    val simpleMeaning: String,
    val plainExplanation: String,
    val etymology: String,
    val mnemonic: String,
    val quickTip: String,
    val pronunciationTip: String,
    val spellingTip: String,
    /** Stored as a delimited string; see Converters. */
    val wordFamily: String,
    val prefixRootSuffix: String,
    val visualAssociation: String,
    val tone: String,
    val typicalContexts: String,
    val miniConversation: String,
    val confusingWords: String,
    val relatedWords: String,
    val synonyms: String,
    val antonyms: String,
    val emotionFeel: String,
    val commonMistakeWrong: String,
    val commonMistakeCorrect: String,
    val quickRecallPrompt: String,
    /**
     * Filename of this word's illustration, by convention `<wordId>.webp`.
     *
     * The artwork does not exist yet — it is drawn and added later — but the
     * filename is stored from the start so the card can reserve the space now
     * and nothing needs a schema change or a content regeneration when the
     * images arrive. Blank means this word is deliberately text-only.
     *
     * Stored rather than derived so two words can share one drawing, and so a
     * single word's artwork can be replaced without touching the convention.
     */
    val illustration: String = "",
    /** Position in the canonical ordering, used when the queue has no better signal. */
    val orderIndex: Int
)

@Entity(
    tableName = "chunks",
    foreignKeys = [
        ForeignKey(
            entity = WordEntity::class,
            parentColumns = ["wordId"],
            childColumns = ["wordId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["wordId"]),
        Index(value = ["type"])
    ]
)
data class ChunkEntity(
    @PrimaryKey val chunkId: String,
    val wordId: String,
    val text: String,
    /** COLLOCATION, PHRASAL or PATTERN. */
    val type: String,
    val orderIndex: Int
)

@Entity(
    tableName = "practice_items",
    foreignKeys = [
        ForeignKey(
            entity = WordEntity::class,
            parentColumns = ["wordId"],
            childColumns = ["wordId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["wordId"]),
        Index(value = ["type"])
    ]
)
data class PracticeItemEntity(
    @PrimaryKey val itemId: String,
    val wordId: String,
    val text: String,
    val highlight: String,
    val type: String,
    val orderIndex: Int
)

/**
 * The five practice-zone exercises for one word — the material behind part three
 * of the card.
 *
 * One row per word rather than a row per exercise: they are authored together,
 * shown together, and every word has exactly one of each. A table of 5,000 rows
 * keyed on (wordId, type) would buy nothing and cost a join on every card.
 *
 * The multiple-choice columns do double duty — they also feed the standalone
 * quiz mode, which is the only quiz format v1 ships.
 */
@Entity(
    tableName = "exercises",
    foreignKeys = [
        ForeignKey(
            entity = WordEntity::class,
            parentColumns = ["wordId"],
            childColumns = ["wordId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["wordId"])]
)
data class ExerciseEntity(
    @PrimaryKey val wordId: String,

    // 1 — multiple choice
    val mcqQuestion: String,
    /** Options joined with the converter delimiter, in presentation order. */
    val mcqOptions: String,
    val mcqAnswerIndex: Int,

    // 2 — fill in the blank
    val fillBlankPrompt: String = "",
    val fillBlankAnswer: String = "",

    // 3 — sentence correction
    val findFixWrong: String = "",
    val findFixCorrected: String = "",

    // 4 — translate from Hindi
    val translatePrompt: String = "",
    val translateAnswer: String = "",

    // 5 — write your own sentence. Open-ended: there is no answer to check, so
    // the learner's attempt is kept and shown back rather than graded.
    val writeYourOwnPrompt: String = ""
)
