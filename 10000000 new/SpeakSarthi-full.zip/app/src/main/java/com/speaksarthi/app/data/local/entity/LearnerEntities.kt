package com.speaksarthi.app.data.local.entity

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation

/**
 * Learner tables — everything the person generates. A content update must never
 * touch these, which is why they are keyed on [WordEntity.wordId] rather than on
 * anything that changes when content is corrected.
 */

@Entity(
    tableName = "progress",
    foreignKeys = [
        ForeignKey(
            entity = WordEntity::class,
            parentColumns = ["wordId"],
            childColumns = ["wordId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["nextReviewAt"]),
        Index(value = ["isBookmarked"]),
        Index(value = ["isKnown"])
    ]
)
data class ProgressEntity(
    @PrimaryKey val wordId: String,
    val easeFactor: Double = 2.5,
    val intervalDays: Int = 0,
    val repetitions: Int = 0,
    /** Epoch millis. 0 means "never scheduled", i.e. a brand-new word. */
    val nextReviewAt: Long = 0L,
    val lastReviewedAt: Long = 0L,
    val timesSeen: Int = 0,
    val timesCorrect: Int = 0,
    val isBookmarked: Boolean = false,
    val isKnown: Boolean = false
)

/** A word joined to its study state. Room builds this with a single query. */
data class WordWithProgressRow(
    @Embedded val word: WordEntity,
    @Relation(parentColumn = "wordId", entityColumn = "wordId")
    val progress: ProgressEntity?
)

/**
 * One voice recording, kept on the device only.
 *
 * [filePath] points at app-private storage — recordings are deliberately not
 * backed up and never leave the phone in v1. When human review arrives in v2 an
 * upload path is added, and [uploadedAt] is the hook for it; storing the field
 * now means v2 does not require a migration of existing rows.
 */
@Entity(
    tableName = "recordings",
    foreignKeys = [
        ForeignKey(
            entity = WordEntity::class,
            parentColumns = ["wordId"],
            childColumns = ["wordId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["wordId"]),
        Index(value = ["practiceItemId"]),
        Index(value = ["recordedAt"])
    ]
)
data class RecordingEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val wordId: String,
    val practiceItemId: String,
    val filePath: String,
    val durationMillis: Long,
    val recordedAt: Long,
    // Scores from the pronunciation-assessment service, 0-100, all null until
    // the clip has been scored. Held as plain nullable columns rather than a
    // nullable @Embedded so the generated schema is unambiguous.
    //
    // These are the raw service numbers. What the learner is *shown* is a
    // separate presentation decision: showing a bare failing percentage to
    // someone already embarrassed about speaking is the fastest way to lose
    // them, so the UI turns these into a band plus the one sound to fix next.
    val scoreAccuracy: Float? = null,
    val scoreFluency: Float? = null,
    val scoreCompleteness: Float? = null,
    val scoreOverall: Float? = null,
    /** Phonemes the service flagged, delimited; feeds weak-sound tracking. */
    val weakPhonemes: String? = null,
    /** Reserved for the v2 human-review upload. Null means never uploaded. */
    val uploadedAt: Long? = null
)

/**
 * Per-phoneme error tally across all of a learner's recordings. This is what
 * makes "your /v/ and /w/ keep swapping" possible instead of a generic score.
 */
@Entity(tableName = "weak_sounds")
data class WeakSoundEntity(
    @PrimaryKey val phoneme: String,
    val errorCount: Int = 0,
    val attemptCount: Int = 0,
    val lastSeenAt: Long = 0L
)

/** One answered MCQ. Kept per attempt so mistake review can resurface real misses. */
@Entity(
    tableName = "quiz_attempts",
    foreignKeys = [
        ForeignKey(
            entity = WordEntity::class,
            parentColumns = ["wordId"],
            childColumns = ["wordId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["wordId"]),
        Index(value = ["answeredAt"]),
        Index(value = ["wasCorrect"])
    ]
)
data class QuizAttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val wordId: String,
    val selectedIndex: Int,
    val wasCorrect: Boolean,
    val answeredAt: Long
)

/**
 * Counters for one local calendar day.
 *
 * [secondsGraded] is the cost meter. Cloud pronunciation scoring is billed per
 * minute of audio, so the app has to know how much a learner has spent today
 * before sending another clip — this column is what the daily cap reads.
 */
@Entity(tableName = "daily_stats")
data class DailyStatEntity(
    /** Local date, `yyyy-MM-dd`. */
    @PrimaryKey val date: String,
    val wordsStudied: Int = 0,
    val chunksStudied: Int = 0,
    val quizzesAnswered: Int = 0,
    val quizzesCorrect: Int = 0,
    val recordingsMade: Int = 0,
    val secondsGraded: Int = 0,
    val studySeconds: Int = 0,
    /**
     * Words reviewed through mistake review rather than the normal queue.
     *
     * Counted separately because going back to what you got wrong is the part
     * almost everyone skips, and it is worth being able to say so.
     */
    val mistakesReviewed: Int = 0
)

/** An earned badge. Rows exist only once earned, so absence means not yet earned. */
@Entity(tableName = "badges")
data class BadgeEntity(
    @PrimaryKey val badgeId: String,
    val earnedAt: Long
)

/**
 * A sentence the learner wrote themselves, from the last practice-zone exercise.
 *
 * There is no answer to mark it against, which is the point: the card keeps what
 * they wrote and shows it back on the next review so they can see their own
 * progress. For a learner whose whole problem is being afraid of getting it
 * wrong, one exercise that cannot be marked wrong is worth having.
 */
@Entity(
    tableName = "learner_sentences",
    foreignKeys = [
        ForeignKey(
            entity = WordEntity::class,
            parentColumns = ["wordId"],
            childColumns = ["wordId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class LearnerSentenceEntity(
    @PrimaryKey val wordId: String,
    val text: String,
    val updatedAt: Long
)
