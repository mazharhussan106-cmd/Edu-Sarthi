package com.speaksarthi.app.data.preferences

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import com.speaksarthi.app.presentation.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Settings and small bits of app state.
 *
 * Everything here is per-device and survives an app update but not an uninstall,
 * which is the right lifetime for a theme choice or a daily goal. Learning data
 * lives in Room, never here.
 */
@Singleton
class AppPreferences @Inject constructor(
    private val dataStore: DataStore<Preferences>
) {

    val contentVersion: Flow<Int> =
        dataStore.data.map { it[KEY_CONTENT_VERSION] ?: 0 }

    suspend fun setContentVersion(version: Int) {
        dataStore.edit { it[KEY_CONTENT_VERSION] = version }
    }

    val themeMode: Flow<ThemeMode> =
        dataStore.data.map { ThemeMode.fromStoredValue(it[KEY_THEME_MODE]) }

    suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { it[KEY_THEME_MODE] = mode.name }
    }

    /** Words per day the learner is aiming for. */
    val dailyGoal: Flow<Int> =
        dataStore.data.map { it[KEY_DAILY_GOAL] ?: DEFAULT_DAILY_GOAL }

    suspend fun setDailyGoal(words: Int) {
        dataStore.edit { it[KEY_DAILY_GOAL] = words.coerceIn(1, 200) }
    }

    /** CEFR level the learner is working through, set by the placement test or by hand. */
    val currentLevel: Flow<String> =
        dataStore.data.map { it[KEY_CURRENT_LEVEL] ?: "A1" }

    suspend fun setCurrentLevel(level: String) {
        dataStore.edit { it[KEY_CURRENT_LEVEL] = level }
    }

    /** False until the learner has taken or explicitly skipped the placement test. */
    val hasCompletedOnboarding: Flow<Boolean> =
        dataStore.data.map { it[KEY_ONBOARDED] ?: false }

    suspend fun setOnboardingComplete(complete: Boolean) {
        dataStore.edit { it[KEY_ONBOARDED] = complete }
    }


    /**
     * Playback speed for spoken words and sentences, 0.5 to 1.5.
     *
     * A setting rather than a constant because a learner drilling a hard word
     * slows it right down, and the same learner skimming a familiar sentence
     * does not want to wait through it.
     */
    val audioSpeed: Flow<Float> =
        dataStore.data.map { it[KEY_AUDIO_SPEED] ?: DEFAULT_AUDIO_SPEED }

    suspend fun setAudioSpeed(speed: Float) {
        dataStore.edit { it[KEY_AUDIO_SPEED] = speed.coerceIn(0.5f, 1.5f) }
    }

    /**
     * Where illustrations are fetched from, e.g. `https://cdn.example.com/art`.
     *
     * Empty until there is somewhere to host them, and empty is a supported
     * state: every card falls back to its text frame and nothing breaks. Stored
     * rather than hardcoded so the host can change — or be pointed at a staging
     * bucket during testing — without shipping a new build.
     */
    val illustrationBaseUrl: Flow<String> =
        dataStore.data.map { it[KEY_ILLUSTRATION_BASE_URL] ?: "" }

    suspend fun setIllustrationBaseUrl(url: String) {
        dataStore.edit { it[KEY_ILLUSTRATION_BASE_URL] = url.trim() }
    }

    /**
     * The learner's daily reminders, serialised as `HH:mm:enabled` triples.
     *
     * Three of them, always — the slots exist whether or not they are switched
     * on, so turning one off and back on keeps the time the learner chose rather
     * than resetting it to a default they never picked.
     */
    val reminders: Flow<String> =
        dataStore.data.map { it[KEY_REMINDERS] ?: "" }

    suspend fun setReminders(serialised: String) {
        dataStore.edit { it[KEY_REMINDERS] = serialised }
    }

    /** False until the learner has been asked for notification permission once. */
    val hasAskedForNotifications: Flow<Boolean> =
        dataStore.data.map { it[KEY_ASKED_NOTIFICATIONS] ?: false }

    suspend fun setAskedForNotifications(asked: Boolean) {
        dataStore.edit { it[KEY_ASKED_NOTIFICATIONS] = asked }
    }

    /**
     * The anonymous profile, as four small values rather than a serialised blob.
     *
     * Kept in DataStore rather than Room because identity should survive anything
     * that clears learning data, and because reading it must never wait on a
     * database that might still be seeding.
     */
    val localId: Flow<String> = dataStore.data.map { it[KEY_LOCAL_ID] ?: "" }

    val accountId: Flow<String> = dataStore.data.map { it[KEY_ACCOUNT_ID] ?: "" }

    val displayName: Flow<String> = dataStore.data.map { it[KEY_DISPLAY_NAME] ?: "" }

    val email: Flow<String> = dataStore.data.map { it[KEY_EMAIL] ?: "" }

    val profileCreatedAt: Flow<Long> = dataStore.data.map { it[KEY_PROFILE_CREATED] ?: 0L }

    suspend fun setLocalProfile(localId: String, createdAt: Long) {
        dataStore.edit {
            it[KEY_LOCAL_ID] = localId
            it[KEY_PROFILE_CREATED] = createdAt
        }
    }

    suspend fun setAccount(accountId: String, displayName: String, email: String) {
        dataStore.edit {
            it[KEY_ACCOUNT_ID] = accountId
            it[KEY_DISPLAY_NAME] = displayName
            it[KEY_EMAIL] = email
        }
    }

    /** Clears the account fields only. The local id and all learning data stay. */
    suspend fun clearAccount() {
        dataStore.edit {
            it.remove(KEY_ACCOUNT_ID)
            it.remove(KEY_DISPLAY_NAME)
            it.remove(KEY_EMAIL)
        }
    }

    /**
     * The bearer token for this install's session with the server.
     *
     * Not a secret worth protecting beyond normal app-private storage: it
     * identifies an account, it does not authorise spending beyond what that
     * account already has, and the server re-checks every balance itself. It is
     * kept only so the app does not have to introduce itself on every request.
     */
    val sessionToken: Flow<String> = dataStore.data.map { it[KEY_SESSION_TOKEN] ?: "" }

    suspend fun setSessionToken(token: String) {
        dataStore.edit { it[KEY_SESSION_TOKEN] = token }
    }

    suspend fun clearSessionToken() {
        dataStore.edit { it.remove(KEY_SESSION_TOKEN) }
    }

    /**
     * The last balance the server reported.
     *
     * A cache, and only ever written from a server response — never incremented
     * or decremented locally. Its whole job is to let a screen show a number and
     * disable a button without a round trip per card. If it is wrong, the next
     * server response corrects it; if the app trusted it instead, a rooted
     * device could edit it and spend somebody else's money.
     */
    val cachedCredits: Flow<Int> = dataStore.data.map { it[KEY_CREDITS] ?: 0 }

    val cachedCreditsCheckedAt: Flow<Long> = dataStore.data.map { it[KEY_CREDITS_AT] ?: 0L }

    val isSignedIn: Flow<Boolean> = dataStore.data.map { it[KEY_SIGNED_IN] ?: false }

    suspend fun setCachedCredits(credits: Int, signedIn: Boolean, checkedAt: Long) {
        dataStore.edit {
            it[KEY_CREDITS] = credits.coerceAtLeast(0)
            it[KEY_SIGNED_IN] = signedIn
            it[KEY_CREDITS_AT] = checkedAt
        }
    }

    /** True once the learner has seen and accepted the privacy notice. */
    val hasAcceptedPrivacy: Flow<Boolean> =
        dataStore.data.map { it[KEY_PRIVACY_ACCEPTED] ?: false }

    suspend fun setPrivacyAccepted(accepted: Boolean) {
        dataStore.edit { it[KEY_PRIVACY_ACCEPTED] = accepted }
    }

    companion object {
        const val STORE_NAME = "speak_sarthi_prefs"

        const val DEFAULT_DAILY_GOAL = 10
        const val DEFAULT_AUDIO_SPEED = 1.0f


        private val KEY_CONTENT_VERSION = intPreferencesKey("content_version")
        private val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        private val KEY_DAILY_GOAL = intPreferencesKey("daily_goal")
        private val KEY_CURRENT_LEVEL = stringPreferencesKey("current_level")
        private val KEY_ONBOARDED = booleanPreferencesKey("onboarding_complete")
        private val KEY_ILLUSTRATION_BASE_URL = stringPreferencesKey("illustration_base_url")
        private val KEY_AUDIO_SPEED = floatPreferencesKey("audio_speed")
        private val KEY_REMINDERS = stringPreferencesKey("reminders")
        private val KEY_ASKED_NOTIFICATIONS = booleanPreferencesKey("asked_notifications")
        private val KEY_LOCAL_ID = stringPreferencesKey("local_id")
        private val KEY_PROFILE_CREATED = longPreferencesKey("profile_created_at")
        private val KEY_ACCOUNT_ID = stringPreferencesKey("account_id")
        private val KEY_DISPLAY_NAME = stringPreferencesKey("display_name")
        private val KEY_EMAIL = stringPreferencesKey("email")
        private val KEY_SESSION_TOKEN = stringPreferencesKey("session_token")
        private val KEY_CREDITS = intPreferencesKey("cached_credits")
        private val KEY_CREDITS_AT = longPreferencesKey("cached_credits_at")
        private val KEY_SIGNED_IN = booleanPreferencesKey("signed_in")
        private val KEY_PRIVACY_ACCEPTED = booleanPreferencesKey("privacy_accepted")
    }
}
