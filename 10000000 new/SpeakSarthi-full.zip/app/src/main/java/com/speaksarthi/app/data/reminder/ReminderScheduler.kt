package com.speaksarthi.app.data.reminder

import android.content.Context
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.domain.usecase.reminders.Reminder
import com.speaksarthi.app.domain.usecase.reminders.ReminderSchedule
import com.speaksarthi.app.util.Clock
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Puts the learner's reminders on WorkManager and keeps them there.
 *
 * Each reminder is one-shot work under a stable unique name, replaced rather
 * than added to, which is what stops a learner who edits their 8am reminder four
 * times from being woken four times.
 */
@Singleton
class ReminderScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val preferences: AppPreferences,
    private val clock: Clock
) {

    private val workManager: WorkManager get() = WorkManager.getInstance(context)

    /** Re-applies every reminder from settings. Safe to call as often as you like. */
    suspend fun applyAll() {
        val reminders = ReminderSchedule.parse(preferences.reminders.first())
        reminders.forEach { schedule(it) }
    }

    /**
     * Called by the worker after it fires, to queue tomorrow's.
     *
     * Reads the setting again rather than trusting what was scheduled yesterday:
     * the learner may have turned this reminder off since, and a reminder that
     * keeps arriving after being switched off is the fastest route to the app's
     * notifications being blocked wholesale.
     */
    suspend fun rescheduleSlot(slot: Int) {
        val reminder = ReminderSchedule.parse(preferences.reminders.first())
            .firstOrNull { it.slot == slot }
            ?: return
        schedule(reminder)
    }

    private fun schedule(reminder: Reminder) {
        val name = ReminderSchedule.workName(reminder.slot)

        if (!reminder.enabled) {
            workManager.cancelUniqueWork(name)
            return
        }

        val delay = ReminderSchedule.delayMillis(reminder, clock.nowLocalDateTime())

        val request = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(Data.Builder().putInt(ReminderWorker.KEY_SLOT, reminder.slot).build())
            .addTag(TAG)
            .build()

        // REPLACE, not KEEP: saving a new time must move the reminder, and KEEP
        // would leave yesterday's time in place while the settings screen showed
        // the new one.
        workManager.enqueueUniqueWork(name, ExistingWorkPolicy.REPLACE, request)
    }

    /** Turns everything off — used when the learner disables reminders wholesale. */
    fun cancelAll() {
        repeat(ReminderSchedule.MAX_REMINDERS) { slot ->
            workManager.cancelUniqueWork(ReminderSchedule.workName(slot))
        }
    }

    private companion object {
        const val TAG = "study_reminder"
    }
}
