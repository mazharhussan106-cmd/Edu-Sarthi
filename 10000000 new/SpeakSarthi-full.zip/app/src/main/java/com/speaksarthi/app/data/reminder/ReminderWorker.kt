package com.speaksarthi.app.data.reminder

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.speaksarthi.app.R
import com.speaksarthi.app.domain.repository.StudyRepository
import com.speaksarthi.app.domain.usecase.reminders.ReminderSchedule
import com.speaksarthi.app.presentation.MainActivity
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first

/**
 * Posts one daily reminder, then schedules the next one.
 *
 * WorkManager's periodic work has a fifteen-minute floor on its interval and no
 * guarantee about *when* inside a period it runs, which is useless for "remind
 * me at 8am". So each reminder is one-shot work that reschedules itself after
 * firing — the standard way to get an exact-ish daily time without an alarm
 * permission the Play Store now asks awkward questions about.
 */
@HiltWorker
class ReminderWorker @AssistedInject constructor(
    @Assisted private val context: Context,
    @Assisted params: WorkerParameters,
    private val study: StudyRepository,
    private val scheduler: ReminderScheduler
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val slot = inputData.getInt(KEY_SLOT, 0)

        // Rescheduled first. If posting the notification throws — a permission
        // revoked, a manufacturer's notification shim misbehaving — the chain
        // must not end there, silently, with the learner never reminded again.
        scheduler.rescheduleSlot(slot)

        if (!canNotify()) return Result.success()

        val dueCount = runCatching { study.observeDueCount().first() }.getOrDefault(0)
        val streak = runCatching { study.currentStreak() }.getOrDefault(0)

        // Nothing due and no streak to protect means there is nothing worth
        // interrupting someone for. A reminder that says nothing is how an app
        // teaches people to ignore it.
        if (dueCount == 0 && streak == 0) return Result.success()

        post(
            slot = slot,
            text = ReminderSchedule.message(slot, dueCount, streak)
        )
        return Result.success()
    }

    private fun canNotify(): Boolean {
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return false

        // POST_NOTIFICATIONS is a runtime permission from Android 13. Below that
        // it does not exist and must not be checked.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true

        return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun post(slot: Int, text: String) {
        ensureChannel(context)

        val openApp = PendingIntent.getActivity(
            context,
            slot,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(ReminderSchedule.NOTIFICATION_TITLE)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .build()

        runCatching {
            // One id per slot, so three reminders never stack into a pile and a
            // missed one is replaced rather than added to.
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID_BASE + slot, notification)
        }
    }

    companion object {
        const val KEY_SLOT = "slot"

        const val CHANNEL_ID = "study_reminders"
        private const val NOTIFICATION_ID_BASE = 4200

        /**
         * Created on demand rather than at startup: a learner who never turns a
         * reminder on should not find a notification category in their settings
         * for something the app does not do.
         */
        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

            val manager = context.getSystemService(NotificationManager::class.java) ?: return
            if (manager.getNotificationChannel(CHANNEL_ID) != null) return

            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Study reminders",
                    // DEFAULT, not HIGH: this is a nudge, not an emergency, and
                    // an importance that vibrates gets the whole channel muted.
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "A quiet daily nudge to practise. At most three a day."
                    setShowBadge(false)
                }
            )
        }
    }
}
