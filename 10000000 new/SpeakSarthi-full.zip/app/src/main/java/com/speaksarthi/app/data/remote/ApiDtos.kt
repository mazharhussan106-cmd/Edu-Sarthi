package com.speaksarthi.app.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * The wire shapes the Speak Sarthi server speaks.
 *
 * Deliberately dumb: no logic, no defaults that hide a missing field, and
 * nothing the app can set that the server does not re-check. The one thing
 * worth noticing is what is *absent* — nothing here lets the app state a
 * balance. It can only ever be told one.
 */

@Serializable
data class SessionRequest(val localId: String)

@Serializable
data class SessionResponse(
    val token: String,
    val balance: Int,
    val signedIn: Boolean = false
)

@Serializable
data class BalanceResponse(
    val balance: Int,
    val signedIn: Boolean = false
)

@Serializable
data class LinkRequest(val idToken: String)

@Serializable
data class LinkResponse(
    /** Reissued, because merging two accounts can change which one this is. */
    val token: String,
    val balance: Int,
    val signedIn: Boolean = true,
    val email: String? = null
)

@Serializable
data class PurchaseRequest(
    val productId: String,
    val purchaseToken: String
)

@Serializable
data class PurchaseResponse(
    /** "purchased", "pending", or absent on older responses. */
    val state: String = "",
    /** False when this token had already been redeemed. Success, not an error. */
    val granted: Boolean = false,
    val balance: Int = 0
)

@Serializable
data class EarnRequest(
    val kind: String,
    val ref: String
)

@Serializable
data class EarnResponse(
    val granted: Boolean = false,
    val balance: Int = 0
)

/** What the server sends instead of a body when it refuses. */
@Serializable
data class ApiErrorBody(
    @SerialName("error") val code: String = "",
    val message: String = ""
)
