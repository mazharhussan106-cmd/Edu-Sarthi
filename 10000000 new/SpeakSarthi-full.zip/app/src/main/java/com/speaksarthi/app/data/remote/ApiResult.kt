package com.speaksarthi.app.data.remote

/**
 * What came back from the server.
 *
 * Every failure a learner can actually hit is a named case rather than an
 * exception, for the same reason [com.speaksarthi.app.domain.model.ScoringOutcome]
 * is: "you have no credits", "you are offline" and "the server is having a bad
 * day" each need a different sentence, and collapsing them into one throw is how
 * an app ends up telling someone with no signal that something went wrong.
 */
sealed interface ApiResult<out T> {
    data class Ok<T>(val value: T) : ApiResult<T>

    /** No proxy address in this build. Scoring is off; everything else works. */
    data object NotConfigured : ApiResult<Nothing>

    data object Offline : ApiResult<Nothing>

    /** The session token was rejected. The caller should get a new one and retry once. */
    data object Unauthorized : ApiResult<Nothing>

    /** Out of credits. */
    data class NoCredits(val balance: Int) : ApiResult<Nothing>

    /** Refused for a reason the learner could act on, or a server fault. */
    data class Failed(
        val code: String,
        val message: String,
        val isRetryable: Boolean = true
    ) : ApiResult<Nothing>
}

inline fun <T> ApiResult<T>.onOk(action: (T) -> Unit): ApiResult<T> {
    if (this is ApiResult.Ok) action(value)
    return this
}

fun <T> ApiResult<T>.valueOrNull(): T? = (this as? ApiResult.Ok)?.value
