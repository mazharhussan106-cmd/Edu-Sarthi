package com.speaksarthi.app.data.remote

import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.domain.repository.AccountRepository
import com.speaksarthi.app.util.Clock
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Keeps this install's session with the server alive.
 *
 * A session is bootstrapped from the profile's `localId`, which is created on
 * first launch and never regenerated — it is the only thread connecting a
 * learner to credits they have already been granted. Losing it would look to the
 * server like a brand-new install, and the welcome credits already spent would
 * be gone with it.
 *
 * Everything is serialised behind one lock. Without it, the home screen, the
 * speaking screen and the paywall all opening at once would each notice there is
 * no token and each bootstrap a session, and on a fresh install that means
 * several accounts where there should be one.
 */
@Singleton
class SessionManager @Inject constructor(
    private val api: SpeakSarthiApi,
    private val accounts: AccountRepository,
    private val preferences: AppPreferences,
    private val clock: Clock
) {

    private val lock = Mutex()

    /** Whether there is a server to have a session with at all. */
    fun isConfigured(): Boolean = api.isConfigured()

    /**
     * A usable token, bootstrapping one if this install has never had a session.
     *
     * Null means there is no token and no way to get one right now — no proxy
     * configured, or the network is down. Callers treat that as "scoring is
     * unavailable", never as "the learner has no credits", because those are
     * very different things to be told.
     */
    suspend fun token(): String? {
        if (!api.isConfigured()) return null

        val existing = preferences.sessionToken.first()
        if (existing.isNotBlank()) return existing

        return lock.withLock {
            // Re-read inside the lock: another caller may have bootstrapped
            // while this one was waiting, and starting a second session would
            // strand the first account's credits.
            val current = preferences.sessionToken.first()
            if (current.isNotBlank()) return@withLock current
            bootstrap()
        }
    }

    /**
     * Throws away the current token and gets a new one.
     *
     * Called after the server rejects a token — expired, or issued for an
     * account that has since been merged into another by signing in on a second
     * device. The `localId` is unchanged, so the new session lands on the same
     * account with the same balance.
     */
    suspend fun refresh(): String? = lock.withLock {
        preferences.clearSessionToken()
        bootstrap()
    }

    /** Stores the token the server reissued after linking a Google account. */
    suspend fun adopt(token: String) {
        preferences.setSessionToken(token)
    }

    private suspend fun bootstrap(): String? {
        val localId = accounts.profile().localId
        if (localId.isBlank()) return null

        return when (val result = api.startSession(localId)) {
            is ApiResult.Ok -> {
                preferences.setSessionToken(result.value.token)
                preferences.setCachedCredits(
                    credits = result.value.balance,
                    signedIn = result.value.signedIn,
                    checkedAt = clock.nowMillis()
                )
                result.value.token
            }
            // Every failure is the same answer here — no token — but they are
            // deliberately not collapsed at the call site, where "you are
            // offline" and "this build has no server" say different things.
            else -> null
        }
    }
}
