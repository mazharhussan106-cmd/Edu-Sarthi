package com.speaksarthi.app.data.remote

import com.speaksarthi.app.data.speech.SpeechServiceConfig
import com.speaksarthi.app.di.IoDispatcher
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.UnknownHostException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Everything the app says to its own server, except sending audio.
 *
 * Audio stays in [com.speaksarthi.app.data.speech.PronunciationScorer] because
 * that call is shaped by the speech service's protocol rather than this one's,
 * and because it is the only request whose body is not JSON.
 *
 * Nothing here decides anything. The app cannot grant itself credits, cannot say
 * what a purchase was worth, and cannot assert that it earned a bonus — it can
 * only report that something happened and be told the result. That asymmetry is
 * the whole design, and it is why this class is so thin.
 */
interface SpeakSarthiApi {

    fun isConfigured(): Boolean

    /**
     * Introduces this install and gets a session token back.
     *
     * Anonymous — no account, no sign-in. Called on first launch and whenever a
     * token is rejected.
     */
    suspend fun startSession(localId: String): ApiResult<SessionResponse>

    suspend fun balance(token: String): ApiResult<BalanceResponse>

    /** Attaches a Google identity. Returns a **new** token; the old one is stale. */
    suspend fun link(token: String, idToken: String): ApiResult<LinkResponse>

    /** Reports a Play purchase for verification. The server decides what it was worth. */
    suspend fun redeemPurchase(
        token: String,
        productId: String,
        purchaseToken: String
    ): ApiResult<PurchaseResponse>

    /** Reports something that earns credits. The server decides whether it pays. */
    suspend fun claimEarned(token: String, kind: String, reference: String): ApiResult<EarnResponse>
}

@Singleton
class HttpSpeakSarthiApi @Inject constructor(
    private val config: SpeechServiceConfig,
    private val client: OkHttpClient,
    private val json: Json,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : SpeakSarthiApi {

    override fun isConfigured(): Boolean = config.usesProxy

    override suspend fun startSession(localId: String): ApiResult<SessionResponse> =
        post("/v1/session", null, SessionRequest(localId), SessionRequest.serializer(), SessionResponse.serializer())

    override suspend fun balance(token: String): ApiResult<BalanceResponse> =
        get("/v1/balance", token, BalanceResponse.serializer())

    override suspend fun link(token: String, idToken: String): ApiResult<LinkResponse> =
        post("/v1/link", token, LinkRequest(idToken), LinkRequest.serializer(), LinkResponse.serializer())

    override suspend fun redeemPurchase(
        token: String,
        productId: String,
        purchaseToken: String
    ): ApiResult<PurchaseResponse> = post(
        "/v1/purchase",
        token,
        PurchaseRequest(productId, purchaseToken),
        PurchaseRequest.serializer(),
        PurchaseResponse.serializer()
    )

    override suspend fun claimEarned(
        token: String,
        kind: String,
        reference: String
    ): ApiResult<EarnResponse> = post(
        "/v1/earn",
        token,
        EarnRequest(kind, reference),
        EarnRequest.serializer(),
        EarnResponse.serializer()
    )

    // ---- plumbing ----------------------------------------------------------

    private suspend fun <Req, Res> post(
        path: String,
        token: String?,
        body: Req,
        requestSerializer: kotlinx.serialization.KSerializer<Req>,
        responseSerializer: kotlinx.serialization.KSerializer<Res>
    ): ApiResult<Res> = execute(responseSerializer) {
        Request.Builder()
            .url(config.proxyEndpoint(path))
            .post(json.encodeToString(requestSerializer, body).toRequestBody(JSON_MEDIA_TYPE))
            .applyAuth(token)
            .build()
    }

    private suspend fun <Res> get(
        path: String,
        token: String?,
        responseSerializer: kotlinx.serialization.KSerializer<Res>
    ): ApiResult<Res> = execute(responseSerializer) {
        Request.Builder()
            .url(config.proxyEndpoint(path))
            .get()
            .applyAuth(token)
            .build()
    }

    private fun Request.Builder.applyAuth(token: String?) = apply {
        header("Accept", "application/json")
        if (!token.isNullOrBlank()) header("Authorization", "Bearer $token")
    }

    private suspend fun <Res> execute(
        serializer: kotlinx.serialization.KSerializer<Res>,
        build: () -> Request
    ): ApiResult<Res> = withContext(ioDispatcher) {
        if (!config.usesProxy) return@withContext ApiResult.NotConfigured

        val request = try {
            build()
        } catch (error: IllegalArgumentException) {
            // A malformed proxy address is a build-configuration mistake, not
            // something a retry will fix.
            return@withContext ApiResult.Failed(
                code = "bad_endpoint",
                message = "The server address is not valid",
                isRetryable = false
            )
        }

        try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()

                if (response.isSuccessful) {
                    return@withContext try {
                        ApiResult.Ok(json.decodeFromString(serializer, body))
                    } catch (error: Exception) {
                        ApiResult.Failed("bad_response", "The server sent something unreadable")
                    }
                }

                val error = runCatching {
                    json.decodeFromString(ApiErrorBody.serializer(), body)
                }.getOrNull()

                when (response.code) {
                    401 -> ApiResult.Unauthorized
                    402 -> ApiResult.NoCredits(0)
                    // 429 is retryable but not immediately; the caller backs off.
                    429 -> ApiResult.Failed("rate_limited", "Too many requests just now")
                    in 500..599 -> ApiResult.Failed(
                        error?.code.orEmpty().ifBlank { "server_error" },
                        "The server is having trouble"
                    )
                    else -> ApiResult.Failed(
                        error?.code.orEmpty().ifBlank { "request_failed" },
                        error?.message.orEmpty().ifBlank { "That did not work" },
                        isRetryable = false
                    )
                }
            }
        } catch (error: UnknownHostException) {
            ApiResult.Offline
        } catch (error: IOException) {
            ApiResult.Offline
        }
    }

    private companion object {
        val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }
}
