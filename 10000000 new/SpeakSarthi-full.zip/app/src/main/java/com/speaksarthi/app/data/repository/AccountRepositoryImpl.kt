package com.speaksarthi.app.data.repository

import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.di.IoDispatcher
import com.speaksarthi.app.domain.model.Profile
import com.speaksarthi.app.domain.repository.AccountRepository
import com.speaksarthi.app.util.Clock
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AccountRepositoryImpl @Inject constructor(
    private val preferences: AppPreferences,
    private val clock: Clock,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : AccountRepository {

    /**
     * Guards profile creation.
     *
     * Several things ask for the profile at launch — the home screen, the
     * session bootstrap, the backup writer — and without this they can race into
     * creating two local ids, the second overwriting the first. That would
     * detach a learner's work from its identity on the very first launch, which
     * is precisely the failure this whole idea exists to prevent. It would now
     * also strand their welcome credits on an account nothing can reach again.
     */
    private val creationLock = Mutex()

    override fun observeProfile(): Flow<Profile> = combine(
        preferences.localId,
        preferences.accountId,
        preferences.displayName,
        preferences.email,
        preferences.profileCreatedAt
    ) { localId, accountId, name, email, createdAt ->
        Profile(
            localId = localId,
            accountId = accountId,
            displayName = name,
            email = email,
            createdAt = createdAt
        )
    }

    override suspend fun profile(): Profile = withContext(ioDispatcher) {
        creationLock.withLock {
            val existing = preferences.localId.first()
            if (existing.isBlank()) {
                // A random id, not the Android id or anything else derived from
                // the hardware. A device-derived identifier is a tracking
                // identifier whatever it is used for, and this one only has to be
                // unique, not meaningful.
                val fresh = UUID.randomUUID().toString()
                preferences.setLocalProfile(localId = fresh, createdAt = clock.nowMillis())
            }
        }

        Profile(
            localId = preferences.localId.first(),
            accountId = preferences.accountId.first(),
            displayName = preferences.displayName.first(),
            email = preferences.email.first(),
            createdAt = preferences.profileCreatedAt.first()
        )
    }

    override suspend fun signIn(accountId: String, displayName: String, email: String) =
        withContext(ioDispatcher) {
            // Deliberately attaches to the *existing* local profile rather than
            // replacing it. Every progress row already points at work done on
            // this device, and signing in must not orphan a single one.
            profile()
            preferences.setAccount(accountId, displayName, email)
        }

    override suspend fun signOut() = withContext(ioDispatcher) {
        preferences.clearAccount()
        // The session goes too. It identifies an account with a balance on it,
        // and the next person to pick up this phone should not inherit it.
        preferences.clearSessionToken()
        preferences.setCachedCredits(credits = 0, signedIn = false, checkedAt = 0L)
    }
}
