package com.speaksarthi.app.data.repository

import com.speaksarthi.app.data.local.dao.BadgeDao
import com.speaksarthi.app.data.local.dao.DailyStatDao
import com.speaksarthi.app.data.local.dao.LearnerSentenceDao
import com.speaksarthi.app.data.local.dao.ProgressDao
import com.speaksarthi.app.data.local.dao.RecordingDao
import com.speaksarthi.app.data.local.dao.WeakSoundDao
import com.speaksarthi.app.data.local.entity.BadgeEntity
import com.speaksarthi.app.di.IoDispatcher
import com.speaksarthi.app.domain.repository.BadgeRepository
import com.speaksarthi.app.domain.repository.StudyRepository
import com.speaksarthi.app.domain.usecase.badges.Badge
import com.speaksarthi.app.domain.usecase.badges.BadgeEvaluator
import com.speaksarthi.app.domain.usecase.badges.BadgeProgress
import com.speaksarthi.app.domain.usecase.pronunciation.ScoreInterpreter
import com.speaksarthi.app.util.Clock
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BadgeRepositoryImpl @Inject constructor(
    private val badgeDao: BadgeDao,
    private val progressDao: ProgressDao,
    private val dailyStatDao: DailyStatDao,
    private val recordingDao: RecordingDao,
    private val weakSoundDao: WeakSoundDao,
    private val learnerSentenceDao: LearnerSentenceDao,
    private val study: StudyRepository,
    private val clock: Clock,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : BadgeRepository {

    /**
     * The streak is the one input that has to be asked for rather than observed —
     * it is counted back from today's date rather than stored — so it is read
     * when [award] runs and when the badge screen loads, not watched.
     */
    override fun observeProgress(): Flow<BadgeProgress> = combine(
        combine(
            dailyStatDao.observeTotalWordsStudied(),
            dailyStatDao.observeTotalChunksStudied(),
            dailyStatDao.observeTotalMistakesReviewed()
        ) { words, chunks, mistakes -> Triple(words, chunks, mistakes) },
        combine(
            progressDao.observeKnownCount(),
            recordingDao.observeCount(),
            recordingDao.observeClearRecordingCount(ScoreInterpreter.CLEAR_FROM)
        ) { known, recordings, clear -> Triple(known, recordings, clear) },
        weakSoundDao.observeFixedSoundCount(
            minAttempts = BadgeProgress.SOUND_FIXED_MIN_ATTEMPTS,
            maxRate = BadgeProgress.SOUND_FIXED_RATE
        ),
        learnerSentenceDao.observeCount()
    ) { daily, speaking, fixedSounds, ownSentences ->
        BadgeProgress(
            wordsStudied = daily.first,
            chunksSeen = daily.second,
            mistakesReviewed = daily.third,
            knownWords = speaking.first,
            recordingsMade = speaking.second,
            clearSentences = speaking.third,
            soundsFixed = fixedSounds,
            ownSentencesWritten = ownSentences
        )
    }

    override fun observeEarned(): Flow<Set<String>> =
        badgeDao.observeAll().map { rows -> rows.map { it.badgeId }.toSet() }

    override suspend fun award(): List<Badge> = withContext(ioDispatcher) {
        val progress = observeProgress().first().copy(
            currentStreak = study.currentStreak()
        )
        val held = observeEarned().first()
        val fresh = BadgeEvaluator.newlyEarned(progress, held)

        val now = clock.nowMillis()
        fresh.forEach { badge ->
            // Upsert on the badge id, so a race between two callers awards it
            // once and keeps the earlier timestamp's intent rather than throwing.
            badgeDao.upsert(BadgeEntity(badgeId = badge.id, earnedAt = now))
        }
        fresh
    }
}
