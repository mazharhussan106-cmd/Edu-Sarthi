package com.speaksarthi.app.data.repository

import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.data.remote.ApiResult
import com.speaksarthi.app.data.remote.SessionManager
import com.speaksarthi.app.data.remote.SpeakSarthiApi
import com.speaksarthi.app.di.IoDispatcher
import com.speaksarthi.app.domain.model.CreditBalance
import com.speaksarthi.app.domain.model.EarnKind
import com.speaksarthi.app.domain.model.LinkOutcome
import com.speaksarthi.app.domain.model.RedeemOutcome
import com.speaksarthi.app.domain.repository.AccountRepository
import com.speaksarthi.app.domain.repository.CreditsRepository
import com.speaksarthi.app.util.Clock
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CreditsRepositoryImpl @Inject constructor(
    private val api: SpeakSarthiApi,
    private val session: SessionManager,
    private val accounts: AccountRepository,
    private val preferences: AppPreferences,
    private val clock: Clock,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : CreditsRepository {

    override fun isConfigured(): Boolean = api.isConfigured()

    override fun observeBalance(): Flow<CreditBalance> = combine(
        preferences.cachedCredits,
        preferences.isSignedIn,
        preferences.cachedCreditsCheckedAt
    ) { credits, signedIn, checkedAt ->
        CreditBalance(
            credits = credits,
            source = when {
                !api.isConfigured() -> CreditBalance.Source.NotConfigured
                checkedAt > 0L -> CreditBalance.Source.Server
                else -> CreditBalance.Source.Unknown
            },
            signedIn = signedIn,
            checkedAt = checkedAt
        )
    }

    override suspend fun balance(): CreditBalance = withContext(ioDispatcher) {
        observeBalance().first()
    }

    override suspend fun refresh(): CreditBalance = withContext(ioDispatcher) {
        if (!api.isConfigured()) return@withContext CreditBalance.notConfigured

        val token = session.token() ?: return@withContext balance()

        when (val result = api.balance(token)) {
            is ApiResult.Ok -> store(result.value.balance, result.value.signedIn)
            // A rejected token means the session is stale, not that the learner
            // is broke. One retry on a fresh token, then give up quietly and
            // keep showing the cached figure.
            ApiResult.Unauthorized -> retryWithFreshSession()
            else -> balance()
        }
    }

    override suspend fun recordServerBalance(credits: Int) {
        withContext(ioDispatcher) {
            store(credits, preferences.isSignedIn.first())
        }
    }

    override suspend fun redeem(productId: String, purchaseToken: String): RedeemOutcome =
        withContext(ioDispatcher) {
            val token = session.token() ?: return@withContext RedeemOutcome.Offline

            when (val result = api.redeemPurchase(token, productId, purchaseToken)) {
                is ApiResult.Ok -> {
                    val body = result.value
                    store(body.balance, preferences.isSignedIn.first())
                    when {
                        body.state == "pending" -> RedeemOutcome.Pending
                        body.granted -> RedeemOutcome.Granted(body.balance)
                        // Not granted and not pending means this token had
                        // already been redeemed. That is what a retry looks
                        // like, and the balance is already right.
                        else -> RedeemOutcome.AlreadyRedeemed(body.balance)
                    }
                }
                ApiResult.Offline -> RedeemOutcome.Offline
                ApiResult.Unauthorized -> {
                    session.refresh()
                    RedeemOutcome.Failed("Please try that again")
                }
                is ApiResult.Failed -> RedeemOutcome.Failed(result.message)
                else -> RedeemOutcome.Failed("That purchase could not be confirmed")
            }
        }

    override suspend fun claimEarned(kind: EarnKind, reference: String) {
        withContext(ioDispatcher) {
            val token = session.token() ?: return@withContext
            val result = api.claimEarned(token, kind.wireName, reference)
            // Deliberately no retry and no error surfaced. The learner keeps the
            // lesson either way, and chasing a two-credit bonus around a flaky
            // network is not worth the battery or the interruption.
            if (result is ApiResult.Ok) {
                store(result.value.balance, preferences.isSignedIn.first())
            }
        }
    }

    override suspend fun linkGoogleAccount(idToken: String): LinkOutcome =
        withContext(ioDispatcher) {
            val token = session.token() ?: return@withContext LinkOutcome.Offline

            when (val result = api.link(token, idToken)) {
                is ApiResult.Ok -> {
                    val body = result.value
                    // The server reissues the token because merging two accounts
                    // changes which one this session belongs to. Keeping the old
                    // one would point at an account that no longer exists.
                    session.adopt(body.token)
                    store(body.balance, signedIn = true)
                    // A marker, not the server's account id — the app is never
                    // told that and has no business inventing one. All
                    // `accountId` means locally is "no longer anonymous", and
                    // the email is what the learner actually recognises.
                    accounts.signIn(
                        accountId = SIGNED_IN_MARKER,
                        displayName = "",
                        email = body.email.orEmpty()
                    )
                    LinkOutcome.Linked(body.balance, body.email.orEmpty())
                }
                ApiResult.Offline -> LinkOutcome.Offline
                ApiResult.Unauthorized -> LinkOutcome.Rejected("Google did not accept that sign-in")
                is ApiResult.Failed -> LinkOutcome.Failed(result.message)
                else -> LinkOutcome.Failed("Signing in did not work")
            }
        }

    private companion object {
        /**
         * What `Profile.accountId` holds once signed in.
         *
         * Deliberately not an identifier. The account this maps to lives on the
         * server and is keyed by the Google subject; the app only needs to know
         * that it is no longer anonymous.
         */
        const val SIGNED_IN_MARKER = "google"
    }

    private suspend fun retryWithFreshSession(): CreditBalance {
        val fresh = session.refresh() ?: return balance()
        return when (val retry = api.balance(fresh)) {
            is ApiResult.Ok -> store(retry.value.balance, retry.value.signedIn)
            else -> balance()
        }
    }

    /**
     * Writes a figure the server reported.
     *
     * The only way the cached balance ever changes. There is deliberately no
     * `add`, no `spend` and no `decrement` anywhere in this class — if one
     * existed, a rooted device would find it, and every forged credit is money
     * off somebody's card.
     */
    private suspend fun store(credits: Int, signedIn: Boolean): CreditBalance {
        val at = clock.nowMillis()
        preferences.setCachedCredits(credits = credits, signedIn = signedIn, checkedAt = at)
        return CreditBalance(
            credits = credits.coerceAtLeast(0),
            source = CreditBalance.Source.Server,
            signedIn = signedIn,
            checkedAt = at
        )
    }
}
