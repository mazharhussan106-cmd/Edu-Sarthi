package com.speaksarthi.app.data.repository

import com.speaksarthi.app.data.local.dao.ContentDao
import com.speaksarthi.app.data.local.toDomain
import com.speaksarthi.app.data.local.toMcq
import com.speaksarthi.app.domain.model.Chunk
import com.speaksarthi.app.domain.model.Exercise
import com.speaksarthi.app.domain.model.McqQuestion
import com.speaksarthi.app.domain.model.PracticeItem
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.di.IoDispatcher
import com.speaksarthi.app.domain.repository.LibraryRepository
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LibraryRepositoryImpl @Inject constructor(
    private val contentDao: ContentDao,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : LibraryRepository {

    override fun observeWordCount(): Flow<Int> = contentDao.observeWordCount()

    override suspend fun wordCount(): Int = withContext(ioDispatcher) { contentDao.wordCount() }

    override suspend fun chunkCount(): Int = withContext(ioDispatcher) { contentDao.chunkCount() }

    override suspend fun practiceItemCount(): Int =
        withContext(ioDispatcher) { contentDao.practiceItemCount() }

    override suspend fun exerciseCount(): Int =
        withContext(ioDispatcher) { contentDao.exerciseCount() }

    override suspend fun countsByLevel(): Map<String, Int> = withContext(ioDispatcher) {
        contentDao.countsByLevel().associate { it.level to it.total }
    }

    override suspend fun countsByChunkType(): Map<String, Int> = withContext(ioDispatcher) {
        contentDao.countsByChunkType().associate { it.type to it.total }
    }

    override suspend fun word(wordId: String): Word? = withContext(ioDispatcher) {
        contentDao.wordById(wordId)?.toDomain()
    }

    override fun observeWords(): Flow<List<Word>> =
        contentDao.observeAllWords().map { rows -> rows.map { it.toDomain() } }

    override fun observeWordsByLevel(level: String): Flow<List<Word>> =
        contentDao.observeWordsByLevel(level).map { rows -> rows.map { it.toDomain() } }

    override suspend fun search(query: String, limit: Int): List<Word> = withContext(ioDispatcher) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) emptyList()
        // LIKE treats these as wildcards, so a learner typing "100%" or "_" would
        // otherwise match everything. Escaped here rather than in the query so the
        // DAO stays readable.
        else contentDao
            .searchWords(trimmed.replace("%", "\\%").replace("_", "\\_"), limit)
            .map { it.toDomain() }
    }

    override suspend fun chunks(wordId: String): List<Chunk> = withContext(ioDispatcher) {
        contentDao.chunksForWord(wordId).map { it.toDomain() }
    }

    override suspend fun practiceItems(wordId: String): List<PracticeItem> =
        withContext(ioDispatcher) {
            contentDao.practiceItemsForWord(wordId).map { it.toDomain() }
        }

    override suspend fun exercise(wordId: String): Exercise? = withContext(ioDispatcher) {
        contentDao.exerciseForWord(wordId)?.toDomain()
    }

    override fun observeBookmarked(): Flow<List<Word>> =
        contentDao.observeBookmarkedWords().map { rows -> rows.map { it.toDomain() } }

    override suspend fun recentlyStudied(limit: Int): List<Word> = withContext(ioDispatcher) {
        contentDao.recentlyStudiedWords(limit).map { it.toDomain() }
    }

    override suspend fun studiedWords(limit: Int): List<Word> = withContext(ioDispatcher) {
        contentDao.randomStudiedWords(limit).map { it.toDomain() }
    }

    override suspend fun randomWords(level: String, limit: Int): List<Word> =
        withContext(ioDispatcher) {
            contentDao.randomWords(level, limit).map { it.toDomain() }
        }

    override suspend fun randomMcqs(level: String, limit: Int): List<McqQuestion> =
        withContext(ioDispatcher) {
            contentDao.randomExercises(level, limit).map { it.toMcq() }
        }
}
