package com.speaksarthi.app.data.repository

import android.content.Context
import com.speaksarthi.app.data.local.converter.Converters
import com.speaksarthi.app.data.local.dao.ContentDao
import com.speaksarthi.app.data.local.dao.DailyStatDao
import com.speaksarthi.app.data.local.dao.RecordingDao
import com.speaksarthi.app.data.local.dao.WeakSoundDao
import com.speaksarthi.app.data.local.entity.RecordingEntity
import com.speaksarthi.app.data.local.entity.WeakSoundEntity
import com.speaksarthi.app.data.local.toDomain
import com.speaksarthi.app.data.speech.PronunciationScorer
import com.speaksarthi.app.di.IoDispatcher
import com.speaksarthi.app.domain.model.PracticeItem
import com.speaksarthi.app.domain.model.PronunciationReport
import com.speaksarthi.app.domain.model.Recording
import com.speaksarthi.app.domain.model.ScoringOutcome
import com.speaksarthi.app.domain.model.WeakSound
import com.speaksarthi.app.domain.model.WordWithProgress
import com.speaksarthi.app.domain.repository.CreditsRepository
import com.speaksarthi.app.domain.repository.SpeakingRepository
import com.speaksarthi.app.domain.usecase.pronunciation.SpeechBudget
import com.speaksarthi.app.util.Clock
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SpeakingRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val contentDao: ContentDao,
    private val recordingDao: RecordingDao,
    private val weakSoundDao: WeakSoundDao,
    private val dailyStatDao: DailyStatDao,
    private val scorer: PronunciationScorer,
    private val credits: CreditsRepository,
    private val clock: Clock,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : SpeakingRepository {

    override fun scoringIsConfigured(): Boolean = scorer.isConfigured()

    /**
     * Recordings live in `filesDir`, not `cacheDir`.
     *
     * The learner's own voice is the one thing in this app they cannot get back
     * if it disappears, and the system clears `cacheDir` without asking. It is
     * still private app storage, so it never appears in the gallery and goes
     * away on uninstall.
     */
    override fun recordingDirectory(): File =
        File(context.filesDir, RECORDINGS_DIR).apply { if (!exists()) mkdirs() }

    override fun newRecordingFile(wordId: String): File {
        // The timestamp keeps successive attempts at the same word distinct, so
        // a retry never overwrites the clip the learner might still want to hear.
        val safeId = wordId.replace(Regex("[^A-Za-z0-9_-]"), "_")
        return File(recordingDirectory(), "${safeId}_${clock.nowMillis()}.wav")
    }

    override suspend fun promptsFor(wordId: String): List<PracticeItem> =
        withContext(ioDispatcher) {
            contentDao.practiceItemsForWord(wordId)
                .map { it.toDomain() }
                .filter { it.text.isNotBlank() }
                // Shortest first: a short line is finished, scored fairly and
                // less frightening. Long ones stay available further down.
                .sortedBy { it.text.length }
        }

    override suspend fun speakingQueue(limit: Int): List<WordWithProgress> =
        withContext(ioDispatcher) {
            contentDao.dueQueue(now = clock.nowMillis(), level = "", limit = limit)
                .map { it.toDomain() }
        }

    override suspend fun scoreAndStore(
        audio: File,
        wordId: String,
        prompt: PracticeItem,
        durationMillis: Long
    ): ScoringOutcome = withContext(ioDispatcher) {
        val clipSeconds = SpeechBudget.costOf(durationMillis)

        // A courtesy check, not the gate. The server reserves a credit before it
        // calls the speech service and refunds it if that call fails, which is
        // the only version of this a rooted device cannot talk its way past.
        // What this saves is a pointless round trip when the cached balance
        // already says zero — and the clip is still kept, because the learner
        // did the work and can hear themselves back either way.
        if (credits.isConfigured() && !credits.balance().hasCredits) {
            storeUnscored(audio, wordId, prompt, durationMillis)
            return@withContext ScoringOutcome.NoCredits(credits.balance().credits)
        }

        val outcome = scorer.score(audio, prompt.text)

        when (outcome) {
            is ScoringOutcome.Scored -> {
                store(audio, wordId, prompt, durationMillis, outcome.report)
                // Counted on what was actually sent and only when the service
                // answered — a failed call costs the learner nothing, and the
                // server has already given the credit back.
                dailyStatDao.increment(
                    date = today(),
                    recordings = 1,
                    secondsGraded = clipSeconds
                )
                tallyPhonemes(outcome.report)
                // The response carried the new balance, so nothing has to go and
                // ask for it.
                outcome.creditsRemaining?.let { credits.recordServerBalance(it) }
            }

            is ScoringOutcome.NoCredits -> {
                storeUnscored(audio, wordId, prompt, durationMillis)
                // The server disagreed with the cached figure, which means the
                // cache was stale. Believe the server.
                credits.recordServerBalance(outcome.balance)
            }

            else -> storeUnscored(audio, wordId, prompt, durationMillis)
        }

        outcome
    }

    override suspend fun storeUnscored(
        audio: File,
        wordId: String,
        prompt: PracticeItem,
        durationMillis: Long
    ): Long = withContext(ioDispatcher) {
        val id = recordingDao.upsert(
            RecordingEntity(
                wordId = wordId,
                practiceItemId = prompt.itemId,
                filePath = audio.absolutePath,
                durationMillis = durationMillis,
                recordedAt = clock.nowMillis()
            )
        )
        // Counted as a recording made but zero seconds graded: the streak and
        // the "you practised today" line should reflect the effort even when
        // nothing was sent for scoring.
        dailyStatDao.increment(date = today(), recordings = 1)
        id
    }

    private suspend fun store(
        audio: File,
        wordId: String,
        prompt: PracticeItem,
        durationMillis: Long,
        report: PronunciationReport
    ): Long = recordingDao.upsert(
        RecordingEntity(
            wordId = wordId,
            practiceItemId = prompt.itemId,
            filePath = audio.absolutePath,
            durationMillis = durationMillis,
            recordedAt = clock.nowMillis(),
            scoreAccuracy = report.accuracy,
            scoreFluency = report.fluency,
            scoreCompleteness = report.completeness,
            scoreOverall = report.overall,
            weakPhonemes = Converters.listToString(report.weakPhonemes.map { it.phoneme })
        )
    )

    /**
     * Updates the running per-phoneme tallies.
     *
     * Every phoneme the service scored counts as an attempt; the weak ones also
     * count as an error. Tracking attempts as well as errors is what stops the
     * list being dominated by whichever sound simply appears most often in
     * English — /t/ will always have the most errors in absolute terms, and it
     * is the error *rate* that says something about the learner.
     */
    private suspend fun tallyPhonemes(report: PronunciationReport) {
        val now = clock.nowMillis()
        val attempts = report.words
            .flatMap { it.phonemes }
            .groupBy { it.phoneme.lowercase().trim() }
            .filterKeys { it.isNotEmpty() }

        attempts.forEach { (phoneme, scores) ->
            val existing = weakSoundDao.byPhoneme(phoneme)
            val errors = scores.count { it.isWeak }

            weakSoundDao.upsert(
                WeakSoundEntity(
                    phoneme = phoneme,
                    errorCount = (existing?.errorCount ?: 0) + errors,
                    attemptCount = (existing?.attemptCount ?: 0) + scores.size,
                    lastSeenAt = now
                )
            )
        }
    }

    override fun observeRecordings(wordId: String): Flow<List<Recording>> =
        recordingDao.observeForWord(wordId).map { rows -> rows.map { it.toDomain() } }

    override fun observeRecordingCount(): Flow<Int> = recordingDao.observeCount()

    override fun observeWeakSounds(limit: Int): Flow<List<WeakSound>> =
        weakSoundDao.observeWeakest(limit = limit).map { rows -> rows.map { it.toDomain() } }

    override suspend fun averageScoreSince(since: Long): Float? = withContext(ioDispatcher) {
        recordingDao.averageScoreSince(since)
    }

    override suspend fun deleteAllRecordings() = withContext(ioDispatcher) {
        // Files first, then rows: a crash between the two leaves orphaned rows
        // pointing at nothing, which the UI already tolerates, whereas the
        // reverse leaves audio on the device that the learner asked to be gone.
        recordingDao.allFilePaths().forEach { path -> File(path).delete() }
        recordingDao.deleteAll()
    }

    private fun today(): String = clock.today().toString()

    private companion object {
        const val RECORDINGS_DIR = "recordings"
    }
}
