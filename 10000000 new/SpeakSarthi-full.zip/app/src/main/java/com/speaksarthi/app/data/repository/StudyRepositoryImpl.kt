package com.speaksarthi.app.data.repository

import com.speaksarthi.app.data.local.dao.ContentDao
import com.speaksarthi.app.data.local.dao.DailyStatDao
import com.speaksarthi.app.data.local.dao.LearnerSentenceDao
import com.speaksarthi.app.data.local.dao.ProgressDao
import com.speaksarthi.app.data.local.dao.QuizAttemptDao
import com.speaksarthi.app.data.local.entity.LearnerSentenceEntity
import com.speaksarthi.app.data.local.entity.QuizAttemptEntity
import com.speaksarthi.app.data.local.toDomain
import com.speaksarthi.app.data.local.toEntity
import com.speaksarthi.app.domain.model.DailyStat
import com.speaksarthi.app.domain.model.Progress
import com.speaksarthi.app.domain.model.ReviewGrade
import com.speaksarthi.app.domain.model.WordWithProgress
import com.speaksarthi.app.di.IoDispatcher
import com.speaksarthi.app.domain.repository.StudyRepository
import com.speaksarthi.app.domain.usecase.spacedrepetition.SM2Algorithm
import com.speaksarthi.app.util.Clock
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StudyRepositoryImpl @Inject constructor(
    private val contentDao: ContentDao,
    private val progressDao: ProgressDao,
    private val quizAttemptDao: QuizAttemptDao,
    private val dailyStatDao: DailyStatDao,
    private val learnerSentenceDao: LearnerSentenceDao,
    private val clock: Clock,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : StudyRepository {

    override suspend fun dueQueue(level: String, limit: Int): List<WordWithProgress> =
        withContext(ioDispatcher) {
            contentDao.dueQueue(now = clock.nowMillis(), level = level, limit = limit)
                .map { it.toDomain() }
        }

    /**
     * Note the "now" is captured when the flow is created, not on each emission,
     * so a screen left open across a review boundary will not notice new words
     * falling due until it is recollected. That is fine while a session is
     * minutes long; when the home dashboard arrives it should re-subscribe on
     * resume rather than assume this ticks.
     */
    override fun observeDueCount(): Flow<Int> = contentDao.observeDueCount(clock.nowMillis())

    override fun observeKnownCount(): Flow<Int> = progressDao.observeKnownCount()

    override fun observeStartedCount(): Flow<Int> = progressDao.observeStartedCount()

    override suspend fun progress(wordId: String): Progress = withContext(ioDispatcher) {
        progressDao.byWordId(wordId)?.toDomain() ?: Progress(wordId = wordId)
    }

    override suspend fun allProgress(): List<Progress> = withContext(ioDispatcher) {
        progressDao.all().map { it.toDomain() }
    }

    override suspend fun grade(
        wordId: String,
        grade: ReviewGrade,
        chunksSeen: Int,
        wasMistakeReview: Boolean
    ): Progress = withContext(ioDispatcher) {
        val now = clock.nowMillis()
        val current = progressDao.byWordId(wordId)?.toDomain() ?: Progress(wordId = wordId)
        val updated = SM2Algorithm.apply(current, grade, now)

        progressDao.upsert(updated.toEntity())
        dailyStatDao.increment(
            date = today(),
            words = 1,
            chunks = chunksSeen.coerceAtLeast(0),
            mistakesReviewed = if (wasMistakeReview) 1 else 0
        )

        updated
    }

    override suspend fun setBookmarked(wordId: String, bookmarked: Boolean) =
        withContext(ioDispatcher) {
            // A word with no progress row yet has nothing to update, so the row
            // is created first. Bookmarking something never studied is a normal
            // thing to do from search.
            if (progressDao.byWordId(wordId) == null) {
                progressDao.upsert(Progress(wordId = wordId, isBookmarked = bookmarked).toEntity())
            } else {
                progressDao.setBookmarked(wordId, bookmarked)
            }
        }

    override suspend fun weakestWords(limit: Int): List<WordWithProgress> =
        withContext(ioDispatcher) {
            progressDao.weakestWords(limit = limit).mapNotNull { progress ->
                contentDao.wordWithProgress(progress.wordId)?.toDomain()
            }
        }

    /**
     * Words with a poor answer record first, then words recently missed in a
     * quiz, deduplicated.
     *
     * Two sources because they catch different failures: the first is a word the
     * learner keeps rating "Again", the second is one they were confident about
     * and still got wrong. Both belong in mistake review; only the first shows up
     * in the accuracy figures.
     */
    override suspend fun mistakeQueue(limit: Int): List<WordWithProgress> =
        withContext(ioDispatcher) {
            val weakest = weakestWords(limit = limit)
            if (weakest.size >= limit) return@withContext weakest

            val alreadyIn = weakest.map { it.word.wordId }.toSet()
            val missed = quizAttemptDao.recentlyMissedWordIds(limit = limit)
                .asSequence()
                .filter { it !in alreadyIn }
                .mapNotNull { wordId -> contentDao.wordWithProgress(wordId)?.toDomain() }
                .take(limit - weakest.size)
                .toList()

            weakest + missed
        }

    override suspend fun lessonQueue(wordIds: List<String>, limit: Int): List<WordWithProgress> =
        withContext(ioDispatcher) {
            wordIds
                .mapNotNull { wordId -> contentDao.wordWithProgress(wordId)?.toDomain() }
                // Unknown first, then least recently reviewed. Finishing a lesson
                // should mean meeting what is left, not re-reading what is done.
                .sortedWith(
                    compareBy<WordWithProgress> { it.progress.isKnown }
                        .thenBy { it.progress.lastReviewedAt }
                )
                .take(limit)
        }

    override suspend fun recordQuizAnswer(wordId: String, selectedIndex: Int, wasCorrect: Boolean) =
        withContext(ioDispatcher) {
            quizAttemptDao.upsert(
                QuizAttemptEntity(
                    wordId = wordId,
                    selectedIndex = selectedIndex,
                    wasCorrect = wasCorrect,
                    answeredAt = clock.nowMillis()
                )
            )
            dailyStatDao.increment(
                date = today(),
                quizzes = 1,
                quizzesCorrect = if (wasCorrect) 1 else 0
            )
        }

    override fun observeToday(): Flow<DailyStat> {
        val date = today()
        return dailyStatDao.observeForDate(date)
            .map { it?.toDomain() ?: DailyStat(date = date) }
    }

    /**
     * Counts back from today while each preceding day has activity.
     *
     * Today not being present does not break the streak — someone opening the app
     * at 7am has not lost yesterday's run — but a gap before that does.
     */
    override suspend fun currentStreak(): Int = withContext(ioDispatcher) {
        val active = dailyStatDao.activeDates().toSet()
        if (active.isEmpty()) return@withContext 0

        val today = clock.today()
        var cursor = if (active.contains(today.toString())) today else today.minusDays(1)
        var streak = 0

        while (active.contains(cursor.toString())) {
            streak++
            cursor = cursor.minusDays(1)
        }
        streak
    }

    override suspend fun ownSentence(wordId: String): String = withContext(ioDispatcher) {
        learnerSentenceDao.forWord(wordId)?.text.orEmpty()
    }

    override suspend fun saveOwnSentence(wordId: String, text: String) =
        withContext(ioDispatcher) {
            val trimmed = text.trim()
            if (trimmed.isEmpty()) {
                // Clearing the box means the learner withdrew what they wrote,
                // not that an empty sentence should be kept and shown back.
                learnerSentenceDao.delete(wordId)
            } else {
                learnerSentenceDao.upsert(
                    LearnerSentenceEntity(
                        wordId = wordId,
                        text = trimmed,
                        updatedAt = clock.nowMillis()
                    )
                )
            }
        }

    /** `yyyy-MM-dd` in the device's own timezone — a "day" must mean the learner's day. */
    private fun today(): String = clock.today().toString()
}
