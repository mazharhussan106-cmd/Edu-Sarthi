package com.speaksarthi.app.data.seed

import com.speaksarthi.app.data.local.dao.ContentDao
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.domain.model.ImportReport
import kotlinx.coroutines.flow.first
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Decides whether the bundled library needs importing, and does it.
 *
 * This is the "system to update content in future" the product brief asked for.
 * The mechanism is a single integer: [CONTENT_VERSION] is bumped whenever the
 * files in `assets/seed/` are regenerated. On launch the seeder compares it with
 * the version last imported on this device and re-runs the import if the app is
 * carrying newer content.
 *
 * Because the import is an upsert keyed on stable ids, re-running it corrects and
 * extends the library in place while leaving every review record, bookmark,
 * recording and streak untouched. Shipping corrected content is therefore a
 * normal app update with a bumped constant — no migration, no data loss, no
 * special casing.
 */
@Singleton
class ContentSeeder @Inject constructor(
    private val contentDao: ContentDao,
    private val seedImporter: SeedImporter,
    private val preferences: AppPreferences
) {

    sealed interface Result {
        /** Library was already current; nothing was written. */
        data class AlreadyCurrent(val wordCount: Int) : Result

        /** Content was imported — either a first-run seed or an update. */
        data class Imported(val report: ImportReport, val wasUpdate: Boolean) : Result

        /** Import ran but produced no words; the app has an empty library. */
        data class Failed(val report: ImportReport) : Result
    }

    suspend fun seedIfNeeded(): Result {
        val importedVersion = preferences.contentVersion.first()
        val wordCount = contentDao.wordCount()

        // A non-empty database at the current version needs nothing. The word
        // count is checked as well as the version so a database cleared by
        // "clear app data" re-seeds even if a stale preference survives.
        if (importedVersion >= CONTENT_VERSION && wordCount > 0) {
            return Result.AlreadyCurrent(wordCount)
        }

        val wasUpdate = wordCount > 0
        val report = seedImporter.importBundledSeed()

        return if (report.isSuccess) {
            preferences.setContentVersion(CONTENT_VERSION)
            Result.Imported(report, wasUpdate)
        } else {
            // Deliberately does not record the version, so the next launch retries
            // rather than leaving the learner with a permanently empty library.
            Result.Failed(report)
        }
    }

    companion object {
        /**
         * Bump this whenever `assets/seed/` is regenerated. See
         * `content/build_seed.py`.
         *
         * 1 — initial 1,000-word library: 7,053 chunks, 8,000 speaking prompts,
         *     1,000 multiple-choice questions.
         */
        const val CONTENT_VERSION = 1
    }
}
