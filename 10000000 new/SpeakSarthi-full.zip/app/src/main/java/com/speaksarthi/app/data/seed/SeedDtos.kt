package com.speaksarthi.app.data.seed

import kotlinx.serialization.Serializable

/**
 * Wire format of the bundled seed files in `assets/seed/`, produced by
 * `content/build_seed.py` from the 1000-word workbook.
 *
 * Every field defaults to empty so a content file that gains a column does not
 * break an older app build, and one that loses a column does not crash a newer
 * one. Validation of what is actually *required* happens in [SeedImporter],
 * per row, so one malformed entry is skipped and reported rather than aborting
 * the whole import.
 */

@Serializable
data class WordDto(
    val wordId: String = "",
    val word: String = "",
    val partOfSpeech: String = "",
    val category: String = "",
    val cefrLevel: String = "",
    val frequency: String = "",
    val importance: String = "",
    val register: String = "",
    val ipa: String = "",
    val syllableBreak: String = "",
    val hindiPronunciation: String = "",
    val hindiMeaning: String = "",
    val simpleMeaning: String = "",
    val plainExplanation: String = "",
    val etymology: String = "",
    val mnemonic: String = "",
    val quickTip: String = "",
    val pronunciationTip: String = "",
    val spellingTip: String = "",
    val wordFamily: List<String> = emptyList(),
    val prefixRootSuffix: String = "",
    val visualAssociation: String = "",
    val tone: String = "",
    val typicalContexts: List<String> = emptyList(),
    val miniConversation: String = "",
    val confusingWords: String = "",
    val relatedWords: List<String> = emptyList(),
    val synonyms: List<String> = emptyList(),
    val antonyms: List<String> = emptyList(),
    val emotionFeel: String = "",
    val commonMistakeWrong: String = "",
    val commonMistakeCorrect: String = "",
    val quickRecallPrompt: String = "",
    /** Filename of the illustration, by convention `<wordId>.webp`. Artwork is added later. */
    val illustration: String = "",
    val orderIndex: Int = 0
)

@Serializable
data class ChunkDto(
    val chunkId: String = "",
    val wordId: String = "",
    val text: String = "",
    val type: String = "",
    val orderIndex: Int = 0
)

@Serializable
data class PracticeItemDto(
    val itemId: String = "",
    val wordId: String = "",
    val text: String = "",
    val highlight: String = "",
    val type: String = "",
    val orderIndex: Int = 0
)

@Serializable
data class McqDto(
    val question: String = "",
    val options: List<String> = emptyList(),
    val answerIndex: Int = -1
)

@Serializable
data class FillBlankDto(
    val prompt: String = "",
    val answer: String = ""
)

@Serializable
data class FindFixDto(
    val wrong: String = "",
    val corrected: String = ""
)

@Serializable
data class TranslateDto(
    val prompt: String = "",
    val answer: String = ""
)

/**
 * One word's full practice set — the five exercises that make up part three of
 * the card: multiple choice, fill in the blank, sentence correction, translate
 * from Hindi, and write your own sentence.
 *
 * [writeYourOwn] is open-ended and has no answer to check against. The app keeps
 * what the learner writes and shows it back on the next review rather than
 * grading it.
 */
@Serializable
data class QuizItemDto(
    val wordId: String = "",
    val mcq: McqDto? = null,
    val fillBlank: FillBlankDto? = null,
    val findFix: FindFixDto? = null,
    val translate: TranslateDto? = null,
    val writeYourOwn: String = ""
)
