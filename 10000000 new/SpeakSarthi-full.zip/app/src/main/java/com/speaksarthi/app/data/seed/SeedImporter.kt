package com.speaksarthi.app.data.seed

import android.content.Context
import com.speaksarthi.app.data.local.converter.Converters
import com.speaksarthi.app.data.local.dao.ContentDao
import com.speaksarthi.app.data.local.entity.ChunkEntity
import com.speaksarthi.app.data.local.entity.ExerciseEntity
import com.speaksarthi.app.data.local.entity.PracticeItemEntity
import com.speaksarthi.app.data.local.entity.WordEntity
import com.speaksarthi.app.domain.model.CefrLevel
import com.speaksarthi.app.domain.model.ChunkType
import com.speaksarthi.app.domain.model.ImportReport
import com.speaksarthi.app.domain.model.PracticeType
import com.speaksarthi.app.di.IoDispatcher
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Loads the bundled library into Room.
 *
 * Two properties matter more than anything else here, both learned from
 * WordMaster's import bug:
 *
 *  1. **Non-destructive.** Every write is an upsert keyed on the natural id, so
 *     re-running an import updates content in place and never deletes a row that
 *     a learner's progress points at.
 *  2. **Partial success.** A row that fails validation is skipped and reported
 *     by id; it does not abort the import. One bad entry in a content update
 *     must not cost the learner the other 999 words.
 *
 * The same code path serves the first-run seed and every later content update,
 * so the update mechanism is exercised on every single install rather than
 * being a rarely-run branch that silently rots.
 */
@Singleton
class SeedImporter @Inject constructor(
    @ApplicationContext private val context: Context,
    private val contentDao: ContentDao,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) {

    private val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        isLenient = true
    }

    suspend fun importBundledSeed(): ImportReport = withContext(ioDispatcher) {
        val warnings = mutableListOf<String>()

        val words = importWords(warnings)
        // Chunks, prompts and questions all carry a wordId foreign key, so they
        // can only be written once their words exist. Passing the set of ids
        // that actually landed lets the child importers skip orphans instead of
        // failing on a constraint violation.
        val knownWordIds = words.second
        val chunks = importChunks(knownWordIds, warnings)
        val practice = importPracticeItems(knownWordIds, warnings)
        val questions = importExercises(knownWordIds, warnings)

        ImportReport(
            wordsImported = words.first,
            chunksImported = chunks,
            practiceItemsImported = practice,
            questionsImported = questions,
            warnings = warnings
        )
    }

    // ---- words -------------------------------------------------------------

    private suspend fun importWords(warnings: MutableList<String>): Pair<Int, Set<String>> {
        val payload = readAsset(FILE_WORDS, warnings) ?: return 0 to emptySet()
        val parsed = runCatching { json.decodeFromString<List<WordDto>>(payload) }
            .getOrElse {
                warnings += "$FILE_WORDS could not be parsed: ${it.message}"
                return 0 to emptySet()
            }

        val seen = mutableSetOf<String>()
        val entities = mutableListOf<WordEntity>()

        parsed.forEachIndexed { index, dto ->
            val id = dto.wordId.trim()
            when {
                id.isEmpty() -> warnings += "words[$index]: missing wordId — skipped"
                dto.word.isBlank() -> warnings += "words[$index] ($id): missing word text — skipped"
                !seen.add(id) -> warnings += "words[$index] ($id): duplicate wordId — skipped"
                else -> entities += dto.toEntity()
            }
        }

        entities.chunked(BATCH).forEach { contentDao.upsertWords(it) }
        return entities.size to seen
    }

    private fun WordDto.toEntity(): WordEntity = WordEntity(
        wordId = wordId.trim(),
        word = word.trim(),
        partOfSpeech = partOfSpeech,
        category = category,
        // Normalised through the enum so an unexpected value in a future content
        // drop lands on a real level rather than an unmatchable string.
        level = CefrLevel.fromCode(cefrLevel).code,
        frequency = frequency,
        importance = importance,
        register = register,
        ipa = ipa,
        syllableBreak = syllableBreak,
        hindiPronunciation = hindiPronunciation,
        hindiMeaning = hindiMeaning,
        simpleMeaning = simpleMeaning,
        plainExplanation = plainExplanation,
        etymology = etymology,
        mnemonic = mnemonic,
        quickTip = quickTip,
        pronunciationTip = pronunciationTip,
        spellingTip = spellingTip,
        wordFamily = Converters.listToString(wordFamily),
        prefixRootSuffix = prefixRootSuffix,
        visualAssociation = visualAssociation,
        tone = tone,
        typicalContexts = Converters.listToString(typicalContexts),
        miniConversation = miniConversation,
        confusingWords = confusingWords,
        relatedWords = Converters.listToString(relatedWords),
        synonyms = Converters.listToString(synonyms),
        antonyms = Converters.listToString(antonyms),
        emotionFeel = emotionFeel,
        commonMistakeWrong = commonMistakeWrong,
        commonMistakeCorrect = commonMistakeCorrect,
        quickRecallPrompt = quickRecallPrompt,
        illustration = illustration.trim(),
        orderIndex = orderIndex
    )

    // ---- chunks ------------------------------------------------------------

    private suspend fun importChunks(
        knownWordIds: Set<String>,
        warnings: MutableList<String>
    ): Int {
        val payload = readAsset(FILE_CHUNKS, warnings) ?: return 0
        val parsed = runCatching { json.decodeFromString<List<ChunkDto>>(payload) }
            .getOrElse {
                warnings += "$FILE_CHUNKS could not be parsed: ${it.message}"
                return 0
            }

        val seen = mutableSetOf<String>()
        val entities = mutableListOf<ChunkEntity>()
        var orphans = 0

        parsed.forEachIndexed { index, dto ->
            val id = dto.chunkId.trim()
            when {
                id.isEmpty() || dto.text.isBlank() ->
                    warnings += "chunks[$index]: missing chunkId or text — skipped"
                dto.wordId !in knownWordIds -> orphans++
                !seen.add(id) -> warnings += "chunks[$index] ($id): duplicate chunkId — skipped"
                else -> entities += ChunkEntity(
                    chunkId = id,
                    wordId = dto.wordId,
                    text = dto.text.trim(),
                    type = ChunkType.fromRaw(dto.type).name,
                    orderIndex = dto.orderIndex
                )
            }
        }

        if (orphans > 0) warnings += "chunks: $orphans row(s) referenced an unknown wordId — skipped"
        entities.chunked(BATCH).forEach { contentDao.upsertChunks(it) }
        return entities.size
    }

    // ---- speaking prompts --------------------------------------------------

    private suspend fun importPracticeItems(
        knownWordIds: Set<String>,
        warnings: MutableList<String>
    ): Int {
        val payload = readAsset(FILE_PRACTICE, warnings) ?: return 0
        val parsed = runCatching { json.decodeFromString<List<PracticeItemDto>>(payload) }
            .getOrElse {
                warnings += "$FILE_PRACTICE could not be parsed: ${it.message}"
                return 0
            }

        val seen = mutableSetOf<String>()
        val entities = mutableListOf<PracticeItemEntity>()
        var orphans = 0

        parsed.forEachIndexed { index, dto ->
            val id = dto.itemId.trim()
            when {
                id.isEmpty() || dto.text.isBlank() ->
                    warnings += "practice[$index]: missing itemId or text — skipped"
                dto.wordId !in knownWordIds -> orphans++
                !seen.add(id) -> warnings += "practice[$index] ($id): duplicate itemId — skipped"
                else -> entities += PracticeItemEntity(
                    itemId = id,
                    wordId = dto.wordId,
                    text = dto.text.trim(),
                    highlight = dto.highlight.trim(),
                    type = PracticeType.fromRaw(dto.type).name,
                    orderIndex = dto.orderIndex
                )
            }
        }

        if (orphans > 0) warnings += "practice: $orphans row(s) referenced an unknown wordId — skipped"
        entities.chunked(BATCH).forEach { contentDao.upsertPracticeItems(it) }
        return entities.size
    }

    // ---- practice-zone exercises -------------------------------------------

    /**
     * Multiple choice is the one exercise that must be valid for a row to be
     * worth keeping — it drives quiz mode as well as part three of the card.
     * The other four are optional: a word missing its translation exercise still
     * renders a useful practice zone, so a blank there is not a reason to drop
     * the whole set.
     */
    private suspend fun importExercises(
        knownWordIds: Set<String>,
        warnings: MutableList<String>
    ): Int {
        val payload = readAsset(FILE_QUIZ, warnings) ?: return 0
        val parsed = runCatching { json.decodeFromString<List<QuizItemDto>>(payload) }
            .getOrElse {
                warnings += "$FILE_QUIZ could not be parsed: ${it.message}"
                return 0
            }

        val entities = mutableListOf<ExerciseEntity>()
        var orphans = 0

        parsed.forEachIndexed { index, dto ->
            val mcq = dto.mcq ?: return@forEachIndexed
            val wordId = dto.wordId.trim()
            when {
                wordId.isEmpty() -> warnings += "exercises[$index]: missing wordId — skipped"
                wordId !in knownWordIds -> orphans++
                mcq.question.isBlank() || mcq.options.size < 2 ->
                    warnings += "exercises[$index] ($wordId): multiple choice needs text and at least two options — skipped"
                mcq.answerIndex !in mcq.options.indices ->
                    warnings += "exercises[$index] ($wordId): answerIndex ${mcq.answerIndex} is outside the options — skipped"
                else -> entities += ExerciseEntity(
                    wordId = wordId,
                    mcqQuestion = mcq.question.trim(),
                    mcqOptions = Converters.listToString(mcq.options),
                    mcqAnswerIndex = mcq.answerIndex,
                    fillBlankPrompt = dto.fillBlank?.prompt?.trim().orEmpty(),
                    fillBlankAnswer = dto.fillBlank?.answer?.trim().orEmpty(),
                    findFixWrong = dto.findFix?.wrong?.trim().orEmpty(),
                    findFixCorrected = dto.findFix?.corrected?.trim().orEmpty(),
                    translatePrompt = dto.translate?.prompt?.trim().orEmpty(),
                    translateAnswer = dto.translate?.answer?.trim().orEmpty(),
                    writeYourOwnPrompt = dto.writeYourOwn.trim()
                )
            }
        }

        if (orphans > 0) warnings += "exercises: $orphans row(s) referenced an unknown wordId — skipped"
        entities.chunked(BATCH).forEach { contentDao.upsertExercises(it) }
        return entities.size
    }

    // ---- io ----------------------------------------------------------------

    private fun readAsset(name: String, warnings: MutableList<String>): String? =
        runCatching {
            context.assets.open("$SEED_DIR/$name").bufferedReader().use { it.readText() }
        }.getOrElse {
            warnings += "$name could not be read from assets: ${it.message}"
            null
        }

    companion object {
        const val SEED_DIR = "seed"
        const val FILE_WORDS = "words.json"
        const val FILE_CHUNKS = "chunks.json"
        const val FILE_PRACTICE = "practice_items.json"
        const val FILE_QUIZ = "quiz_items.json"

        /**
         * Rows per transaction. Large enough to keep the 1,000-word first-run
         * seed fast, small enough that a low-end phone is not asked to hold the
         * whole set in a single statement.
         */
        private const val BATCH = 250
    }
}
