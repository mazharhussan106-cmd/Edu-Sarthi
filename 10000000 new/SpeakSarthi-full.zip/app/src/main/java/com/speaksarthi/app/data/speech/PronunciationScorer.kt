package com.speaksarthi.app.data.speech

import android.util.Base64
import com.speaksarthi.app.data.remote.SessionManager
import com.speaksarthi.app.di.IoDispatcher
import com.speaksarthi.app.domain.model.ScoringOutcome
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.IOException
import java.net.UnknownHostException
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Scores a recording against the sentence the learner was asked to say.
 *
 * Behind an interface because the implementation is the one part of this app
 * that talks to a paid third party, and because every screen that uses it must
 * be testable without one.
 */
interface PronunciationScorer {

    /** True when there is somewhere to send audio. */
    fun isConfigured(): Boolean

    /**
     * Sends [audio] to be scored against [referenceText].
     *
     * Never throws for an expected condition — no network, no configuration, a
     * clip with no speech in it — because each of those has its own thing to
     * say to the learner. See [ScoringOutcome].
     */
    suspend fun score(audio: File, referenceText: String): ScoringOutcome
}

@Singleton
class AzurePronunciationScorer @Inject constructor(
    private val config: SpeechServiceConfig,
    private val session: SessionManager,
    private val client: OkHttpClient,
    private val json: Json,
    @IoDispatcher private val ioDispatcher: CoroutineDispatcher
) : PronunciationScorer {

    override fun isConfigured(): Boolean = config.isConfigured

    override suspend fun score(audio: File, referenceText: String): ScoringOutcome =
        withContext(ioDispatcher) {
            if (!config.isConfigured) return@withContext ScoringOutcome.NotConfigured
            if (!audio.exists() || audio.length() <= 0) {
                return@withContext ScoringOutcome.Failed("The recording is missing", isRetryable = true)
            }
            if (referenceText.isBlank()) {
                return@withContext ScoringOutcome.Failed(
                    "There is no sentence to score this against",
                    isRetryable = false
                )
            }

            if (!config.usesProxy) {
                return@withContext when (val direct = attempt(audio, referenceText, token = null)) {
                    is Attempt.Done -> direct.outcome
                    // Only our own server issues a 401 the app can fix; from
                    // Azure it means the key is wrong, which a retry will not
                    // mend and which is not the learner's problem.
                    Attempt.StaleSession -> ScoringOutcome.Failed(
                        "Scoring is not authorised for this build",
                        isRetryable = false
                    )
                }
            }

            // A session is needed before anything can be sent. No token means no
            // server reachable, which is an outage — never reported as "you have
            // no credits", because that would tell a learner they are out of
            // money when in fact they are out of signal.
            val token = session.token() ?: return@withContext ScoringOutcome.Offline

            when (val first = attempt(audio, referenceText, token)) {
                Attempt.StaleSession -> {
                    // The token was issued for an account that has since been
                    // merged by signing in elsewhere, or it simply expired. One
                    // quiet retry on a fresh session; the local id is unchanged,
                    // so it lands on the same account with the same balance.
                    val fresh = session.refresh() ?: return@withContext ScoringOutcome.Offline
                    when (val second = attempt(audio, referenceText, fresh)) {
                        Attempt.StaleSession -> ScoringOutcome.Failed(
                            "Could not verify your account",
                            isRetryable = false
                        )
                        is Attempt.Done -> second.outcome
                    }
                }
                is Attempt.Done -> first.outcome
            }
        }

    /**
     * One request.
     *
     * Returns [StaleSession] rather than an outcome when the server rejects the
     * token, because that is the caller's business to retry and not something a
     * learner should ever see.
     */
    private fun attempt(audio: File, referenceText: String, token: String?): Attempt {
        val request = try {
            buildRequest(audio, referenceText, token)
        } catch (error: IllegalArgumentException) {
            return Attempt.of(
                ScoringOutcome.Failed(
                    "The scoring endpoint address is not valid",
                    isRetryable = false
                )
            )
        }

        return try {
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()

                if (!response.isSuccessful) {
                    return if (response.code == 401) {
                        Attempt.StaleSession
                    } else {
                        Attempt.of(failureFor(response.code, body))
                    }
                }
                Attempt.of(
                    parse(body, referenceText, response.header(CREDITS_HEADER)?.toIntOrNull())
                )
            }
        } catch (error: UnknownHostException) {
            Attempt.of(ScoringOutcome.Offline)
        } catch (error: IOException) {
            // Covers timeouts as well as a connection dropped mid-upload,
            // which on a mobile connection is the common case rather than
            // the exceptional one.
            Attempt.of(ScoringOutcome.Offline)
        }
    }

    private fun buildRequest(audio: File, referenceText: String, token: String?): Request {
        val builder = Request.Builder()
            .url(config.scoringEndpoint(referenceText))
            .post(audio.asRequestBody(WAV_MEDIA_TYPE))
            .header("Accept", "application/json")
            .header("Content-Type", WAV_CONTENT_TYPE)

        if (config.usesProxy) {
            // The reference text is already in the query string and the server
            // builds the assessment header itself — it has to, since it is the
            // one holding the speech key. The body stays pure audio so those
            // bytes can be forwarded untouched.
            builder.header("Authorization", "Bearer ${token.orEmpty()}")
        } else {
            val assessment = json.encodeToString(
                AssessmentRequestConfig.serializer(),
                AssessmentRequestConfig(referenceText = referenceText)
            )
            // The service reads its assessment parameters from this header,
            // base64 of the JSON above. NO_WRAP matters: the default encoder
            // inserts newlines, and a header value containing a newline is
            // rejected before it reaches the service.
            builder.header(
                "Pronunciation-Assessment",
                Base64.encodeToString(assessment.toByteArray(), Base64.NO_WRAP)
            )
            builder.header("Ocp-Apim-Subscription-Key", config.azureKey)
        }

        return builder.build()
    }

    private fun parse(
        body: String,
        referenceText: String,
        creditsRemaining: Int?
    ): ScoringOutcome {
        val response = try {
            json.decodeFromString(AssessmentResponse.serializer(), body)
        } catch (error: Exception) {
            return ScoringOutcome.Failed("The scoring service sent something unexpected")
        }

        if (response.heardNothing) return ScoringOutcome.NoSpeechHeard
        if (!response.isSuccess) {
            return ScoringOutcome.Failed("The service could not process that recording")
        }

        val report = response.toReport(referenceText)
            ?: return ScoringOutcome.NoSpeechHeard

        return ScoringOutcome.Scored(report, creditsRemaining)
    }

    /**
     * Turns an HTTP status into something with a next step in it.
     *
     * The distinction that matters is retryable versus not: a learner tapping
     * "try again" at a 401 will tap it forever, and a learner who does not tap
     * it at a 429 gives up on a feature that would have worked in a minute.
     */
    private fun failureFor(code: Int, body: String): ScoringOutcome = when (code) {
        // The one case that is not a fault at all. Recording and playback keep
        // working — only the score stops.
        402 -> ScoringOutcome.NoCredits()

        403 -> ScoringOutcome.Failed(
            "Scoring is not authorised for this build",
            isRetryable = false
        )

        429 -> ScoringOutcome.Failed(
            "The scoring service is busy. Try again in a minute.",
            isRetryable = true
        )

        // 502 from our own server means the speech service failed and the
        // credit has already been given back. Worth saying it is worth retrying,
        // because it costs the learner nothing to.
        in 500..599 -> ScoringOutcome.Failed(
            "The scoring service is having trouble. Try again shortly.",
            isRetryable = true
        )

        400 -> ScoringOutcome.Failed(
            // Almost always the audio format or the reference text, neither of
            // which the learner can do anything about — so it is logged as
            // non-retryable rather than inviting them to keep trying.
            "That recording could not be read by the scoring service",
            isRetryable = false
        )

        else -> ScoringOutcome.Failed("Scoring failed ($code)", isRetryable = true)
    }

    /**
     * The result of one HTTP attempt.
     *
     * [StaleSession] exists so a rejected token can be retried without ever
     * becoming something a learner is shown. It is private to this file rather
     * than a [ScoringOutcome] because no screen should have to handle it, and a
     * state nothing renders is a state that eventually gets rendered wrong.
     */
    private sealed interface Attempt {
        data class Done(val outcome: ScoringOutcome) : Attempt
        data object StaleSession : Attempt

        companion object {
            fun of(outcome: ScoringOutcome): Attempt = Done(outcome)
        }
    }

    companion object {
        private val WAV_MEDIA_TYPE = "audio/wav".toMediaType()

        /** The server reports the new balance here, saving a request per card. */
        private const val CREDITS_HEADER = "X-Credits-Remaining"

        /**
         * The service needs the sample rate spelled out in the content type; it
         * does not read the WAV header to find it.
         */
        private const val WAV_CONTENT_TYPE = "audio/wav; codecs=audio/pcm; samplerate=16000"
    }
}
