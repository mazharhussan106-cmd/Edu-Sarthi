package com.speaksarthi.app.data.speech

import com.speaksarthi.app.domain.model.PhonemeScore
import com.speaksarthi.app.domain.model.PronunciationReport
import com.speaksarthi.app.domain.model.SpokenWordScore
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * The shape of an Azure Speech pronunciation-assessment response.
 *
 * Field names are PascalCase because that is what the service sends; they are
 * mapped with [SerialName] rather than renamed, so this file can be checked
 * against the service's own documentation line by line.
 *
 * Everything is nullable with a default. The service omits fields rather than
 * sending nulls — a clip with no speech in it comes back with `RecognitionStatus`
 * and nothing else — and a parser that insists on a field being present turns
 * that into a crash instead of a "say it again".
 */
@Serializable
data class AssessmentResponse(
    @SerialName("RecognitionStatus") val recognitionStatus: String = "",
    @SerialName("DisplayText") val displayText: String = "",
    @SerialName("Offset") val offset: Long = 0,
    @SerialName("Duration") val duration: Long = 0,
    @SerialName("NBest") val nBest: List<AssessmentCandidate> = emptyList()
) {
    val isSuccess: Boolean get() = recognitionStatus.equals("Success", ignoreCase = true)

    val heardNothing: Boolean
        get() = recognitionStatus.equals("NoMatch", ignoreCase = true) ||
            recognitionStatus.equals("InitialSilenceTimeout", ignoreCase = true) ||
            recognitionStatus.equals("BabbleTimeout", ignoreCase = true)
}

@Serializable
data class AssessmentCandidate(
    @SerialName("Display") val display: String = "",
    @SerialName("Lexical") val lexical: String = "",
    @SerialName("PronunciationAssessment") val assessment: AssessmentScores? = null,
    @SerialName("Words") val words: List<AssessedWord> = emptyList()
)

@Serializable
data class AssessmentScores(
    @SerialName("AccuracyScore") val accuracy: Float = 0f,
    @SerialName("FluencyScore") val fluency: Float = 0f,
    @SerialName("CompletenessScore") val completeness: Float = 0f,
    @SerialName("PronScore") val pronunciation: Float = 0f
)

@Serializable
data class AssessedWord(
    @SerialName("Word") val word: String = "",
    @SerialName("PronunciationAssessment") val assessment: WordScores? = null,
    @SerialName("Phonemes") val phonemes: List<AssessedPhoneme> = emptyList()
)

@Serializable
data class WordScores(
    @SerialName("AccuracyScore") val accuracy: Float = 0f,
    @SerialName("ErrorType") val errorType: String = "None"
)

@Serializable
data class AssessedPhoneme(
    @SerialName("Phoneme") val phoneme: String = "",
    @SerialName("PronunciationAssessment") val assessment: PhonemeScores? = null
)

@Serializable
data class PhonemeScores(
    @SerialName("AccuracyScore") val accuracy: Float = 0f
)

/**
 * The request header the service reads, sent base64-encoded.
 *
 * `granularity = Phoneme` is the reason this app can say "your /v/ keeps coming
 * out as /w/" instead of "72%", so it is not optional. `enableMiscue` makes the
 * service report words the learner skipped or added rather than quietly scoring
 * around them, which is what makes the completeness score mean anything.
 */
@Serializable
data class AssessmentRequestConfig(
    @SerialName("referenceText") val referenceText: String,
    @SerialName("gradingSystem") val gradingSystem: String = "HundredMark",
    @SerialName("granularity") val granularity: String = "Phoneme",
    @SerialName("phonemeAlphabet") val phonemeAlphabet: String = "IPA",
    @SerialName("dimension") val dimension: String = "Comprehensive",
    @SerialName("enableMiscue") val enableMiscue: Boolean = true
)

/** Flattens the service's nested response into the app's own model. */
fun AssessmentResponse.toReport(referenceText: String): PronunciationReport? {
    val best = nBest.firstOrNull() ?: return null
    val scores = best.assessment ?: return null

    return PronunciationReport(
        referenceText = referenceText,
        accuracy = scores.accuracy,
        fluency = scores.fluency,
        completeness = scores.completeness,
        overall = scores.pronunciation,
        recognisedText = best.display.ifBlank { displayText },
        words = best.words.map { word ->
            SpokenWordScore(
                word = word.word,
                accuracy = word.assessment?.accuracy ?: 0f,
                errorType = word.assessment?.errorType ?: "None",
                phonemes = word.phonemes.map { phoneme ->
                    PhonemeScore(
                        phoneme = phoneme.phoneme,
                        accuracy = phoneme.assessment?.accuracy ?: 0f
                    )
                }
            )
        }
    )
}
