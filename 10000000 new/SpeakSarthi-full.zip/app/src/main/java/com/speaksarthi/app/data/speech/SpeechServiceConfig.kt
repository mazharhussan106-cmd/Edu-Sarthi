package com.speaksarthi.app.data.speech

import java.net.URLEncoder

/**
 * Where the app talks to its server, and whether it is set up at all.
 *
 * Two routes, deliberately:
 *
 * **Through the proxy** ([proxyUrl]) — what a released build uses, and the only
 * route that supports credits at all. The app holds one address; the server
 * holds the speech key, owns the balance, and decides what every purchase was
 * worth. Nothing secret is in the APK and nothing the app claims about money is
 * believed.
 *
 * **Straight to Azure** ([azureKey] + [azureRegion]) — development only, for
 * testing against real audio before the server exists. There are no credits on
 * this route because there is nothing to keep them in: scoring is unmetered and
 * billed straight to whoever's key it is. A key in an APK is extractable in
 * minutes, so this must never ship.
 *
 * Neither configured is a supported state, not a bug: recording, playback and
 * the whole rest of the app work, and the speaking screen says plainly that
 * scoring is not switched on in this build.
 */
data class SpeechServiceConfig(
    /** The server's base address, with no trailing slash and no path. */
    val proxyUrl: String,
    val azureKey: String,
    val azureRegion: String,
    val locale: String = DEFAULT_LOCALE
) {
    val usesProxy: Boolean get() = proxyUrl.isNotBlank()

    val usesAzureDirectly: Boolean
        get() = !usesProxy && azureKey.isNotBlank() && azureRegion.isNotBlank()

    val isConfigured: Boolean get() = usesProxy || usesAzureDirectly

    /** The server's base address with any trailing slash removed, so paths append cleanly. */
    private val normalisedProxy: String get() = proxyUrl.trimEnd('/')

    /** One of the server's JSON endpoints, e.g. `/v1/balance`. */
    fun proxyEndpoint(path: String): String = normalisedProxy + path

    /**
     * Where a clip is sent for scoring.
     *
     * On the proxy route the reference text rides in the query string so the
     * body stays pure audio — the server needs to forward those bytes onward
     * untouched, and wrapping them in a multipart envelope would mean unwrapping
     * them again on the other side for no gain.
     */
    fun scoringEndpoint(referenceText: String): String = when {
        usesProxy ->
            normalisedProxy + "/v1/score?text=" + URLEncoder.encode(referenceText, "UTF-8")
        usesAzureDirectly ->
            "https://$azureRegion.stt.speech.microsoft.com/speech/recognition" +
                "/conversation/cognitiveservices/v1?language=$locale"
        else -> ""
    }

    companion object {
        /**
         * Indian English, on purpose.
         *
         * Scoring an Indian learner against en-US marks their own variety of
         * English wrong — retroflex consonants, syllable-timed rhythm, a
         * different vowel inventory — none of which makes them harder to
         * understand in the rooms they will actually be speaking in. en-IN
         * scores whether they are intelligible in the English they are learning
         * to speak, which is the thing worth measuring.
         *
         * If a learner is specifically preparing for IELTS or a US employer,
         * en-US is the better reference. That is a setting worth adding, not a
         * default worth imposing.
         */
        const val DEFAULT_LOCALE = "en-IN"
    }
}
