package com.speaksarthi.app.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStoreFile
import androidx.room.Room
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.speaksarthi.app.BuildConfig
import com.speaksarthi.app.data.local.Migrations
import com.speaksarthi.app.data.local.SpeakSarthiDatabase
import com.speaksarthi.app.data.local.dao.BadgeDao
import com.speaksarthi.app.data.local.dao.ContentDao
import com.speaksarthi.app.data.audio.AndroidTtsPlayer
import com.speaksarthi.app.data.analytics.Analytics
import com.speaksarthi.app.data.analytics.LoggingAnalytics
import com.speaksarthi.app.data.audio.AudioRecordVoiceRecorder
import com.speaksarthi.app.data.audio.MediaRecordingPlayer
import com.speaksarthi.app.data.audio.RecordingPlayer
import com.speaksarthi.app.data.audio.SpeechPlayer
import com.speaksarthi.app.data.audio.VoiceRecorder
import com.speaksarthi.app.data.speech.AzurePronunciationScorer
import com.speaksarthi.app.data.speech.PronunciationScorer
import com.speaksarthi.app.data.speech.SpeechServiceConfig
import com.speaksarthi.app.data.local.dao.DailyStatDao
import com.speaksarthi.app.data.local.dao.LearnerSentenceDao
import com.speaksarthi.app.data.local.dao.ProgressDao
import com.speaksarthi.app.data.local.dao.QuizAttemptDao
import com.speaksarthi.app.data.local.dao.RecordingDao
import com.speaksarthi.app.data.local.dao.WeakSoundDao
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.data.billing.BillingRepository
import com.speaksarthi.app.data.billing.PlayBillingRepository
import com.speaksarthi.app.data.auth.CredentialManagerGoogleSignIn
import com.speaksarthi.app.data.auth.GoogleSignIn
import com.speaksarthi.app.data.remote.HttpSpeakSarthiApi
import com.speaksarthi.app.data.remote.SpeakSarthiApi
import com.speaksarthi.app.data.repository.AccountRepositoryImpl
import com.speaksarthi.app.data.repository.CreditsRepositoryImpl
import com.speaksarthi.app.data.repository.BadgeRepositoryImpl
import com.speaksarthi.app.data.repository.LibraryRepositoryImpl
import com.speaksarthi.app.data.repository.SpeakingRepositoryImpl
import com.speaksarthi.app.data.repository.StudyRepositoryImpl
import com.speaksarthi.app.domain.repository.AccountRepository
import com.speaksarthi.app.domain.repository.BadgeRepository
import com.speaksarthi.app.domain.repository.CreditsRepository
import com.speaksarthi.app.domain.repository.LibraryRepository
import com.speaksarthi.app.domain.repository.SpeakingRepository
import com.speaksarthi.app.domain.repository.StudyRepository
import com.speaksarthi.app.util.Clock
import com.speaksarthi.app.util.SystemClock
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import javax.inject.Qualifier
import javax.inject.Singleton

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class IoDispatcher

@Qualifier
@Retention(AnnotationRetention.BINARY)
annotation class ApplicationScope

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): SpeakSarthiDatabase =
        Room.databaseBuilder(context, SpeakSarthiDatabase::class.java, SpeakSarthiDatabase.NAME)
            // No fallbackToDestructiveMigration: losing a learner's review history
            // on a schema change is exactly the failure this project has already
            // been bitten by once. Every version ships a real migration instead,
            // and a missing one crashes in testing rather than wiping in the wild.
            .addMigrations(*Migrations.ALL)
            .build()

    @Provides fun provideContentDao(db: SpeakSarthiDatabase): ContentDao = db.contentDao()
    @Provides fun provideProgressDao(db: SpeakSarthiDatabase): ProgressDao = db.progressDao()
    @Provides fun provideRecordingDao(db: SpeakSarthiDatabase): RecordingDao = db.recordingDao()
    @Provides fun provideWeakSoundDao(db: SpeakSarthiDatabase): WeakSoundDao = db.weakSoundDao()
    @Provides fun provideQuizAttemptDao(db: SpeakSarthiDatabase): QuizAttemptDao = db.quizAttemptDao()
    @Provides fun provideDailyStatDao(db: SpeakSarthiDatabase): DailyStatDao = db.dailyStatDao()
    @Provides fun provideBadgeDao(db: SpeakSarthiDatabase): BadgeDao = db.badgeDao()
    @Provides fun provideLearnerSentenceDao(db: SpeakSarthiDatabase): LearnerSentenceDao =
        db.learnerSentenceDao()

    @Provides
    @Singleton
    fun provideDataStore(@ApplicationContext context: Context): DataStore<Preferences> =
        PreferenceDataStoreFactory.create {
            context.preferencesDataStoreFile(AppPreferences.STORE_NAME)
        }

    @Provides
    @Singleton
    @IoDispatcher
    fun provideIoDispatcher(): CoroutineDispatcher = Dispatchers.IO

    @Provides
    @Singleton
    @ApplicationScope
    fun provideApplicationScope(@IoDispatcher dispatcher: CoroutineDispatcher): CoroutineScope =
        CoroutineScope(SupervisorJob() + dispatcher)

    /**
     * Image loader for the illustrations, which are fetched on demand rather
     * than bundled.
     *
     * The disk cache is capped at 64 MB — comfortably more than the whole
     * library of 1,000 drawings at the target file size, so in practice nothing
     * is ever evicted, while still bounding what the app can take from a phone
     * with little storage left. The memory cache is deliberately small: a card
     * shows one drawing at a time and there is no grid of thumbnails to scroll.
     */
    @Provides
    @Singleton
    fun provideImageLoader(@ApplicationContext context: Context): ImageLoader =
        ImageLoader.Builder(context)
            .diskCache {
                DiskCache.Builder()
                    .directory(context.cacheDir.resolve("illustrations"))
                    .maxSizeBytes(ILLUSTRATION_CACHE_BYTES)
                    .build()
            }
            .memoryCache {
                MemoryCache.Builder(context)
                    .maxSizePercent(0.10)
                    .build()
            }
            .respectCacheHeaders(false)
            .build()

    /**
     * Where pronunciation scoring is sent. All three values come from
     * `local.properties` or the environment at build time and are blank in a
     * checkout, which is a supported state — see the comment in
     * `app/build.gradle.kts`.
     */
    @Provides
    @Singleton
    fun provideSpeechServiceConfig(): SpeechServiceConfig = SpeechServiceConfig(
        proxyUrl = BuildConfig.SPEECH_PROXY_URL,
        azureKey = BuildConfig.AZURE_SPEECH_KEY,
        azureRegion = BuildConfig.AZURE_SPEECH_REGION
    )

    /**
     * The HTTP client for the scoring call.
     *
     * Timeouts are generous on write and read because the request body is audio
     * going up a mobile connection and the response waits on the service
     * actually assessing it — but they are finite, because a request that hangs
     * forever leaves the learner looking at a spinner with no way back.
     * Retries are off: a retry re-uploads the clip and is billed again, so
     * retrying is the learner's decision, taken in front of a button that says
     * what happened.
     */
    @Provides
    @Singleton
    fun provideOkHttpClient(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    /**
     * One JSON parser for the whole app.
     *
     * `ignoreUnknownKeys` because both the seed files and the speech service
     * gain fields over time and neither should be able to break the app by
     * doing so. `explicitNulls = false` keeps requests to the service free of
     * null-valued keys it does not expect.
     */
    @Provides
    @Singleton
    fun provideJson(): Json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        isLenient = true
    }

    /** 64 MB — more than the whole library needs, still bounded. */
    private const val ILLUSTRATION_CACHE_BYTES = 64L * 1024 * 1024
}

/**
 * Interface-to-implementation bindings. The implementations carry
 * `@Inject constructor`, so Hilt builds them itself and these only say which
 * concrete type satisfies each interface.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class BindsModule {

    @Binds
    @Singleton
    abstract fun bindClock(impl: SystemClock): Clock

    @Binds
    @Singleton
    abstract fun bindAnalytics(impl: LoggingAnalytics): Analytics

    @Binds
    @Singleton
    abstract fun bindSpeechPlayer(impl: AndroidTtsPlayer): SpeechPlayer

    @Binds
    @Singleton
    abstract fun bindLibraryRepository(impl: LibraryRepositoryImpl): LibraryRepository

    @Binds
    @Singleton
    abstract fun bindStudyRepository(impl: StudyRepositoryImpl): StudyRepository

    @Binds
    @Singleton
    abstract fun bindSpeakingRepository(impl: SpeakingRepositoryImpl): SpeakingRepository

    @Binds
    @Singleton
    abstract fun bindBadgeRepository(impl: BadgeRepositoryImpl): BadgeRepository

    @Binds
    @Singleton
    abstract fun bindAccountRepository(impl: AccountRepositoryImpl): AccountRepository

    @Binds
    @Singleton
    abstract fun bindCreditsRepository(impl: CreditsRepositoryImpl): CreditsRepository

    @Binds
    @Singleton
    abstract fun bindSpeakSarthiApi(impl: HttpSpeakSarthiApi): SpeakSarthiApi

    @Binds
    @Singleton
    abstract fun bindGoogleSignIn(impl: CredentialManagerGoogleSignIn): GoogleSignIn

    @Binds
    @Singleton
    abstract fun bindBillingRepository(impl: PlayBillingRepository): BillingRepository

    @Binds
    @Singleton
    abstract fun bindVoiceRecorder(impl: AudioRecordVoiceRecorder): VoiceRecorder

    @Binds
    @Singleton
    abstract fun bindRecordingPlayer(impl: MediaRecordingPlayer): RecordingPlayer

    @Binds
    @Singleton
    abstract fun bindPronunciationScorer(impl: AzurePronunciationScorer): PronunciationScorer
}
