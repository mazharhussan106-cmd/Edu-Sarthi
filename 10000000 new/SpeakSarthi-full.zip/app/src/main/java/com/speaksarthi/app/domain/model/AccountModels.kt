package com.speaksarthi.app.domain.model

/**
 * The learner's credit balance.
 *
 * One credit buys one scored attempt. Everything else in the app — all 1,000
 * words, every chunk, the flashcards, listening practice, recording and playing
 * back your own voice, mistake review, badges, statistics — is free forever and
 * always will be.
 *
 * That line is not a marketing choice, it is the only one the arithmetic allows.
 * AI scoring is the single thing here that costs money per use, and it is also
 * the thing people would pay for. Charging for anything else would mean charging
 * for what costs nothing to serve while giving away the thing that does.
 *
 * **This number is a copy.** The real balance lives on the server, because a
 * number kept on the phone is editable on a rooted device in about two minutes
 * and every edit spends the owner's Azure money. What is held here is the last
 * figure the server reported, and it exists so the app can show a balance and
 * disable a button without a network round trip per card. When the two disagree,
 * the server is right.
 */
data class CreditBalance(
    val credits: Int = 0,
    val source: Source = Source.Unknown,
    /** True once the learner has signed in; see [Profile.isAnonymous]. */
    val signedIn: Boolean = false,
    /** When the server last told us. Zero means it never has. */
    val checkedAt: Long = 0L
) {
    val hasCredits: Boolean get() = credits > 0

    /**
     * Low enough to be worth mentioning, but not yet empty.
     *
     * This is where sign-in is asked for — before the learner is stuck, not
     * after. Asking at zero means interrupting someone at the exact moment they
     * wanted to practise.
     */
    val isRunningLow: Boolean get() = credits in 1..LOW_WATER_MARK

    enum class Source {
        /** Nothing has been checked yet. */
        Unknown,

        /** The figure the server reported. */
        Server,

        /** No proxy configured in this build — scoring is off entirely. */
        NotConfigured
    }

    companion object {
        /**
         * Ten attempts left.
         *
         * Enough warning to sign in or buy a pack in a calm moment, chosen
         * because a learner mid-practice should not be interrupted by an
         * account prompt they could have dealt with yesterday.
         */
        const val LOW_WATER_MARK = 10

        val unknown = CreditBalance()

        val notConfigured = CreditBalance(source = Source.NotConfigured)
    }
}

/**
 * The learner, as this app knows them.
 *
 * Anonymous by default and **created on first launch**, not on sign-in. The
 * reason is a specific failure this project flagged twice and kept putting off:
 * a learner practises for three weeks, changes phone, and loses everything —
 * at precisely the moment they were starting to feel confident.
 *
 * Giving every install a stable id from day one means their work belongs to
 * *something* from the first minute, and that something can later be attached to
 * a real account without a single review record moving. Retrofitting identity
 * onto data that never had any is the version of this that does not work.
 *
 * [localId] is also what the server keys an anonymous account on, which is why
 * it must never be regenerated: it is the only thread connecting a learner to
 * the credits they have already been given.
 */
data class Profile(
    /** Stable for the life of the install. Random, not derived from the device. */
    val localId: String,
    /** Set when the learner signs in. Empty means anonymous, which is a full state. */
    val accountId: String = "",
    val displayName: String = "",
    val email: String = "",
    val createdAt: Long = 0L
) {
    val isAnonymous: Boolean get() = accountId.isBlank()
}
