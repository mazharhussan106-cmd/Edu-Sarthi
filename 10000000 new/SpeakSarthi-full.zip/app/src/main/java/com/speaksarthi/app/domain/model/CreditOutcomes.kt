package com.speaksarthi.app.domain.model

/** What happened when a Play purchase was sent to the server for verification. */
sealed interface RedeemOutcome {
    /** Credits added. [balance] is the new total. */
    data class Granted(val balance: Int) : RedeemOutcome

    /**
     * Play has the purchase but the money has not arrived.
     *
     * Normal in India rather than an edge case: a UPI mandate can sit
     * unconfirmed for hours and may never complete. The learner has done
     * everything right and has not been charged yet, and the app has to say so
     * without implying they failed.
     */
    data object Pending : RedeemOutcome

    /**
     * This purchase was already redeemed.
     *
     * Success, not an error — it is what a retry looks like. The balance is
     * already correct and there is nothing to tell the learner beyond it.
     */
    data class AlreadyRedeemed(val balance: Int) : RedeemOutcome

    data object Offline : RedeemOutcome

    data class Failed(val reason: String) : RedeemOutcome
}

/** What happened when a Google account was attached. */
sealed interface LinkOutcome {
    /** Linked. [balance] may be higher than before if another device had credits. */
    data class Linked(val balance: Int, val email: String) : LinkOutcome

    data object Offline : LinkOutcome

    /** The Google token was refused. Almost always a misconfigured OAuth client. */
    data class Rejected(val reason: String) : LinkOutcome

    data class Failed(val reason: String) : LinkOutcome
}
