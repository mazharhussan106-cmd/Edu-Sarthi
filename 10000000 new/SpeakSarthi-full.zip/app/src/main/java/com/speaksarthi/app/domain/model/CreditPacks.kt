package com.speaksarthi.app.domain.model

/**
 * The credit packs, as configured in the Play Console.
 *
 * Only the **ids** live here. How many credits each pack contains is decided by
 * the server and never by the app — partly because the app must not be the thing
 * that says how much was bought, and partly because those numbers still depend on
 * a cost that has not been measured. Keeping them server-side means correcting
 * them is a config change, not an app release that leaves everyone on old terms
 * until they update.
 *
 * The ids themselves are permanent. Changing one after launch strands everybody
 * who bought it on a product the app no longer asks about.
 */
enum class CreditPack(val productId: String) {
    Entry("credits_entry"),
    Standard("credits_standard"),
    Large("credits_large");

    companion object {
        fun forProductId(productId: String): CreditPack? =
            entries.firstOrNull { it.productId == productId }

        val productIds: List<String> = entries.map { it.productId }
    }
}

/**
 * Ways to earn credits without paying.
 *
 * The server decides what each is worth and caps how often it pays, because the
 * app claiming "I finished a lesson" is not something a server can verify
 * without syncing the whole progress model. The app's job is only to say that
 * the thing happened.
 */
enum class EarnKind(val wireName: String) {
    /** Finishing a lesson. [reference] is the lesson id. */
    Lesson("lesson"),

    /** A completed 7-day streak. [reference] is the ISO week. */
    Streak("streak")
}
