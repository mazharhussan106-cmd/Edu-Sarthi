package com.speaksarthi.app.domain.model

/**
 * Domain models — plain Kotlin, no Room or Android types, so the whole domain
 * layer is unit-testable on the JVM without an emulator.
 */

/**
 * CEFR band. The whole library is organised by difficulty rather than by topic,
 * so this drives the study queue, the placement test result, and the level badge
 * shown on every card.
 */
enum class CefrLevel(val code: String, val displayName: String, val order: Int) {
    A1("A1", "Beginner", 0),
    A2("A2", "Elementary", 1),
    B1("B1", "Intermediate", 2),
    B2("B2", "Upper intermediate", 3);

    companion object {
        fun fromCode(code: String): CefrLevel =
            entries.firstOrNull { it.code.equals(code.trim(), ignoreCase = true) } ?: A1
    }
}

/**
 * The learner's self-assessment after seeing a card's answer. Maps onto SM-2's
 * 0-5 recall quality; four buttons is the most a person will reliably use.
 */
enum class ReviewGrade(val sm2Quality: Int) {
    /** Did not know it. Resets the interval. */
    Again(1),

    /** Knew it, but it was a struggle. */
    Hard(3),

    /** Knew it. */
    Good(4),

    /** Instant, effortless recall. */
    Easy(5)
}

/** What kind of multi-word unit a chunk is. */
enum class ChunkType {
    /** Words that habitually travel together: "fully understand", "hard to understand". */
    COLLOCATION,

    /** Phrasal verbs and fixed expressions: "figure out", "catch on". */
    PHRASAL,

    /** A sentence frame with a slot: "understand + noun/clause". */
    PATTERN;

    companion object {
        fun fromRaw(raw: String): ChunkType =
            entries.firstOrNull { it.name.equals(raw.trim(), ignoreCase = true) } ?: COLLOCATION
    }
}

/** Where a speaking prompt came from, which sets how it is framed to the learner. */
enum class PracticeType {
    EXAMPLE,
    EVERYDAY,
    NEWS,
    CASUAL,
    CONVERSATION;

    companion object {
        fun fromRaw(raw: String): PracticeType =
            entries.firstOrNull { it.name.equals(raw.trim(), ignoreCase = true) } ?: EXAMPLE
    }
}

/**
 * One vocabulary entry — everything shown on parts 1 and 2 of the card.
 *
 * [wordId] (e.g. "VRB-001") is the stable identity across content updates. It is
 * the primary key in the database and the foreign key everything else points at,
 * so re-importing corrected content can never orphan a learner's progress.
 */
data class Word(
    val wordId: String,
    val word: String,
    val partOfSpeech: String,
    val category: String,
    val level: CefrLevel,
    val frequency: String,
    val importance: String,
    val register: String,
    val ipa: String,
    val syllableBreak: String,
    val hindiPronunciation: String,
    val hindiMeaning: String,
    val simpleMeaning: String,
    val plainExplanation: String,
    val etymology: String,
    val mnemonic: String,
    val quickTip: String,
    val pronunciationTip: String,
    val spellingTip: String,
    val wordFamily: List<String>,
    val prefixRootSuffix: String,
    val visualAssociation: String,
    val tone: String,
    val typicalContexts: List<String>,
    val miniConversation: String,
    val confusingWords: String,
    val relatedWords: List<String>,
    val synonyms: List<String>,
    val antonyms: List<String>,
    val emotionFeel: String,
    val commonMistakeWrong: String,
    val commonMistakeCorrect: String,
    val quickRecallPrompt: String,
    /** Filename of this word's illustration. Empty until the artwork is added. */
    val illustration: String,
    val orderIndex: Int
)

/** A multi-word unit belonging to a word. Part 3 of the card is built from these. */
data class Chunk(
    val chunkId: String,
    val wordId: String,
    val text: String,
    val type: ChunkType,
    val orderIndex: Int
)

/**
 * A sentence the learner is asked to say out loud. In v1 these are read and
 * self-recorded; from phase 3 they are the input to pronunciation scoring.
 */
data class PracticeItem(
    val itemId: String,
    val wordId: String,
    val text: String,
    /** The target word within [text], for emphasis in the UI. */
    val highlight: String,
    val type: PracticeType,
    val orderIndex: Int
)

/** A four-option multiple-choice question. The only standalone quiz format v1 ships. */
data class McqQuestion(
    val wordId: String,
    val question: String,
    val options: List<String>,
    val answerIndex: Int
) {
    val answer: String get() = options.getOrElse(answerIndex) { "" }
}

/** A prompt paired with the expected answer. */
data class AnswerablePrompt(
    val prompt: String,
    val answer: String
) {
    val isPresent: Boolean get() = prompt.isNotBlank() && answer.isNotBlank()
}

/**
 * The five practice-zone exercises for one word — part three of the card.
 *
 * [writeYourOwnPrompt] is open-ended and deliberately has no answer: the app
 * keeps what the learner writes and shows it back at the next review instead of
 * marking it. Anything a learner cannot be marked wrong on is worth including
 * for someone whose whole problem is being afraid of getting it wrong.
 */
data class Exercise(
    val wordId: String,
    val mcq: McqQuestion,
    val fillBlank: AnswerablePrompt,
    val findFix: AnswerablePrompt,
    val translate: AnswerablePrompt,
    val writeYourOwnPrompt: String
) {
    /** The exercises that actually have content, in the order the card shows them. */
    val availableCount: Int
        get() = 1 +
            (if (fillBlank.isPresent) 1 else 0) +
            (if (findFix.isPresent) 1 else 0) +
            (if (translate.isPresent) 1 else 0) +
            (if (writeYourOwnPrompt.isNotBlank()) 1 else 0)
}

/** Spaced-repetition state for one word. */
data class Progress(
    val wordId: String,
    val easeFactor: Double = SM2_DEFAULT_EASE,
    val intervalDays: Int = 0,
    val repetitions: Int = 0,
    val nextReviewAt: Long = 0L,
    val lastReviewedAt: Long = 0L,
    val timesSeen: Int = 0,
    val timesCorrect: Int = 0,
    val isBookmarked: Boolean = false,
    val isKnown: Boolean = false
) {
    val accuracy: Float
        get() = if (timesSeen == 0) 0f else timesCorrect.toFloat() / timesSeen

    fun isDue(nowEpochMillis: Long): Boolean = nextReviewAt <= nowEpochMillis

    /** A word never studied has no review row yet, or one with no repetitions. */
    val isNew: Boolean get() = repetitions == 0 && lastReviewedAt == 0L

    companion object {
        const val SM2_DEFAULT_EASE = 2.5
    }
}

/** A word plus its study state — what the study queue actually deals in. */
data class WordWithProgress(
    val word: Word,
    val progress: Progress
)

/** Counters for one calendar day, used by streaks, the daily goal and the speech meter. */
data class DailyStat(
    /** Local date as `yyyy-MM-dd`, so a day boundary means the learner's midnight. */
    val date: String,
    val wordsStudied: Int = 0,
    val chunksStudied: Int = 0,
    val quizzesAnswered: Int = 0,
    val quizzesCorrect: Int = 0,
    val recordingsMade: Int = 0,
    /** Seconds of audio sent for scoring. The cost meter — see the speech budget. */
    val secondsGraded: Int = 0,
    val studySeconds: Int = 0,
    val mistakesReviewed: Int = 0
) {
    /** Any activity at all — what the streak counts. */
    val isActive: Boolean
        get() = wordsStudied > 0 || quizzesAnswered > 0 || recordingsMade > 0

    val quizAccuracy: Float
        get() = if (quizzesAnswered == 0) 0f else quizzesCorrect.toFloat() / quizzesAnswered
}

/**
 * Result of the import pipeline. Rows that fail validation are skipped and
 * reported rather than aborting the whole import, so one bad row in a content
 * update never costs the learner the other 999.
 */
data class ImportReport(
    val wordsImported: Int = 0,
    val chunksImported: Int = 0,
    val practiceItemsImported: Int = 0,
    val questionsImported: Int = 0,
    val warnings: List<String> = emptyList()
) {
    val isSuccess: Boolean get() = wordsImported > 0
    val totalRows: Int get() = wordsImported + chunksImported + practiceItemsImported + questionsImported
}
