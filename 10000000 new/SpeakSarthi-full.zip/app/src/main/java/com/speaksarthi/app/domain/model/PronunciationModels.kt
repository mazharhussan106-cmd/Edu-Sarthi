package com.speaksarthi.app.domain.model

/**
 * Pronunciation scoring models.
 *
 * These carry the **raw** numbers the service returned. Nothing here decides
 * what the learner sees — that is `ScoreInterpreter`'s job, deliberately kept
 * separate, because the single biggest risk in this feature is showing someone
 * who is already embarrassed about their English a bare failing percentage.
 */

/** One phoneme the service scored inside a word. */
data class PhonemeScore(
    /** The phoneme as the service labels it, e.g. "v", "ah", "sh". */
    val phoneme: String,
    val accuracy: Float
) {
    val isWeak: Boolean get() = accuracy < WEAK_THRESHOLD

    companion object {
        /**
         * Below 60 a phoneme is worth telling the learner about.
         *
         * Not lower: the service is noticeably harsher on Indian English vowels
         * than on consonants, and a threshold of 75 or 80 would fill the weak-
         * sound list with vowels that are perfectly intelligible. The app scores
         * intelligibility, not accent conformity.
         */
        const val WEAK_THRESHOLD = 60f
    }
}

/** One word the service scored inside the sentence. */
data class SpokenWordScore(
    val word: String,
    val accuracy: Float,
    /** "None", "Omission", "Insertion", "Mispronunciation" as the service reports it. */
    val errorType: String,
    val phonemes: List<PhonemeScore> = emptyList()
) {
    val wasSkipped: Boolean get() = errorType.equals("Omission", ignoreCase = true)

    val wasMispronounced: Boolean
        get() = errorType.equals("Mispronunciation", ignoreCase = true) ||
            (!wasSkipped && accuracy < WEAK_WORD_THRESHOLD)

    /** The phonemes in this word worth naming, worst first. */
    val weakPhonemes: List<PhonemeScore>
        get() = phonemes.filter { it.isWeak }.sortedBy { it.accuracy }

    companion object {
        const val WEAK_WORD_THRESHOLD = 60f
    }
}

/**
 * A full scoring result for one recording.
 *
 * All four headline scores are 0–100 as the service returns them.
 */
data class PronunciationReport(
    val referenceText: String,
    /** How close each sound was to the expected one. */
    val accuracy: Float,
    /** Pacing and pausing — the score that most often reveals a nervous reader. */
    val fluency: Float,
    /** How much of the sentence was actually said. Low here usually means skipped words. */
    val completeness: Float,
    /** The service's own weighted overall. */
    val overall: Float,
    val words: List<SpokenWordScore> = emptyList(),
    /** What the service heard, which is worth showing when it heard something else entirely. */
    val recognisedText: String = ""
) {
    val mispronouncedWords: List<SpokenWordScore>
        get() = words.filter { it.wasMispronounced }.sortedBy { it.accuracy }

    val skippedWords: List<SpokenWordScore> get() = words.filter { it.wasSkipped }

    /** Every weak phoneme across the sentence, worst first, duplicates kept. */
    val weakPhonemes: List<PhonemeScore>
        get() = words.flatMap { it.weakPhonemes }.sortedBy { it.accuracy }
}

/**
 * What came back from asking for a score.
 *
 * Every non-success case is a named state rather than an exception, because
 * every one of them has a different thing to say to the learner and the
 * difference matters: "you have used today's scoring" is not an error, and
 * "scoring is not set up in this build" is not the learner's problem at all.
 */
sealed interface ScoringOutcome {
    data class Scored(
        val report: PronunciationReport,
        /** From `X-Credits-Remaining`. Null on the direct-Azure dev route. */
        val creditsRemaining: Int? = null
    ) : ScoringOutcome

    /** No key and no proxy configured. Recording still works; scoring does not. */
    data object NotConfigured : ScoringOutcome

    /**
     * No credits left. Carries the balance the server reported, which is zero
     * unless something odd happened.
     *
     * Not an error and never shown as one. Recording and playback keep working
     * — only the AI score stops — because recording costs nothing to provide
     * and taking it away would punish a learner for being broke.
     */
    data class NoCredits(val balance: Int = 0) : ScoringOutcome


    data object Offline : ScoringOutcome

    /** The service answered, but not with a score. */
    data class Failed(val reason: String, val isRetryable: Boolean = true) : ScoringOutcome

    /**
     * The service could not make out speech in the clip at all — usually
     * silence, a covered microphone, or a room too loud to work in.
     */
    data object NoSpeechHeard : ScoringOutcome
}

/** A phoneme the learner keeps getting wrong, with its running tally. */
data class WeakSound(
    val phoneme: String,
    val errorCount: Int,
    val attemptCount: Int,
    val lastSeenAt: Long
) {
    val errorRate: Float
        get() = if (attemptCount == 0) 0f else errorCount.toFloat() / attemptCount
}

/** A stored recording and whatever score it has. */
data class Recording(
    val id: Long,
    val wordId: String,
    val practiceItemId: String,
    val filePath: String,
    val durationMillis: Long,
    val recordedAt: Long,
    val accuracy: Float? = null,
    val fluency: Float? = null,
    val completeness: Float? = null,
    val overall: Float? = null,
    val weakPhonemes: List<String> = emptyList()
) {
    val isScored: Boolean get() = overall != null
}
