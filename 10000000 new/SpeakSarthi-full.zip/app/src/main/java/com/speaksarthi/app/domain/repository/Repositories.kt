package com.speaksarthi.app.domain.repository

import com.speaksarthi.app.domain.model.Chunk
import com.speaksarthi.app.domain.model.DailyStat
import com.speaksarthi.app.domain.model.CreditBalance
import com.speaksarthi.app.domain.model.EarnKind
import com.speaksarthi.app.domain.model.LinkOutcome
import com.speaksarthi.app.domain.model.Exercise
import com.speaksarthi.app.domain.model.McqQuestion
import com.speaksarthi.app.domain.model.PracticeItem
import com.speaksarthi.app.domain.model.Profile
import com.speaksarthi.app.domain.model.Progress
import com.speaksarthi.app.domain.model.Recording
import com.speaksarthi.app.domain.model.RedeemOutcome
import com.speaksarthi.app.domain.model.ReviewGrade
import com.speaksarthi.app.domain.model.ScoringOutcome
import com.speaksarthi.app.domain.model.WeakSound
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.domain.model.WordWithProgress
import com.speaksarthi.app.domain.usecase.badges.Badge
import com.speaksarthi.app.domain.usecase.badges.BadgeProgress
import kotlinx.coroutines.flow.Flow
import java.io.File

/** Reads over the shipped library. No learner state. */
interface LibraryRepository {

    fun observeWordCount(): Flow<Int>

    suspend fun wordCount(): Int

    suspend fun chunkCount(): Int

    suspend fun practiceItemCount(): Int

    suspend fun exerciseCount(): Int

    suspend fun countsByLevel(): Map<String, Int>

    suspend fun countsByChunkType(): Map<String, Int>

    suspend fun word(wordId: String): Word?

    fun observeWords(): Flow<List<Word>>

    fun observeWordsByLevel(level: String): Flow<List<Word>>

    suspend fun search(query: String, limit: Int = 50): List<Word>

    /** The chunks for a word — the material behind part three of the card. */
    suspend fun chunks(wordId: String): List<Chunk>

    /** The sentences a learner is asked to say out loud for this word. */
    suspend fun practiceItems(wordId: String): List<PracticeItem>

    /** All five practice-zone exercises for a word — part three of the card. */
    suspend fun exercise(wordId: String): Exercise?

    /**
     * A random sample of words the learner has already met, for listening
     * practice. Returns fewer than [limit] — or nothing at all — before they
     * have studied that many.
     */
    suspend fun studiedWords(limit: Int): List<Word>

    /** A random sample of the library, for distractors and first-run fallbacks. */
    suspend fun randomWords(level: String = "", limit: Int = 40): List<Word>

    /**
     * Words the learner has bookmarked, in library order.
     *
     * A Flow rather than a one-off read: bookmarking happens from the study card
     * and from search, and a stale list is exactly what makes a bookmarks screen
     * feel broken.
     */
    fun observeBookmarked(): Flow<List<Word>>

    /** Words touched recently, newest first — "where was I?". */
    suspend fun recentlyStudied(limit: Int = 30): List<Word>

    /** Quiz mode pulls only the multiple-choice half of a random exercise set. */
    suspend fun randomMcqs(level: String = "", limit: Int = 10): List<McqQuestion>
}

/** Study state: the review queue, grading, bookmarks and daily counters. */
interface StudyRepository {

    /**
     * Words due for review right now, plus never-seen words, ordered so the most
     * overdue come first.
     *
     * @param level restricts to one CEFR band; empty string means all levels.
     */
    suspend fun dueQueue(level: String = "", limit: Int = 30): List<WordWithProgress>

    fun observeDueCount(): Flow<Int>

    fun observeKnownCount(): Flow<Int>

    fun observeStartedCount(): Flow<Int>

    suspend fun progress(wordId: String): Progress

    /**
     * Every progress row at once.
     *
     * For callers that need to know about many words — the lesson path asks about
     * all 1,000 — because a thousand single-row queries is a thousand round trips
     * to SQLite for a screen that opens in one.
     */
    suspend fun allProgress(): List<Progress>

    /**
     * Applies a grade through the SM-2 engine, persists the new schedule and
     * bumps today's counters. Returns the updated progress.
     *
     * @param chunksSeen how many phrases were on the card, counted towards the
     *   phrase-builder badge — a learner working through the chunk list is doing
     *   the thing that actually makes speech sound fluent.
     * @param wasMistakeReview true when this came from mistake review rather than
     *   the normal queue, counted separately because going back to what you got
     *   wrong is the part almost everyone skips.
     */
    suspend fun grade(
        wordId: String,
        grade: ReviewGrade,
        chunksSeen: Int = 0,
        wasMistakeReview: Boolean = false
    ): Progress

    suspend fun setBookmarked(wordId: String, bookmarked: Boolean)

    /** Words the learner gets wrong more often than right, worst first. */
    suspend fun weakestWords(limit: Int = 30): List<WordWithProgress>

    /**
     * The mistake-review queue: words answered wrong, worst first, topped up
     * with words recently missed in a quiz.
     *
     * Deliberately not the SM-2 queue. SM-2 schedules what you are about to
     * forget; this is what you keep getting wrong, which is a different list and
     * the one a learner actually asks for.
     */
    suspend fun mistakeQueue(limit: Int = 20): List<WordWithProgress>

    /**
     * The words of one lesson, unlearned ones first.
     *
     * A lesson is a restricted queue, not a separate study mode. Ordering by what
     * is still unknown means reopening a half-finished lesson picks up where it
     * was left rather than re-showing what is already solid.
     */
    suspend fun lessonQueue(wordIds: List<String>, limit: Int = 20): List<WordWithProgress>

    suspend fun recordQuizAnswer(wordId: String, selectedIndex: Int, wasCorrect: Boolean)

    fun observeToday(): Flow<DailyStat>

    /** Consecutive days with activity, counting back from today. */
    suspend fun currentStreak(): Int

    /** The sentence the learner wrote for this word, or empty if they never did. */
    suspend fun ownSentence(wordId: String): String

    /** Keeps what the learner wrote. Never marked — it is shown back at the next review. */
    suspend fun saveOwnSentence(wordId: String, text: String)
}

/**
 * Speaking practice: recordings, scoring and the sounds to work on.
 *
 * Separate from [StudyRepository] because it is the only part of the app that
 * spends money per use. What it spends is metered by the server, not here; this
 * interface exists so the one call that costs money has exactly one place it can
 * be made from, and that place is covered by a test.
 */
interface SpeakingRepository {

    /** True when there is somewhere to send audio for scoring. */
    fun scoringIsConfigured(): Boolean

    /** Where this app keeps recordings. Device-local; nothing is uploaded in v1. */
    fun recordingDirectory(): File

    /** A fresh file to record into, named so it cannot collide with an existing clip. */
    fun newRecordingFile(wordId: String): File

    /**
     * Sentences worth saying out loud for a word, shortest first.
     *
     * Short lines score better and teach more: the service's completeness score
     * punishes a learner who runs out of breath halfway through a long sentence,
     * and a nervous speaker is far more likely to finish a short one.
     */
    suspend fun promptsFor(wordId: String): List<PracticeItem>

    /** Words to practise speaking, drawn from the review queue. */
    suspend fun speakingQueue(limit: Int = 10): List<WordWithProgress>

    /**
     * Scores a clip and stores everything that follows from it — the recording
     * row, the phoneme tallies, and today's counters.
     *
     * Does **not** decide whether the learner can afford it. The server holds
     * that gate, reserves the credit before calling the speech service and gives
     * it back if the call fails, which is the only version of the check that a
     * rooted device cannot talk its way past. What this does is skip the request
     * when the cached balance already says zero — a courtesy that saves a
     * pointless round trip, not a control.
     *
     * The recording is saved whatever comes back, so a learner never loses a
     * clip because the network did.
     */
    suspend fun scoreAndStore(
        audio: File,
        wordId: String,
        prompt: PracticeItem,
        durationMillis: Long
    ): ScoringOutcome

    /** Saves a clip without scoring it — used when scoring is off or unavailable. */
    suspend fun storeUnscored(
        audio: File,
        wordId: String,
        prompt: PracticeItem,
        durationMillis: Long
    ): Long

    fun observeRecordings(wordId: String): Flow<List<Recording>>

    fun observeRecordingCount(): Flow<Int>

    /** Phonemes the learner keeps missing, worst error rate first. */
    fun observeWeakSounds(limit: Int = 10): Flow<List<WeakSound>>

    /** Average overall score across recent scored clips, or null if none are scored. */
    suspend fun averageScoreSince(since: Long): Float?

    /** Deletes every clip and its rows — the "clear my recordings" action. */
    suspend fun deleteAllRecordings()
}

/**
 * Badges, and the counters they are earned against.
 *
 * Its own repository rather than a corner of [StudyRepository] because a badge
 * is earned from evidence spread across studying, speaking and streaks — it
 * belongs to none of them, and wedging it into one would mean that one reaching
 * into the others.
 */
interface BadgeRepository {

    /** Everything the evaluator tests against, kept current as the learner works. */
    fun observeProgress(): Flow<BadgeProgress>

    /** Badge ids already earned. Only ever added to — a badge is never withdrawn. */
    fun observeEarned(): Flow<Set<String>>

    /**
     * Awards anything newly earned and returns just those, so the caller can
     * announce them. Safe to call often; awarding a badge already held is a
     * no-op and announces nothing.
     */
    suspend fun award(): List<Badge>
}

/**
 * Who the learner is.
 *
 * Identity only — what they can afford lives in [CreditsRepository], because the
 * balance is the server's and the profile is the device's, and keeping them in
 * one interface was how the old subscription model ended up with a tier the app
 * could simply assert.
 */
interface AccountRepository {

    /** The profile, created on first read if this install has never had one. */
    fun observeProfile(): Flow<Profile>

    suspend fun profile(): Profile

    /** Attaches a real account to the existing local profile, keeping all its work. */
    suspend fun signIn(accountId: String, displayName: String, email: String)

    /**
     * Detaches the account, keeping everything on the device.
     *
     * Signing out must never delete a learner's progress — it was earned on this
     * device and it stays here. It does clear the session, because the next
     * person to use the phone should not inherit the last one's credits.
     */
    suspend fun signOut()
}

/**
 * What the learner can afford, and the only path by which that changes.
 *
 * Every method here either reports something to the server or reads what the
 * server says back. **None of them can raise a balance on their own**, and that
 * is the point: a credit count the app could write is a credit count a rooted
 * device can write, and every forged credit spends the owner's Azure money.
 *
 * The balance this exposes is a cache of the last server answer, kept so a
 * screen can show a number without a round trip. When the two disagree the
 * server wins, and the next call fixes the cache.
 */
interface CreditsRepository {

    /** True when this build has a server to meter against. */
    fun isConfigured(): Boolean

    fun observeBalance(): Flow<CreditBalance>

    suspend fun balance(): CreditBalance

    /** Asks the server for the current figure. Falls back to the cache when offline. */
    suspend fun refresh(): CreditBalance

    /**
     * Records a balance the server reported through some other channel.
     *
     * Scoring returns the new balance in a response header, which saves a
     * request per card. This is how that figure gets home.
     */
    suspend fun recordServerBalance(credits: Int)

    /** Sends a Play purchase for verification. The server decides what it was worth. */
    suspend fun redeem(productId: String, purchaseToken: String): RedeemOutcome

    /**
     * Reports something that earns credits.
     *
     * Fire and forget by design: if it fails the learner still keeps the lesson,
     * and retrying forever to chase a two-credit bonus is not worth the battery.
     */
    suspend fun claimEarned(kind: EarnKind, reference: String)

    /** Attaches a Google identity, merging any credits that account already had. */
    suspend fun linkGoogleAccount(idToken: String): LinkOutcome
}
