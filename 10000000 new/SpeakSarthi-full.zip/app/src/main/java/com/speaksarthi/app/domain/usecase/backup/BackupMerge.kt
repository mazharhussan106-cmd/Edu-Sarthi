package com.speaksarthi.app.domain.usecase.backup

import com.speaksarthi.app.data.backup.BackupBadge
import com.speaksarthi.app.data.backup.BackupDailyStat
import com.speaksarthi.app.data.backup.BackupProgress
import com.speaksarthi.app.data.backup.BackupSentence
import com.speaksarthi.app.data.backup.BackupWeakSound

/**
 * How a restore combines the backup with whatever is already on the device.
 *
 * Restoring is not always onto an empty phone. The two real cases are a new
 * device (nothing local, so any rule works) and a learner who kept using the app
 * after taking the backup and now wants their old data too. The second is where
 * a naive rule loses work — and losing work is the exact thing this feature was
 * built to prevent, so it would be a poor way to fail.
 *
 * Every rule below is therefore "keep the one that represents more learning",
 * never "the incoming one wins". Pure functions, so all of it is tested.
 */
object BackupMerge {

    /**
     * The more recently reviewed record wins.
     *
     * Not the higher interval: a word the learner has just rated "Again" has a
     * *lower* interval than its backed-up version and is the truer record of
     * where they stand. Recency is what spaced repetition actually cares about.
     */
    fun mergeProgress(local: BackupProgress?, incoming: BackupProgress): BackupProgress {
        if (local == null) return incoming

        val winner = if (incoming.lastReviewedAt > local.lastReviewedAt) incoming else local

        // Bookmarks and "known" are the exception: they are intent rather than
        // schedule, so they survive from either side. Un-bookmarking is rare and
        // trivially redone; losing a bookmark list is annoying and silent.
        return winner.copy(
            isBookmarked = local.isBookmarked || incoming.isBookmarked,
            isKnown = local.isKnown || incoming.isKnown,
            timesSeen = maxOf(local.timesSeen, incoming.timesSeen),
            timesCorrect = maxOf(local.timesCorrect, incoming.timesCorrect)
        )
    }

    /**
     * Per-counter maximum, not a sum.
     *
     * Summing would double every day that appears on both sides — which is every
     * day, when someone restores a backup taken from the same device. A learner
     * discovering they apparently studied 40 words on a day they studied 20 has
     * lost trust in every number the app shows them.
     */
    fun mergeDailyStat(local: BackupDailyStat?, incoming: BackupDailyStat): BackupDailyStat {
        if (local == null) return incoming
        return BackupDailyStat(
            date = incoming.date,
            wordsStudied = maxOf(local.wordsStudied, incoming.wordsStudied),
            chunksStudied = maxOf(local.chunksStudied, incoming.chunksStudied),
            quizzesAnswered = maxOf(local.quizzesAnswered, incoming.quizzesAnswered),
            quizzesCorrect = maxOf(local.quizzesCorrect, incoming.quizzesCorrect),
            recordingsMade = maxOf(local.recordingsMade, incoming.recordingsMade),
            secondsGraded = maxOf(local.secondsGraded, incoming.secondsGraded),
            studySeconds = maxOf(local.studySeconds, incoming.studySeconds),
            mistakesReviewed = maxOf(local.mistakesReviewed, incoming.mistakesReviewed)
        )
    }

    /**
     * Earned is earned, and the earlier date is the true one.
     *
     * A badge is never withdrawn anywhere else in this app; a restore is not the
     * place to make an exception.
     */
    fun mergeBadge(local: BackupBadge?, incoming: BackupBadge): BackupBadge {
        if (local == null) return incoming
        val earliest = listOf(local.earnedAt, incoming.earnedAt).filter { it > 0 }.minOrNull()
            ?: incoming.earnedAt
        return incoming.copy(earnedAt = earliest)
    }

    /**
     * Whichever side has heard the sound more often.
     *
     * Not a sum, for the same double-counting reason as the daily stats: the
     * backup and the device usually overlap. Taking the longer history keeps the
     * error *rate* meaningful, which is the number the sounds list ranks by.
     */
    fun mergeWeakSound(local: BackupWeakSound?, incoming: BackupWeakSound): BackupWeakSound {
        if (local == null) return incoming
        return if (incoming.attemptCount >= local.attemptCount) incoming else local
    }

    /** The later edit wins. It is one sentence, and the newer one is what they meant. */
    fun mergeSentence(local: BackupSentence?, incoming: BackupSentence): BackupSentence {
        if (local == null) return incoming
        return if (incoming.updatedAt >= local.updatedAt) incoming else local
    }

    /**
     * Merges two whole lists by key, applying [merge] where both sides have a row.
     *
     * Rows only on the local side are left alone — they are not returned, because
     * nothing needs to be written for them. Only what changes is handed back, so a
     * restore onto an untouched device writes nothing it does not have to.
     */
    fun <T> mergeAll(
        local: Map<String, T>,
        incoming: List<T>,
        keyOf: (T) -> String,
        merge: (T?, T) -> T
    ): List<T> = incoming.map { row -> merge(local[keyOf(row)], row) }
}
