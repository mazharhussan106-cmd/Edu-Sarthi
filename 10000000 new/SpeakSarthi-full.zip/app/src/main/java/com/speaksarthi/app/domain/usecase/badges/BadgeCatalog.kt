package com.speaksarthi.app.domain.usecase.badges

/**
 * The ten badges.
 *
 * Deliberately not an XP system, not coins, not levels. The user asked for a
 * simple progress model, and there is a better reason than that to keep it
 * simple: points reward *volume*, and volume is not what makes someone fluent.
 * Every badge here marks a thing that is genuinely worth having done — the first
 * time you recorded your own voice, a week you did not break, a sound you fixed.
 *
 * Three rules they all follow:
 *
 *  1. **Every badge is reachable without paying.** Scoring is the subscription,
 *     so only two badges involve a score at all, and neither needs more than the
 *     free tier allows.
 *  2. **None of them can be earned by grinding.** No "study 500 words" badge —
 *     that is a badge for having time, not for learning.
 *  3. **None of them punish a missed day.** The streak badges are earned once
 *     and kept; breaking a streak afterwards does not take them away. A learner
 *     who loses a badge for being ill does not come back.
 */
enum class Badge(
    val id: String,
    val title: String,
    /** What earns it, in the second person. */
    val requirement: String,
    /** Said once, at the moment it is earned. */
    val earnedMessage: String,
    val emoji: String
) {
    FirstWord(
        id = "first_word",
        title = "First word",
        requirement = "Study your first word",
        earnedMessage = "One down. The other 999 work exactly the same way.",
        emoji = "🌱"
    ),

    FirstRecording(
        id = "first_recording",
        title = "First time speaking",
        requirement = "Record yourself saying a sentence",
        earnedMessage = "That was the hard part. Nobody heard it but you.",
        emoji = "🎙"
    ),

    SevenDayStreak(
        id = "streak_7",
        title = "A full week",
        requirement = "Practise seven days in a row",
        earnedMessage = "Seven days. This is roughly where a habit starts holding on its own.",
        emoji = "🔥"
    ),

    ThirtyDayStreak(
        id = "streak_30",
        title = "A month of days",
        requirement = "Practise thirty days in a row",
        earnedMessage = "Thirty days. Most people who get here do not stop.",
        emoji = "🏔"
    ),

    HundredKnown(
        id = "known_100",
        title = "A hundred words",
        requirement = "Know 100 words well enough that they stop coming back daily",
        earnedMessage = "A hundred words you no longer have to think about.",
        emoji = "📗"
    ),

    ChunkCollector(
        id = "chunks_100",
        title = "Phrase builder",
        requirement = "Work through 100 ready-made phrases",
        earnedMessage = "Phrases are what make you sound fluent, not single words.",
        emoji = "🧩"
    ),

    CleanSentence(
        id = "clean_sentence",
        title = "Said it clearly",
        requirement = "Get a sentence scored as clear",
        earnedMessage = "That sentence would land with anyone. Do it again tomorrow.",
        emoji = "✨"
    ),

    SoundFixed(
        id = "sound_fixed",
        title = "Fixed a sound",
        requirement = "Turn one of your weak sounds around",
        earnedMessage = "You changed how you make a sound. That is the slow one, and you did it.",
        emoji = "🔧"
    ),

    MistakeMender(
        id = "mistakes_25",
        title = "Faced the hard ones",
        requirement = "Review 25 words you had got wrong",
        earnedMessage = "Going back to what you got wrong is the part almost everyone skips.",
        emoji = "🪞"
    ),

    OwnWords(
        id = "own_sentences_25",
        title = "In your own words",
        requirement = "Write 25 sentences of your own",
        earnedMessage = "Twenty-five sentences nobody marked. That is you using the language.",
        emoji = "✍️"
    );

    companion object {
        fun fromId(id: String): Badge? = entries.firstOrNull { it.id == id }

        /** The order they are shown in — roughly the order they are earned. */
        val displayOrder: List<Badge> = entries.toList()
    }
}

/**
 * Everything a badge can be tested against.
 *
 * Gathered once and passed in whole, so the evaluator stays a pure function of
 * its input and the rules below can be read in one place without chasing five
 * repositories.
 */
data class BadgeProgress(
    val wordsStudied: Int = 0,
    val knownWords: Int = 0,
    val chunksSeen: Int = 0,
    val currentStreak: Int = 0,
    val recordingsMade: Int = 0,
    /** Sentences the service rated in the top band. */
    val clearSentences: Int = 0,
    /**
     * A sound that was once weak and is now being said correctly.
     *
     * Specifically: a phoneme with at least [SOUND_FIXED_MIN_ATTEMPTS] attempts
     * whose error rate has fallen below [SOUND_FIXED_RATE]. Requiring a minimum
     * number of attempts is what stops a single lucky recording counting as
     * having fixed a sound.
     */
    val soundsFixed: Int = 0,
    val mistakesReviewed: Int = 0,
    val ownSentencesWritten: Int = 0
) {
    companion object {
        const val SOUND_FIXED_MIN_ATTEMPTS = 8
        const val SOUND_FIXED_RATE = 0.25f
    }
}

/**
 * Decides which badges the learner has earned.
 *
 * Pure, so the rules are unit-tested rather than discovered in production, and
 * so adding a badge means adding one branch here and one entry above.
 */
object BadgeEvaluator {

    fun isEarned(badge: Badge, progress: BadgeProgress): Boolean = when (badge) {
        Badge.FirstWord -> progress.wordsStudied >= 1
        Badge.FirstRecording -> progress.recordingsMade >= 1
        Badge.SevenDayStreak -> progress.currentStreak >= 7
        Badge.ThirtyDayStreak -> progress.currentStreak >= 30
        Badge.HundredKnown -> progress.knownWords >= 100
        Badge.ChunkCollector -> progress.chunksSeen >= 100
        Badge.CleanSentence -> progress.clearSentences >= 1
        Badge.SoundFixed -> progress.soundsFixed >= 1
        Badge.MistakeMender -> progress.mistakesReviewed >= 25
        Badge.OwnWords -> progress.ownSentencesWritten >= 25
    }

    /** Every badge earned by this progress, in display order. */
    fun earned(progress: BadgeProgress): List<Badge> =
        Badge.displayOrder.filter { isEarned(it, progress) }

    /**
     * Badges earned by [progress] that are not in [alreadyHeld].
     *
     * This is what the app actually announces. A badge already held is never
     * re-announced, and — importantly — a badge is never withdrawn: [alreadyHeld]
     * is only ever added to. Losing "a full week" because you were ill is how you
     * lose the learner too.
     */
    fun newlyEarned(progress: BadgeProgress, alreadyHeld: Set<String>): List<Badge> =
        earned(progress).filter { it.id !in alreadyHeld }

    /**
     * How far along an unearned badge is, 0f–1f, for the progress ring.
     *
     * Only meaningful for the counting badges; the one-off ones are either done
     * or not, and report 0f until they are.
     */
    fun progressTowards(badge: Badge, progress: BadgeProgress): Float {
        if (isEarned(badge, progress)) return 1f

        val fraction = when (badge) {
            Badge.SevenDayStreak -> progress.currentStreak / 7f
            Badge.ThirtyDayStreak -> progress.currentStreak / 30f
            Badge.HundredKnown -> progress.knownWords / 100f
            Badge.ChunkCollector -> progress.chunksSeen / 100f
            Badge.MistakeMender -> progress.mistakesReviewed / 25f
            Badge.OwnWords -> progress.ownSentencesWritten / 25f
            else -> 0f
        }
        return fraction.coerceIn(0f, 1f)
    }
}
