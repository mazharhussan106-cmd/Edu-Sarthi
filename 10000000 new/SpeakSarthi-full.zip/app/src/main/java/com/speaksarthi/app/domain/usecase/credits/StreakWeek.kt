package com.speaksarthi.app.domain.usecase.credits

import java.time.LocalDate
import java.time.temporal.WeekFields

/**
 * Which week a streak bonus belongs to.
 *
 * Its own object with a test on it because getting this wrong is silent in both
 * directions: a reference that changes too often pays a weekly bonus several
 * times a week, and one that changes too rarely stops paying it at all. Neither
 * shows up as a crash, and both are about money.
 *
 * ISO weeks, and specifically the ISO **week-based year**, because the calendar
 * year is the trap here. 31 December 2025 falls in week 1 of 2026, not of 2025 —
 * so pairing the ISO week number with the ordinary calendar year would emit
 * "2025-W1" in December and again in early January, and the server, having
 * already paid "2025-W1", would never pay the second one.
 */
object StreakWeek {

    /** A full week of practice before the bonus is due. */
    const val DAYS_REQUIRED = 7

    /** The reference the server keys this week's bonus on, e.g. `2026-W38`. */
    fun reference(date: LocalDate): String {
        val week = date.get(WeekFields.ISO.weekOfWeekBasedYear())
        val year = date.get(WeekFields.ISO.weekBasedYear())
        return "$year-W$week"
    }

    fun isDue(streakDays: Int): Boolean = streakDays >= DAYS_REQUIRED
}
