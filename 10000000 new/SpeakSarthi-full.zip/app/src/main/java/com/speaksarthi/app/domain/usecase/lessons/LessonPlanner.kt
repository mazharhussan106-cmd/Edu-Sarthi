package com.speaksarthi.app.domain.usecase.lessons

import com.speaksarthi.app.domain.model.CefrLevel
import com.speaksarthi.app.domain.model.Word

/**
 * One lesson: a named, finishable set of words.
 *
 * The point of a lesson, next to the spaced-repetition queue that already exists,
 * is **an ending**. The queue is infinite by design — it hands you what you are
 * about to forget, forever. That is the right way to remember things and a poor
 * way to feel you are getting somewhere. A lesson has twenty words, a title, and
 * a moment where it is done.
 */
data class Lesson(
    val id: String,
    val number: Int,
    val title: String,
    /** One line on what this lesson is for, in the second person. */
    val subtitle: String,
    val level: CefrLevel,
    val category: String,
    val wordIds: List<String>
) {
    val size: Int get() = wordIds.size
}

/** A lesson plus how far the learner has got through it. */
data class LessonProgress(
    val lesson: Lesson,
    val wordsKnown: Int,
    val wordsStarted: Int
) {
    val isComplete: Boolean get() = lesson.size > 0 && wordsKnown >= lesson.size

    val isStarted: Boolean get() = wordsStarted > 0

    val fraction: Float
        get() = if (lesson.size == 0) 0f else (wordsKnown.toFloat() / lesson.size).coerceIn(0f, 1f)
}

/**
 * Builds the lesson path out of the library that already exists.
 *
 * **This is scaffolding, and it says so.** A hand-authored course — where a human
 * decided that lesson 7 teaches the past continuous and chose eighteen words to
 * do it with — is better than anything an algorithm can group, and it is weeks of
 * work by someone who knows how to teach. What this does is produce a coherent,
 * finishable path through the same 1,000 words in the meantime, so the app has a
 * sense of forward motion on day one rather than on day ninety.
 *
 * The grouping rules, in order:
 *
 *  1. **Easiest level first.** Someone placed at A1 should not meet B2 words in
 *     lesson 3.
 *  2. **Within a level, group by category.** Twenty words about food is a lesson;
 *     twenty words with nothing in common is a list.
 *  3. **Keep the library's own order inside a group**, which is roughly frequency
 *     order — so the most useful words in each category come first.
 *  4. **Never leave a stub.** A trailing group of three words is folded into the
 *     lesson before it rather than shipped as "Lesson 12: three words".
 */
object LessonPlanner {

    /**
     * Twenty words, matching a study session.
     *
     * Deliberately the same number, so "do a lesson" and "do a session" are the
     * same size of commitment and a learner can predict what they are agreeing
     * to.
     */
    const val TARGET_SIZE = 20

    /** Below this a group is folded into its neighbour rather than left alone. */
    const val MINIMUM_SIZE = 8

    fun plan(words: List<Word>): List<Lesson> {
        if (words.isEmpty()) return emptyList()

        val lessons = mutableListOf<Lesson>()
        var number = 1

        // Levels in order, so the path climbs.
        val byLevel = words.groupBy { it.level }.toSortedMap(compareBy { it.order })

        byLevel.forEach { (level, levelWords) ->
            val byCategory = levelWords
                .groupBy { it.category.trim().ifBlank { "General" } }
                // Bigger categories first: a learner's early lessons should be
                // the ones with enough material to be coherent.
                .toList()
                .sortedByDescending { it.second.size }

            byCategory.forEach { (category, categoryWords) ->
                val ordered = categoryWords.sortedBy { it.orderIndex }
                val chunks = chunk(ordered)

                chunks.forEachIndexed { index, group ->
                    lessons += Lesson(
                        id = "L%03d".format(number),
                        number = number,
                        title = titleFor(category, index, chunks.size),
                        subtitle = subtitleFor(level, category, group.size),
                        level = level,
                        category = category,
                        wordIds = group.map { it.wordId }
                    )
                    number++
                }
            }
        }
        return lessons
    }

    /**
     * Splits into lessons of [TARGET_SIZE], folding a short tail into the last
     * full lesson.
     *
     * Without the fold, a category of 23 words produces a lesson of 20 and a
     * lesson of 3 — and a three-word lesson looks like a bug, not a lesson.
     */
    fun chunk(words: List<Word>): List<List<Word>> {
        if (words.isEmpty()) return emptyList()
        if (words.size <= TARGET_SIZE + MINIMUM_SIZE) return listOf(words)

        val groups = words.chunked(TARGET_SIZE).toMutableList()
        val last = groups.last()

        if (last.size < MINIMUM_SIZE && groups.size > 1) {
            groups.removeAt(groups.lastIndex)
            groups[groups.lastIndex] = groups.last() + last
        }
        return groups
    }

    private fun titleFor(category: String, index: Int, total: Int): String =
        if (total <= 1) category else "$category ${index + 1}"

    /**
     * A line about what the lesson is for.
     *
     * Generated, and therefore general. This is the most obvious place a human
     * pass would improve the course: "Twenty words about food" is true and dull,
     * where "Ordering, complaining and asking what is in it" is a reason to open
     * the lesson.
     */
    private fun subtitleFor(level: CefrLevel, category: String, size: Int): String =
        "$size words · ${level.displayName.lowercase()} · ${category.lowercase()}"

    /**
     * The next lesson to offer: the first unfinished one.
     *
     * Not the first unstarted one — a lesson half-done is a better thing to point
     * someone at than a fresh one, and finishing things is the entire reason
     * lessons exist alongside the queue.
     */
    fun nextLesson(progress: List<LessonProgress>): LessonProgress? =
        progress.firstOrNull { it.isStarted && !it.isComplete }
            ?: progress.firstOrNull { !it.isComplete }
}
