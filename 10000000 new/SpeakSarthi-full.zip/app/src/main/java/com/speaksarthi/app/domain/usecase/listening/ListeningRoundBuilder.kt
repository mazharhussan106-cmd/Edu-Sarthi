package com.speaksarthi.app.domain.usecase.listening

import com.speaksarthi.app.domain.model.Word
import kotlin.random.Random

/**
 * One listening question: a word that gets spoken, and four words to choose from.
 *
 * [sentence] is the same word inside a real sentence. Hearing a word on its own
 * and hearing it inside connected speech are close to different skills — the
 * second is where endings get swallowed and stress moves — so the learner can
 * ask for it, but only after the bare word.
 */
data class ListeningQuestion(
    val word: Word,
    val options: List<String>,
    val answerIndex: Int,
    val sentence: String = ""
) {
    val answer: String get() = options.getOrElse(answerIndex) { word.word }
}

/**
 * Builds a listening round.
 *
 * The whole difficulty of a listening test lives in the wrong options. Four
 * words picked at random make a test of nothing: "understand" against "table",
 * "purple" and "swim" is answerable from one syllable, or from no syllables at
 * all if the learner recognises three of the four as words they have never met.
 * So distractors are scored for how close they sound to the target and the
 * closest are used, which is what turns this into a test of the ear.
 */
object ListeningRoundBuilder {

    const val OPTIONS_PER_QUESTION = 4

    /** Below this many usable words there is no honest round to build. */
    const val MINIMUM_POOL = OPTIONS_PER_QUESTION

    /**
     * @param targets the words that will be spoken, in the order asked.
     * @param pool every word available to draw wrong options from. May contain
     *   the targets; they are filtered out per question.
     * @param sentences a sentence per word id, used for the "in a sentence"
     *   replay. Missing entries simply mean that button does not appear.
     */
    fun build(
        targets: List<Word>,
        pool: List<Word>,
        sentences: Map<String, String> = emptyMap(),
        random: Random = Random.Default
    ): List<ListeningQuestion> {
        val everything = (targets + pool).distinctBy { it.wordId }
        if (everything.size < MINIMUM_POOL) return emptyList()

        return targets.mapNotNull { target ->
            val distractors = pickDistractors(target, everything, random)
            if (distractors.size < OPTIONS_PER_QUESTION - 1) return@mapNotNull null

            val options = (distractors.map { it.word } + target.word).shuffled(random)
            ListeningQuestion(
                word = target,
                options = options,
                answerIndex = options.indexOf(target.word),
                sentence = sentences[target.wordId].orEmpty()
            )
        }
    }

    /**
     * The three closest-sounding words that are not the target.
     *
     * Ties are broken randomly rather than by list order, so meeting the same
     * word twice in a week does not mean meeting the same three wrong options.
     */
    private fun pickDistractors(
        target: Word,
        pool: List<Word>,
        random: Random
    ): List<Word> = pool
        .asSequence()
        .filter { it.wordId != target.wordId }
        .filter { !it.word.equals(target.word, ignoreCase = true) }
        .distinctBy { it.word.lowercase() }
        .map { candidate -> candidate to (confusability(target, candidate) * 10 + random.nextInt(10)) }
        .sortedByDescending { it.second }
        .take(OPTIONS_PER_QUESTION - 1)
        .map { it.first }
        .toList()

    /**
     * How easily [candidate] could be misheard as [target]. Higher is closer.
     *
     * A real phonetic distance would need a pronunciation dictionary and an
     * edit distance over phonemes. This is spelling and shape instead, which is
     * a rough proxy — but the data does carry IPA and a syllable break, and
     * syllable count especially is something the ear does notice, so the
     * approximation is better than it sounds. Worth replacing with real phoneme
     * distance if listening practice becomes a paid feature.
     */
    fun confusability(target: Word, candidate: Word): Int {
        val a = target.word.trim().lowercase()
        val b = candidate.word.trim().lowercase()
        if (a.isEmpty() || b.isEmpty()) return 0

        var score = 0

        if (a.first() == b.first()) score += 3
        if (a.last() == b.last()) score += 2

        val sharedPrefix = a.commonPrefixWith(b).length
        if (sharedPrefix >= 3) score += 3 else if (sharedPrefix == 2) score += 1

        val sharedSuffix = a.commonSuffixWith(b).length
        if (sharedSuffix >= 3) score += 2 else if (sharedSuffix == 2) score += 1

        when (kotlin.math.abs(a.length - b.length)) {
            0, 1 -> score += 2
            2 -> score += 1
        }

        val targetSyllables = syllableCount(target)
        val candidateSyllables = syllableCount(candidate)
        if (targetSyllables > 0 && targetSyllables == candidateSyllables) score += 2

        // Same part of speech keeps the option set grammatically level, so the
        // learner cannot shortcut past the audio by ruling out the one verb.
        if (target.partOfSpeech.isNotBlank() &&
            target.partOfSpeech.equals(candidate.partOfSpeech, ignoreCase = true)
        ) {
            score += 1
        }

        return score
    }

    /** Syllables from the dot-separated break in the content, e.g. "un·der·stand" = 3. */
    private fun syllableCount(word: Word): Int {
        val raw = word.syllableBreak.trim()
        if (raw.isEmpty()) return 0
        return raw.split('·', '-', '.', '|', '/')
            .count { it.isNotBlank() }
    }
}
