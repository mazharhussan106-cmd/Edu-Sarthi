package com.speaksarthi.app.domain.usecase.placement

import com.speaksarthi.app.domain.model.CefrLevel

/**
 * One answered placement question.
 *
 * Only the band and whether it was right are kept. The question itself has done
 * its job by the time this exists, and keeping it would tempt someone into
 * showing a learner their wrong answers — which is exactly what this test is
 * designed not to do.
 */
data class PlacementAnswer(
    val level: CefrLevel,
    val wasCorrect: Boolean
)

/**
 * Decides where to start a learner, from a short test they are free to skip.
 *
 * The design constraint that shapes everything here: **this test must not feel
 * like an exam.** The learner it is for is someone embarrassed about their
 * English, opening a language app for the first time. A test that opens with
 * B2 vocabulary and marks them down tells them, in the first two minutes, that
 * they were right to be embarrassed.
 *
 * So it climbs rather than samples. It starts at A1, moves up only while the
 * learner is getting things right, and stops the moment they are not. Most
 * people therefore see mostly questions they can answer, and the test ends
 * early for the people who would find it hardest.
 */
object PlacementScorer {

    /** Questions asked per band before moving up. */
    const val QUESTIONS_PER_LEVEL = 3

    /**
     * How many of a band's questions must be right to climb past it.
     *
     * Two out of three. One is luck on a four-option question; three is a bar
     * that puts genuinely capable learners a level below where they belong,
     * which wastes weeks of their time.
     */
    const val CORRECT_TO_ADVANCE = 2

    /** The bands the test walks through, easiest first. */
    val ladder: List<CefrLevel> = CefrLevel.entries.sortedBy { it.order }

    /**
     * The level a learner has demonstrated.
     *
     * The highest band they cleared, or the lowest band if they cleared none —
     * never "below A1", because there is no such thing to offer them and no
     * value in saying it.
     */
    fun levelFor(answers: List<PlacementAnswer>): CefrLevel {
        if (answers.isEmpty()) return ladder.first()

        val cleared = ladder.filter { level ->
            val forLevel = answers.filter { it.level == level }
            forLevel.size >= QUESTIONS_PER_LEVEL &&
                forLevel.count { it.wasCorrect } >= CORRECT_TO_ADVANCE
        }
        return cleared.maxByOrNull { it.order } ?: ladder.first()
    }

    /**
     * The band to ask about next, or null when the test is over.
     *
     * Over means one of two things: they failed a band, or they cleared the top
     * one. Both are finished tests.
     */
    fun nextLevel(answers: List<PlacementAnswer>): CefrLevel? {
        for (level in ladder) {
            val forLevel = answers.filter { it.level == level }

            if (forLevel.size < QUESTIONS_PER_LEVEL) return level

            val correct = forLevel.count { it.wasCorrect }
            // Failed this band: stop here rather than marching them through
            // three more questions they will also get wrong.
            if (correct < CORRECT_TO_ADVANCE) return null
        }
        return null
    }

    fun isComplete(answers: List<PlacementAnswer>): Boolean = nextLevel(answers) == null

    /** Total questions if the learner goes all the way — for the progress bar. */
    val maximumQuestions: Int get() = ladder.size * QUESTIONS_PER_LEVEL

    /**
     * What to tell the learner at the end.
     *
     * Never a score, never a percentage, and never the word "test". They are
     * being placed, not assessed, and the difference is most of the point.
     */
    fun resultMessage(level: CefrLevel): String = when (level) {
        CefrLevel.A1 ->
            "We will start from the beginning. That is where most people start, " +
                "and it is the fastest way to get solid."

        CefrLevel.A2 ->
            "You already know the basics, so we will start just past them."

        CefrLevel.B1 ->
            "You have a real working vocabulary. We will start where it gets useful."

        CefrLevel.B2 ->
            "You know a lot of words already. We will start with the ones that " +
                "make the difference between understood and fluent."
    }
}
