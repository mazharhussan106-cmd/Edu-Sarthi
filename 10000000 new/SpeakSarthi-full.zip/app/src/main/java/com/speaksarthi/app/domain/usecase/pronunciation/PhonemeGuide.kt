package com.speaksarthi.app.domain.usecase.pronunciation

/**
 * Plain-language names for the sounds the scoring service reports.
 *
 * The service returns IPA symbols. "ʒ" on a screen is not information — it is a
 * character most learners have never seen, attached to a score they did not ask
 * for. This turns each one into a name, an English example, and where the
 * tongue goes.
 *
 * Only the sounds that actually cause trouble for Hindi and Urdu speakers are
 * described in detail. The rest fall back to an honest generic entry rather than
 * an invented one — a confidently wrong pronunciation tip is worse than none,
 * because the learner will practise it.
 */
object PhonemeGuide {

    data class Sound(
        val symbol: String,
        /** How to refer to it out loud, e.g. "the v sound". */
        val name: String,
        /** A common English word containing it. */
        val example: String,
        /** What the mouth does. */
        val how: String,
        /** Why this one specifically trips up Hindi and Urdu speakers, if it does. */
        val note: String = ""
    )

    private val sounds: Map<String, Sound> = listOf(
        Sound("v", "the v sound", "very", "Top teeth resting on your bottom lip, voice on.",
            "Hindi has no separate v and w, so these two swap. “Vine” and “wine” are different words."),
        Sound("w", "the w sound", "water", "Lips rounded and pushed forward, teeth not involved.",
            "The opposite half of the v/w pair."),
        Sound("θ", "the hard th", "think", "Tongue tip just touching the back of your top teeth, no voice.",
            "Usually comes out as a t. “Think” becomes “tink”."),
        Sound("ð", "the soft th", "this", "Same tongue position as the hard th, but with the voice on.",
            "Usually comes out as a d. “This” becomes “dis”."),
        Sound("z", "the z sound", "zoo", "Tongue near the ridge behind your teeth, voice buzzing.",
            "Often flattens into an s, which makes “eyes” sound like “ice”."),
        Sound("ʃ", "the sh sound", "ship", "Lips slightly forward, tongue further back than for s."),
        Sound("ʒ", "the soft j", "measure", "Like sh with the voice on.",
            "Rare in Hindi, so it often becomes a hard j."),
        Sound("f", "the f sound", "food", "Teeth on lip, no voice.",
            "Sometimes becomes a p. “Coffee” becomes “coppee”."),
        Sound("p", "the p sound", "paper", "Lips together, then a small puff of air.",
            "English p carries more air than the Hindi प."),
        Sound("t", "the t sound", "table", "Tongue on the ridge behind your top teeth.",
            "The Hindi ट is made further back with the tongue curled; English t is flatter and further forward."),
        Sound("d", "the d sound", "door", "Tongue on the ridge, voice on.",
            "Same curl-back difference as t."),
        Sound("r", "the r sound", "red", "Tongue raised but never touching — it does not tap.",
            "The Hindi र taps. An English r that taps sounds like a d to an English ear."),
        Sound("l", "the l sound", "little", "Tongue tip up, sound flowing around the sides."),
        Sound("ŋ", "the ng sound", "sing", "Back of the tongue against the roof, nothing released.",
            "Often finished with a hard g: “sing-g”."),
        Sound("h", "the h sound", "house", "A soft breath before the vowel.",
            "Easy to drop entirely, which changes “hair” into “air”."),
        Sound("æ", "the short a", "cat", "Mouth open wide, tongue low and forward.",
            "Sits between the Hindi अ and ए, so it usually lands on one or the other."),
        Sound("ɪ", "the short i", "sit", "Relaxed and quick — not the long ee.",
            "“Sit” and “seat” are different words; this is the difference."),
        Sound("iː", "the long ee", "seat", "Lips slightly spread, held a little longer."),
        Sound("ʊ", "the short u", "book", "Short, relaxed, lips barely rounded."),
        Sound("uː", "the long oo", "food", "Lips well rounded, held longer."),
        Sound("ə", "the weak vowel", "about", "Say it fast and quiet — almost swallowed.",
            "English weakens unstressed vowels; Hindi gives every syllable its full value. " +
                "Learning to weaken them is what makes English sound fluent rather than recited."),
        Sound("ɜː", "the er sound", "bird", "Tongue mid-mouth, lips neutral, no r at the end.",
            "Adding an r at the end is the most common giveaway here."),
        Sound("ɔː", "the aw sound", "thought", "Lips rounded, tongue back."),
        Sound("eɪ", "the ay sound", "day", "Starts at e and slides toward i."),
        Sound("aɪ", "the eye sound", "time", "Starts open, slides toward i."),
        Sound("əʊ", "the oh sound", "go", "Starts weak, slides toward a rounded oo."),
        Sound("aʊ", "the ow sound", "now", "Starts open, slides toward oo.")
    ).associateBy { it.symbol }

    /** The guide entry for a symbol, or an honest placeholder. */
    fun describe(symbol: String): Sound {
        val key = symbol.trim()
        return sounds[key]
            ?: sounds[key.lowercase()]
            ?: Sound(
                symbol = symbol,
                name = "the “$symbol” sound",
                example = "",
                how = "Play a word containing it and copy what you hear."
            )
    }

    /** True when there is real guidance rather than the placeholder. */
    fun isDescribed(symbol: String): Boolean =
        sounds.containsKey(symbol.trim()) || sounds.containsKey(symbol.trim().lowercase())
}
