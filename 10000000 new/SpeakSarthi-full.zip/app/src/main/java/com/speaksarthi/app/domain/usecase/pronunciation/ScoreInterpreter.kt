package com.speaksarthi.app.domain.usecase.pronunciation

import com.speaksarthi.app.domain.model.PhonemeScore
import com.speaksarthi.app.domain.model.PronunciationReport
import com.speaksarthi.app.domain.model.SpokenWordScore

/**
 * Where the learner stands on one recording — the whole score, in four words.
 *
 * A band rather than a number because a number invites comparison with a
 * standard nobody set, and because the difference between 71 and 74 is inside
 * the service's own noise on an Indian accent.
 */
enum class ScoreBand(val label: String) {
    /** Clear enough that a stranger would not have to ask again. */
    Clear("Clear"),

    /** Understandable, with a sound or two to tidy up. */
    Understandable("Understandable"),

    /** Some words would need repeating. */
    NeedsWork("Getting there"),

    /** The service could not match much of what was said to the sentence. */
    HardToFollow("Say it again")
}

/**
 * One thing to do next, named as a sound and a word to practise it on.
 *
 * Deliberately singular. A list of nine wrong phonemes is a report card; one
 * sound with one word is a thing a person can go and do.
 */
data class NextFix(
    val phoneme: String,
    /** The word from the sentence where it went wrong. */
    val inWord: String,
    val accuracy: Float,
    /** Plain-language description, e.g. "the v in 'very' — not a w". */
    val advice: String
)

/** Everything the score card draws, decided here rather than in the UI. */
data class ScoreReading(
    /** The sentence the learner was asked to say, for marking up on screen. */
    val reference: String,
    val band: ScoreBand,
    /** One sentence, addressed to the learner. Never a bare percentage. */
    val headline: String,
    val detail: String,
    val nextFix: NextFix?,
    /** Words worth marking in the sentence, lowercased. */
    val wordsToMark: Set<String>,
    val skippedWords: List<String>,
    /** True when the service heard something quite different from the prompt. */
    val heardSomethingElse: Boolean,
    /** Shown only on request, and never on its own. */
    val rawOverall: Int,
    val rawAccuracy: Int,
    val rawFluency: Int,
    val rawCompleteness: Int
)

/**
 * Turns raw service numbers into what the learner is told.
 *
 * This file exists because of a specific risk: the scoring service is measurably
 * harsher on Indian English than on American English, and this app is for
 * learners who are already embarrassed about speaking. Handing them a raw 64%
 * would be accurate, useless and discouraging in one go.
 *
 * So four rules are enforced here rather than left to each screen:
 *
 *  1. **A band, not a number.** The raw scores are kept and can be shown behind
 *     a tap, but they are never the headline.
 *  2. **Completeness is read separately from accuracy.** Skipping three words is
 *     a different problem from mispronouncing one, and telling someone their
 *     pronunciation is poor when they simply stopped early is wrong.
 *  3. **A low score always comes with one specific fix.** Never a low band on
 *     its own.
 *  4. **Nothing is ever called a failure.** The lowest band is an instruction
 *     ("Say it again"), not a verdict.
 *
 * Pure Kotlin and no Android types, so all of the above is unit-tested.
 */
object ScoreInterpreter {

    /**
     * Band thresholds, set from the service's own 0–100 scale.
     *
     * Lower than they would be for a native-speaker product, on purpose. At the
     * default thresholds a perfectly intelligible Indian English speaker lands
     * in the middle band on almost every sentence, which teaches them nothing
     * except that the app disapproves of how they talk.
     */
    const val CLEAR_FROM = 78f
    const val UNDERSTANDABLE_FROM = 62f
    const val NEEDS_WORK_FROM = 45f

    /** Below this, the learner left most of the sentence unsaid. */
    const val COMPLETENESS_FLOOR = 70f

    fun read(report: PronunciationReport): ScoreReading {
        val incomplete = report.completeness < COMPLETENESS_FLOOR
        val band = bandFor(report)
        val fix = nextFix(report)

        return ScoreReading(
            reference = report.referenceText,
            band = band,
            headline = headlineFor(band, incomplete),
            detail = detailFor(report, band, incomplete, fix),
            nextFix = fix,
            wordsToMark = (report.mispronouncedWords + report.skippedWords)
                .map { it.word.lowercase() }
                .toSet(),
            skippedWords = report.skippedWords.map { it.word },
            heardSomethingElse = heardSomethingElse(report),
            rawOverall = report.overall.toInt(),
            rawAccuracy = report.accuracy.toInt(),
            rawFluency = report.fluency.toInt(),
            rawCompleteness = report.completeness.toInt()
        )
    }

    /**
     * The band comes off accuracy, not the service's own overall.
     *
     * The overall score folds fluency in, and fluency punishes the careful,
     * slightly slow delivery of someone reading a sentence they are nervous
     * about — which is exactly the learner this app is for. Their sounds being
     * right is the thing being measured; their pacing is coaching, not a grade.
     */
    fun bandFor(report: PronunciationReport): ScoreBand {
        if (report.completeness < COMPLETENESS_FLOOR && report.completeness > 0f) {
            // Said too little to judge the sounds fairly.
            return ScoreBand.NeedsWork
        }
        return when {
            report.accuracy >= CLEAR_FROM -> ScoreBand.Clear
            report.accuracy >= UNDERSTANDABLE_FROM -> ScoreBand.Understandable
            report.accuracy >= NEEDS_WORK_FROM -> ScoreBand.NeedsWork
            else -> ScoreBand.HardToFollow
        }
    }

    /**
     * The worst phoneme in the worst word, with a word to practise it on.
     *
     * Worst-in-worst rather than worst-overall: a single bad phoneme inside an
     * otherwise clear word is usually the service being fussy, whereas a bad
     * phoneme inside a word the service also marked wrong is a real miss.
     */
    fun nextFix(report: PronunciationReport): NextFix? {
        val candidates = report.words
            .filter { it.wasMispronounced && it.weakPhonemes.isNotEmpty() }
            .sortedBy { it.accuracy }

        val word = candidates.firstOrNull()
            ?: report.words.firstOrNull { it.weakPhonemes.isNotEmpty() }
            ?: return null

        val phoneme = word.weakPhonemes.firstOrNull() ?: return null

        return NextFix(
            phoneme = phoneme.phoneme,
            inWord = word.word,
            accuracy = phoneme.accuracy,
            advice = adviceFor(phoneme, word)
        )
    }

    /**
     * Plain-language coaching for a phoneme.
     *
     * The listed sounds are the ones that actually cause trouble for Hindi and
     * Urdu speakers, and the advice is phrased as a mouth movement rather than
     * as phonetic terminology — "top teeth on your bottom lip" is something a
     * learner can do; "labiodental fricative" is something they can look up.
     * Anything not in the list gets an honest generic line rather than a
     * confidently wrong one.
     */
    fun adviceFor(phoneme: PhonemeScore, word: SpokenWordScore): String {
        val sound = phoneme.phoneme.lowercase().trim()
        val inWord = "in “${word.word}”"

        return when (sound) {
            "v" -> "The v $inWord — top teeth touching your bottom lip, not a w."
            "w" -> "The w $inWord — round your lips, no teeth."
            "θ", "th" -> "The th $inWord — tongue tip just behind your top teeth, not a t."
            "ð" -> "The soft th $inWord — tongue behind the teeth with the voice on, not a d."
            "z" -> "The z $inWord — keep the voice buzzing; it is not an s."
            "s" -> "The s $inWord — a clean hiss, no buzz."
            "ʃ", "sh" -> "The sh $inWord — lips a little forward, tongue further back than an s."
            "ʒ" -> "The soft j $inWord — like the s in “measure”."
            "f" -> "The f $inWord — teeth on lip, no voice; it is not a p."
            "p" -> "The p $inWord — a small puff of air, stronger than in Hindi."
            "t" -> "The t $inWord — tongue on the ridge behind your teeth, not curled back."
            "d" -> "The d $inWord — tongue on the ridge, not curled back."
            "æ" -> "The short a $inWord — wider and flatter than the Hindi a."
            "ɪ" -> "The short i $inWord — relaxed, not the long ee."
            "iː", "i" -> "The long ee $inWord — hold it slightly longer."
            "ʊ" -> "The short u $inWord — short and relaxed, not oo."
            "ə" -> "The weak vowel $inWord — say it quickly and quietly; it is not a full a."
            "ɜː", "ɜ" -> "The er $inWord — no r sound at the end of it."
            "r" -> "The r $inWord — the tongue does not tap; let it hover."
            "l" -> "The l $inWord — tongue tip up, sound flowing round it."
            "ŋ" -> "The ng $inWord — stop at the back of the mouth, no hard g."
            "h" -> "The h $inWord — a soft breath, do not drop it."
            else -> "The “${phoneme.phoneme}” sound $inWord came out unclear. " +
                "Play the model, then say just that word three times."
        }
    }

    private fun headlineFor(band: ScoreBand, incomplete: Boolean): String = when {
        incomplete -> "Some of the sentence was missing"
        band == ScoreBand.Clear -> "Clear"
        band == ScoreBand.Understandable -> "Understandable"
        band == ScoreBand.NeedsWork -> "Close — one sound to fix"
        else -> "Say it again"
    }

    private fun detailFor(
        report: PronunciationReport,
        band: ScoreBand,
        incomplete: Boolean,
        fix: NextFix?
    ): String {
        if (incomplete) {
            val skipped = report.skippedWords.map { it.word }
            return if (skipped.isNotEmpty()) {
                "It sounded like “${skipped.joinToString("”, “")}” got left out. " +
                    "Read the whole line, slowly — speed is not being marked."
            } else {
                "Part of the line did not come through. Try again a little closer to the microphone."
            }
        }

        return when (band) {
            ScoreBand.Clear ->
                if (report.fluency < 60f) {
                    "Every sound landed. It came out a little halting — say it once more " +
                        "without stopping and it will sound natural."
                } else {
                    "Every sound landed and it flowed. Nothing to fix here."
                }

            ScoreBand.Understandable ->
                "Someone would understand you without asking again. " +
                    (fix?.advice ?: "One or two sounds are a little soft.")

            ScoreBand.NeedsWork ->
                fix?.advice ?: "A couple of sounds need another go. Play the model and follow it."

            ScoreBand.HardToFollow ->
                "That one did not come through clearly. Play the model first, then say it " +
                    "at half speed — most of the time it is the room, not you."
        }
    }

    /**
     * Whether the service transcribed something substantially different.
     *
     * Worth telling the learner, because "it heard 'wine' when you said 'vine'"
     * is the single most useful sentence this feature can produce — but only
     * when the difference is real, so a comparison ignores punctuation and case.
     */
    fun heardSomethingElse(report: PronunciationReport): Boolean {
        if (report.recognisedText.isBlank()) return false
        return normalise(report.recognisedText) != normalise(report.referenceText)
    }

    private fun normalise(text: String): String =
        text.lowercase().filter { it.isLetterOrDigit() || it == ' ' }.trim().replace(Regex("\\s+"), " ")
}
