package com.speaksarthi.app.domain.usecase.pronunciation

import kotlin.math.ceil

/**
 * How much audio a clip counts for.
 *
 * This used to be the paywall — the rule that decided whether a clip could be
 * sent at all. It is not any more, and that is the point: the gate moved to the
 * server, where a rooted device cannot reach it. A limit enforced on the phone
 * was only ever a courtesy that looked like a control.
 *
 * What is left is arithmetic for the daily statistics: how many seconds of
 * speech the learner actually practised. Nothing here decides anything or costs
 * anyone money.
 */
object SpeechBudget {

    /**
     * What a clip counts for, in seconds.
     *
     * Rounded **up**, and kept that way even though this no longer meters
     * spending: a 1.2-second clip is a second of practice, not zero, and a
     * statistic that rounds effort down is a statistic that discourages the
     * person reading it.
     */
    fun costOf(durationMillis: Long): Int =
        ceil(durationMillis.coerceAtLeast(0) / 1000.0).toInt().coerceAtLeast(MINIMUM_COST_SECONDS)

    /** Even the shortest clip counts for something. */
    const val MINIMUM_COST_SECONDS = 1
}
