package com.speaksarthi.app.domain.usecase.reminders

import java.time.Duration
import java.time.LocalDateTime
import java.time.LocalTime

/**
 * One daily reminder, as the learner set it.
 *
 * [slot] is its identity — 0, 1 or 2 — rather than the time, so moving a reminder
 * from 8am to 9pm updates that reminder instead of creating a second one.
 */
data class Reminder(
    val slot: Int,
    val hour: Int,
    val minute: Int,
    val enabled: Boolean
) {
    val time: LocalTime get() = LocalTime.of(hour.coerceIn(0, 23), minute.coerceIn(0, 59))

    /** `08:30`, for storage. Parsed back by [ReminderSchedule.parse]. */
    fun serialise(): String = "%02d:%02d:%d".format(hour, minute, if (enabled) 1 else 0)

    /** `8:30 am`, for the learner. */
    fun display(): String {
        val suffix = if (hour < 12) "am" else "pm"
        val twelve = when {
            hour == 0 -> 12
            hour > 12 -> hour - 12
            else -> hour
        }
        return "%d:%02d %s".format(twelve, minute, suffix)
    }
}

/**
 * When reminders fire, worked out as arithmetic rather than platform calls.
 *
 * Separate from the scheduling machinery so the part that is easy to get subtly
 * wrong — "a reminder set for 8am at 9am today should fire tomorrow, not in
 * thirteen hours' time, and definitely not immediately" — is a pure function
 * with tests on it.
 */
object ReminderSchedule {

    /**
     * Three, because that is the cap the product set and it is the right one.
     *
     * A learning app that can notify you six times a day is an app you turn
     * notifications off for, and an app whose notifications you have turned off
     * cannot remind you of anything ever again. Three is the most that stays
     * inside the budget of goodwill a learner extends.
     */
    const val MAX_REMINDERS = 3

    /** Sensible defaults, offered but never switched on without being asked. */
    val defaults: List<Reminder> = listOf(
        Reminder(slot = 0, hour = 8, minute = 0, enabled = false),
        Reminder(slot = 1, hour = 13, minute = 30, enabled = false),
        Reminder(slot = 2, hour = 21, minute = 0, enabled = false)
    )

    /**
     * Milliseconds from [now] until this reminder's next firing.
     *
     * If the time has already passed today — including exactly now — the answer
     * is tomorrow. Returning zero or a negative delay would make WorkManager fire
     * the moment the learner saves the setting, which reads as a bug and teaches
     * them that this app pings for no reason.
     */
    fun delayMillis(reminder: Reminder, now: LocalDateTime): Long {
        val todayAt = now.toLocalDate().atTime(reminder.time)
        val next = if (todayAt.isAfter(now)) todayAt else todayAt.plusDays(1)
        return Duration.between(now, next).toMillis().coerceAtLeast(0)
    }

    /** Stable unique name per slot, so rescheduling replaces rather than duplicates. */
    fun workName(slot: Int): String = "reminder_slot_$slot"

    fun serialise(reminders: List<Reminder>): String =
        reminders.sortedBy { it.slot }.joinToString(",") { it.serialise() }

    /**
     * Reads reminders back, falling through to the defaults on anything it does
     * not understand.
     *
     * Lenient on purpose: a corrupt preference should cost the learner their
     * reminder times, not the ability to open the settings screen.
     */
    fun parse(raw: String): List<Reminder> {
        if (raw.isBlank()) return defaults

        val parsed = raw.split(",").mapIndexedNotNull { index, part ->
            val pieces = part.trim().split(":")
            if (pieces.size != 3) return@mapIndexedNotNull null

            val hour = pieces[0].toIntOrNull() ?: return@mapIndexedNotNull null
            val minute = pieces[1].toIntOrNull() ?: return@mapIndexedNotNull null
            if (hour !in 0..23 || minute !in 0..59) return@mapIndexedNotNull null

            Reminder(
                slot = index,
                hour = hour,
                minute = minute,
                enabled = pieces[2] == "1"
            )
        }

        if (parsed.size != MAX_REMINDERS) return defaults
        return parsed
    }

    /**
     * The message a reminder carries.
     *
     * Keyed on the slot so the three do not all say the same thing, and worded as
     * an invitation rather than an accusation. "You haven't studied today" is
     * true, unhelpful, and the reason notifications get switched off.
     */
    fun message(slot: Int, dueCount: Int, streakDays: Int): String = when {
        streakDays >= 3 && dueCount > 0 ->
            "$streakDays days in a row. $dueCount words are waiting whenever you have five minutes."

        dueCount > 0 -> "$dueCount words are ready when you are."

        slot == 0 -> "A few minutes of English before the day starts?"
        slot == 1 -> "Five minutes now is worth an hour later in the week."
        else -> "One round before bed — it is the one that sticks best."
    }

    const val NOTIFICATION_TITLE = "Speak Sarthi"
}
