package com.speaksarthi.app.domain.usecase.spacedrepetition

import com.speaksarthi.app.domain.model.Progress
import com.speaksarthi.app.domain.model.ReviewGrade
import kotlin.math.roundToLong

/**
 * SM-2 (SuperMemo 2, Piotr Wozniak, 1987) — https://super-memory.com/english/ol/sm2.htm
 *
 * Ported unchanged from WordMaster 1000, where it is already covered by unit
 * tests and has been running against real review data. Pure functions with no
 * Android or Room dependency, which keeps [SM2AlgorithmTest] a fast JVM test.
 *
 * The one deliberate deviation from the published algorithm is the lapse branch:
 * the paper restarts the interval at 1 day, and so does this, but the ease factor
 * is still updated on a lapse rather than left alone. That matches how modern
 * SM-2 implementations behave and makes repeatedly-failed words drift toward
 * shorter intervals instead of sitting at the default ease forever.
 */
object SM2Algorithm {

    /** Below this, intervals stop growing meaningfully; the paper's floor. */
    const val MIN_EASE_FACTOR = 1.3

    const val DEFAULT_EASE_FACTOR = 2.5

    private const val DAY_MILLIS = 24L * 60 * 60 * 1000

    data class Input(
        val previousEaseFactor: Double,
        val previousIntervalDays: Int,
        val previousRepetitions: Int,
        /** SM-2's "quality of recall", 0..5. */
        val quality: Int
    )

    data class Output(
        val newEaseFactor: Double,
        val newIntervalDays: Int,
        val newRepetitions: Int,
        val nextReviewDateEpochMillis: Long
    )

    /** Convenience overload driven by the app's four grade buttons. */
    fun review(
        previousEaseFactor: Double,
        previousIntervalDays: Int,
        previousRepetitions: Int,
        grade: ReviewGrade,
        nowEpochMillis: Long = System.currentTimeMillis()
    ): Output = compute(
        Input(
            previousEaseFactor = previousEaseFactor,
            previousIntervalDays = previousIntervalDays,
            previousRepetitions = previousRepetitions,
            quality = grade.sm2Quality
        ),
        nowEpochMillis
    )

    fun compute(input: Input, nowEpochMillis: Long = System.currentTimeMillis()): Output {
        val quality = input.quality.coerceIn(0, 5)

        // EF' = EF + (0.1 - (5-q) * (0.08 + (5-q) * 0.02)), floored at 1.3
        val delta = 0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02)
        val newEaseFactor = (input.previousEaseFactor + delta).coerceAtLeast(MIN_EASE_FACTOR)

        return if (quality < 3) {
            // Any lapse resets the repetition counter and forces a next-day re-review.
            Output(
                newEaseFactor = newEaseFactor,
                newIntervalDays = 1,
                newRepetitions = 0,
                nextReviewDateEpochMillis = nowEpochMillis + DAY_MILLIS
            )
        } else {
            val newRepetitions = input.previousRepetitions + 1
            val newInterval = when (newRepetitions) {
                1 -> 1
                2 -> 6
                else -> (input.previousIntervalDays * newEaseFactor)
                    .roundToLong()
                    .toInt()
                    .coerceAtLeast(1)
            }
            Output(
                newEaseFactor = newEaseFactor,
                newIntervalDays = newInterval,
                newRepetitions = newRepetitions,
                nextReviewDateEpochMillis = nowEpochMillis + newInterval * DAY_MILLIS
            )
        }
    }

    /**
     * Applies a grade to an existing [Progress] row and returns the updated one.
     * This is the single place review bookkeeping happens, so the counters and
     * the SM-2 state can never drift apart.
     */
    fun apply(
        progress: Progress,
        grade: ReviewGrade,
        nowEpochMillis: Long = System.currentTimeMillis()
    ): Progress {
        val result = review(
            previousEaseFactor = progress.easeFactor,
            previousIntervalDays = progress.intervalDays,
            previousRepetitions = progress.repetitions,
            grade = grade,
            nowEpochMillis = nowEpochMillis
        )
        val recalled = grade != ReviewGrade.Again
        return progress.copy(
            easeFactor = result.newEaseFactor,
            intervalDays = result.newIntervalDays,
            repetitions = result.newRepetitions,
            nextReviewAt = result.nextReviewDateEpochMillis,
            lastReviewedAt = nowEpochMillis,
            timesSeen = progress.timesSeen + 1,
            timesCorrect = progress.timesCorrect + if (recalled) 1 else 0,
            // "Known" means it has survived three successful reviews and is
            // scheduled more than a week out — not merely answered once.
            isKnown = result.newRepetitions >= 3 && result.newIntervalDays >= 7
        )
    }
}
