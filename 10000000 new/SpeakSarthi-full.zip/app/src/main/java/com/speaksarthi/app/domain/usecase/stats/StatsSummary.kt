package com.speaksarthi.app.domain.usecase.stats

import com.speaksarthi.app.domain.model.DailyStat
import java.time.LocalDate

/** One day on the chart. */
data class StatsDay(
    val date: LocalDate,
    val wordsStudied: Int,
    val studySeconds: Int,
    val recordings: Int,
    val quizzesAnswered: Int,
    val quizzesCorrect: Int
) {
    val isActive: Boolean get() = wordsStudied > 0 || recordings > 0 || quizzesAnswered > 0
}

/**
 * The statistics screen's whole content, computed in one place.
 *
 * Aggregation lives here rather than in the view model so the arithmetic — which
 * is the part that quietly goes wrong, especially around empty days and
 * divide-by-zero — is a pure function with tests on it.
 */
data class StatsSummary(
    val days: List<StatsDay>,
    val wordsThisWeek: Int,
    val wordsLastWeek: Int,
    val minutesThisWeek: Int,
    val activeDaysThisWeek: Int,
    val accuracy: Float,
    val totalRecordings: Int,
    val bestDayWords: Int
) {
    /** Change on last week as a fraction. Null when last week has nothing to compare against. */
    val weekOnWeekChange: Float?
        get() = if (wordsLastWeek == 0) null else (wordsThisWeek - wordsLastWeek) / wordsLastWeek.toFloat()

    val hasAnyActivity: Boolean get() = days.any { it.isActive }
}

object StatsCalculator {

    /** How many days the chart covers. Two weeks fits a phone without scrolling. */
    const val WINDOW_DAYS = 14

    /**
     * Builds the summary from whatever daily rows exist.
     *
     * Days with no row are filled in as zeroes rather than skipped. A chart that
     * silently omits the days you did nothing shows an unbroken run of effort
     * that never happened — flattering, and useless for deciding whether the
     * habit is actually holding.
     */
    fun summarise(
        stats: List<DailyStat>,
        today: LocalDate,
        windowDays: Int = WINDOW_DAYS
    ): StatsSummary {
        val byDate = stats.associateBy { it.date }

        val days = (windowDays - 1 downTo 0).map { back ->
            val date = today.minusDays(back.toLong())
            val stat = byDate[date.toString()]
            StatsDay(
                date = date,
                wordsStudied = stat?.wordsStudied ?: 0,
                studySeconds = stat?.studySeconds ?: 0,
                recordings = stat?.recordingsMade ?: 0,
                quizzesAnswered = stat?.quizzesAnswered ?: 0,
                quizzesCorrect = stat?.quizzesCorrect ?: 0
            )
        }

        // "This week" is the last seven days including today, not a calendar
        // week: a learner opening this on a Monday morning should not be told
        // they have done nothing this week.
        val thisWeek = days.takeLast(7)
        val lastWeek = days.dropLast(7).takeLast(7)

        val answered = days.sumOf { it.quizzesAnswered }
        val correct = days.sumOf { it.quizzesCorrect }

        return StatsSummary(
            days = days,
            wordsThisWeek = thisWeek.sumOf { it.wordsStudied },
            wordsLastWeek = lastWeek.sumOf { it.wordsStudied },
            minutesThisWeek = thisWeek.sumOf { it.studySeconds } / 60,
            activeDaysThisWeek = thisWeek.count { it.isActive },
            accuracy = if (answered == 0) 0f else correct.toFloat() / answered,
            totalRecordings = days.sumOf { it.recordings },
            bestDayWords = days.maxOfOrNull { it.wordsStudied } ?: 0
        )
    }
}
