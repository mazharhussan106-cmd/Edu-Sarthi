package com.speaksarthi.app.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.data.analytics.Analytics
import com.speaksarthi.app.data.analytics.AnalyticsEvent
import com.speaksarthi.app.data.reminder.ReminderScheduler
import com.speaksarthi.app.data.seed.ContentSeeder
import com.speaksarthi.app.presentation.navigation.Routes
import com.speaksarthi.app.presentation.theme.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Whether the app is ready to show anything. */
sealed interface StartupState {
    data object Seeding : StartupState

    /**
     * @param startRoute where the app opens. First launch goes to the privacy
     *   notice, then the placement test, then home — and never back, because each
     *   step records that it happened.
     */
    data class Ready(val startRoute: String) : StartupState

    /** The library failed to import. Without it there is no app, so this is fatal-but-retryable. */
    data class Failed(val warnings: List<String>) : StartupState
}

/**
 * Holds the two things that belong to the whole app rather than any one screen:
 * the display mode, and whether the library has been imported yet.
 *
 * The import runs before the first screen is shown. It is a few seconds on a
 * first launch and nothing on every launch after, and doing it here means no
 * screen has to handle the case of an empty database.
 */
@HiltViewModel
class AppViewModel @Inject constructor(
    private val seeder: ContentSeeder,
    private val reminders: ReminderScheduler,
    private val analytics: Analytics,
    private val preferences: AppPreferences
) : ViewModel() {

    private val _startup = MutableStateFlow<StartupState>(StartupState.Seeding)
    val startup: StateFlow<StartupState> = _startup.asStateFlow()

    val themeMode: StateFlow<ThemeMode> = preferences.themeMode
        .stateIn(viewModelScope, SharingStarted.Eagerly, ThemeMode.System)

    init {
        seed()
        analytics.track(AnalyticsEvent.AppOpened)

        // Reminders are re-applied on every launch. WorkManager persists across
        // reboots, but a device whose work database was cleared — or an app
        // restored from backup — would otherwise stop reminding silently, which
        // is the kind of failure nobody reports because nothing visibly breaks.
        viewModelScope.launch { reminders.applyAll() }
    }

    fun retry() = seed()

    /**
     * Where to open.
     *
     * Privacy before the placement test, and the placement test before home. The
     * notice comes first because the very next screen asks questions, and asking
     * before saying what happens to the answers is the wrong way round.
     */
    private suspend fun firstRoute(): String = when {
        !preferences.hasAcceptedPrivacy.first() -> Routes.PRIVACY_CONSENT
        !preferences.hasCompletedOnboarding.first() -> Routes.PLACEMENT
        else -> Routes.HOME
    }

    fun acceptPrivacy() {
        viewModelScope.launch { preferences.setPrivacyAccepted(true) }
    }

    private fun seed() {
        _startup.value = StartupState.Seeding
        viewModelScope.launch {
            _startup.value = when (val result = seeder.seedIfNeeded()) {
                is ContentSeeder.Result.Failed -> StartupState.Failed(result.report.warnings)
                else -> StartupState.Ready(startRoute = firstRoute())
            }
        }
    }
}
