package com.speaksarthi.app.presentation.badges

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.presentation.theme.SarthiTheme

/**
 * The ten badges — earned ones in colour, the rest greyed with their progress.
 *
 * Showing the unearned ones is the point. A locked badge with a half-full bar is
 * a reason to come back; a screen that only lists what you already have is a
 * trophy cabinet, and nobody opens it twice.
 */
@Composable
fun BadgesScreen(
    onBack: () -> Unit,
    viewModel: BadgesViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Badges",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${state.earnedCount} of ${state.rows.size}",
                        style = MaterialTheme.typography.labelMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(state.rows, key = { it.badge.id }) { row ->
                    BadgeCard(row = row)
                }

                item {
                    Text(
                        text = "No points, no coins, no levels. Each of these marks " +
                            "something worth having done — and none of them can be taken " +
                            "away once you have it.",
                        style = MaterialTheme.typography.labelMedium,
                        color = SarthiTheme.colors.mutedText,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun BadgeCard(row: BadgeRow) {
    val earned = row.isEarned

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(
                if (earned) {
                    SarthiTheme.colors.successContainer
                } else {
                    MaterialTheme.colorScheme.surface
                }
            )
            .padding(16.dp)
            .semantics {
                contentDescription = if (earned) {
                    "${row.badge.title}, earned. ${row.badge.requirement}"
                } else {
                    "${row.badge.title}, not yet earned. ${row.badge.requirement}"
                }
            },
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(
                    if (earned) {
                        SarthiTheme.colors.success.copy(alpha = 0.18f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = row.badge.emoji,
                fontSize = 22.sp,
                // Unearned badges are dimmed rather than hidden or replaced with
                // a padlock: seeing what it is makes it something to aim at.
                modifier = if (earned) Modifier else Modifier.alpha(0.35f)
            )
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = row.badge.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = if (earned) row.badge.earnedMessage else row.badge.requirement,
                style = MaterialTheme.typography.bodyMedium,
                color = if (earned) {
                    MaterialTheme.colorScheme.onSurface
                } else {
                    SarthiTheme.colors.mutedText
                }
            )

            if (!earned && row.progress > 0f) {
                LinearProgressIndicator(
                    progress = { row.progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .padding(top = 4.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = SarthiTheme.colors.divider
                )
            }

            if (earned && row.earnedOn.isNotBlank()) {
                Text(
                    text = "Earned ${row.earnedOn}",
                    style = MaterialTheme.typography.labelSmall,
                    color = SarthiTheme.colors.mutedText
                )
            }
        }
    }
}
