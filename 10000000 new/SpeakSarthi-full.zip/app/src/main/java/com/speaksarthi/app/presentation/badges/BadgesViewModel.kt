package com.speaksarthi.app.presentation.badges

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.local.dao.BadgeDao
import com.speaksarthi.app.domain.repository.BadgeRepository
import com.speaksarthi.app.domain.repository.StudyRepository
import com.speaksarthi.app.domain.usecase.badges.Badge
import com.speaksarthi.app.domain.usecase.badges.BadgeEvaluator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import javax.inject.Inject

/** One badge, ready to draw. */
data class BadgeRow(
    val badge: Badge,
    val isEarned: Boolean,
    /** 0f–1f for the unearned counting badges; 0f for the one-off ones. */
    val progress: Float,
    /** Formatted date, empty when not earned. */
    val earnedOn: String
)

data class BadgesUiState(
    val rows: List<BadgeRow> = emptyList(),
    val earnedCount: Int = 0
)

@HiltViewModel
class BadgesViewModel @Inject constructor(
    private val badges: BadgeRepository,
    private val badgeDao: BadgeDao,
    private val study: StudyRepository
) : ViewModel() {

    /**
     * The streak is counted back from today rather than stored, so it is fetched
     * once when the screen opens instead of being watched.
     */
    private val streak = MutableStateFlow(0)

    val state: StateFlow<BadgesUiState> = combine(
        badges.observeProgress(),
        badgeDao.observeAll().map { rows -> rows.associate { it.badgeId to it.earnedAt } },
        streak
    ) { progress, earnedAt, currentStreak ->
        val withStreak = progress.copy(currentStreak = currentStreak)

        val rows = Badge.displayOrder.map { badge ->
            val held = badge.id in earnedAt
            BadgeRow(
                badge = badge,
                // Held wins over the live evaluation, so a badge stays earned
                // even once the thing that earned it is no longer true — a broken
                // streak must not take back the week you did finish.
                isEarned = held || BadgeEvaluator.isEarned(badge, withStreak),
                progress = BadgeEvaluator.progressTowards(badge, withStreak),
                earnedOn = earnedAt[badge.id]?.let(::formatDate).orEmpty()
            )
        }

        BadgesUiState(rows = rows, earnedCount = rows.count { it.isEarned })
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), BadgesUiState())

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            streak.value = study.currentStreak()
            // Opening the screen is as good a moment as any to catch up on
            // anything earned since the last check.
            badges.award()
        }
    }

    private fun formatDate(epochMillis: Long): String =
        Instant.ofEpochMilli(epochMillis)
            .atZone(ZoneId.systemDefault())
            .format(DATE_FORMAT)

    private companion object {
        /** Day and month, no year — "earned 16 Sep" reads better than a timestamp. */
        val DATE_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM")
    }
}
