package com.speaksarthi.app.presentation.card

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.speaksarthi.app.domain.model.CefrLevel
import com.speaksarthi.app.presentation.theme.PhoneticStyle
import com.speaksarthi.app.presentation.theme.SarthiTheme

/**
 * The pieces the three card parts are built from.
 *
 * Two rules run through all of them, both taken from the accessibility brief:
 * colour is never the only signal (a wrong sentence is struck through as well as
 * tinted), and nothing is sized in a way that breaks when the system font scale
 * is turned up.
 */

/**
 * The illustration frame — a fixed 4:3 box that is the same size whether or not
 * artwork exists.
 *
 * Artwork is fetched on demand, so most of the time early on there will be
 * nothing to show. When that happens the frame holds the word's visual
 * association text instead, set in the card's own type. The layout must not
 * shift when an image arrives, which is the whole reason the frame is fixed.
 */
@Composable
fun IllustrationFrame(
    imageUrl: String?,
    visualAssociation: String,
    word: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(4f / 3f)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        if (imageUrl != null) {
            AsyncImage(
                model = imageUrl,
                contentDescription = "Illustration for $word",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text(
                text = visualAssociation.ifBlank { word },
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(24.dp)
                    .semantics {
                        contentDescription = "Picture for $word not available. $visualAssociation"
                    }
            )
        }
    }
}

/** CEFR band, colour-coded and labelled. The label carries the meaning, not the colour. */
@Composable
fun LevelBadge(level: CefrLevel, modifier: Modifier = Modifier) {
    val colour = SarthiTheme.colors.forLevel(level.code)
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(colour.copy(alpha = 0.14f))
            .border(1.dp, colour, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = level.code,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = colour
        )
    }
}

/** A small neutral tag — word id, part of speech, category, register. */
@Composable
fun MetaTag(text: String, modifier: Modifier = Modifier) {
    if (text.isBlank()) return
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

/**
 * Importance, out of five.
 *
 * The workbook stores this as a run of asterisks; the count is what matters.
 * Read out as "4 out of 5" rather than as five separate star icons.
 */
@Composable
fun ImportanceStars(importance: String, modifier: Modifier = Modifier) {
    val filled = importance.count { it == '*' }.coerceIn(0, 5)
    if (filled == 0) return

    Row(
        modifier = modifier.semantics { contentDescription = "Importance $filled out of 5" },
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        repeat(5) { index ->
            Text(
                text = if (index < filled) "★" else "☆",
                style = MaterialTheme.typography.labelLarge,
                color = if (index < filled) {
                    SarthiTheme.colors.warning
                } else {
                    SarthiTheme.colors.mutedText
                }
            )
        }
    }
}

/** A titled block. The card is a long scroll, so every section announces itself. */
@Composable
fun SectionCard(
    title: String,
    modifier: Modifier = Modifier,
    accent: Color? = null,
    content: @Composable () -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp)
    ) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = accent ?: MaterialTheme.colorScheme.primary
        )
        Box(modifier = Modifier.padding(top = 10.dp)) { content() }
    }
}

/** Label above, value below. The card's default way of showing a single field. */
@Composable
fun LabelledValue(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueStyle: TextStyle? = null
) {
    if (value.isBlank()) return
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = SarthiTheme.colors.mutedText
        )
        Text(
            text = value,
            style = valueStyle ?: MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}

/** A list rendered as comma-separated text — synonyms, antonyms, word family. */
@Composable
fun LabelledList(label: String, values: List<String>, modifier: Modifier = Modifier) {
    if (values.isEmpty()) return
    LabelledValue(label = label, value = values.joinToString(", "), modifier = modifier)
}

/**
 * The wrong/right pair from the common-mistakes block.
 *
 * The wrong sentence is struck through as well as tinted, so the distinction
 * survives for a learner who cannot tell the two colours apart.
 */
@Composable
fun MistakePair(wrong: String, corrected: String, modifier: Modifier = Modifier) {
    if (wrong.isBlank() && corrected.isBlank()) return

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (wrong.isNotBlank()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "✗",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.error
                )
                Text(
                    text = wrong,
                    style = MaterialTheme.typography.bodyLarge,
                    textDecoration = TextDecoration.LineThrough,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
        if (corrected.isNotBlank()) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "✓",
                    style = MaterialTheme.typography.bodyLarge,
                    color = SarthiTheme.colors.success
                )
                Text(
                    text = corrected,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

/**
 * A sentence with the target word emphasised.
 *
 * Matching is case-insensitive and whole-word-ish: "understand" should highlight
 * inside "Do you understand?" but not inside "misunderstanding", which would
 * teach the learner to look at the wrong thing.
 */
@Composable
fun HighlightedSentence(
    text: String,
    highlight: String,
    modifier: Modifier = Modifier,
    onSpeak: (() -> Unit)? = null
) {
    if (text.isBlank()) return

    val annotated = buildAnnotatedString {
        if (highlight.isBlank()) {
            append(text)
            return@buildAnnotatedString
        }

        val pattern = Regex("\\b${Regex.escape(highlight)}\\w*\\b", RegexOption.IGNORE_CASE)
        var cursor = 0
        pattern.findAll(text).forEach { match ->
            append(text.substring(cursor, match.range.first))
            withStyle(
                SpanStyle(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            ) {
                append(match.value)
            }
            cursor = match.range.last + 1
        }
        if (cursor < text.length) append(text.substring(cursor))
    }

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = annotated,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        if (onSpeak != null) {
            SpeakerButton(onClick = onSpeak, contentDescription = "Listen to this sentence")
        }
    }
}

/** Tap to hear something read aloud. Absent entirely when speech is unavailable. */
@Composable
fun SpeakerButton(
    onClick: () -> Unit,
    contentDescription: String,
    modifier: Modifier = Modifier,
    size: Dp = 36.dp,
    icon: ImageVector = Icons.AutoMirrored.Filled.VolumeUp
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .clickable(onClick = onClick)
            .semantics { this.contentDescription = contentDescription },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.size(size * 0.55f)
        )
    }
}

/** A chunk — the multi-word unit part three is built around. */
@Composable
fun ChunkRow(
    text: String,
    onSpeak: (() -> Unit)?,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        if (onSpeak != null) {
            SpeakerButton(
                onClick = onSpeak,
                contentDescription = "Listen to $text",
                size = 30.dp
            )
        }
    }
}

/** The syllable break, with the stressed syllable picked out. */
@Composable
fun SyllableBreak(syllables: String, modifier: Modifier = Modifier) {
    if (syllables.isBlank()) return

    // The workbook capitalises the stressed syllable: "uhn-der-STAND".
    val annotated = buildAnnotatedString {
        syllables.split("-").forEachIndexed { index, part ->
            if (index > 0) {
                withStyle(SpanStyle(color = SarthiTheme.colors.mutedText)) { append(" · ") }
            }
            val stressed = part.isNotBlank() && part == part.uppercase() && part.any { it.isLetter() }
            if (stressed) {
                withStyle(
                    SpanStyle(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.tertiary,
                        textDecoration = TextDecoration.Underline
                    )
                ) {
                    append(part.lowercase())
                }
            } else {
                append(part)
            }
        }
    }

    Text(
        text = annotated,
        style = PhoneticStyle,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = modifier.semantics {
            contentDescription = "Syllables: ${syllables.replace("-", ", ")}"
        }
    )
}

/**
 * One tappable answer in a multiple-choice question.
 *
 * Shared between the card's practice zone and listening practice so the two
 * behave identically: neutral until answered, then the correct option turns
 * green with a tick and a wrong pick turns red with a cross. The tick and cross
 * carry as much of the meaning as the colour does — a learner who cannot tell
 * the two hues apart still sees which is which — and the whole row is one
 * touch target rather than a small radio button.
 */
@Composable
fun ChoiceOption(
    text: String,
    selected: Boolean,
    correct: Boolean,
    answered: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    prefix: String = ""
) {
    val success = SarthiTheme.colors.success
    val error = MaterialTheme.colorScheme.error

    val borderColour: Color = when {
        !answered -> MaterialTheme.colorScheme.outline
        correct -> success
        selected -> error
        else -> MaterialTheme.colorScheme.outline
    }
    val marker: String? = when {
        !answered -> null
        correct -> "✓"
        selected -> "✗"
        else -> null
    }
    val label = if (prefix.isBlank()) text else "$prefix $text"

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (answered && correct) {
                    success.copy(alpha = 0.10f)
                } else {
                    MaterialTheme.colorScheme.surfaceVariant
                }
            )
            .border(
                width = if (answered && (correct || selected)) 2.dp else 1.dp,
                color = borderColour,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(enabled = !answered, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 14.dp)
            .semantics {
                contentDescription = when {
                    !answered -> label
                    correct -> "$label. Correct answer"
                    selected -> "$label. Your answer, incorrect"
                    else -> label
                }
            },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
        if (marker != null) {
            Text(
                text = marker,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (correct) success else error
            )
        }
    }
}
