package com.speaksarthi.app.presentation.card

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.speaksarthi.app.domain.model.Chunk
import com.speaksarthi.app.domain.model.ChunkType
import com.speaksarthi.app.domain.model.PracticeItem
import com.speaksarthi.app.domain.model.PracticeType
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.presentation.theme.FlashcardWordStyle
import com.speaksarthi.app.presentation.theme.PhoneticStyle
import com.speaksarthi.app.presentation.theme.SarthiTheme

/**
 * The card, in three parts: recognise, understand, practise.
 *
 * The reference card is a wide two-sided print layout with dense multi-column
 * blocks. On a phone those become vertically scrolling sections, but the
 * grouping and the labels are kept so it reads as the same card.
 */

// ---------------------------------------------------------------- part one

/**
 * Part 1 — Recognition. What the learner sees before they know the word.
 *
 * Deliberately holds nothing that gives the meaning away: no translation, no
 * definition. Someone should be able to sit on this page and try to remember.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CardPartRecognition(
    word: Word,
    imageUrl: String?,
    canSpeak: Boolean,
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        IllustrationFrame(
            imageUrl = imageUrl,
            visualAssociation = word.visualAssociation,
            word = word.word
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            MetaTag(word.wordId)
            LevelBadge(word.level)
        }

        // The word itself, and the two things a learner needs to say it.
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = word.word,
                style = FlashcardWordStyle,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.fillMaxWidth()
            )

            if (word.ipa.isNotBlank()) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (canSpeak) {
                        SpeakerButton(
                            onClick = { onSpeak(word.word) },
                            contentDescription = "Listen to ${word.word}"
                        )
                    }
                    Text(
                        text = word.ipa,
                        style = PhoneticStyle,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            SyllableBreak(word.syllableBreak)

            if (word.hindiPronunciation.isNotBlank()) {
                Text(
                    text = word.hindiPronunciation,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }

        SectionCard(title = "About this word") {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetaTag(word.partOfSpeech)
                    MetaTag(word.category)
                    MetaTag(word.register)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = word.frequency,
                        style = MaterialTheme.typography.bodyMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                    ImportanceStars(word.importance)
                }
            }
        }

        if (word.etymology.isNotBlank()) {
            SectionCard(title = "Where it comes from") {
                Text(
                    text = word.etymology,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        val tips = listOf(
            "Quick tip" to word.quickTip,
            "Saying it" to word.pronunciationTip,
            "Spelling it" to word.spellingTip,
            "Remembering it" to word.mnemonic
        ).filter { it.second.isNotBlank() }

        if (tips.isNotEmpty()) {
            SectionCard(title = "Tips", accent = MaterialTheme.colorScheme.tertiary) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    tips.forEachIndexed { index, (label, value) ->
                        if (index > 0) HorizontalDivider(color = SarthiTheme.colors.divider)
                        LabelledValue(label = label, value = value)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- part two

/** Part 2 — Understanding and usage. The answer side. */
@Composable
fun CardPartUnderstanding(
    word: Word,
    examples: List<PracticeItem>,
    canSpeak: Boolean,
    onSpeak: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val exampleSentences = examples.filter { it.type == PracticeType.EXAMPLE }
    val everyday = examples.firstOrNull { it.type == PracticeType.EVERYDAY }
    val news = examples.firstOrNull { it.type == PracticeType.NEWS }
    val casual = examples.firstOrNull { it.type == PracticeType.CASUAL }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionCard(title = "Meaning") {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                LabelledValue(
                    label = "In English",
                    value = word.simpleMeaning,
                    valueStyle = MaterialTheme.typography.titleLarge
                )
                LabelledValue(
                    label = "हिंदी में",
                    value = word.hindiMeaning,
                    valueStyle = MaterialTheme.typography.titleLarge
                )
                LabelledValue(label = "Put simply", value = word.plainExplanation)
            }
        }

        if (exampleSentences.isNotEmpty()) {
            SectionCard(title = "In a sentence") {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    exampleSentences.forEach { item ->
                        HighlightedSentence(
                            text = item.text,
                            highlight = item.highlight,
                            onSpeak = if (canSpeak) {
                                { onSpeak(item.text) }
                            } else {
                                null
                            }
                        )
                    }
                }
            }
        }

        if (word.synonyms.isNotEmpty() || word.antonyms.isNotEmpty()) {
            SectionCard(title = "Similar and opposite") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    LabelledList("Means about the same", word.synonyms)
                    LabelledList("Means the opposite", word.antonyms)
                }
            }
        }

        if (word.commonMistakeWrong.isNotBlank() || word.commonMistakeCorrect.isNotBlank()) {
            SectionCard(title = "Common mistake", accent = MaterialTheme.colorScheme.error) {
                MistakePair(word.commonMistakeWrong, word.commonMistakeCorrect)
            }
        }

        val wordBuilding = listOf(
            "Word family" to word.wordFamily.joinToString(", "),
            "Built from" to word.prefixRootSuffix,
            "Easily confused with" to word.confusingWords,
            "Related" to word.relatedWords.joinToString(", ")
        ).filter { it.second.isNotBlank() }

        if (wordBuilding.isNotEmpty()) {
            SectionCard(title = "Word building") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    wordBuilding.forEach { (label, value) ->
                        LabelledValue(label = label, value = value)
                    }
                }
            }
        }

        val toneAndUse = listOf(
            "Tone" to word.tone,
            "Feels" to word.emotionFeel,
            "Used in" to word.typicalContexts.joinToString(", ")
        ).filter { it.second.isNotBlank() }

        if (toneAndUse.isNotEmpty()) {
            SectionCard(title = "How it feels") {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    toneAndUse.forEach { (label, value) ->
                        LabelledValue(label = label, value = value)
                    }
                }
            }
        }

        if (word.miniConversation.isNotBlank()) {
            SectionCard(title = "In conversation") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = word.miniConversation,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (canSpeak) {
                        SpeakerButton(
                            onClick = { onSpeak(word.miniConversation) },
                            contentDescription = "Listen to this conversation"
                        )
                    }
                }
            }
        }

        val usageLines = listOfNotNull(
            everyday?.let { "Everyday" to it },
            news?.let { "News style" to it },
            casual?.let { "Casual" to it }
        )

        if (usageLines.isNotEmpty()) {
            SectionCard(title = "How people use it") {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    usageLines.forEach { (label, item) ->
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelMedium,
                                color = SarthiTheme.colors.mutedText
                            )
                            HighlightedSentence(
                                text = item.text,
                                highlight = item.highlight,
                                onSpeak = if (canSpeak) {
                                    { onSpeak(item.text) }
                                } else {
                                    null
                                }
                            )
                        }
                    }
                    // These read like quotes and are not. Saying so is cheap;
                    // implying a real film or outlet said them is a legal problem.
                    Text(
                        text = "Written as examples of how the word is used. " +
                            "Not quotes from any real film, article or person.",
                        style = MaterialTheme.typography.labelSmall,
                        color = SarthiTheme.colors.mutedText
                    )
                }
            }
        }

        if (word.quickRecallPrompt.isNotBlank()) {
            SectionCard(title = "Test yourself backwards", accent = MaterialTheme.colorScheme.tertiary) {
                Text(
                    text = word.quickRecallPrompt,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

// -------------------------------------------------------------- part three

/**
 * Part 3 — Chunks and practice.
 *
 * The chunks are the point of a spoken-English app: the learner memorises the
 * block, not the word. The practice zone sits underneath, one exercise per
 * block, in the order the reference card shows them.
 */
@Composable
fun CardPartPractice(
    word: Word,
    chunks: List<Chunk>,
    practice: PracticeZoneState,
    canSpeak: Boolean,
    onSpeak: (String) -> Unit,
    onSelectOption: (Int) -> Unit,
    onReveal: (PracticeReveal) -> Unit,
    onOwnSentenceChanged: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val collocations = chunks.filter { it.type == ChunkType.COLLOCATION }
    val phrasal = chunks.filter { it.type == ChunkType.PHRASAL }
    val patterns = chunks.filter { it.type == ChunkType.PATTERN }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (collocations.isNotEmpty()) {
            SectionCard(title = "Words that go together") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    collocations.forEach { chunk ->
                        ChunkRow(
                            text = chunk.text,
                            onSpeak = if (canSpeak) {
                                { onSpeak(chunk.text) }
                            } else {
                                null
                            }
                        )
                    }
                }
            }
        }

        if (phrasal.isNotEmpty()) {
            SectionCard(title = "Related expressions") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    phrasal.forEach { chunk ->
                        ChunkRow(
                            text = chunk.text,
                            onSpeak = if (canSpeak) {
                                { onSpeak(chunk.text) }
                            } else {
                                null
                            }
                        )
                    }
                }
            }
        }

        if (patterns.isNotEmpty()) {
            SectionCard(title = "Sentence pattern") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    patterns.forEach { chunk ->
                        Text(
                            text = chunk.text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        PracticeZone(
            state = practice,
            onSelectOption = onSelectOption,
            onReveal = onReveal,
            onOwnSentenceChanged = onOwnSentenceChanged
        )
    }
}
