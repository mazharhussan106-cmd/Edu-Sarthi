package com.speaksarthi.app.presentation.card

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.speaksarthi.app.domain.model.Exercise
import com.speaksarthi.app.presentation.theme.SarthiTheme

/** Which reveal-answer exercise the learner just opened. */
enum class PracticeReveal { FILL_BLANK, FIND_FIX, TRANSLATE }

/**
 * Everything the practice zone needs to draw itself.
 *
 * Reveal state lives here rather than inside the composables so it survives the
 * card being scrolled off screen and back, and so the study session can reset it
 * when it moves to the next word.
 */
data class PracticeZoneState(
    val exercise: Exercise?,
    val selectedOption: Int? = null,
    val revealed: Set<PracticeReveal> = emptySet(),
    val ownSentence: String = "",
    /** A sentence written in an earlier session, shown back rather than marked. */
    val previousOwnSentence: String = ""
) {
    val hasAnswered: Boolean get() = selectedOption != null
}

/**
 * The five exercises from the reference card's practice zone.
 *
 * Only the multiple choice is graded. The other three reveal their answer when
 * the learner asks, because this is a study card, not a test — making someone
 * type the right answer before they are allowed to see it is how you lose the
 * learner this product is for.
 */
@Composable
fun PracticeZone(
    state: PracticeZoneState,
    onSelectOption: (Int) -> Unit,
    onReveal: (PracticeReveal) -> Unit,
    onOwnSentenceChanged: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val exercise = state.exercise ?: return

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        SectionCard(title = "Practice", accent = MaterialTheme.colorScheme.tertiary) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {

                // 1 — multiple choice, the one exercise that is actually graded
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    ExerciseLabel("1", "Choose the answer")
                    Text(
                        text = exercise.mcq.question,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    exercise.mcq.options.forEachIndexed { index, option ->
                        ChoiceOption(
                            text = option,
                            prefix = "${('A' + index)}.",
                            selected = state.selectedOption == index,
                            correct = index == exercise.mcq.answerIndex,
                            answered = state.hasAnswered,
                            onClick = { onSelectOption(index) }
                        )
                    }
                }

                if (exercise.fillBlank.isPresent) {
                    RevealExercise(
                        number = "2",
                        title = "Fill the blank",
                        prompt = exercise.fillBlank.prompt,
                        answer = exercise.fillBlank.answer,
                        revealed = PracticeReveal.FILL_BLANK in state.revealed,
                        onReveal = { onReveal(PracticeReveal.FILL_BLANK) }
                    )
                }

                if (exercise.findFix.isPresent) {
                    RevealExercise(
                        number = "3",
                        title = "Fix the sentence",
                        prompt = exercise.findFix.prompt,
                        answer = exercise.findFix.answer,
                        revealed = PracticeReveal.FIND_FIX in state.revealed,
                        onReveal = { onReveal(PracticeReveal.FIND_FIX) },
                        promptIsWrong = true
                    )
                }

                if (exercise.translate.isPresent) {
                    RevealExercise(
                        number = "4",
                        title = "Say it in English",
                        prompt = exercise.translate.prompt,
                        answer = exercise.translate.answer,
                        revealed = PracticeReveal.TRANSLATE in state.revealed,
                        onReveal = { onReveal(PracticeReveal.TRANSLATE) }
                    )
                }

                if (exercise.writeYourOwnPrompt.isNotBlank()) {
                    OwnSentenceExercise(
                        prompt = exercise.writeYourOwnPrompt,
                        text = state.ownSentence,
                        previous = state.previousOwnSentence,
                        onChange = onOwnSentenceChanged
                    )
                }
            }
        }
    }
}

@Composable
private fun ExerciseLabel(number: String, title: String) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = number,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.tertiary
        )
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            color = SarthiTheme.colors.mutedText
        )
    }
}

/** A prompt with its answer hidden behind a tap. */
@Composable
private fun RevealExercise(
    number: String,
    title: String,
    prompt: String,
    answer: String,
    revealed: Boolean,
    onReveal: () -> Unit,
    promptIsWrong: Boolean = false
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ExerciseLabel(number, title)

        if (promptIsWrong) {
            // The find-and-fix prompt is a deliberately wrong sentence, so it is
            // marked as wrong on sight rather than left looking like an example
            // to copy.
            MistakePair(wrong = prompt, corrected = if (revealed) answer else "")
        } else {
            Text(
                text = prompt,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        AnimatedVisibility(visible = revealed && !promptIsWrong) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SarthiTheme.colors.successContainer)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "✓",
                    style = MaterialTheme.typography.bodyLarge,
                    color = SarthiTheme.colors.success
                )
                Text(
                    text = answer,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        if (!revealed) {
            TextButton(onClick = onReveal) {
                Text("Show the answer")
            }
        }
    }
}

/**
 * The fifth exercise: write your own sentence.
 *
 * Nothing marks this. Whatever the learner types is kept and shown back the next
 * time they meet the word, so they can see their own writing improve. One
 * exercise that cannot be got wrong is worth having for someone whose whole
 * problem is the fear of getting it wrong.
 */
@Composable
private fun OwnSentenceExercise(
    prompt: String,
    text: String,
    previous: String,
    onChange: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        ExerciseLabel("5", "Write your own")

        Text(
            text = prompt,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface
        )

        if (previous.isNotBlank() && previous != text) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "What you wrote last time",
                    style = MaterialTheme.typography.labelMedium,
                    color = SarthiTheme.colors.mutedText
                )
                Text(
                    text = previous,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        OutlinedTextField(
            value = text,
            onValueChange = onChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Your sentence…") },
            minLines = 2,
            shape = RoundedCornerShape(12.dp)
        )

        Text(
            text = "Not marked — it is saved so you can see it again next time.",
            style = MaterialTheme.typography.labelSmall,
            color = SarthiTheme.colors.mutedText
        )
    }
}
