package com.speaksarthi.app.presentation.feedback

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.speaksarthi.app.BuildConfig
import com.speaksarthi.app.presentation.theme.SarthiTheme

/** What the learner is writing about, which decides how it gets triaged. */
private enum class FeedbackKind(val label: String, val subject: String) {
    Bug("Something is broken", "Bug report"),
    Content("A word looks wrong", "Content correction"),
    Idea("An idea", "Feature idea"),
    Other("Something else", "Feedback")
}

/**
 * In-app feedback, sent as an email.
 *
 * An email intent rather than a form that posts somewhere, because there is no
 * backend yet and a form that silently drops what someone wrote is worse than no
 * form at all. It also means the learner keeps a copy in their sent folder and
 * can be replied to — which for a beta is the whole point.
 *
 * [FEEDBACK_ADDRESS] is a real inbox, but a personal one — see the note on it.
 */
@Composable
fun FeedbackScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var kind by remember { mutableStateOf(FeedbackKind.Bug) }
    var message by remember { mutableStateOf("") }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = "Send feedback",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "What is this about?",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SarthiTheme.colors.mutedText
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FeedbackKind.entries.forEach { option ->
                        FilterChip(
                            selected = kind == option,
                            onClick = { kind = option },
                            label = { Text(option.label) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("What happened, and what did you expect?") },
                    minLines = 5,
                    shape = RoundedCornerShape(12.dp)
                )

                Text(
                    text = "Your Android version and the app version are attached, because " +
                        "they are usually what explains a bug. Nothing else is — not your " +
                        "words, your recordings, or your progress.",
                    style = MaterialTheme.typography.labelMedium,
                    color = SarthiTheme.colors.mutedText
                )

                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                            // ACTION_SENDTO with a mailto: URI, so only email apps
                            // offer to handle it — ACTION_SEND would put the
                            // learner in front of a share sheet full of everything.
                            data = Uri.parse("mailto:$FEEDBACK_ADDRESS")
                            putExtra(Intent.EXTRA_SUBJECT, "Speak Sarthi — ${kind.subject}")
                            putExtra(Intent.EXTRA_TEXT, body(message))
                        }
                        runCatching { context.startActivity(intent) }
                    },
                    enabled = message.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open email")
                }
            }
        }
    }
}

private fun body(message: String): String = buildString {
    appendLine(message)
    appendLine()
    appendLine("—")
    appendLine("App ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
    appendLine("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
    appendLine("${Build.MANUFACTURER} ${Build.MODEL}")
}

/** Placeholder. Point this at a real inbox before the beta goes out. */
/**
 * Where feedback lands.
 *
 * A personal address, which is honest for a one-person app and better than a
 * `noreply@` that nobody reads. Worth replacing with a dedicated inbox before
 * the public listing — partly so it survives this address changing, and partly
 * because a Play listing that shows a personal Gmail invites a different kind of
 * mail than a support address does.
 */
private const val FEEDBACK_ADDRESS = "mazharhussan106@gmail.com"
