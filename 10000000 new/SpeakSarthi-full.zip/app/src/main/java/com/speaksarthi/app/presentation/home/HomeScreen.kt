package com.speaksarthi.app.presentation.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.presentation.theme.SarthiTheme
import com.speaksarthi.app.presentation.util.OnResume

/**
 * The screen the app opens on.
 *
 * One question answered above the fold — is there work waiting, and how much —
 * then the ways to do it, in the order they are worth doing. Everything else is
 * underneath, where a learner who wants it can find it and a learner who does
 * not is never confronted by their own averages before they have done anything.
 *
 * The app now has a dozen screens. This one deliberately does not list them.
 */
@Composable
fun HomeScreen(
    onStudy: () -> Unit,
    onListen: () -> Unit,
    onSpeak: () -> Unit,
    onSounds: () -> Unit,
    onMistakes: () -> Unit,
    onLessons: () -> Unit,
    onBadges: () -> Unit,
    onStats: () -> Unit,
    onLibraryStatus: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    // The due count is computed against a fixed "now", so it is recalculated
    // whenever the learner comes back rather than going stale in the background.
    OnResume { viewModel.refresh() }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Speak Sarthi",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = streakLine(state.streakDays),
                        style = MaterialTheme.typography.bodyMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                }
                IconButton(onClick = onBadges) {
                    Icon(
                        imageVector = Icons.Default.EmojiEvents,
                        contentDescription = "Badges",
                        tint = if (state.badgesEarned > 0) {
                            MaterialTheme.colorScheme.tertiary
                        } else {
                            SarthiTheme.colors.mutedText
                        }
                    )
                }
                IconButton(onClick = onLibraryStatus) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Library details",
                        tint = SarthiTheme.colors.mutedText
                    )
                }
            }

            TodayCard(state = state, onTap = onStats)

            // Lessons sit directly under the goal because they are the answer to
            // "am I getting anywhere", which the never-ending review queue cannot
            // give. The queue is still the primary action — it is what actually
            // makes things stick.
            SecondaryAction(
                title = "Lessons",
                subtitle = "A path with an end to it",
                icon = Icons.AutoMirrored.Filled.MenuBook,
                onClick = onLessons
            )

            PrimaryAction(
                title = if (state.dueCount > 0) "Study now" else "Study anyway",
                subtitle = when {
                    state.dueCount > 0 -> "${state.dueCount} words waiting"
                    state.hasStarted -> "Nothing is due — a round of review never hurts"
                    else -> "Start with your first words"
                },
                onClick = onStudy
            )

            // Speaking above listening: it is the thing the app is for, and the
            // thing a learner avoids if it is not put in front of them.
            SecondaryAction(
                title = "Say it out loud",
                subtitle = speakingSubtitle(state),
                icon = Icons.Default.Mic,
                onClick = onSpeak
            )

            SecondaryAction(
                title = "Listening practice",
                subtitle = "Hear a word, pick which one it was",
                icon = Icons.AutoMirrored.Filled.VolumeUp,
                onClick = onListen
            )

            if (state.mistakeCount > 0) {
                SecondaryAction(
                    title = "Review your mistakes",
                    subtitle = "${state.mistakeCount} words you keep getting wrong",
                    icon = Icons.Default.Replay,
                    onClick = onMistakes
                )
            }

            if (state.weakSoundCount > 0) {
                SecondaryAction(
                    title = "Sounds to work on",
                    subtitle = if (state.topWeakSound.isNotBlank()) {
                        "Start with ${state.topWeakSound}"
                    } else {
                        "${state.weakSoundCount} sounds to practise"
                    },
                    icon = Icons.Default.GraphicEq,
                    onClick = onSounds
                )
            }

            StatsRow(state = state, onClick = onStats)

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

private fun streakLine(days: Int): String = when (days) {
    0 -> "Today is a good day to start"
    1 -> "1 day in a row"
    else -> "$days days in a row"
}

/**
 * What the speaking row says underneath its title.
 *
 * Says how much scoring is left before the learner taps in, not after they hit
 * the limit. Finding a cap by running into it feels like a trick; seeing it
 * coming lets them spend it on the sentence they care about.
 */
private fun speakingSubtitle(state: HomeUiState): String = when {
    !state.scoringConfigured -> "Record yourself and compare against the model"
    state.creditsKnown && state.credits == 0 ->
        "Out of credits — recording still works, and lessons earn more"
    state.creditsKnown && state.credits <= 10 -> "${state.credits} credits left"
    else -> "Read a line, get it scored, fix one sound"
}

/** Today's goal, and nothing else about today. */
@Composable
private fun TodayCard(state: HomeUiState, onTap: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                if (state.goalMet) {
                    SarthiTheme.colors.successContainer
                } else {
                    MaterialTheme.colorScheme.surfaceVariant
                }
            )
            .clickable(onClick = onTap)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = "${state.today.wordsStudied}",
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.Bold,
                color = if (state.goalMet) {
                    SarthiTheme.colors.success
                } else {
                    MaterialTheme.colorScheme.primary
                }
            )
            Text(
                text = " of ${state.dailyGoal} today",
                style = MaterialTheme.typography.titleMedium,
                color = SarthiTheme.colors.mutedText,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        LinearProgressIndicator(
            progress = { state.goalProgress },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp)),
            color = if (state.goalMet) SarthiTheme.colors.success else MaterialTheme.colorScheme.primary,
            trackColor = SarthiTheme.colors.divider
        )

        Text(
            text = if (state.goalMet) {
                "Goal met. Anything more today is a bonus."
            } else {
                "Ten minutes is usually enough."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = SarthiTheme.colors.mutedText
        )
    }
}

@Composable
private fun PrimaryAction(title: String, subtitle: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun SecondaryAction(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = SarthiTheme.colors.mutedText
            )
        }
    }
}

@Composable
private fun StatsRow(state: HomeUiState, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        Stat("${state.knownCount}", "known")
        Stat("${state.startedCount}", "started")
        Stat("${state.libraryCount}", "in library")
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = SarthiTheme.colors.mutedText
        )
    }
}
