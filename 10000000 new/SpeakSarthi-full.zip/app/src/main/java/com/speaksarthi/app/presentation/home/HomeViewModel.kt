package com.speaksarthi.app.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.domain.model.DailyStat
import com.speaksarthi.app.domain.repository.BadgeRepository
import com.speaksarthi.app.domain.repository.LibraryRepository
import com.speaksarthi.app.domain.model.EarnKind
import com.speaksarthi.app.domain.repository.CreditsRepository
import com.speaksarthi.app.domain.usecase.credits.StreakWeek
import com.speaksarthi.app.util.Clock
import com.speaksarthi.app.domain.repository.SpeakingRepository
import com.speaksarthi.app.domain.repository.StudyRepository
import com.speaksarthi.app.domain.usecase.pronunciation.PhonemeGuide
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * What the home screen shows.
 *
 * Deliberately small. A dashboard that reports fourteen numbers tells a learner
 * nothing; what they need on opening the app is whether there is work waiting
 * and whether today counts yet.
 */
data class HomeUiState(
    val dueCount: Int = 0,
    val streakDays: Int = 0,
    val today: DailyStat = DailyStat(date = ""),
    val dailyGoal: Int = AppPreferences.DEFAULT_DAILY_GOAL,
    val knownCount: Int = 0,
    val startedCount: Int = 0,
    val libraryCount: Int = 0,
    /** Credits left — the one rationed thing here. */
    val credits: Int = 0,
    val creditsKnown: Boolean = false,
    val scoringConfigured: Boolean = false,
    val weakSoundCount: Int = 0,
    /** The sound worth starting on, already named in plain language. */
    val topWeakSound: String = "",
    /** Words the learner keeps getting wrong, waiting in mistake review. */
    val mistakeCount: Int = 0,
    val badgesEarned: Int = 0
) {
    /** Progress toward today's goal, clamped — going over the goal is not an error. */
    val goalProgress: Float
        get() = if (dailyGoal <= 0) 1f else (today.wordsStudied.toFloat() / dailyGoal).coerceIn(0f, 1f)

    val goalMet: Boolean get() = today.wordsStudied >= dailyGoal

    val hasStarted: Boolean get() = startedCount > 0
}

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class HomeViewModel @Inject constructor(
    private val study: StudyRepository,
    private val library: LibraryRepository,
    private val speaking: SpeakingRepository,
    private val credits: CreditsRepository,
    private val clock: Clock,
    private val badges: BadgeRepository,
    private val preferences: AppPreferences
) : ViewModel() {

    /**
     * Bumped on every resume.
     *
     * The due-count query fixes "now" when its flow is created, so a phone left
     * on the home screen overnight would otherwise still show yesterday's
     * count. Re-creating the flow on resume is the honest fix; a ticking clock
     * would wake the database once a minute for a number that changes once a day.
     */
    private val refreshKey = MutableStateFlow(0)

    /** Values that have to be asked for rather than observed, refreshed on resume. */
    private data class Polled(
        val streakDays: Int = 0,
        val credits: Int = 0,
        val creditsKnown: Boolean = false,
        val scoringConfigured: Boolean = false,
        val mistakeCount: Int = 0
    )

    private val polled = MutableStateFlow(Polled())

    val state: StateFlow<HomeUiState> = combine(
        refreshKey.flatMapLatest { study.observeDueCount() },
        study.observeToday(),
        preferences.dailyGoal,
        combine(
            study.observeKnownCount(),
            study.observeStartedCount(),
            library.observeWordCount()
        ) { known, started, total -> Triple(known, started, total) },
        // Nested because `combine` tops out at five flows and this screen now
        // reports on six things. Grouped by what they are about rather than
        // arbitrarily, so the shape stays readable.
        combine(
            polled,
            speaking.observeWeakSounds(limit = WEAK_SOUND_PEEK),
            badges.observeEarned()
        ) { values, sounds, earned -> Triple(values, sounds, earned) }
    ) { due, today, goal, counts, speakingState ->
        val (values, sounds, earned) = speakingState
        val worst = sounds.maxByOrNull { it.errorRate }

        HomeUiState(
            dueCount = due,
            streakDays = values.streakDays,
            today = today,
            dailyGoal = goal,
            knownCount = counts.first,
            startedCount = counts.second,
            libraryCount = counts.third,
            credits = values.credits,
            creditsKnown = values.creditsKnown,
            scoringConfigured = values.scoringConfigured,
            weakSoundCount = sounds.size,
            topWeakSound = worst?.let { PhonemeGuide.describe(it.phoneme).name }.orEmpty(),
            mistakeCount = values.mistakeCount,
            badgesEarned = earned.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    init {
        refresh()
    }

    /** Called when the screen comes back to the foreground. */
    fun refresh() {
        refreshKey.value = refreshKey.value + 1
        viewModelScope.launch {
            polled.value = Polled(
                streakDays = study.currentStreak(),
                // Read here rather than observed: the balance changes only
                // when the learner scores something, and they cannot do that
                // from this screen.
                credits = credits.balance().credits,
                creditsKnown = credits.isConfigured(),
                scoringConfigured = speaking.scoringIsConfigured(),
                mistakeCount = study.mistakeQueue(limit = MISTAKE_PEEK).size
            )

            // A full week of practice earns credits. Keyed on the ISO week so
            // the server pays it once however often this screen refreshes —
            // which means no local record of what has been claimed, and so no
            // local record to drift out of step with the server's.
            if (StreakWeek.isDue(polled.value.streakDays)) {
                credits.claimEarned(EarnKind.Streak, StreakWeek.reference(clock.today()))
            }
            // Catches anything earned elsewhere — a streak badge in particular,
            // which is earned by a date changing rather than by anything the
            // learner did in the app.
            badges.award()
        }
    }

    fun setDailyGoal(words: Int) {
        viewModelScope.launch { preferences.setDailyGoal(words) }
    }

    /** Cycles System → Light → Dark → Eye protection until a settings screen exists. */
    fun cycleThemeMode() {
        viewModelScope.launch {
            val current = preferences.themeMode.first()
            preferences.setThemeMode(current.next())
        }
    }

    private companion object {
        /** Only the worst sound is named on the home screen; three is enough to find it. */
        const val WEAK_SOUND_PEEK = 3

        /** Enough to say "a few" versus "a lot" without querying the whole list. */
        const val MISTAKE_PEEK = 20
    }
}
