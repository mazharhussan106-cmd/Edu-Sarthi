package com.speaksarthi.app.presentation.lessons

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.domain.usecase.lessons.LessonProgress
import com.speaksarthi.app.presentation.card.LevelBadge
import com.speaksarthi.app.presentation.theme.SarthiTheme
import com.speaksarthi.app.presentation.util.OnResume

/**
 * The lesson path.
 *
 * Exists next to the study queue for one reason: the queue never ends. That is
 * correct for remembering things and poor for feeling you are getting anywhere.
 * A lesson has a name, twenty words and a moment where it is finished.
 */
@Composable
fun LessonsScreen(
    onOpenLesson: (String) -> Unit,
    onBack: () -> Unit,
    viewModel: LessonsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    OnResume { viewModel.refresh() }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Lessons",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${state.completed} of ${state.total} finished",
                        style = MaterialTheme.typography.labelMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                }
            }

            if (state.isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                return@Column
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                state.next?.let { next ->
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "Carry on",
                                style = MaterialTheme.typography.labelLarge,
                                color = SarthiTheme.colors.mutedText
                            )
                            LessonRow(
                                row = next,
                                highlighted = true,
                                onClick = { onOpenLesson(next.lesson.id) }
                            )
                        }
                    }
                }

                items(state.lessons, key = { it.lesson.id }) { row ->
                    LessonRow(
                        row = row,
                        highlighted = false,
                        onClick = { onOpenLesson(row.lesson.id) }
                    )
                }

                item {
                    Text(
                        text = "These lessons are grouped automatically from the word " +
                            "library — by level, then by topic. A course written by a " +
                            "teacher would be better, and this is what there is until " +
                            "there is one.",
                        style = MaterialTheme.typography.labelMedium,
                        color = SarthiTheme.colors.mutedText,
                        modifier = Modifier.padding(top = 12.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun LessonRow(row: LessonProgress, highlighted: Boolean, onClick: () -> Unit) {
    val done = row.isComplete

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                when {
                    done -> SarthiTheme.colors.successContainer
                    highlighted -> MaterialTheme.colorScheme.primaryContainer
                    else -> MaterialTheme.colorScheme.surface
                }
            )
            .clickable(onClick = onClick)
            .padding(14.dp)
            .semantics {
                contentDescription = "Lesson ${row.lesson.number}, ${row.lesson.title}. " +
                    if (done) {
                        "Finished."
                    } else {
                        "${row.wordsKnown} of ${row.lesson.size} words known."
                    }
            },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(
                    if (done) {
                        SarthiTheme.colors.success.copy(alpha = 0.2f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                // A tick rather than a number once it is done: the number was only
                // ever there to say which one is next.
                text = if (done) "✓" else "${row.lesson.number}",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = if (done) {
                    SarthiTheme.colors.success
                } else {
                    MaterialTheme.colorScheme.onSurface
                }
            )
        }

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = row.lesson.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                LevelBadge(level = row.lesson.level)
            }
            Text(
                text = row.lesson.subtitle,
                style = MaterialTheme.typography.labelMedium,
                color = SarthiTheme.colors.mutedText
            )

            if (!done && row.isStarted) {
                LinearProgressIndicator(
                    progress = { row.fraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .padding(top = 2.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = SarthiTheme.colors.divider
                )
            }
        }
    }
}
