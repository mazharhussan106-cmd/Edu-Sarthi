package com.speaksarthi.app.presentation.lessons

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.domain.repository.LibraryRepository
import com.speaksarthi.app.domain.model.EarnKind
import com.speaksarthi.app.domain.repository.CreditsRepository
import com.speaksarthi.app.domain.repository.StudyRepository
import com.speaksarthi.app.domain.usecase.lessons.Lesson
import com.speaksarthi.app.domain.usecase.lessons.LessonPlanner
import com.speaksarthi.app.domain.usecase.lessons.LessonProgress
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LessonsUiState(
    val lessons: List<LessonProgress> = emptyList(),
    val next: LessonProgress? = null,
    val completed: Int = 0,
    val isLoading: Boolean = true
) {
    val total: Int get() = lessons.size
}

/**
 * The lesson path.
 *
 * A lesson is not a separate study mode — opening one starts an ordinary study
 * session restricted to its words. The card, the grading and the scheduling are
 * all the same, because a second implementation of any of those would drift from
 * the first within a month.
 */
@HiltViewModel
class LessonsViewModel @Inject constructor(
    private val library: LibraryRepository,
    private val study: StudyRepository,
    private val credits: CreditsRepository
) : ViewModel() {

    private val _state = MutableStateFlow(LessonsUiState())
    val state: StateFlow<LessonsUiState> = _state.asStateFlow()

    private var plan: List<Lesson> = emptyList()

    init {
        load()
    }

    fun refresh() = load()

    private fun load() {
        viewModelScope.launch {
            val words = library.observeWords().first()
            if (plan.isEmpty()) plan = LessonPlanner.plan(words)

            // Progress comes from the rows that already exist. No lesson-
            // completion table: "known" already means something precise here, and
            // a second source of truth for the same fact is a bug waiting to be
            // written.
            //
            // Read in one query, not one per word — this screen asks about all
            // 1,000, and a thousand round trips to SQLite is a visible pause.
            val progress = study.allProgress()
            val known = progress.filter { it.isKnown }.map { it.wordId }.toSet()
            val started = progress.filterNot { it.isNew }.map { it.wordId }.toSet()

            val withProgress = plan.map { lesson ->
                LessonProgress(
                    lesson = lesson,
                    wordsKnown = lesson.wordIds.count { it in known },
                    wordsStarted = lesson.wordIds.count { it in started }
                )
            }

            _state.value = LessonsUiState(
                lessons = withProgress,
                next = LessonPlanner.nextLesson(withProgress),
                completed = withProgress.count { it.isComplete },
                isLoading = false
            )

            // Claim a bonus for every finished lesson, every time this screen
            // loads. That sounds wasteful and is not: the server grants each
            // lesson id exactly once and treats the rest as no-ops, so this is
            // simply "tell the server what is finished" — which needs no local
            // bookkeeping about what has already been claimed, and therefore has
            // no local bookkeeping to get out of step.
            withProgress.filter { it.isComplete }.forEach { row ->
                credits.claimEarned(EarnKind.Lesson, row.lesson.id)
            }
        }
    }
}
