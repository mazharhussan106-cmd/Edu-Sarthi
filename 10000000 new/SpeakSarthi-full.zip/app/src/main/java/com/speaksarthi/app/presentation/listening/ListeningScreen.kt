package com.speaksarthi.app.presentation.listening

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.domain.usecase.listening.ListeningRoundBuilder
import com.speaksarthi.app.presentation.card.ChoiceOption
import com.speaksarthi.app.presentation.theme.PhoneticStyle
import com.speaksarthi.app.presentation.theme.SarthiTheme

/**
 * Listening practice.
 *
 * The word is never written down until the learner has answered — the moment it
 * appears on screen, the ear has nothing left to do. So the top of this screen
 * is a play button and nothing else.
 */
@Composable
fun ListeningScreen(
    onExit: () -> Unit,
    viewModel: ListeningViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (val current = state) {
                ListeningUiState.Loading -> Centered { CircularProgressIndicator() }

                is ListeningUiState.Unavailable -> Message(
                    title = "This phone cannot speak yet",
                    body = "${current.reason}. Listening practice needs an English " +
                        "voice installed. Everything else in the app works without it — " +
                        "you can add a voice later in your phone's settings, under " +
                        "Language and input.",
                    onExit = onExit
                )

                is ListeningUiState.NotReady -> Message(
                    title = "Not enough words yet",
                    body = "Listening practice needs at least " +
                        "${ListeningRoundBuilder.MINIMUM_POOL} words to ask anything, and " +
                        "there ${if (current.available == 1) "is" else "are"} " +
                        "${current.available} so far. Study some cards first and come back.",
                    onExit = onExit
                )

                is ListeningUiState.Asking -> Question(
                    state = current,
                    onExit = onExit,
                    onReplay = viewModel::replay,
                    onSlow = viewModel::replaySlowly,
                    onSentence = viewModel::playInSentence,
                    onSelect = viewModel::select,
                    onNext = viewModel::next
                )

                is ListeningUiState.Finished -> RoundSummary(
                    state = current,
                    onAgain = viewModel::startRound,
                    onExit = onExit
                )
            }
        }
    }
}

@Composable
private fun Question(
    state: ListeningUiState.Asking,
    onExit: () -> Unit,
    onReplay: () -> Unit,
    onSlow: () -> Unit,
    onSentence: () -> Unit,
    onSelect: (Int) -> Unit,
    onNext: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onExit) {
                Icon(Icons.Default.Close, contentDescription = "Leave listening practice")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Listening — ${state.position} of ${state.total}",
                    style = MaterialTheme.typography.labelMedium,
                    color = SarthiTheme.colors.mutedText
                )
                LinearProgressIndicator(
                    progress = { state.position.toFloat() / state.total },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .padding(top = 4.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = SarthiTheme.colors.divider
                )
            }
            Spacer(modifier = Modifier.size(48.dp))
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            PlayButton(isSpeaking = state.isSpeaking, onClick = onReplay)

            Text(
                text = "Which word did you hear?",
                style = MaterialTheme.typography.titleMedium,
                color = SarthiTheme.colors.mutedText,
                textAlign = TextAlign.Center
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onSlow, shape = RoundedCornerShape(12.dp)) {
                    Text("Slower")
                }
                if (state.question.sentence.isNotBlank()) {
                    OutlinedButton(onClick = onSentence, shape = RoundedCornerShape(12.dp)) {
                        Text("In a sentence")
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                state.question.options.forEachIndexed { index, option ->
                    ChoiceOption(
                        text = option,
                        selected = state.selectedOption == index,
                        correct = index == state.question.answerIndex,
                        answered = state.hasAnswered,
                        onClick = { onSelect(index) }
                    )
                }
            }

            AnimatedVisibility(visible = state.hasAnswered) {
                AnswerPanel(word = state.question.word, wasCorrect = state.wasCorrect)
            }

            Spacer(modifier = Modifier.height(8.dp))
        }

        AnimatedVisibility(visible = state.hasAnswered) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Button(onClick = onNext, modifier = Modifier.fillMaxWidth()) {
                    Text(if (state.position == state.total) "See how you did" else "Next")
                }
            }
        }
    }
}

/**
 * The one big control on the screen.
 *
 * Large on purpose: it is tapped more than anything else in the app, often
 * repeatedly, and often by someone holding the phone one-handed on a bus.
 */
@Composable
private fun PlayButton(isSpeaking: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(132.dp)
            .clip(CircleShape)
            .background(
                if (isSpeaking) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.primaryContainer
                }
            )
            .clickable(onClick = onClick)
            .semantics { contentDescription = "Play the word again" },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
            contentDescription = null,
            tint = if (isSpeaking) {
                MaterialTheme.colorScheme.onPrimary
            } else {
                MaterialTheme.colorScheme.onPrimaryContainer
            },
            modifier = Modifier.size(60.dp)
        )
    }
}

/** What the word was, once answering can no longer be helped by seeing it. */
@Composable
private fun AnswerPanel(word: Word, wasCorrect: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                if (wasCorrect) {
                    SarthiTheme.colors.successContainer
                } else {
                    MaterialTheme.colorScheme.surfaceVariant
                }
            )
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = if (wasCorrect) "Right" else "It was “${word.word}”",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = if (wasCorrect) {
                SarthiTheme.colors.success
            } else {
                MaterialTheme.colorScheme.onSurface
            }
        )
        if (word.ipa.isNotBlank()) {
            Text(
                text = word.ipa,
                style = PhoneticStyle,
                color = SarthiTheme.colors.mutedText
            )
        }
        if (word.syllableBreak.isNotBlank()) {
            Text(
                text = word.syllableBreak,
                style = MaterialTheme.typography.bodyMedium,
                color = SarthiTheme.colors.mutedText
            )
        }
        if (word.hindiMeaning.isNotBlank()) {
            Text(
                text = word.hindiMeaning,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        if (!wasCorrect && word.pronunciationTip.isNotBlank()) {
            Text(
                text = word.pronunciationTip,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun RoundSummary(
    state: ListeningUiState.Finished,
    onAgain: () -> Unit,
    onExit: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "${state.correct} of ${state.total}",
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "heard correctly",
            style = MaterialTheme.typography.bodyLarge,
            color = SarthiTheme.colors.mutedText
        )

        if (state.missed.isNotEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Worth another listen",
                    style = MaterialTheme.typography.labelLarge,
                    color = SarthiTheme.colors.mutedText
                )
                state.missed.forEach { word ->
                    Column {
                        Text(
                            text = word.word,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (word.ipa.isNotBlank()) {
                            Text(
                                text = word.ipa,
                                style = PhoneticStyle,
                                color = SarthiTheme.colors.mutedText
                            )
                        }
                    }
                }
            }
        } else {
            Text(
                text = "Nothing misheard. Try a round with the sentence button — " +
                    "words are harder to catch inside real speech.",
                style = MaterialTheme.typography.bodyMedium,
                color = SarthiTheme.colors.mutedText,
                textAlign = TextAlign.Center
            )
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(onClick = onAgain, modifier = Modifier.fillMaxWidth()) {
                Text("Another round")
            }
            OutlinedButton(onClick = onExit, modifier = Modifier.fillMaxWidth()) {
                Text("Done")
            }
        }
    }
}

@Composable
private fun Message(title: String, body: String, onExit: () -> Unit) {
    Centered {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )
            Text(
                text = body,
                style = MaterialTheme.typography.bodyLarge,
                color = SarthiTheme.colors.mutedText,
                textAlign = TextAlign.Center
            )
            Button(onClick = onExit) { Text("Back") }
        }
    }
}

@Composable
private fun Centered(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) { content() }
}
