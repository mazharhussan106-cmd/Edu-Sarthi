package com.speaksarthi.app.presentation.listening

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.audio.SpeechPlayer
import com.speaksarthi.app.data.audio.SpeechState
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.domain.repository.LibraryRepository
import com.speaksarthi.app.domain.repository.StudyRepository
import com.speaksarthi.app.domain.usecase.listening.ListeningQuestion
import com.speaksarthi.app.domain.usecase.listening.ListeningRoundBuilder
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/** What listening practice is showing. */
sealed interface ListeningUiState {
    data object Loading : ListeningUiState

    /**
     * No speech engine, or no English voice. Listening practice is the one
     * screen that genuinely cannot degrade gracefully, so it says so plainly
     * rather than showing a dead play button.
     */
    data class Unavailable(val reason: String) : ListeningUiState

    /** Not enough words in the library yet to build four honest options. */
    data class NotReady(val available: Int) : ListeningUiState

    data class Asking(
        val question: ListeningQuestion,
        val position: Int,
        val total: Int,
        val selectedOption: Int? = null,
        val isSpeaking: Boolean = false
    ) : ListeningUiState {
        val hasAnswered: Boolean get() = selectedOption != null
        val wasCorrect: Boolean get() = selectedOption == question.answerIndex
    }

    data class Finished(
        val total: Int,
        val correct: Int,
        /** The words that were misheard — the only part of a score worth reading. */
        val missed: List<Word>
    ) : ListeningUiState
}

/**
 * Listening practice: a word is spoken, the learner picks which one it was.
 *
 * This is deliberately not wired into SM-2. Getting a word wrong here means the
 * ear missed it, not that the memory has decayed, and pushing a word's review
 * date around on that evidence would corrupt the schedule. It is recorded as a
 * quiz answer instead, which is what mistake review reads.
 */
@HiltViewModel
class ListeningViewModel @Inject constructor(
    private val library: LibraryRepository,
    private val study: StudyRepository,
    private val speech: SpeechPlayer,
    private val preferences: AppPreferences
) : ViewModel() {

    private val _state = MutableStateFlow<ListeningUiState>(ListeningUiState.Loading)
    val state: StateFlow<ListeningUiState> = _state.asStateFlow()

    private var questions: List<ListeningQuestion> = emptyList()
    private var index = 0
    private var correct = 0
    private val missed = mutableListOf<Word>()

    /**
     * Set once the engine reports it cannot speak.
     *
     * Kept as a field as well as in the UI state because the round is loaded on
     * its own coroutine: without this, an engine that fails while the queue is
     * being read would have its Unavailable state overwritten by the first
     * question, leaving the learner looking at a play button that does nothing.
     */
    private var unavailableReason: String? = null

    init {
        observeSpeech()
        startRound()
    }

    /**
     * Mirrors the engine's speaking state into the question so the play button
     * can show it, and catches the engine failing after the round has started.
     */
    private fun observeSpeech() {
        viewModelScope.launch {
            speech.state.collect { speechState ->
                val current = _state.value
                when {
                    speechState is SpeechState.Unavailable -> {
                        unavailableReason = speechState.reason
                        _state.value = ListeningUiState.Unavailable(speechState.reason)
                    }

                    current is ListeningUiState.Asking ->
                        _state.value = current.copy(isSpeaking = speechState is SpeechState.Speaking)

                    else -> Unit
                }
            }
        }
    }

    fun startRound() {
        _state.value = ListeningUiState.Loading
        viewModelScope.launch {
            val level = preferences.currentLevel.first()

            // Words the learner has met come first. On a first run there are
            // none, so the level's words stand in — otherwise listening practice
            // would be locked until some unknowable amount of study had happened.
            val studied = library.studiedWords(ROUND_SIZE * 2)
            val targets = if (studied.size >= ROUND_SIZE) {
                studied.take(ROUND_SIZE)
            } else {
                (studied + library.randomWords(level, ROUND_SIZE * 2))
                    .distinctBy { it.wordId }
                    .take(ROUND_SIZE)
            }

            val pool = (targets + library.randomWords(level, DISTRACTOR_POOL))
                .distinctBy { it.wordId }
                .let { atLevel ->
                    // A narrow level may not hold enough words to choose good
                    // distractors from, so the rest of the library backfills.
                    if (atLevel.size >= DISTRACTOR_POOL) {
                        atLevel
                    } else {
                        (atLevel + library.randomWords("", DISTRACTOR_POOL))
                            .distinctBy { it.wordId }
                    }
                }

            val sentences = targets.associate { word ->
                word.wordId to library.practiceItems(word.wordId).firstOrNull()?.text.orEmpty()
            }

            questions = ListeningRoundBuilder.build(
                targets = targets,
                pool = pool,
                sentences = sentences
            )
            index = 0
            correct = 0
            missed.clear()

            if (questions.isEmpty()) {
                _state.value = ListeningUiState.NotReady(available = pool.size)
                return@launch
            }
            show()
        }
    }

    private fun show() {
        unavailableReason?.let {
            _state.value = ListeningUiState.Unavailable(it)
            return
        }

        val question = questions.getOrNull(index) ?: run { finish(); return }
        _state.value = ListeningUiState.Asking(
            question = question,
            position = index + 1,
            total = questions.size
        )

        // The word plays without being asked for. Making the learner tap play
        // before every single question is a tap that carries no information.
        // On the first question the engine may still be starting up, and
        // speaking into a half-initialised engine silently drops the utterance.
        viewModelScope.launch {
            speech.state.first { it !is SpeechState.Initialising }
            replay()
        }
    }

    /** Says the word again at the learner's chosen speed. */
    fun replay() {
        val current = _state.value as? ListeningUiState.Asking ?: return
        viewModelScope.launch {
            speech.speak(current.question.word.word, rate = preferences.audioSpeed.first())
        }
    }

    /** Says it slowly. The single most useful control on this screen. */
    fun replaySlowly() {
        val current = _state.value as? ListeningUiState.Asking ?: return
        speech.speak(current.question.word.word, rate = SpeechPlayer.RATE_SLOW)
    }

    /** Says the word inside a sentence, where it is harder to catch. */
    fun playInSentence() {
        val current = _state.value as? ListeningUiState.Asking ?: return
        if (current.question.sentence.isBlank()) return
        viewModelScope.launch {
            speech.speak(current.question.sentence, rate = preferences.audioSpeed.first())
        }
    }

    fun select(option: Int) {
        val current = _state.value as? ListeningUiState.Asking ?: return
        if (current.hasAnswered) return

        val wasCorrect = option == current.question.answerIndex
        if (wasCorrect) correct++ else missed += current.question.word

        _state.value = current.copy(selectedOption = option)

        viewModelScope.launch {
            study.recordQuizAnswer(current.question.word.wordId, option, wasCorrect)
            // Hearing it right after choosing is the moment the correction
            // actually lands, right or wrong.
            speech.speak(current.question.word.word, rate = preferences.audioSpeed.first())
        }
    }

    fun next() {
        if (_state.value !is ListeningUiState.Asking) return
        speech.stop()
        index++
        show()
    }

    private fun finish() {
        _state.value = ListeningUiState.Finished(
            total = questions.size,
            correct = correct,
            missed = missed.toList()
        )
    }

    override fun onCleared() {
        speech.stop()
        super.onCleared()
    }

    companion object {
        /** Ten questions — about three minutes, and short enough to finish standing up. */
        const val ROUND_SIZE = 10

        /** How many words to draw wrong options from. */
        const val DISTRACTOR_POOL = 80
    }
}
