package com.speaksarthi.app.presentation.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.speaksarthi.app.presentation.badges.BadgesScreen
import com.speaksarthi.app.presentation.feedback.FeedbackScreen
import com.speaksarthi.app.presentation.home.HomeScreen
import com.speaksarthi.app.presentation.AppViewModel
import com.speaksarthi.app.presentation.lessons.LessonsScreen
import com.speaksarthi.app.presentation.listening.ListeningScreen
import com.speaksarthi.app.presentation.paywall.PaywallScreen
import com.speaksarthi.app.presentation.privacy.PrivacyScreen
import com.speaksarthi.app.presentation.placement.PlacementScreen
import com.speaksarthi.app.presentation.search.SearchScreen
import com.speaksarthi.app.presentation.settings.SettingsScreen
import com.speaksarthi.app.presentation.sounds.SoundsScreen
import com.speaksarthi.app.presentation.speaking.SpeakingScreen
import com.speaksarthi.app.presentation.stats.StatsScreen
import com.speaksarthi.app.presentation.study.StudyScreen
import com.speaksarthi.app.presentation.ui.LibraryStatusScreen
import com.speaksarthi.app.presentation.ui.LibraryStatusViewModel
import com.speaksarthi.app.presentation.worddetail.WordDetailScreen
import com.speaksarthi.app.presentation.worddetail.WordDetailViewModel

/**
 * Every screen the app can be on.
 *
 * String routes rather than type-safe navigation: the app targets a Navigation
 * Compose version that predates it. Only one route takes an argument, and it is
 * a word id, so the cost of that choice is one `navArgument` block.
 */
object Routes {
    const val HOME = "home"
    const val SEARCH = "search"
    const val SPEAKING = "speaking"
    const val STATS = "stats"
    const val SETTINGS = "settings"

    const val STUDY = "study"
    const val MISTAKES = "mistakes"
    const val LISTENING = "listening"
    const val SOUNDS = "sounds"
    const val BADGES = "badges"
    const val FEEDBACK = "feedback"
    const val PLACEMENT = "placement"
    const val PRIVACY_CONSENT = "privacy-consent"
    const val PRIVACY = "privacy"
    const val PAYWALL = "paywall"
    const val LESSONS = "lessons"

    const val LESSON_STUDY = "lesson/{lessonId}"

    fun lessonStudy(lessonId: String): String = "lesson/$lessonId"

    const val WORD_DETAIL = "word/{${WordDetailViewModel.ARG_WORD_ID}}"

    fun wordDetail(wordId: String): String = "word/$wordId"

    /** Developer diagnostics: what actually landed in the database. */
    const val LIBRARY_STATUS = "library-status"
}

/**
 * The five destinations on the bottom bar.
 *
 * Five, and no more. The app now has a dozen screens, and the temptation is a
 * navigation drawer listing all of them — which is how an app ends up feeling
 * like a filing cabinet. These are the five a learner opens repeatedly;
 * everything else is reached from the screen it belongs to.
 *
 * Speaking is in the middle on purpose: it is the thing the app is for, and the
 * thing an embarrassed learner avoids unless it is directly in front of them.
 */
enum class TopLevel(
    val route: String,
    val label: String,
    val icon: ImageVector
) {
    Home(Routes.HOME, "Home", Icons.Default.Home),
    Search(Routes.SEARCH, "Words", Icons.Default.Search),
    Speak(Routes.SPEAKING, "Speak", Icons.Default.Mic),
    Progress(Routes.STATS, "Progress", Icons.Default.BarChart),
    Settings(Routes.SETTINGS, "Settings", Icons.Default.Settings)
}

@Composable
fun SarthiNavHost(
    startRoute: String,
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController()
) {
    val backStack by navController.currentBackStackEntryAsState()
    val currentDestination = backStack?.destination

    // Hidden on the full-screen flows: a study session, a recording or the
    // placement test is one task, and a bar offering four ways out of it is an
    // invitation to abandon it half-finished.
    val showBar = currentDestination?.route in TopLevel.entries.map { it.route }

    Scaffold(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    TopLevel.entries.forEach { item ->
                        val selected = currentDestination?.hierarchy
                            ?.any { it.route == item.route } == true

                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(item.route) {
                                    // Standard bottom-bar behaviour: one entry per
                                    // tab, state kept, and back from any tab goes
                                    // to home rather than walking the whole history.
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = null) },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = startRoute,
            modifier = Modifier.fillMaxSize().padding(padding)
        ) {
            composable(Routes.PRIVACY_CONSENT) {
                val viewModel: AppViewModel = hiltViewModel()
                PrivacyScreen(
                    isConsent = true,
                    onAccept = {
                        viewModel.acceptPrivacy()
                        navController.navigate(Routes.PLACEMENT) {
                            popUpTo(Routes.PRIVACY_CONSENT) { inclusive = true }
                        }
                    },
                    onBack = {}
                )
            }

            composable(Routes.PRIVACY) {
                PrivacyScreen(
                    isConsent = false,
                    onAccept = {},
                    onBack = { navController.popBackStack() }
                )
            }

            composable(Routes.PAYWALL) {
                PaywallScreen(onBack = { navController.popBackStack() })
            }

            composable(Routes.LESSONS) {
                LessonsScreen(
                    onOpenLesson = { id -> navController.navigate(Routes.lessonStudy(id)) },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = Routes.LESSON_STUDY,
                arguments = listOf(navArgument("lessonId") { type = NavType.StringType })
            ) { entry ->
                StudyScreen(
                    onExit = { navController.popBackStack() },
                    lessonId = entry.arguments?.getString("lessonId").orEmpty()
                )
            }

            composable(Routes.PLACEMENT) {
                PlacementScreen(
                    onDone = {
                        // The test is never returned to, so it is popped out of
                        // the back stack rather than left behind home.
                        navController.navigate(Routes.HOME) {
                            popUpTo(Routes.PLACEMENT) { inclusive = true }
                        }
                    }
                )
            }

            composable(Routes.HOME) {
                HomeScreen(
                    onStudy = { navController.navigate(Routes.STUDY) },
                    onListen = { navController.navigate(Routes.LISTENING) },
                    onSpeak = { navController.navigate(Routes.SPEAKING) },
                    onSounds = { navController.navigate(Routes.SOUNDS) },
                    onMistakes = { navController.navigate(Routes.MISTAKES) },
                    onLessons = { navController.navigate(Routes.LESSONS) },
                    onBadges = { navController.navigate(Routes.BADGES) },
                    onStats = { navController.navigate(Routes.STATS) },
                    onLibraryStatus = { navController.navigate(Routes.LIBRARY_STATUS) }
                )
            }

            composable(Routes.SEARCH) {
                SearchScreen(
                    onOpenWord = { wordId -> navController.navigate(Routes.wordDetail(wordId)) }
                )
            }

            composable(
                route = Routes.WORD_DETAIL,
                arguments = listOf(
                    navArgument(WordDetailViewModel.ARG_WORD_ID) { type = NavType.StringType }
                )
            ) {
                WordDetailScreen(onBack = { navController.popBackStack() })
            }

            composable(Routes.STUDY) {
                // popBackStack rather than navigate(HOME): the session is finished
                // with, and a back stack full of dead sessions is how you end up
                // pressing back six times to leave an app.
                StudyScreen(onExit = { navController.popBackStack() })
            }

            composable(Routes.MISTAKES) {
                // Same screen, different queue. Two near-identical study screens
                // would drift apart within a month.
                StudyScreen(
                    onExit = { navController.popBackStack() },
                    mistakeReview = true
                )
            }

            composable(Routes.LISTENING) {
                ListeningScreen(onExit = { navController.popBackStack() })
            }

            composable(Routes.SPEAKING) {
                SpeakingScreen(
                    onExit = { navController.popBackStack() },
                    onOpenSounds = { navController.navigate(Routes.SOUNDS) }
                )
            }

            composable(Routes.SOUNDS) {
                SoundsScreen(onBack = { navController.popBackStack() })
            }

            composable(Routes.BADGES) {
                BadgesScreen(onBack = { navController.popBackStack() })
            }

            composable(Routes.STATS) {
                StatsScreen(onBack = { navController.popBackStack() })
            }

            composable(Routes.SETTINGS) {
                SettingsScreen(
                    onBack = { navController.popBackStack() },
                    onSendFeedback = { navController.navigate(Routes.FEEDBACK) },
                    onOpenPaywall = { navController.navigate(Routes.PAYWALL) },
                    onOpenPrivacy = { navController.navigate(Routes.PRIVACY) }
                )
            }

            composable(Routes.FEEDBACK) {
                FeedbackScreen(onBack = { navController.popBackStack() })
            }

            composable(Routes.LIBRARY_STATUS) {
                val viewModel: LibraryStatusViewModel = hiltViewModel()
                val state by viewModel.state.collectAsStateWithLifecycle()

                LibraryStatusScreen(
                    state = state,
                    onRetry = viewModel::retry,
                    onCycleTheme = viewModel::cycleThemeMode
                )
            }
        }
    }
}
