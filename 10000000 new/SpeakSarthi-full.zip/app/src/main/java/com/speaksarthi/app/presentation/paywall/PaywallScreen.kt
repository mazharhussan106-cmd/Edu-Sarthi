package com.speaksarthi.app.presentation.paywall

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.data.billing.BillingState
import com.speaksarthi.app.data.billing.PackOffer

/**
 * Where credits are bought.
 *
 * Built around one rule: **be specific about what is and is not behind it.** A
 * paywall that implies the app is crippled without paying is lying, because it
 * is not — all 1,000 words, every chunk, the flashcards, listening, recording and
 * hearing yourself back, mistake review, badges and statistics are free forever.
 * Credits buy AI pronunciation scoring, and that is the whole of it.
 *
 * Saying so plainly loses a few impulse purchases and keeps the people who would
 * otherwise have paid, felt misled, and asked for their money back.
 *
 * The second rule is that **nothing here is a wall**. A learner with no credits
 * can still record, still play themselves back, still study every word. They
 * lose the score, not the app.
 */
@Composable
fun PaywallScreen(
    onBack: () -> Unit,
    viewModel: PaywallViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val event by viewModel.events.collectAsStateWithLifecycle()
    val snackbars = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(Unit) { viewModel.onOpened() }

    LaunchedEffect(event) {
        event?.let {
            snackbars.showSnackbar(it)
            viewModel.consumeEvent()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Credits") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbars) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(Modifier.height(8.dp))

            BalanceHeader(credits = state.credits)

            WhatCreditsAreFor()

            when (val billing = state.billing) {
                BillingState.Loading -> Centered { CircularProgressIndicator() }

                BillingState.NotConfigured -> Notice(
                    "Credit packs are not on sale in this build yet. " +
                        "Everything else works, and any credits you have still count."
                )

                BillingState.Unavailable -> Notice(
                    "Google Play is not available on this device, so packs cannot be " +
                        "bought here. Everything except AI scoring still works."
                )

                is BillingState.Failed -> Notice(billing.reason)

                is BillingState.Ready -> {
                    billing.offers.forEach { offer ->
                        PackCard(
                            offer = offer,
                            enabled = state.canBuy,
                            onBuy = {
                                (context as? Activity)?.let { viewModel.buy(it, offer.pack) }
                            }
                        )
                    }
                }
            }

            if (state.shouldSuggestSignIn) {
                SignInSuggestion(
                    enabled = !state.isWorking,
                    onSignIn = { (context as? Activity)?.let(viewModel::signIn) }
                )
            }

            TextButton(
                onClick = viewModel::restore,
                enabled = !state.isWorking,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Already paid? Restore purchases")
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun BalanceHeader(credits: Int) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = credits.toString(),
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        Text(
            // "credits left" rather than "credits remaining": shorter, and it
            // reads the same whether the number is 400 or 0.
            text = if (credits == 1) "credit left" else "credits left",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onPrimaryContainer
        )
    }
}

@Composable
private fun WhatCreditsAreFor() {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "One credit scores one sentence",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text = "Credits pay for the AI that listens to your pronunciation and " +
                "tells you which sounds to work on. That is the only thing they buy.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = "Everything else is free forever — all 1,000 words, the flashcards, " +
                "listening practice, recording and playing yourself back, mistake " +
                "review, badges and statistics. Run out of credits and all of that " +
                "keeps working.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = "You also earn credits by finishing lessons and keeping a weekly streak.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun PackCard(
    offer: PackOffer,
    enabled: Boolean,
    onBuy: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = offer.pack.name,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                // How many credits a pack holds is the server's business, not
                // the app's — so the app does not claim a number it would have
                // to be updated to keep honest.
                text = "Top up your credits",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Button(onClick = onBuy, enabled = enabled) {
            // Play's own formatted price, never one built here: it knows the
            // learner's currency and their country's tax display rules.
            Text(offer.formattedPrice)
        }
    }
}

@Composable
private fun SignInSuggestion(enabled: Boolean, onSignIn: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.secondaryContainer)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Keep your credits safe",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSecondaryContainer
        )
        Text(
            text = "Sign in with Google and your credits and progress follow you to a " +
                "new phone. Without it, they live only on this device.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSecondaryContainer
        )
        OutlinedButton(onClick = onSignIn, enabled = enabled) { Text("Sign in with Google") }
    }
}

@Composable
private fun Centered(content: @Composable () -> Unit) {
    Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
        content()
    }
}

@Composable
private fun Notice(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
    )
}
