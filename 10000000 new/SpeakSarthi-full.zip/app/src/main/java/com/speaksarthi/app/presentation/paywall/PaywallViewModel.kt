package com.speaksarthi.app.presentation.paywall

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.analytics.Analytics
import com.speaksarthi.app.data.analytics.AnalyticsEvent
import com.speaksarthi.app.data.billing.BillingRepository
import com.speaksarthi.app.data.billing.BillingState
import com.speaksarthi.app.data.billing.PackOffer
import com.speaksarthi.app.data.auth.GoogleSignIn
import com.speaksarthi.app.data.auth.GoogleSignInResult
import com.speaksarthi.app.data.billing.PurchaseResult
import com.speaksarthi.app.domain.model.CreditBalance
import com.speaksarthi.app.domain.model.CreditPack
import com.speaksarthi.app.domain.model.LinkOutcome
import com.speaksarthi.app.domain.repository.CreditsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class PaywallUiState(
    val billing: BillingState = BillingState.Loading,
    val balance: CreditBalance = CreditBalance.unknown,
    val isWorking: Boolean = false
) {
    val credits: Int get() = balance.credits

    val offers: List<PackOffer>
        get() = (billing as? BillingState.Ready)?.offers.orEmpty()

    val canBuy: Boolean get() = billing is BillingState.Ready && !isWorking

    /**
     * Worth suggesting sign-in.
     *
     * Asked when the balance is running low rather than at first launch, and
     * never as a wall. Someone nervous about their English, asked to make an
     * account before they have seen anything work, simply leaves.
     */
    val shouldSuggestSignIn: Boolean
        get() = !balance.signedIn && balance.credits <= CreditBalance.LOW_WATER_MARK
}

@HiltViewModel
class PaywallViewModel @Inject constructor(
    private val billing: BillingRepository,
    private val credits: CreditsRepository,
    private val googleSignIn: GoogleSignIn,
    private val analytics: Analytics
) : ViewModel() {

    private val local = MutableStateFlow(PaywallUiState())

    val state: StateFlow<PaywallUiState> = combine(
        billing.state,
        credits.observeBalance(),
        local
    ) { billingState, balance, own ->
        own.copy(billing = billingState, balance = balance)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), PaywallUiState())

    private val _events = MutableStateFlow<String?>(null)
    val events: StateFlow<String?> = _events.asStateFlow()

    init {
        billing.start()
    }

    fun consumeEvent() {
        _events.value = null
    }

    fun buy(activity: Activity, pack: CreditPack) {
        local.value = local.value.copy(isWorking = true)
        viewModelScope.launch {
            analytics.track(AnalyticsEvent.PackPurchaseStarted)

            when (val result = billing.purchase(activity, pack)) {
                is PurchaseResult.Credited -> {
                    analytics.track(AnalyticsEvent.PackPurchased)
                    _events.value = "Added. You have ${result.balance} credits."
                }

                // Play's sheet is open, or a UPI mandate is still confirming.
                // Either way there is nothing to report yet and nothing has been
                // charged, so the screen says so plainly rather than guessing.
                PurchaseResult.Pending -> Unit

                // Backing out is not a failure and is never shown as one. An app
                // that scolds you for closing its payment sheet does not get a
                // second attempt.
                PurchaseResult.Cancelled -> Unit

                is PurchaseResult.Failed -> _events.value = result.reason
            }
            local.value = local.value.copy(isWorking = false)
            credits.refresh()
        }
    }

    /**
     * Re-reads what Play knows and redeems anything outstanding.
     *
     * Every paid app needs this and most hide it three menus deep. The learner
     * who paid and cannot see the credits has exactly one question, and this is
     * the answer to it. It also quietly finishes any purchase that was
     * interrupted — the app killed mid-flow, or a pending payment that has since
     * cleared.
     */
    fun restore() {
        local.value = local.value.copy(isWorking = true)
        viewModelScope.launch {
            val found = billing.restorePurchases()
            val balance = credits.refresh()
            if (found) analytics.track(AnalyticsEvent.PurchasesRestored)
            _events.value = if (found) {
                "Restored. You have ${balance.credits} credits."
            } else {
                "Google Play has no unclaimed purchases on this account."
            }
            local.value = local.value.copy(isWorking = false)
        }
    }

    /**
     * Attaches a Google account.
     *
     * Offered when credits run low, never as a gate. Nothing is lost by
     * declining and nothing is unlocked by accepting — it moves the credits and
     * the progress off this one device, which is the honest reason to do it and
     * the only one given.
     */
    fun signIn(activity: Activity) {
        local.value = local.value.copy(isWorking = true)
        viewModelScope.launch {
            when (val result = googleSignIn.requestIdToken(activity)) {
                is GoogleSignInResult.Token -> {
                    // The token is forwarded, never inspected. Its payload is
                    // plain base64 and reading it here would mean believing
                    // whatever the device handed over.
                    when (val linked = credits.linkGoogleAccount(result.idToken)) {
                        is LinkOutcome.Linked -> {
                            analytics.track(AnalyticsEvent.SignedIn)
                            _events.value = "Signed in. You have ${linked.balance} credits."
                        }
                        LinkOutcome.Offline ->
                            _events.value = "No connection, so signing in did not finish."
                        is LinkOutcome.Rejected -> _events.value = linked.reason
                        is LinkOutcome.Failed -> _events.value = linked.reason
                    }
                }

                // Backing out is not a failure. Saying nothing is the whole
                // response.
                GoogleSignInResult.Cancelled -> Unit

                GoogleSignInResult.NoAccount ->
                    _events.value = "There is no Google account on this phone to sign in with."

                GoogleSignInResult.NotConfigured ->
                    _events.value = "Signing in is not switched on in this build."

                is GoogleSignInResult.Failed -> _events.value = result.reason
            }
            local.value = local.value.copy(isWorking = false)
        }
    }

    fun onOpened() {
        analytics.track(AnalyticsEvent.PaywallViewed)
        billing.start()
        viewModelScope.launch { credits.refresh() }
    }
}
