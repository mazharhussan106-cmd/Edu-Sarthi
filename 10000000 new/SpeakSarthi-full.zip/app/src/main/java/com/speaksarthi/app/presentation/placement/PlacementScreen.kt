package com.speaksarthi.app.presentation.placement

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.presentation.card.ChoiceOption
import com.speaksarthi.app.presentation.theme.SarthiTheme

/**
 * Where a learner starts.
 *
 * The word "test" appears nowhere on this screen, and no score is ever shown.
 * The person opening it is someone who is embarrassed about their English; being
 * marked in the first two minutes is how you lose them before they have studied
 * a single word.
 */
@Composable
fun PlacementScreen(
    onDone: () -> Unit,
    viewModel: PlacementViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (val current = state) {
                PlacementUiState.Intro -> Intro(
                    onStart = viewModel::start,
                    onSkip = viewModel::skip
                )

                PlacementUiState.Loading -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) { CircularProgressIndicator() }

                PlacementUiState.Unavailable -> Centered {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "We will start from the beginning",
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.Center
                        )
                        Button(onClick = { viewModel.skip(); onDone() }) { Text("Start learning") }
                    }
                }

                is PlacementUiState.Asking -> Question(
                    state = current,
                    onSelect = viewModel::select,
                    onNext = viewModel::next,
                    onSkip = { viewModel.skip() }
                )

                is PlacementUiState.Finished -> Finished(state = current, onDone = onDone)
            }
        }
    }
}

@Composable
private fun Intro(onStart: () -> Unit, onSkip: () -> Unit) {
    Centered {
        Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Let's find where to start",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )
            Text(
                text = "A few quick questions — under two minutes, and it gets easier " +
                    "or harder as you go. There is no score and nobody sees it.",
                style = MaterialTheme.typography.bodyLarge,
                color = SarthiTheme.colors.mutedText,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                Text("Start")
            }
            // Skipping is offered plainly, not buried. It costs the learner
            // nothing and the app very little.
            TextButton(onClick = onSkip, modifier = Modifier.fillMaxWidth()) {
                Text("Skip — start from the beginning")
            }
        }
    }
}

@Composable
private fun Question(
    state: PlacementUiState.Asking,
    onSelect: (Int) -> Unit,
    onNext: () -> Unit,
    onSkip: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {

        LinearProgressIndicator(
            progress = { state.progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp),
            color = MaterialTheme.colorScheme.primary,
            trackColor = SarthiTheme.colors.divider
        )

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Question ${state.answered + 1}",
                style = MaterialTheme.typography.labelMedium,
                color = SarthiTheme.colors.mutedText
            )
            Text(
                text = state.question.question,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                state.question.options.forEachIndexed { index, option ->
                    ChoiceOption(
                        text = option,
                        prefix = "${('A' + index)}.",
                        selected = state.selectedOption == index,
                        correct = index == state.question.answerIndex,
                        answered = state.hasAnswered,
                        onClick = { onSelect(index) }
                    )
                }
            }

            if (!state.hasAnswered) {
                Text(
                    text = "Not sure? Pick anything — getting one wrong just means we " +
                        "start a little earlier.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SarthiTheme.colors.mutedText
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onNext,
                modifier = Modifier.fillMaxWidth(),
                enabled = state.hasAnswered,
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Next")
            }
            TextButton(onClick = onSkip, modifier = Modifier.fillMaxWidth()) {
                Text("Skip the rest")
            }
        }
    }
}

@Composable
private fun Finished(state: PlacementUiState.Finished, onDone: () -> Unit) {
    Centered {
        Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Starting at ${state.level.code}",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )
            Text(
                text = state.level.displayName,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = state.message,
                style = MaterialTheme.typography.bodyLarge,
                color = SarthiTheme.colors.mutedText,
                textAlign = TextAlign.Center
            )
            Text(
                text = "You can change this any time in settings.",
                style = MaterialTheme.typography.labelMedium,
                color = SarthiTheme.colors.mutedText,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(onClick = onDone, modifier = Modifier.fillMaxWidth()) {
                Text("Start learning")
            }
        }
    }
}

@Composable
private fun Centered(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(0.dp)),
        contentAlignment = Alignment.Center
    ) { content() }
}
