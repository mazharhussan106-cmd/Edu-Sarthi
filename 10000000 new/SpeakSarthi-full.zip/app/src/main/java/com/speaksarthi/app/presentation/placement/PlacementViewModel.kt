package com.speaksarthi.app.presentation.placement

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.domain.model.CefrLevel
import com.speaksarthi.app.domain.model.McqQuestion
import com.speaksarthi.app.domain.repository.LibraryRepository
import com.speaksarthi.app.domain.usecase.placement.PlacementAnswer
import com.speaksarthi.app.domain.usecase.placement.PlacementScorer
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface PlacementUiState {
    data object Intro : PlacementUiState

    data object Loading : PlacementUiState

    data class Asking(
        val question: McqQuestion,
        val level: CefrLevel,
        val answered: Int,
        val selectedOption: Int? = null
    ) : PlacementUiState {
        val hasAnswered: Boolean get() = selectedOption != null
        val wasCorrect: Boolean get() = selectedOption == question.answerIndex

        /** Rough progress. The test can end early, so this is a floor, not a promise. */
        val progress: Float
            get() = (answered.toFloat() / PlacementScorer.maximumQuestions).coerceIn(0f, 1f)
    }

    data class Finished(val level: CefrLevel, val message: String) : PlacementUiState

    /** The library has no questions — the test cannot run, and that is not the learner's problem. */
    data object Unavailable : PlacementUiState
}

/**
 * The placement test: skippable, and cheap to skip.
 *
 * Skipping costs nothing — the learner starts at A1 and can change their level
 * in settings whenever they like. That is deliberate. A test you cannot skip is
 * a wall in front of an app someone has not decided to use yet, and this app's
 * learner is the one most likely to walk away from a wall.
 */
@HiltViewModel
class PlacementViewModel @Inject constructor(
    private val library: LibraryRepository,
    private val preferences: AppPreferences
) : ViewModel() {

    private val _state = MutableStateFlow<PlacementUiState>(PlacementUiState.Intro)
    val state: StateFlow<PlacementUiState> = _state.asStateFlow()

    private val answers = mutableListOf<PlacementAnswer>()

    /** Questions already asked, so a band's three are never the same word twice. */
    private val askedWordIds = mutableSetOf<String>()

    fun start() {
        answers.clear()
        askedWordIds.clear()
        askNext()
    }

    private fun askNext() {
        val level = PlacementScorer.nextLevel(answers)
        if (level == null) {
            finish()
            return
        }

        _state.value = PlacementUiState.Loading
        viewModelScope.launch {
            // Over-fetch and filter, because the same word coming up twice in one
            // band makes the test look broken and wastes one of only three shots.
            val question = library
                .randomMcqs(level = level.code, limit = QUESTION_POOL)
                .firstOrNull { it.wordId !in askedWordIds && it.options.size >= 2 }
                ?: library.randomMcqs(level = "", limit = QUESTION_POOL)
                    .firstOrNull { it.wordId !in askedWordIds && it.options.size >= 2 }

            if (question == null) {
                _state.value = if (answers.isEmpty()) {
                    PlacementUiState.Unavailable
                } else {
                    // Ran out of questions mid-test. Place them on what they did
                    // answer rather than throwing the whole thing away.
                    finishState()
                }
                return@launch
            }

            askedWordIds += question.wordId
            _state.value = PlacementUiState.Asking(
                question = question,
                level = level,
                answered = answers.size
            )
        }
    }

    fun select(option: Int) {
        val current = _state.value as? PlacementUiState.Asking ?: return
        if (current.hasAnswered) return

        _state.value = current.copy(selectedOption = option)
        answers += PlacementAnswer(
            level = current.level,
            wasCorrect = option == current.question.answerIndex
        )
    }

    fun next() {
        if (_state.value !is PlacementUiState.Asking) return
        askNext()
    }

    private fun finish() {
        _state.value = finishState()
    }

    private fun finishState(): PlacementUiState.Finished {
        val level = PlacementScorer.levelFor(answers)
        saveLevel(level)
        return PlacementUiState.Finished(
            level = level,
            message = PlacementScorer.resultMessage(level)
        )
    }

    /**
     * Skipping is a first-class outcome, not an escape hatch.
     *
     * The learner still gets a level (A1) and onboarding is still marked done, so
     * skipping never leaves the app in a half-set-up state or nags them again.
     */
    fun skip() {
        saveLevel(CefrLevel.A1)
        _state.value = PlacementUiState.Finished(
            level = CefrLevel.A1,
            message = "Starting from the beginning. You can change your level any time in settings."
        )
    }

    private fun saveLevel(level: CefrLevel) {
        viewModelScope.launch {
            preferences.setCurrentLevel(level.code)
            preferences.setOnboardingComplete(true)
        }
    }

    private companion object {
        /** Fetched per question, then filtered for one not already asked. */
        const val QUESTION_POOL = 12
    }
}
