package com.speaksarthi.app.presentation.privacy

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.speaksarthi.app.presentation.theme.SarthiTheme

/**
 * What the app does with the learner's data, in the app.
 *
 * Shown once before anything is recorded, and available in settings afterwards.
 * Written in the second person and in plain sentences, because a consent screen
 * nobody reads is not consent — it is a checkbox with a legal department behind
 * it.
 *
 * The full policy lives in `docs/PRIVACY_POLICY.md` and has to be published at a
 * public URL before the Play Store will accept the app. This screen is the
 * honest summary of it, not a replacement.
 */
@Composable
fun PrivacyScreen(
    /** True the first time, when it is a consent gate rather than a reference page. */
    isConsent: Boolean,
    onAccept: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            if (!isConsent) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                    Text(
                        text = "Your data",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }

            Column(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                if (isConsent) {
                    Text(
                        text = "Before you start",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Point(
                    heading = "Almost everything stays on your phone",
                    body = "Your words, your progress, your streak, your recordings and the " +
                        "sentences you write are stored on this device only. Nothing is " +
                        "uploaded in the background, and there is no account to make."
                )

                Point(
                    heading = "One thing leaves, and only when you tap it",
                    body = "When you tap “Score it” on a recording, that clip is sent to be " +
                        "scored for pronunciation, and the scores come back. Recording does " +
                        "not send anything — only scoring does. You can use the whole app " +
                        "without ever sending a clip."
                )

                Point(
                    heading = "We never ask who you are",
                    body = "No name, no phone number, no email, no contacts, no location. " +
                        "The app gives this installation a random number so your progress " +
                        "belongs to something and can be backed up. It says nothing about you."
                )

                Point(
                    heading = "The microphone is yours",
                    body = "It is used while you are recording and at no other time. You can " +
                        "refuse the permission and everything except speaking practice still " +
                        "works."
                )

                Point(
                    heading = "Deleting is easy and complete",
                    body = "Settings has a button that deletes every recording. Uninstalling " +
                        "the app removes all of it — because all of it is here."
                )

                if (isConsent) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Button(onClick = onAccept, modifier = Modifier.fillMaxWidth()) {
                        Text("Got it — start learning")
                    }
                    Text(
                        text = "You can read this again any time in Settings.",
                        style = MaterialTheme.typography.labelMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun Point(heading: String, body: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = heading,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = SarthiTheme.colors.mutedText
        )
    }
}
