package com.speaksarthi.app.presentation.search

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.domain.model.CefrLevel
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.presentation.card.LevelBadge
import com.speaksarthi.app.presentation.theme.PhoneticStyle
import com.speaksarthi.app.presentation.theme.SarthiTheme
import com.speaksarthi.app.presentation.util.OnResume

/**
 * Search, bookmarks and browsing — the whole library, reachable directly.
 *
 * The other screens decide what the learner sees next. This is the one where
 * they decide.
 */
@Composable
fun SearchScreen(
    onOpenWord: (String) -> Unit,
    viewModel: SearchViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    OnResume { viewModel.refresh() }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {

            OutlinedTextField(
                value = state.query,
                onValueChange = viewModel::onQueryChanged,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                placeholder = { Text("Search a word, or its Hindi meaning") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (state.query.isNotEmpty()) {
                        IconButton(onClick = viewModel::clearQuery) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear the search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp)
            )

            // The tabs only make sense when not searching — while a query is
            // live, the result list is the answer and a tab row above it is noise.
            if (!state.isQuerying) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SearchTab.entries.forEach { tab ->
                        FilterChip(
                            selected = state.tab == tab,
                            onClick = { viewModel.selectTab(tab) },
                            label = { Text(tab.label) }
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = state.level == null,
                    onClick = { viewModel.selectLevel(null) },
                    label = { Text("Any level") }
                )
                CefrLevel.entries.forEach { level ->
                    FilterChip(
                        selected = state.level == level,
                        onClick = { viewModel.selectLevel(level) },
                        label = { Text(level.code) }
                    )
                }
            }

            val visible = state.visible

            if (visible.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = state.emptyMessage,
                        style = MaterialTheme.typography.bodyLarge,
                        color = SarthiTheme.colors.mutedText,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(32.dp)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(visible, key = { it.wordId }) { word ->
                        WordRow(
                            word = word,
                            isBookmarked = state.bookmarks.any { it.wordId == word.wordId },
                            onClick = { onOpenWord(word.wordId) },
                            onBookmark = { viewModel.toggleBookmark(word) }
                        )
                    }
                }
            }
        }
    }
}

/**
 * One result.
 *
 * Shows the Hindi meaning as well as the English one, because for this learner
 * the Hindi is often what makes the word click — and because it is what they may
 * well have searched for.
 */
@Composable
private fun WordRow(
    word: Word,
    isBookmarked: Boolean,
    onClick: () -> Unit,
    onBookmark: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = word.word,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                LevelBadge(level = word.level)
            }
            if (word.ipa.isNotBlank()) {
                Text(
                    text = word.ipa,
                    style = PhoneticStyle,
                    color = SarthiTheme.colors.mutedText
                )
            }
            val meaning = word.hindiMeaning.ifBlank { word.simpleMeaning }
            if (meaning.isNotBlank()) {
                Text(
                    text = meaning,
                    style = MaterialTheme.typography.bodyMedium,
                    color = SarthiTheme.colors.mutedText,
                    maxLines = 2
                )
            }
        }

        IconButton(onClick = onBookmark, modifier = Modifier.size(40.dp)) {
            Icon(
                imageVector = if (isBookmarked) {
                    Icons.Default.Bookmark
                } else {
                    Icons.Default.BookmarkBorder
                },
                contentDescription = if (isBookmarked) {
                    "Remove ${word.word} from bookmarks"
                } else {
                    "Bookmark ${word.word}"
                },
                tint = if (isBookmarked) {
                    MaterialTheme.colorScheme.tertiary
                } else {
                    SarthiTheme.colors.mutedText
                }
            )
        }
    }
}
