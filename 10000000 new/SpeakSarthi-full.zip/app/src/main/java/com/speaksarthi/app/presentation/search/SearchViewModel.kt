package com.speaksarthi.app.presentation.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.domain.model.CefrLevel
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.domain.repository.LibraryRepository
import com.speaksarthi.app.domain.repository.StudyRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * What the learner is looking at when they have not typed anything.
 *
 * An empty search box should never show an empty screen. These are the three
 * lists worth having one tap away, and they are also the answer to "what did I
 * do yesterday?" — a question the study queue cannot answer.
 */
enum class SearchTab(val label: String) {
    Bookmarks("Bookmarks"),
    Recent("Recent"),
    Browse("All words")
}

data class SearchUiState(
    val query: String = "",
    val results: List<Word> = emptyList(),
    val bookmarks: List<Word> = emptyList(),
    val recent: List<Word> = emptyList(),
    val browse: List<Word> = emptyList(),
    val tab: SearchTab = SearchTab.Bookmarks,
    /** Null means every level. */
    val level: CefrLevel? = null,
    val isSearching: Boolean = false
) {
    val isQuerying: Boolean get() = query.isNotBlank()

    /** What the list actually shows right now. */
    val visible: List<Word>
        get() {
            val base = if (isQuerying) results else when (tab) {
                SearchTab.Bookmarks -> bookmarks
                SearchTab.Recent -> recent
                SearchTab.Browse -> browse
            }
            return level?.let { wanted -> base.filter { it.level == wanted } } ?: base
        }

    val emptyMessage: String
        get() = when {
            isQuerying -> "Nothing matched “$query”. Try a shorter word, or the Hindi meaning."
            tab == SearchTab.Bookmarks ->
                "No bookmarks yet. Tap the bookmark on any card and it lands here."
            tab == SearchTab.Recent -> "Nothing studied yet. Start a session and this fills in."
            else -> "The library is still loading."
        }
}

/**
 * Search over the whole library, plus the three lists worth having without one.
 *
 * Search matters more here than it looks: 1,000 words are otherwise reachable
 * only in the order spaced repetition decides, and a learner who heard a word at
 * work this morning wants *that* word, now, not in eleven days.
 */
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val library: LibraryRepository,
    private val study: StudyRepository
) : ViewModel() {

    private val _state = MutableStateFlow(SearchUiState())
    val state: StateFlow<SearchUiState> = _state.asStateFlow()

    private var searchJob: Job? = null

    init {
        viewModelScope.launch {
            _state.value = _state.value.copy(
                bookmarks = library.observeBookmarked().first(),
                recent = library.recentlyStudied(RECENT_LIMIT),
                browse = library.observeWords().first().take(BROWSE_LIMIT)
            )
        }
        // Bookmarks change from other screens, so they are watched rather than
        // read once — a bookmark added on a card must be here when you come back.
        viewModelScope.launch {
            library.observeBookmarked().collect { words ->
                _state.value = _state.value.copy(bookmarks = words)
            }
        }
    }

    /** Re-reads the lists that are snapshots rather than flows. */
    fun refresh() {
        viewModelScope.launch {
            _state.value = _state.value.copy(recent = library.recentlyStudied(RECENT_LIMIT))
        }
    }

    fun onQueryChanged(query: String) {
        _state.value = _state.value.copy(query = query, isSearching = query.isNotBlank())

        // Debounced: a LIKE across three columns on every keystroke is real work
        // on a cheap phone, and the learner is still typing anyway.
        searchJob?.cancel()
        if (query.isBlank()) {
            _state.value = _state.value.copy(results = emptyList(), isSearching = false)
            return
        }
        searchJob = viewModelScope.launch {
            delay(SEARCH_DEBOUNCE_MS)
            val results = library.search(query, limit = SEARCH_LIMIT)
            _state.value = _state.value.copy(results = results, isSearching = false)
        }
    }

    fun clearQuery() = onQueryChanged("")

    fun selectTab(tab: SearchTab) {
        _state.value = _state.value.copy(tab = tab)
        if (tab == SearchTab.Recent) refresh()
    }

    /** Null clears the filter. */
    fun selectLevel(level: CefrLevel?) {
        _state.value = _state.value.copy(level = level)
    }

    fun toggleBookmark(word: Word) {
        viewModelScope.launch {
            val current = study.progress(word.wordId)
            study.setBookmarked(word.wordId, !current.isBookmarked)
        }
    }

    private companion object {
        const val SEARCH_DEBOUNCE_MS = 250L
        const val SEARCH_LIMIT = 60
        const val RECENT_LIMIT = 40

        /**
         * Browse shows a slice, not all 1,000.
         *
         * Scrolling a thousand rows is not browsing, it is giving up slowly. The
         * level chips narrow it, and search is what a learner actually uses when
         * they know what they want.
         */
        const val BROWSE_LIMIT = 200
    }
}
