package com.speaksarthi.app.presentation.settings

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.data.audio.SpeechPlayer
import com.speaksarthi.app.data.backup.BackupFile
import com.speaksarthi.app.domain.model.CefrLevel
import com.speaksarthi.app.domain.usecase.reminders.Reminder
import com.speaksarthi.app.presentation.theme.SarthiTheme
import com.speaksarthi.app.presentation.theme.ThemeMode
import com.speaksarthi.app.presentation.util.OnResume

/**
 * Settings, in the order a learner is likely to want them.
 *
 * Display first because it is what people change on day one, reminders next
 * because that is what keeps them coming back, and the destructive things last
 * behind a confirmation.
 */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onSendFeedback: () -> Unit,
    onOpenPaywall: () -> Unit,
    onOpenPrivacy: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val event by viewModel.events.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }

    var confirmingDelete by remember { mutableStateOf(false) }
    var editingHost by remember { mutableStateOf(false) }
    var confirmingRestore by remember { mutableStateOf<Uri?>(null) }

    val askForNotifications = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* Declining is fine; the reminder simply will not show. */ }

    // The system file picker, so the backup lands somewhere the learner can
    // actually reach — and so no storage permission is needed.
    val exportBackup = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(BackupFile.MIME_TYPE)
    ) { uri -> uri?.let(viewModel::exportBackup) }

    val importBackup = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { confirmingRestore = it } }

    OnResume { viewModel.refreshStorage() }

    LaunchedEffect(event) {
        when (val current = event) {
            SettingsEvent.AskForNotificationPermission -> {
                // Only exists from Android 13. Below that, notifications are on
                // by default and there is nothing to ask for.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    askForNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                viewModel.consumeEvent()
            }

            is SettingsEvent.Message -> {
                snackbar.showSnackbar(current.text)
                viewModel.consumeEvent()
            }

            null -> Unit
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = "Settings",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Column(
                modifier = Modifier.padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Section(title = "Credits") {
                    Text(
                        text = when {
                            !state.creditsKnown ->
                                "Credits pay for AI pronunciation scoring. Everything " +
                                    "else in the app is free forever."
                            state.credits == 0 ->
                                "No credits left. Recording and everything else still " +
                                    "works — finish a lesson to earn more."
                            else ->
                                "${state.credits} credits. Each one scores a sentence; " +
                                    "everything else in the app is free forever."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (!state.isSignedIn) {
                        Text(
                            // Stated as a fact about where the credits live, not
                            // as a warning. It is true of the progress too, and a
                            // learner deciding whether to sign in deserves to know
                            // it before they change phone, not after.
                            text = "Your credits are on this device only. Signing in " +
                                "keeps them if you change phone.",
                            style = MaterialTheme.typography.labelMedium,
                            color = SarthiTheme.colors.mutedText
                        )
                    }
                    TextButton(onClick = onOpenPaywall) {
                        Text(if (state.credits == 0) "Get credits" else "Credits and packs")
                    }
                }

                Section(title = "Backup") {
                    Text(
                        text = "Save your progress, streak, badges and bookmarks to a file " +
                            "you keep. Restoring it on a new phone brings all of it back.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Recordings are not included — they are too large to move " +
                            "around. The scores from them are.",
                        style = MaterialTheme.typography.labelMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { exportBackup.launch(viewModel.backupFileName()) }) {
                            Text("Export")
                        }
                        TextButton(onClick = { importBackup.launch(arrayOf("application/json")) }) {
                            Text("Restore")
                        }
                    }
                }

                Section(title = "Display") {
                    Label("Mode")
                    ChipRow {
                        ThemeMode.entries.forEach { mode ->
                            FilterChip(
                                selected = state.themeMode == mode,
                                onClick = { viewModel.setThemeMode(mode) },
                                label = { Text(modeLabel(mode)) }
                            )
                        }
                    }
                }

                Section(title = "Learning") {
                    Label("Words a day: ${state.dailyGoal}")
                    Slider(
                        value = state.dailyGoal.toFloat(),
                        onValueChange = { viewModel.setDailyGoal(it.toInt()) },
                        valueRange = 5f..50f,
                        steps = 8
                    )
                    Text(
                        text = "Ten is about ten minutes. A goal you actually hit beats " +
                            "an ambitious one you miss.",
                        style = MaterialTheme.typography.labelMedium,
                        color = SarthiTheme.colors.mutedText
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Label("Level")
                    ChipRow {
                        CefrLevel.entries.forEach { level ->
                            FilterChip(
                                selected = state.level == level,
                                onClick = { viewModel.setLevel(level) },
                                label = { Text("${level.code} · ${level.displayName}") }
                            )
                        }
                    }
                }

                Section(title = "Audio") {
                    Label("Speed: ${"%.2f".format(state.audioSpeed)}×")
                    Slider(
                        value = state.audioSpeed,
                        onValueChange = viewModel::setAudioSpeed,
                        valueRange = SpeechPlayer.RATE_MIN..SpeechPlayer.RATE_MAX,
                        steps = 9
                    )
                    Text(
                        text = "You will hear a sample each time you move it.",
                        style = MaterialTheme.typography.labelMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                }

                Section(title = "Reminders") {
                    state.reminders.forEach { reminder ->
                        ReminderRow(
                            reminder = reminder,
                            onToggle = { viewModel.setReminderEnabled(reminder.slot, it) },
                            onTimeChanged = { hour, minute ->
                                viewModel.setReminderTime(reminder.slot, hour, minute)
                            }
                        )
                    }
                    Text(
                        text = "Three at most, on purpose. An app that can ping you six " +
                            "times a day is one you turn notifications off for — and then " +
                            "it can never remind you of anything again.",
                        style = MaterialTheme.typography.labelMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                }

                Section(title = "Artwork") {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (state.illustrationBaseUrl.isBlank()) {
                                    "No image host set"
                                } else {
                                    state.illustrationBaseUrl
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${state.illustrationCacheBytes / 1024 / 1024} MB cached",
                                style = MaterialTheme.typography.labelMedium,
                                color = SarthiTheme.colors.mutedText
                            )
                        }
                        TextButton(onClick = { editingHost = true }) { Text("Change") }
                    }
                    TextButton(onClick = viewModel::clearIllustrationCache) {
                        Text("Clear cached artwork")
                    }
                }

                Section(title = "Your recordings") {
                    Text(
                        text = "${state.recordingCount} recordings on this phone",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "They never leave your device. Nothing is uploaded anywhere.",
                        style = MaterialTheme.typography.labelMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                    TextButton(
                        onClick = { confirmingDelete = true },
                        enabled = state.recordingCount > 0
                    ) {
                        Text("Delete all recordings", color = MaterialTheme.colorScheme.error)
                    }
                }

                Section(title = "Your data") {
                    Text(
                        text = "Almost everything stays on this phone. The only thing that " +
                            "ever leaves is a recording you choose to have scored.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    TextButton(onClick = onOpenPrivacy) { Text("What is stored, and where") }
                }

                Section(title = "Feedback") {
                    Text(
                        text = "Something broken, or a word that looks wrong? Tell us — " +
                            "it is the fastest way to get it fixed.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                    Button(onClick = onSendFeedback) { Text("Send feedback") }
                }

                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (confirmingDelete) {
        AlertDialog(
            onDismissRequest = { confirmingDelete = false },
            title = { Text("Delete every recording?") },
            text = {
                Text(
                    "This cannot be undone, and your own voice is the one thing here " +
                        "you cannot get back. Your scores and weak sounds are kept."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteAllRecordings()
                        confirmingDelete = false
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmingDelete = false }) { Text("Keep them") }
            }
        )
    }

    confirmingRestore?.let { uri ->
        AlertDialog(
            onDismissRequest = { confirmingRestore = null },
            title = { Text("Restore from this file?") },
            text = {
                Text(
                    "Anything already on this phone is kept — where both have the same " +
                        "word, whichever shows more learning wins. Nothing is deleted."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.restoreBackup(uri)
                        confirmingRestore = null
                    }
                ) { Text("Restore") }
            },
            dismissButton = {
                TextButton(onClick = { confirmingRestore = null }) { Text("Cancel") }
            }
        )
    }

    if (editingHost) {
        HostDialog(
            current = state.illustrationBaseUrl,
            onDismiss = { editingHost = false },
            onSave = {
                viewModel.setIllustrationBaseUrl(it)
                editingHost = false
            }
        )
    }
}

@Composable
private fun HostDialog(current: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(current) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Image host") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("https://cdn.example.com/art") },
                    singleLine = true
                )
                Text(
                    text = "Each drawing is fetched from this address plus its filename. " +
                        "Leave it empty and cards show their text frame instead — " +
                        "nothing breaks.",
                    style = MaterialTheme.typography.labelMedium,
                    color = SarthiTheme.colors.mutedText
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/**
 * One reminder.
 *
 * The time steps in half-hours by tapping rather than opening a picker dialog:
 * three taps to get from 8:00 to 9:30 is fewer interactions than a dialog, and
 * nobody sets a study reminder for 8:07.
 */
@Composable
private fun ReminderRow(
    reminder: Reminder,
    onToggle: (Boolean) -> Unit,
    onTimeChanged: (Int, Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = reminder.display(),
            style = MaterialTheme.typography.titleMedium,
            color = if (reminder.enabled) {
                MaterialTheme.colorScheme.onSurface
            } else {
                SarthiTheme.colors.mutedText
            },
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable {
                    val stepped = (reminder.hour * 60 + reminder.minute + 30) % (24 * 60)
                    onTimeChanged(stepped / 60, stepped % 60)
                }
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )
        Spacer(modifier = Modifier.weight(1f))
        Switch(checked = reminder.enabled, onCheckedChange = onToggle)
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(MaterialTheme.colorScheme.surface)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) { content() }
    }
}

@Composable
private fun Label(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurface
    )
}

@Composable
private fun ChipRow(content: @Composable () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) { content() }
}

private fun modeLabel(mode: ThemeMode): String = when (mode) {
    ThemeMode.System -> "Automatic"
    ThemeMode.Light -> "Light"
    ThemeMode.Dark -> "Dark"
    ThemeMode.EyeProtection -> "Night reading"
}
