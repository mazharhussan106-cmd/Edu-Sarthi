package com.speaksarthi.app.presentation.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.analytics.Analytics
import com.speaksarthi.app.data.analytics.AnalyticsEvent
import android.net.Uri
import com.speaksarthi.app.data.audio.SpeechPlayer
import com.speaksarthi.app.data.backup.BackupManager
import com.speaksarthi.app.data.illustration.IllustrationLoader
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.data.reminder.ReminderScheduler
import com.speaksarthi.app.domain.model.CefrLevel
import com.speaksarthi.app.domain.model.CreditBalance
import com.speaksarthi.app.domain.repository.CreditsRepository
import com.speaksarthi.app.domain.repository.SpeakingRepository
import com.speaksarthi.app.domain.usecase.reminders.Reminder
import com.speaksarthi.app.domain.usecase.reminders.ReminderSchedule
import com.speaksarthi.app.presentation.theme.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val themeMode: ThemeMode = ThemeMode.System,
    val dailyGoal: Int = AppPreferences.DEFAULT_DAILY_GOAL,
    val level: CefrLevel = CefrLevel.A1,
    val audioSpeed: Float = AppPreferences.DEFAULT_AUDIO_SPEED,
    val reminders: List<Reminder> = ReminderSchedule.defaults,
    val illustrationBaseUrl: String = "",
    val recordingCount: Int = 0,
    val illustrationCacheBytes: Long = 0,
    val balance: CreditBalance = CreditBalance.unknown
) {
    val anyReminderOn: Boolean get() = reminders.any { it.enabled }

    val credits: Int get() = balance.credits

    val isSignedIn: Boolean get() = balance.signedIn

    val creditsKnown: Boolean get() = balance.source == CreditBalance.Source.Server
}

/** One-off things the screen has to react to rather than display. */
sealed interface SettingsEvent {
    /** A reminder was switched on and the app has never asked for permission. */
    data object AskForNotificationPermission : SettingsEvent

    data class Message(val text: String) : SettingsEvent
}

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val preferences: AppPreferences,
    private val reminderScheduler: ReminderScheduler,
    private val speaking: SpeakingRepository,
    private val illustrations: IllustrationLoader,
    private val speech: SpeechPlayer,
    private val credits: CreditsRepository,
    private val backups: BackupManager,
    private val analytics: Analytics
) : ViewModel() {

    /** Cache size has to be measured on demand, so it is held rather than observed. */
    private val cacheBytes = MutableStateFlow(0L)

    private val _events = MutableStateFlow<SettingsEvent?>(null)
    val events: StateFlow<SettingsEvent?> = _events.asStateFlow()

    /**
     * Grouped into three bundles because `combine` tops out at five flows and
     * this screen reads nine settings. Grouped by what they are about — display,
     * reminders, storage — rather than by whatever made the arity work.
     */
    private data class Display(
        val themeMode: ThemeMode,
        val dailyGoal: Int,
        val level: CefrLevel,
        val audioSpeed: Float
    )

    private data class Storage(
        val illustrationBaseUrl: String,
        val cacheBytes: Long,
        val recordingCount: Int
    )

    val state: StateFlow<SettingsUiState> = combine(
        combine(
            preferences.themeMode,
            preferences.dailyGoal,
            preferences.currentLevel.map(CefrLevel::fromCode),
            preferences.audioSpeed,
            ::Display
        ),
        preferences.reminders.map(ReminderSchedule::parse),
        combine(
            preferences.illustrationBaseUrl,
            cacheBytes,
            speaking.observeRecordingCount(),
            ::Storage
        ),
        credits.observeBalance()
    ) { display, reminders, storage, balance ->
        SettingsUiState(
            themeMode = display.themeMode,
            dailyGoal = display.dailyGoal,
            level = display.level,
            audioSpeed = display.audioSpeed,
            reminders = reminders,
            illustrationBaseUrl = storage.illustrationBaseUrl,
            balance = balance,
            recordingCount = storage.recordingCount,
            illustrationCacheBytes = storage.cacheBytes
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    init {
        refreshStorage()
    }

    fun refreshStorage() {
        viewModelScope.launch { cacheBytes.value = illustrations.cacheBytes() }
    }

    fun consumeEvent() {
        _events.value = null
    }

    // ---- display -----------------------------------------------------------

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { preferences.setThemeMode(mode) }
    }

    fun setDailyGoal(words: Int) {
        viewModelScope.launch { preferences.setDailyGoal(words) }
    }

    fun setLevel(level: CefrLevel) {
        viewModelScope.launch { preferences.setCurrentLevel(level.code) }
    }

    fun setAudioSpeed(speed: Float) {
        viewModelScope.launch {
            preferences.setAudioSpeed(speed)
            // Spoken back immediately at the new speed. A speed slider you cannot
            // hear is a slider you set by guessing.
            speech.speak("This is how fast it will sound.", rate = speed)
        }
    }

    // ---- reminders ---------------------------------------------------------

    /**
     * Turning a reminder on is the moment to ask for notification permission —
     * not at launch, when the learner has no idea what they would be agreeing to
     * and reflexively says no.
     */
    fun setReminderEnabled(slot: Int, enabled: Boolean) {
        updateReminders { list ->
            list.map { if (it.slot == slot) it.copy(enabled = enabled) else it }
        }
        if (!enabled) return

        viewModelScope.launch {
            analytics.track(AnalyticsEvent.ReminderSet, mapOf("slot" to slot))
            if (!preferences.hasAskedForNotifications.first()) {
                preferences.setAskedForNotifications(true)
                _events.value = SettingsEvent.AskForNotificationPermission
            }
        }
    }

    fun setReminderTime(slot: Int, hour: Int, minute: Int) {
        updateReminders { list ->
            list.map { if (it.slot == slot) it.copy(hour = hour, minute = minute) else it }
        }
    }

    private fun updateReminders(transform: (List<Reminder>) -> List<Reminder>) {
        viewModelScope.launch {
            val current = ReminderSchedule.parse(preferences.reminders.first())
            preferences.setReminders(ReminderSchedule.serialise(transform(current)))
            // Re-applied rather than diffed: three unique work names replaced in
            // place is cheap, and diffing is where duplicate reminders come from.
            reminderScheduler.applyAll()
        }
    }

    // ---- storage -----------------------------------------------------------

    fun setIllustrationBaseUrl(url: String) {
        viewModelScope.launch { preferences.setIllustrationBaseUrl(url) }
    }

    fun clearIllustrationCache() {
        viewModelScope.launch {
            illustrations.clearCache()
            refreshStorage()
            _events.value = SettingsEvent.Message("Artwork cache cleared.")
        }
    }

    // ---- backup ------------------------------------------------------------

    fun backupFileName(): String = backups.suggestedFileName()

    fun exportBackup(uri: Uri) {
        viewModelScope.launch {
            backups.writeTo(uri)
                .onSuccess { rows ->
                    analytics.track(AnalyticsEvent.BackupExported, mapOf("rows" to rows))
                    _events.value = SettingsEvent.Message(
                        "Saved. $rows items backed up — keep the file somewhere safe."
                    )
                }
                .onFailure {
                    _events.value = SettingsEvent.Message(
                        "That location could not be written to. Try somewhere else."
                    )
                }
        }
    }

    fun restoreBackup(uri: Uri) {
        viewModelScope.launch {
            val report = backups.restoreFrom(uri)

            _events.value = SettingsEvent.Message(
                when {
                    !report.isSuccess -> report.error.orEmpty()

                    report.totalRestored == 0 ->
                        "Nothing in that file needed restoring — you are already up to date."

                    else -> {
                        analytics.track(AnalyticsEvent.BackupRestored)
                        "Restored ${report.progressRestored} words, " +
                            "${report.badgesRestored} badges and " +
                            "${report.daysRestored} days of history."
                    }
                }
            )
        }
    }

    /**
     * Deletes every recording and its row.
     *
     * The one destructive action in the app, so the screen confirms first. The
     * learner's own voice is the only thing here they cannot get back.
     */
    fun deleteAllRecordings() {
        viewModelScope.launch {
            speaking.deleteAllRecordings()
            _events.value = SettingsEvent.Message("All recordings deleted.")
        }
    }
}
