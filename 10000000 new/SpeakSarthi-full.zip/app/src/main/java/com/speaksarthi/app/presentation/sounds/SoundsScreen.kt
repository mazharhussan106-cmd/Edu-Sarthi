package com.speaksarthi.app.presentation.sounds

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.presentation.card.SpeakerButton
import com.speaksarthi.app.presentation.theme.PhoneticStyle
import com.speaksarthi.app.presentation.theme.SarthiTheme
import com.speaksarthi.app.presentation.util.OnResume

/**
 * The sounds to work on.
 *
 * Phrased as work, not as faults. The list is the most useful thing the scoring
 * engine produces — a learner who knows their /v/ and /w/ swap can fix that in
 * a week, where a learner who knows they scored 68% cannot fix anything.
 */
@Composable
fun SoundsScreen(
    onBack: () -> Unit,
    viewModel: SoundsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    OnResume { viewModel.refresh() }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = "Sounds to work on",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            when {
                state.isLoading -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) { CircularProgressIndicator() }

                !state.hasData -> Empty(recordingCount = state.recordingCount)

                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Summary(state = state) }

                    items(state.rows, key = { it.sound.phoneme }) { row ->
                        SoundCard(row = row, onPlay = { viewModel.playExample(row.guide.example) })
                    }

                    item {
                        Text(
                            text = "Ranked by how often each sound was marked, not by how " +
                                "many times it went wrong — otherwise the most common sounds " +
                                "in English would always top the list.",
                            style = MaterialTheme.typography.labelMedium,
                            color = SarthiTheme.colors.mutedText
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun Summary(state: SoundsUiState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = "${state.recordingCount} recordings",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = state.averageScore?.let { average ->
                "Averaging ${average.toInt()} on sounds over the last month."
            } ?: "Score a few recordings and this fills in.",
            style = MaterialTheme.typography.bodyMedium,
            color = SarthiTheme.colors.mutedText
        )
    }
}

@Composable
private fun SoundCard(row: SoundRow, onPlay: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = row.guide.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "/${row.sound.phoneme}/" +
                        if (row.guide.example.isNotBlank()) " — as in “${row.guide.example}”" else "",
                    style = PhoneticStyle,
                    color = SarthiTheme.colors.mutedText
                )
            }
            if (row.guide.example.isNotBlank()) {
                SpeakerButton(
                    onClick = onPlay,
                    contentDescription = "Hear ${row.guide.example} said slowly"
                )
            }
        }

        // The rate, drawn as well as printed. A learner scanning the list should
        // be able to see which sound to start with without reading every number.
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            LinearProgressIndicator(
                progress = { row.sound.errorRate.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = SarthiTheme.colors.warning,
                trackColor = SarthiTheme.colors.divider
            )
            Text(
                text = "Marked ${row.errorPercent}% of the " +
                    "${row.sound.attemptCount} times you have said it",
                style = MaterialTheme.typography.labelMedium,
                color = SarthiTheme.colors.mutedText
            )
        }

        Text(
            text = row.guide.how,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface
        )

        if (row.guide.note.isNotBlank()) {
            Text(
                text = row.guide.note,
                style = MaterialTheme.typography.bodyMedium,
                color = SarthiTheme.colors.mutedText
            )
        }
    }
}

@Composable
private fun Empty(recordingCount: Int) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Nothing to work on yet",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )
            Text(
                text = if (recordingCount > 0) {
                    "You have made $recordingCount recordings but none has been scored yet. " +
                        "Score one and the sounds to work on appear here."
                } else {
                    "Record yourself saying a few sentences and score them. This page then " +
                        "tells you which sounds to practise, and how."
                },
                style = MaterialTheme.typography.bodyLarge,
                color = SarthiTheme.colors.mutedText,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}
