package com.speaksarthi.app.presentation.sounds

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.audio.SpeechPlayer
import com.speaksarthi.app.domain.model.WeakSound
import com.speaksarthi.app.domain.repository.SpeakingRepository
import com.speaksarthi.app.domain.usecase.pronunciation.PhonemeGuide
import com.speaksarthi.app.util.Clock
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** One sound, with its tally and its explanation, ready to draw. */
data class SoundRow(
    val sound: WeakSound,
    val guide: PhonemeGuide.Sound,
    val hasRealGuidance: Boolean
) {
    /** Percentage of attempts the service marked weak, rounded. */
    val errorPercent: Int get() = (sound.errorRate * 100).toInt()
}

data class SoundsUiState(
    val rows: List<SoundRow> = emptyList(),
    val recordingCount: Int = 0,
    val averageScore: Float? = null,
    val isLoading: Boolean = true
) {
    /** Nothing to show yet is the normal state before any clip has been scored. */
    val hasData: Boolean get() = rows.isNotEmpty()
}

/**
 * The sounds a learner keeps missing.
 *
 * Ranked by error *rate*, not error count. /t/ appears in more English words
 * than anything else, so counting raw errors would put it top of the list for
 * every learner alive and tell them nothing.
 */
@HiltViewModel
class SoundsViewModel @Inject constructor(
    private val speaking: SpeakingRepository,
    private val speech: SpeechPlayer,
    private val clock: Clock
) : ViewModel() {

    private val averageScore = MutableStateFlow<Float?>(null)

    val state: StateFlow<SoundsUiState> = combine(
        speaking.observeWeakSounds(limit = LIST_LIMIT),
        speaking.observeRecordingCount(),
        averageScore
    ) { sounds, recordings, average ->
        SoundsUiState(
            rows = sounds.map { sound ->
                SoundRow(
                    sound = sound,
                    guide = PhonemeGuide.describe(sound.phoneme),
                    hasRealGuidance = PhonemeGuide.isDescribed(sound.phoneme)
                )
            },
            recordingCount = recordings,
            averageScore = average,
            isLoading = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SoundsUiState())

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            // Last thirty days rather than all time: a learner who is improving
            // should see that reflected, and a month of practice is recent
            // enough to be about how they speak now.
            averageScore.value = speaking.averageScoreSince(clock.nowMillis() - THIRTY_DAYS_MILLIS)
        }
    }

    /** Says a word containing the sound, slowly, so the learner can hear it. */
    fun playExample(word: String) {
        if (word.isBlank()) return
        speech.speak(word, rate = SpeechPlayer.RATE_SLOW)
    }

    override fun onCleared() {
        speech.stop()
        super.onCleared()
    }

    private companion object {
        const val LIST_LIMIT = 12
        const val THIRTY_DAYS_MILLIS = 30L * 24 * 60 * 60 * 1000
    }
}
