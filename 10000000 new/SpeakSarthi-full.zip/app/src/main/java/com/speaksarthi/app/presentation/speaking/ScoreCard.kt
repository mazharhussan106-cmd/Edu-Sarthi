package com.speaksarthi.app.presentation.speaking

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.speaksarthi.app.domain.usecase.pronunciation.NextFix
import com.speaksarthi.app.domain.usecase.pronunciation.ScoreBand
import com.speaksarthi.app.domain.usecase.pronunciation.ScoreReading
import com.speaksarthi.app.presentation.card.SectionCard
import com.speaksarthi.app.presentation.card.SpeakerButton
import com.speaksarthi.app.presentation.theme.SarthiTheme

/**
 * The score card.
 *
 * What it does NOT do is the point: it never leads with a percentage. A learner
 * who is embarrassed about their English and is handed "64%" has learned that
 * they scored 64% — not what to change, and not that 64% on an Indian accent
 * from this service is perfectly intelligible speech. So the headline is a band,
 * the body is one specific sound to fix, and the raw numbers are behind a tap
 * for anyone who wants them.
 */
@Composable
fun ScoreCard(
    reading: ScoreReading,
    onPlayModel: () -> Unit,
    onPlayWord: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showNumbers by remember { mutableStateOf(false) }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        BandHeadline(reading = reading)

        if (reading.nextFix != null) {
            FixCard(
                fix = reading.nextFix,
                onPlayWord = { onPlayWord(reading.nextFix.inWord) }
            )
        }

        if (reading.skippedWords.isNotEmpty()) {
            SectionCard(title = "Left out", accent = SarthiTheme.colors.warning) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = reading.skippedWords.joinToString(", "),
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Read the whole line. Nothing is timing you.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                }
            }
        }

        SectionCard(title = "Your sentence", accent = MaterialTheme.colorScheme.primary) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                MarkedSentence(reading = reading)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SpeakerButton(
                        onClick = onPlayModel,
                        contentDescription = "Hear the sentence said for you"
                    )
                    Text(
                        text = "Hear it, then say it again",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                }
            }
        }

        // Kept, but never the headline. Anyone who wants the raw service output
        // can have it; nobody is shown a bare failing number they did not ask for.
        TextButton(onClick = { showNumbers = !showNumbers }) {
            Text(if (showNumbers) "Hide the numbers" else "Show the numbers")
        }

        AnimatedVisibility(visible = showNumbers) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ScoreBar("Sounds", reading.rawAccuracy)
                ScoreBar("Flow", reading.rawFluency)
                ScoreBar("Completeness", reading.rawCompleteness)
                Text(
                    text = "These come straight from the scoring service. It is stricter " +
                        "on Indian English than on American English, so treat them as a " +
                        "rough guide, not a grade.",
                    style = MaterialTheme.typography.labelMedium,
                    color = SarthiTheme.colors.mutedText
                )
            }
        }
    }
}

@Composable
private fun BandHeadline(reading: ScoreReading) {
    val colour = colourFor(reading.band)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(colour.copy(alpha = 0.12f))
            .border(1.dp, colour.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Text(
            text = reading.headline,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = colour
        )
        Text(
            text = reading.detail,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        if (reading.heardSomethingElse) {
            Text(
                text = "It heard something slightly different from the line — " +
                    "worth another go at the marked words.",
                style = MaterialTheme.typography.bodyMedium,
                color = SarthiTheme.colors.mutedText
            )
        }
    }
}

/** The one thing to do next. Given its own card because it is the whole point. */
@Composable
private fun FixCard(fix: NextFix, onPlayWord: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "Fix this one first",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
            Text(
                text = fix.advice,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
        SpeakerButton(
            onClick = onPlayWord,
            contentDescription = "Hear ${fix.inWord} said slowly"
        )
    }
}

/**
 * The sentence with the weak words marked.
 *
 * Underlined as well as coloured. Colour alone would leave a colour-blind
 * learner with a sentence and no idea which part of it to work on, and this is
 * the screen where knowing which word went wrong is the entire value.
 */
@Composable
private fun MarkedSentence(reading: ScoreReading) {
    val error = MaterialTheme.colorScheme.error
    val normal = MaterialTheme.colorScheme.onSurface

    Text(
        text = buildAnnotatedString {
            reading.reference.split(" ").filter { it.isNotBlank() }.forEachIndexed { index, word ->
                if (index > 0) append(" ")
                val isWeak = word.trim(*TRIM_CHARS).lowercase() in reading.wordsToMark
                if (isWeak) {
                    withStyle(
                        SpanStyle(
                            color = error,
                            fontWeight = FontWeight.Bold,
                            textDecoration = TextDecoration.Underline
                        )
                    ) { append(word) }
                } else {
                    withStyle(SpanStyle(color = normal)) { append(word) }
                }
            }
        },
        style = MaterialTheme.typography.bodyLarge
    )
}

@Composable
private fun ScoreBar(label: String, value: Int) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = SarthiTheme.colors.mutedText,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "$value",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
        LinearProgressIndicator(
            progress = { (value / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = MaterialTheme.colorScheme.primary,
            trackColor = SarthiTheme.colors.divider
        )
    }
}

@Composable
private fun colourFor(band: ScoreBand): Color = when (band) {
    ScoreBand.Clear -> SarthiTheme.colors.success
    ScoreBand.Understandable -> MaterialTheme.colorScheme.primary
    ScoreBand.NeedsWork -> SarthiTheme.colors.warning
    ScoreBand.HardToFollow -> MaterialTheme.colorScheme.error
}

private val TRIM_CHARS = charArrayOf('.', ',', '!', '?', ';', ':', '"', '\'', '’', '“', '”')
