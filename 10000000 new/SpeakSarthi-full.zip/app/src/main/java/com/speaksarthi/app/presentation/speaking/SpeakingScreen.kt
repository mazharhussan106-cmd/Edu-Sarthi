package com.speaksarthi.app.presentation.speaking

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.presentation.card.HighlightedSentence
import com.speaksarthi.app.presentation.card.SpeakerButton
import com.speaksarthi.app.presentation.theme.SarthiTheme

/**
 * Speaking practice: read the line, record it, hear yourself, then score it.
 *
 * The order is deliberate. Hearing your own voice back before spending any of
 * the day's scoring is where most of the learning happens, and it is free.
 */
@Composable
fun SpeakingScreen(
    onExit: () -> Unit,
    onOpenSounds: () -> Unit,
    viewModel: SpeakingViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Held as state, not a one-off read: once the learner grants the permission
    // mid-session, every later tap should go straight to recording rather than
    // back through the launcher.
    var hasMicrophonePermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val askForMicrophone = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicrophonePermission = granted
        if (granted) viewModel.startRecording() else viewModel.onPermissionDenied()
    }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when {
                state.isLoading -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) { CircularProgressIndicator() }

                state.error != null -> Message(
                    title = "Nothing to practise yet",
                    body = state.error.orEmpty(),
                    onExit = onExit
                )

                !state.microphoneAvailable -> Message(
                    title = "No microphone",
                    body = "This device has no microphone, so speaking practice cannot run. " +
                        "Everything else in the app works.",
                    onExit = onExit
                )

                else -> SpeakingContent(
                    state = state,
                    onExit = onExit,
                    onOpenSounds = onOpenSounds,
                    onRecord = {
                        if (hasMicrophonePermission) {
                            viewModel.startRecording()
                        } else {
                            askForMicrophone.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    onStop = viewModel::stopRecording,
                    onDiscard = viewModel::discardRecording,
                    onPlayBack = viewModel::playBack,
                    onStopPlayback = viewModel::stopPlayback,
                    onPlayModel = viewModel::playModel,
                    onPlayWord = viewModel::playWord,
                    onScore = viewModel::score,
                    onTryAgain = viewModel::tryAgain,
                    onNextPrompt = viewModel::nextPrompt,
                    onNextWord = viewModel::nextWord
                )
            }
        }
    }
}

@Composable
private fun SpeakingContent(
    state: SpeakingUiState,
    onExit: () -> Unit,
    onOpenSounds: () -> Unit,
    onRecord: () -> Unit,
    onStop: () -> Unit,
    onDiscard: () -> Unit,
    onPlayBack: () -> Unit,
    onStopPlayback: () -> Unit,
    onPlayModel: () -> Unit,
    onPlayWord: (String) -> Unit,
    onScore: () -> Unit,
    onTryAgain: () -> Unit,
    onNextPrompt: () -> Unit,
    onNextWord: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onExit) {
                Icon(Icons.Default.Close, contentDescription = "Leave speaking practice")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Say it out loud",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = creditLine(state),
                    style = MaterialTheme.typography.labelMedium,
                    color = if (!state.hasCredits) {
                        SarthiTheme.colors.warning
                    } else {
                        SarthiTheme.colors.mutedText
                    }
                )
            }
            IconButton(onClick = onOpenSounds) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Sounds to work on",
                    tint = SarthiTheme.colors.mutedText
                )
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            PromptCard(state = state, onPlayModel = onPlayModel)

            if (state.permissionDenied) {
                Notice(
                    text = "Speaking practice needs the microphone. You can turn it on in " +
                        "your phone's settings, under Apps — everything else keeps working " +
                        "without it.",
                    tone = SarthiTheme.colors.warning
                )
            }

            state.message?.let { message ->
                Notice(text = message, tone = SarthiTheme.colors.mutedText)
            }

            AnimatedVisibility(visible = state.reading != null) {
                state.reading?.let { reading ->
                    ScoreCard(
                        reading = reading,
                        onPlayModel = onPlayModel,
                        onPlayWord = onPlayWord
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
        }

        Controls(
            state = state,
            onRecord = onRecord,
            onStop = onStop,
            onDiscard = onDiscard,
            onPlayBack = onPlayBack,
            onStopPlayback = onStopPlayback,
            onScore = onScore,
            onTryAgain = onTryAgain,
            onNextPrompt = onNextPrompt,
            onNextWord = onNextWord
        )
    }
}

@Composable
private fun PromptCard(state: SpeakingUiState, onPlayModel: () -> Unit) {
    val word = state.word ?: return
    val prompt = state.prompt

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = word.word,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                if (word.ipa.isNotBlank()) {
                    Text(
                        text = word.ipa,
                        style = MaterialTheme.typography.bodyMedium,
                        color = SarthiTheme.colors.mutedText
                    )
                }
            }
            SpeakerButton(
                onClick = onPlayModel,
                contentDescription = "Hear the sentence said for you",
                size = 44.dp
            )
        }

        if (prompt != null) {
            HighlightedSentence(
                text = prompt.text,
                highlight = prompt.highlight.ifBlank { word.word }
            )
        } else {
            Text(
                text = "There is no sentence for this word yet.",
                style = MaterialTheme.typography.bodyMedium,
                color = SarthiTheme.colors.mutedText
            )
        }

        if (!state.scoringConfigured) {
            Text(
                text = "Scoring is not switched on in this build — you can still record " +
                    "and compare yourself against the model.",
                style = MaterialTheme.typography.labelMedium,
                color = SarthiTheme.colors.mutedText
            )
        }
    }
}

/**
 * The bottom bar, which changes shape at each stage.
 *
 * One primary action visible at a time. A learner who is nervous about speaking
 * does not need four buttons competing for the tap.
 */
@Composable
private fun Controls(
    state: SpeakingUiState,
    onRecord: () -> Unit,
    onStop: () -> Unit,
    onDiscard: () -> Unit,
    onPlayBack: () -> Unit,
    onStopPlayback: () -> Unit,
    onScore: () -> Unit,
    onTryAgain: () -> Unit,
    onNextPrompt: () -> Unit,
    onNextWord: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        when (state.stage) {
            SpeakingStage.Ready -> {
                RecordButton(isRecording = false, onClick = onRecord)
                Text(
                    text = "Tap, say the line, tap again",
                    style = MaterialTheme.typography.labelMedium,
                    color = SarthiTheme.colors.mutedText
                )
            }

            SpeakingStage.Recording -> {
                RecordButton(isRecording = true, onClick = onStop)
                LevelMeter(level = state.level)
                Text(
                    text = "${state.elapsedMillis / 1000}s of ${state.maxMillis / 1000}s",
                    style = MaterialTheme.typography.labelMedium,
                    color = SarthiTheme.colors.mutedText
                )
            }

            SpeakingStage.Recorded -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = if (state.isPlayingBack) onStopPlayback else onPlayBack,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = if (state.isPlayingBack) {
                                Icons.Default.Stop
                            } else {
                                Icons.Default.PlayArrow
                            },
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (state.isPlayingBack) " Stop" else " Hear yourself",
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                    OutlinedButton(
                        onClick = onDiscard,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Record again")
                    }
                }
                Button(
                    onClick = onScore,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    enabled = state.scoringConfigured && state.hasCredits
                ) {
                    Text(
                        text = when {
                            !state.scoringConfigured -> "Scoring not available"
                            !state.hasCredits -> "No credits left"
                            else -> "Score it"
                        }
                    )
                }
            }

            SpeakingStage.Scoring -> {
                CircularProgressIndicator()
                Text(
                    text = "Listening to what you said…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = SarthiTheme.colors.mutedText
                )
            }

            SpeakingStage.Reviewed -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = if (state.isPlayingBack) onStopPlayback else onPlayBack,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (state.isPlayingBack) "Stop" else "Hear yourself")
                    }
                    if (state.canRetryScoring) {
                        OutlinedButton(
                            onClick = onScore,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Score again")
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onTryAgain,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Say it again")
                    }
                    OutlinedButton(
                        onClick = if (state.hasMorePrompts) onNextPrompt else onNextWord,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(if (state.hasMorePrompts) "Next line" else "Next word")
                    }
                }
            }
        }
    }
}

/**
 * The record button.
 *
 * Big, round, and the only thing at the bottom of the screen when it is the
 * learner's turn. It goes red while recording, which is the one place in this
 * app where red means "working" rather than "wrong" — the stop icon carries
 * that meaning rather than the colour.
 */
@Composable
private fun RecordButton(isRecording: Boolean, onClick: () -> Unit) {
    val background = if (isRecording) {
        MaterialTheme.colorScheme.error
    } else {
        MaterialTheme.colorScheme.primary
    }

    Box(
        modifier = Modifier
            .size(84.dp)
            .clip(CircleShape)
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.Mic,
            contentDescription = if (isRecording) "Stop recording" else "Start recording",
            tint = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier.size(36.dp)
        )
    }
}

/** A bar that moves while the learner talks — proof the microphone is hearing them. */
@Composable
private fun LevelMeter(level: Float) {
    LinearProgressIndicator(
        progress = { level.coerceIn(0f, 1f) },
        modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(4.dp)),
        color = MaterialTheme.colorScheme.primary,
        trackColor = SarthiTheme.colors.divider
    )
}

@Composable
private fun Notice(text: String, tone: Color) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = tone,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(14.dp)
    )
}

@Composable
private fun Message(title: String, body: String, onExit: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )
            Text(
                text = body,
                style = MaterialTheme.typography.bodyLarge,
                color = SarthiTheme.colors.mutedText,
                textAlign = TextAlign.Center
            )
            Button(onClick = onExit) { Text("Back") }
        }
    }
}

/**
 * How many credits are left, said plainly.
 *
 * Shown always, not only when they run out. A learner who discovers a limit by
 * hitting it feels cheated; one who can see it coming spends it on the sentence
 * they care about.
 *
 * Nothing here scolds. Out of credits is a state, not a failure, and the line
 * says what still works rather than what does not.
 */
private fun creditLine(state: SpeakingUiState): String = when {
    !state.scoringConfigured -> "Recording only in this build"
    !state.creditsKnown -> "Recording and scoring"
    state.credits == 0 -> "No credits left — recording still works"
    state.credits == 1 -> "1 credit left"
    state.creditsRunningLow -> "${state.credits} credits left"
    else -> "${state.credits} credits"
}
