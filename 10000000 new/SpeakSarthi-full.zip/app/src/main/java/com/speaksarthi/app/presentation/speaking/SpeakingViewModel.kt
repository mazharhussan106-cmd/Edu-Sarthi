package com.speaksarthi.app.presentation.speaking

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.audio.RecorderState
import com.speaksarthi.app.data.audio.RecordingPlayer
import com.speaksarthi.app.data.audio.SpeechPlayer
import com.speaksarthi.app.data.audio.VoiceRecorder
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.domain.model.PracticeItem
import com.speaksarthi.app.domain.model.ScoringOutcome
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.domain.repository.LibraryRepository
import com.speaksarthi.app.domain.model.CreditBalance
import com.speaksarthi.app.domain.repository.CreditsRepository
import com.speaksarthi.app.domain.repository.SpeakingRepository
import com.speaksarthi.app.domain.usecase.pronunciation.ScoreInterpreter
import com.speaksarthi.app.domain.usecase.pronunciation.ScoreReading
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

/** Where the learner is in one attempt at saying a sentence. */
enum class SpeakingStage {
    /** Reading the line, not yet recorded. */
    Ready,

    Recording,

    /** Recorded, not yet sent. They can listen back before spending any budget. */
    Recorded,

    /** Clip is with the service. */
    Scoring,

    /** Scored, or scoring did not happen and the reason is on screen. */
    Reviewed
}

data class SpeakingUiState(
    val isLoading: Boolean = true,
    val word: Word? = null,
    val prompts: List<PracticeItem> = emptyList(),
    val promptIndex: Int = 0,
    val stage: SpeakingStage = SpeakingStage.Ready,
    val elapsedMillis: Int = 0,
    val level: Float = 0f,
    val maxMillis: Int = VoiceRecorder.DEFAULT_MAX_MILLIS,
    val recordedFile: File? = null,
    val recordedDurationMillis: Long = 0,
    /**
     * True once the clip has a row in the database pointing at its path.
     *
     * Deleting a stored file leaves a recording row referencing nothing, so
     * moving on discards only takes that were never sent.
     */
    val recordedWasStored: Boolean = false,
    val isPlayingBack: Boolean = false,
    val reading: ScoreReading? = null,
    /** Set when scoring did not produce a score, with something to say about it. */
    val message: String? = null,
    val canRetryScoring: Boolean = false,
    val scoringConfigured: Boolean = true,
    val microphoneAvailable: Boolean = true,
    val permissionDenied: Boolean = false,
    val credits: Int = 0,
    val creditsKnown: Boolean = false,
    val attemptsThisSession: Int = 0,
    val error: String? = null
) {
    val prompt: PracticeItem? get() = prompts.getOrNull(promptIndex)

    val hasMorePrompts: Boolean get() = promptIndex + 1 < prompts.size

    val hasCredits: Boolean get() = !creditsKnown || credits > 0

    /** Few enough left to be worth mentioning, without nagging. */
    val creditsRunningLow: Boolean
        get() = creditsKnown && credits in 1..CreditBalance.LOW_WATER_MARK
}

/**
 * Drives one speaking session: read the line, record it, hear it back, send it.
 *
 * Two deliberate shapes here. First, **nothing is sent automatically** — the
 * learner records, listens to themselves, and then chooses to score. Scoring is
 * the one action in this app that costs money and is rationed, so spending it
 * is always an explicit tap. Second, the recording is kept whatever happens to
 * the scoring: no network, no budget and no configuration all still leave the
 * learner with their own voice to listen to.
 */
@HiltViewModel
class SpeakingViewModel @Inject constructor(
    private val speaking: SpeakingRepository,
    private val library: LibraryRepository,
    private val recorder: VoiceRecorder,
    private val playback: RecordingPlayer,
    private val speech: SpeechPlayer,
    private val creditsRepo: CreditsRepository,
    private val preferences: AppPreferences
) : ViewModel() {

    private val _state = MutableStateFlow(SpeakingUiState())
    val state: StateFlow<SpeakingUiState> = _state.asStateFlow()

    init {
        observeRecorder()
        observePlayback()
        load()
    }

    private fun load() {
        viewModelScope.launch {
            val queue = speaking.speakingQueue(limit = 1)
            val word = queue.firstOrNull()?.word
                ?: library.randomWords(preferences.currentLevel.first(), 1).firstOrNull()

            if (word == null) {
                _state.value = _state.value.copy(
                    isLoading = false,
                    error = "There are no words in the library yet."
                )
                return@launch
            }

            _state.value = _state.value.copy(
                isLoading = false,
                word = word,
                prompts = speaking.promptsFor(word.wordId),
                promptIndex = 0,
                stage = SpeakingStage.Ready,
                scoringConfigured = speaking.scoringIsConfigured(),
                microphoneAvailable = recorder.isAvailable(),
                credits = creditsRepo.balance().credits,
                creditsKnown = creditsRepo.isConfigured()
            )
        }
    }

    /** Loads a different word to practise, keeping the session going. */
    fun nextWord() {
        discardRecording()
        _state.value = _state.value.copy(isLoading = true, reading = null, message = null)
        load()
    }

    /** Moves to another sentence for the same word. */
    fun nextPrompt() {
        val current = _state.value
        if (!current.hasMorePrompts) {
            nextWord()
            return
        }
        discardRecording()
        _state.value = _state.value.copy(
            promptIndex = current.promptIndex + 1,
            stage = SpeakingStage.Ready,
            reading = null,
            message = null,
            recordedFile = null,
            recordedDurationMillis = 0,
            recordedWasStored = false
        )
    }

    // ---- recording ---------------------------------------------------------

    private fun observeRecorder() {
        viewModelScope.launch {
            recorder.state.collect { recorderState ->
                when (recorderState) {
                    is RecorderState.Recording -> _state.value = _state.value.copy(
                        stage = SpeakingStage.Recording,
                        elapsedMillis = recorderState.elapsedMillis,
                        level = recorderState.level,
                        maxMillis = recorderState.maxMillis
                    )

                    is RecorderState.Finished -> _state.value = _state.value.copy(
                        stage = SpeakingStage.Recorded,
                        recordedFile = recorderState.file,
                        recordedDurationMillis = recorderState.durationMillis,
                        recordedWasStored = false,
                        level = 0f
                    )

                    is RecorderState.Failed -> _state.value = _state.value.copy(
                        stage = SpeakingStage.Ready,
                        level = 0f,
                        elapsedMillis = 0,
                        message = recorderState.reason,
                        canRetryScoring = false
                    )

                    RecorderState.Idle -> Unit
                }
            }
        }
    }

    private fun observePlayback() {
        viewModelScope.launch {
            playback.isPlaying.collect { playing ->
                _state.value = _state.value.copy(isPlayingBack = playing)
            }
        }
    }

    /** Called once the RECORD_AUDIO permission is actually held. */
    fun startRecording() {
        val current = _state.value
        val word = current.word ?: return
        if (current.prompt == null) return

        speech.stop()
        playback.stop()

        _state.value = current.copy(
            stage = SpeakingStage.Recording,
            message = null,
            reading = null,
            elapsedMillis = 0,
            permissionDenied = false
        )
        recorder.start(speaking.newRecordingFile(word.wordId))
    }

    fun stopRecording() = recorder.stop()

    fun onPermissionDenied() {
        _state.value = _state.value.copy(
            permissionDenied = true,
            stage = SpeakingStage.Ready,
            message = null
        )
    }

    /** Throws away the take. A clip already saved to the database is left alone. */
    fun discardRecording() {
        recorder.cancel()
        playback.stop()
        val current = _state.value
        if (!current.recordedWasStored) current.recordedFile?.delete()
        _state.value = current.copy(
            stage = SpeakingStage.Ready,
            recordedFile = null,
            recordedDurationMillis = 0,
            recordedWasStored = false,
            reading = null,
            message = null,
            elapsedMillis = 0,
            level = 0f
        )
    }

    fun playBack() {
        val file = _state.value.recordedFile ?: return
        speech.stop()
        playback.play(file)
    }

    fun stopPlayback() = playback.stop()

    /** Speaks the model sentence with the TTS voice, for comparison. */
    fun playModel() {
        val prompt = _state.value.prompt ?: return
        playback.stop()
        viewModelScope.launch {
            speech.speak(prompt.text, rate = preferences.audioSpeed.first())
        }
    }

    /** Speaks just the word that went wrong, slowly. */
    fun playWord(text: String) {
        playback.stop()
        speech.speak(text, rate = SpeechPlayer.RATE_SLOW)
    }

    // ---- scoring -----------------------------------------------------------

    /**
     * Sends the clip for scoring. Always an explicit action — see the class doc.
     */
    fun score() {
        val current = _state.value
        val file = current.recordedFile ?: return
        val prompt = current.prompt ?: return
        val word = current.word ?: return

        _state.value = current.copy(stage = SpeakingStage.Scoring, message = null)

        viewModelScope.launch {
            val outcome = speaking.scoreAndStore(
                audio = file,
                wordId = word.wordId,
                prompt = prompt,
                durationMillis = current.recordedDurationMillis
            )

            val balance = creditsRepo.balance()

            // scoreAndStore writes a row in every branch, scored or not, so the
            // file on disk is now referenced by the database.
            _state.value = _state.value.copy(recordedWasStored = true)

            _state.value = when (outcome) {
                is ScoringOutcome.Scored -> _state.value.copy(
                    stage = SpeakingStage.Reviewed,
                    reading = ScoreInterpreter.read(outcome.report),
                    message = null,
                    canRetryScoring = false,
                    credits = balance.credits,
                    attemptsThisSession = _state.value.attemptsThisSession + 1
                )

                ScoringOutcome.NotConfigured -> reviewedWith(
                    "Scoring is not switched on in this build. Your recording is saved — " +
                        "play it back against the model and listen for the difference.",
                    retryable = false,
                    credits = balance.credits
                )

                is ScoringOutcome.NoCredits -> reviewedWith(
                    "You are out of credits, so this one could not be scored. Your " +
                        "recording is saved — play it back against the model and listen " +
                        "for the difference. Finish a lesson to earn more, or top up.",
                    retryable = false,
                    credits = outcome.balance
                )

                ScoringOutcome.Offline -> reviewedWith(
                    "No connection, so this one could not be scored. It is saved — " +
                        "tap score again when you are back online.",
                    retryable = true,
                    credits = balance.credits
                )

                ScoringOutcome.NoSpeechHeard -> reviewedWith(
                    "Nothing came through clearly enough to score. Hold the phone a " +
                        "little closer and say the line again — this is almost always the room.",
                    retryable = true,
                    credits = balance.credits
                )

                is ScoringOutcome.Failed -> reviewedWith(
                    outcome.reason,
                    retryable = outcome.isRetryable,
                    credits = balance.credits
                )
            }
        }
    }

    private fun reviewedWith(message: String, retryable: Boolean, credits: Int) =
        _state.value.copy(
            stage = SpeakingStage.Reviewed,
            reading = null,
            message = message,
            canRetryScoring = retryable,
            credits = credits,
            attemptsThisSession = _state.value.attemptsThisSession + 1
        )

    /** Another go at the same sentence. The old clip is kept; a new file is made. */
    fun tryAgain() {
        playback.stop()
        _state.value = _state.value.copy(
            stage = SpeakingStage.Ready,
            recordedFile = null,
            recordedDurationMillis = 0,
            recordedWasStored = false,
            reading = null,
            message = null,
            elapsedMillis = 0,
            level = 0f
        )
    }

    override fun onCleared() {
        recorder.cancel()
        playback.release()
        speech.stop()
        super.onCleared()
    }
}
