package com.speaksarthi.app.presentation.stats

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.domain.usecase.stats.StatsDay
import com.speaksarthi.app.presentation.theme.SarthiTheme
import com.speaksarthi.app.presentation.util.OnResume
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

/**
 * Two weeks of work, and what it adds up to.
 *
 * Every day appears, including the empty ones. A chart that quietly drops the
 * days you did nothing shows an unbroken run of effort that never happened —
 * flattering, and no use at all for deciding whether the habit is holding.
 */
@Composable
fun StatsScreen(
    onBack: () -> Unit,
    viewModel: StatsViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    OnResume { viewModel.refresh() }

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = "Your progress",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Column(
                modifier = Modifier.padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (!state.summary.hasAnyActivity) {
                    Text(
                        text = "Nothing here yet. Study a few words and this fills in — " +
                            "two weeks at a time.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = SarthiTheme.colors.mutedText,
                        modifier = Modifier.padding(vertical = 24.dp)
                    )
                }

                HeadlineRow(state = state)

                Chart(days = state.summary.days)

                WeekCard(state = state)

                if (state.summary.totalRecordings > 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Stat("${state.summary.totalRecordings}", "recordings")
                        Stat(
                            value = "${(state.summary.accuracy * 100).roundToInt()}%",
                            label = "quiz accuracy"
                        )
                        Stat("${state.summary.bestDayWords}", "best day")
                    }
                }

                Text(
                    text = "Time is measured while a session is open, so it is a rough " +
                        "figure rather than a stopwatch.",
                    style = MaterialTheme.typography.labelMedium,
                    color = SarthiTheme.colors.mutedText
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun HeadlineRow(state: StatsUiState) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        Stat("${state.streakDays}", if (state.streakDays == 1) "day in a row" else "days in a row")
        Stat("${state.knownWords}", "words known")
        Stat("${state.startedWords}", "words started")
    }
}

/**
 * Fourteen bars, drawn with layout rather than a charting library.
 *
 * A dependency for fourteen rectangles is not worth the download size on a phone
 * where the APK matters, and the one thing a library would add — axes and
 * tooltips — is exactly what this does not want. Each bar carries its own
 * content description so the whole thing is readable by a screen reader, which
 * a canvas-drawn chart would not be.
 */
@Composable
private fun Chart(days: List<StatsDay>) {
    val busiest = days.maxOfOrNull { it.wordsStudied }?.coerceAtLeast(1) ?: 1

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "Last two weeks",
            style = MaterialTheme.typography.labelLarge,
            color = SarthiTheme.colors.mutedText
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            days.forEach { day ->
                Bar(
                    day = day,
                    fraction = day.wordsStudied.toFloat() / busiest,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = days.firstOrNull()?.date?.format(DAY_LABEL).orEmpty(),
                style = MaterialTheme.typography.labelSmall,
                color = SarthiTheme.colors.mutedText
            )
            Text(
                text = "Today",
                style = MaterialTheme.typography.labelSmall,
                color = SarthiTheme.colors.mutedText
            )
        }
    }
}

@Composable
private fun Bar(day: StatsDay, fraction: Float, modifier: Modifier = Modifier) {
    val colour: Color = when {
        !day.isActive -> SarthiTheme.colors.divider
        day.recordings > 0 -> SarthiTheme.colors.success
        else -> MaterialTheme.colorScheme.primary
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .semantics {
                contentDescription = "${day.date.format(DAY_LABEL)}: " +
                    if (day.isActive) {
                        "${day.wordsStudied} words" +
                            if (day.recordings > 0) ", ${day.recordings} recordings" else ""
                    } else {
                        "nothing studied"
                    }
            },
        verticalArrangement = Arrangement.Bottom,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                // A floor of 3dp, so an empty day is a visible gap rather than
                // nothing at all — the absence is part of the information.
                .height((fraction * 104f).dp.coerceAtLeast(3.dp))
                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                .background(colour)
        )
    }
}

@Composable
private fun WeekCard(state: StatsUiState) {
    val summary = state.summary
    val change = summary.weekOnWeekChange

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "This week",
            style = MaterialTheme.typography.labelLarge,
            color = SarthiTheme.colors.mutedText
        )
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = "${summary.wordsThisWeek}",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = " words, ${summary.minutesThisWeek} min, " +
                    "${summary.activeDaysThisWeek} of 7 days",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }

        Text(
            text = when {
                // A first week has nothing to be compared against, and inventing
                // a comparison is how a stats screen starts lying.
                change == null -> "Nothing to compare with yet — next week there will be."
                change > 0.05f -> "Up on last week. Whatever you changed, keep it."
                change < -0.05f -> "Down on last week. A short session still counts."
                else -> "About the same as last week, which is what a habit looks like."
            },
            style = MaterialTheme.typography.bodyMedium,
            color = SarthiTheme.colors.mutedText
        )
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.width(100.dp)
    ) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = SarthiTheme.colors.mutedText,
            textAlign = TextAlign.Center
        )
    }
}

private val DAY_LABEL: DateTimeFormatter = DateTimeFormatter.ofPattern("d MMM")
