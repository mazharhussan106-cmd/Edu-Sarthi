package com.speaksarthi.app.presentation.stats

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.local.dao.DailyStatDao
import com.speaksarthi.app.data.local.toDomain
import com.speaksarthi.app.domain.repository.StudyRepository
import com.speaksarthi.app.domain.usecase.stats.StatsCalculator
import com.speaksarthi.app.domain.usecase.stats.StatsSummary
import com.speaksarthi.app.util.Clock
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

/**
 * The placeholder shown for the instant before the first rows arrive.
 *
 * Built from a fixed date rather than today's, so constructing it does no work
 * and cannot disagree with itself between two calls.
 */
private val EMPTY_SUMMARY = StatsCalculator.summarise(
    stats = emptyList(),
    today = LocalDate.EPOCH
)

data class StatsUiState(
    val summary: StatsSummary = EMPTY_SUMMARY,
    val streakDays: Int = 0,
    val knownWords: Int = 0,
    val startedWords: Int = 0,
    val isLoading: Boolean = true
)

@HiltViewModel
class StatsViewModel @Inject constructor(
    private val dailyStatDao: DailyStatDao,
    private val study: StudyRepository,
    private val clock: Clock
) : ViewModel() {

    private val streak = MutableStateFlow(0)

    val state: StateFlow<StatsUiState> = combine(
        dailyStatDao.observeRecent(limit = HISTORY_LIMIT)
            .map { rows -> rows.map { it.toDomain() } },
        study.observeKnownCount(),
        study.observeStartedCount(),
        streak
    ) { stats, known, started, currentStreak ->
        StatsUiState(
            summary = StatsCalculator.summarise(stats = stats, today = clock.today()),
            streakDays = currentStreak,
            knownWords = known,
            startedWords = started,
            isLoading = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), StatsUiState())

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch { streak.value = study.currentStreak() }
    }

    private companion object {
        /** Enough rows to cover the window with room to spare. */
        const val HISTORY_LIMIT = 40
    }
}
