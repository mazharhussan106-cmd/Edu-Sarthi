package com.speaksarthi.app.presentation.study

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.data.audio.SpeechState
import com.speaksarthi.app.domain.model.ReviewGrade
import com.speaksarthi.app.domain.usecase.badges.Badge
import com.speaksarthi.app.presentation.card.CardPartPractice
import com.speaksarthi.app.presentation.card.CardPartRecognition
import com.speaksarthi.app.presentation.card.CardPartUnderstanding
import com.speaksarthi.app.presentation.card.PracticeReveal
import com.speaksarthi.app.presentation.theme.SarthiTheme
import kotlinx.coroutines.launch

private val PART_TITLES = listOf("Recognise", "Understand", "Practise")

/**
 * One card at a time, three swipeable parts, four grade buttons underneath.
 *
 * The grade bar is always visible, on every part. A learner who knows the word
 * from part one should not have to swipe through two more pages to say so.
 */
@Composable
fun StudyScreen(
    onExit: () -> Unit,
    /** True when this session should work the mistake list rather than the queue. */
    mistakeReview: Boolean = false,
    /** Non-empty when this session should work one lesson's words. */
    lessonId: String = "",
    viewModel: StudyViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val speechState by viewModel.speechState.collectAsStateWithLifecycle()
    val freshBadges by viewModel.freshBadges.collectAsStateWithLifecycle()

    // Set once, before the first queue is taken. Keyed on the flag so navigating
    // in from a different entry point re-runs it rather than reusing the mode.
    LaunchedEffect(mistakeReview, lessonId) {
        when {
            lessonId.isNotBlank() -> viewModel.studyLesson(lessonId)
            mistakeReview -> viewModel.reviewMistakes()
        }
    }
    val canSpeak = speechState !is SpeechState.Unavailable &&
        speechState !is SpeechState.Initialising

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (val current = state) {
                StudyUiState.Loading -> Centered { CircularProgressIndicator() }

                is StudyUiState.NothingDue -> NothingDue(
                    state = current,
                    onExit = onExit
                )

                is StudyUiState.Finished -> SessionSummary(
                    state = current,
                    freshBadges = freshBadges,
                    onAgain = viewModel::startSession,
                    onExit = onExit
                )

                is StudyUiState.Studying -> StudyingCard(
                    state = current,
                    canSpeak = canSpeak,
                    onExit = onExit,
                    onSpeak = viewModel::speak,
                    onBookmark = viewModel::toggleBookmark,
                    onGrade = viewModel::grade,
                    onSelectOption = viewModel::selectOption,
                    onReveal = viewModel::reveal,
                    onOwnSentenceChanged = viewModel::updateOwnSentence
                )
            }
        }
    }
}

@Composable
private fun StudyingCard(
    state: StudyUiState.Studying,
    canSpeak: Boolean,
    onExit: () -> Unit,
    onSpeak: (String) -> Unit,
    onBookmark: () -> Unit,
    onGrade: (ReviewGrade) -> Unit,
    onSelectOption: (Int) -> Unit,
    onReveal: (PracticeReveal) -> Unit,
    onOwnSentenceChanged: (String) -> Unit
) {
    val pagerState = rememberPagerState(pageCount = { PART_TITLES.size })
    val scope = rememberCoroutineScope()

    // A new word starts on part one. Without this the learner lands on the
    // practice page of a word they have not read yet.
    LaunchedEffect(state.word.wordId) {
        pagerState.scrollToPage(0)
    }

    Column(modifier = Modifier.fillMaxSize()) {

        // ---- header: progress through the session, exit, bookmark ----
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onExit) {
                Icon(Icons.Default.Close, contentDescription = "End this session")
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${state.positionInSession} of ${state.sessionSize}",
                    style = MaterialTheme.typography.labelMedium,
                    color = SarthiTheme.colors.mutedText
                )
                LinearProgressIndicator(
                    progress = { state.positionInSession.toFloat() / state.sessionSize },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .padding(top = 4.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = SarthiTheme.colors.divider
                )
            }
            IconButton(onClick = onBookmark) {
                Icon(
                    imageVector = if (state.isBookmarked) {
                        Icons.Default.Bookmark
                    } else {
                        Icons.Default.BookmarkBorder
                    },
                    contentDescription = if (state.isBookmarked) {
                        "Remove bookmark"
                    } else {
                        "Bookmark this word"
                    },
                    tint = if (state.isBookmarked) {
                        MaterialTheme.colorScheme.tertiary
                    } else {
                        SarthiTheme.colors.mutedText
                    }
                )
            }
        }

        TabRow(
            selectedTabIndex = pagerState.currentPage,
            containerColor = MaterialTheme.colorScheme.background,
            contentColor = MaterialTheme.colorScheme.primary
        ) {
            PART_TITLES.forEachIndexed { index, title ->
                Tab(
                    selected = pagerState.currentPage == index,
                    onClick = { scope.launch { pagerState.animateScrollToPage(index) } },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (pagerState.currentPage == index) {
                                FontWeight.Bold
                            } else {
                                FontWeight.Normal
                            }
                        )
                    }
                )
            }
        }

        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f)
        ) { page ->
            when (page) {
                0 -> CardPartRecognition(
                    word = state.word,
                    imageUrl = state.imageUrl,
                    canSpeak = canSpeak,
                    onSpeak = onSpeak
                )

                1 -> CardPartUnderstanding(
                    word = state.word,
                    examples = state.examples,
                    canSpeak = canSpeak,
                    onSpeak = onSpeak
                )

                else -> CardPartPractice(
                    word = state.word,
                    chunks = state.chunks,
                    practice = state.practice,
                    canSpeak = canSpeak,
                    onSpeak = onSpeak,
                    onSelectOption = onSelectOption,
                    onReveal = onReveal,
                    onOwnSentenceChanged = onOwnSentenceChanged
                )
            }
        }

        GradeBar(onGrade = onGrade)
    }
}

/**
 * The four grades.
 *
 * Wording matters here more than it looks. "Again" rather than "Wrong", because
 * a learner who is already embarrassed about English does not need the app
 * telling them they failed — SM-2 treats it the same either way.
 */
@Composable
private fun GradeBar(onGrade: (ReviewGrade) -> Unit) {
    val grades = listOf(
        ReviewGrade.Again to ("Again" to MaterialTheme.colorScheme.error),
        ReviewGrade.Hard to ("Hard" to SarthiTheme.colors.warning),
        ReviewGrade.Good to ("Good" to MaterialTheme.colorScheme.primary),
        ReviewGrade.Easy to ("Easy" to SarthiTheme.colors.success)
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        grades.forEach { (grade, labelAndColour) ->
            val (label, colour) = labelAndColour
            GradeButton(
                label = label,
                colour = colour,
                modifier = Modifier.weight(1f),
                onClick = { onGrade(grade) }
            )
        }
    }
}

@Composable
private fun GradeButton(
    label: String,
    colour: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = colour
        )
    }
}

@Composable
private fun NothingDue(state: StudyUiState.NothingDue, onExit: () -> Unit) {
    Centered {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Text(
                text = if (state.isMistakeReview) {
                    "No mistakes to review"
                } else {
                    "Nothing due right now"
                },
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )
            Text(
                text = when {
                    // An empty mistake list is good news and should read like it.
                    state.isMistakeReview ->
                        "Nothing you have been getting wrong often enough to be worth " +
                            "drilling. That is the point of this list being empty."

                    state.knownCount > 0 ->
                        "You know ${state.knownCount} words well enough that they are not " +
                            "scheduled today. Come back tomorrow and the next batch will be waiting."

                    else -> "Come back tomorrow and the next batch will be waiting."
                },
                style = MaterialTheme.typography.bodyLarge,
                color = SarthiTheme.colors.mutedText,
                textAlign = TextAlign.Center
            )
            Button(onClick = onExit) { Text("Back") }
        }
    }
}

@Composable
private fun SessionSummary(
    state: StudyUiState.Finished,
    freshBadges: List<Badge>,
    onAgain: () -> Unit,
    onExit: () -> Unit
) {
    val minutes = state.secondsSpent / 60
    val seconds = state.secondsSpent % 60

    Centered {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Text(
                text = when {
                    state.lessonTitle.isNotBlank() -> "${state.lessonTitle} done"
                    state.isMistakeReview -> "Mistakes reviewed"
                    else -> "Session done"
                },
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )

            Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                SummaryStat("${state.reviewed}", "words")
                SummaryStat(
                    value = if (minutes > 0) "${minutes}m ${seconds}s" else "${seconds}s",
                    label = "spent"
                )
                SummaryStat("${state.correct}", "quiz right")
            }

            Text(
                text = "Each word comes back when you are about to forget it, " +
                    "not on a fixed timetable.",
                style = MaterialTheme.typography.bodyMedium,
                color = SarthiTheme.colors.mutedText,
                textAlign = TextAlign.Center
            )

            // Badges are announced here and nowhere else — mid-card would be an
            // interruption, and a learner who has just finished is the one person
            // in the app with a spare moment.
            freshBadges.forEach { badge -> BadgeAward(badge = badge) }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(onClick = onAgain, modifier = Modifier.fillMaxWidth()) {
                    Text("Another round")
                }
                OutlinedButton(onClick = onExit, modifier = Modifier.fillMaxWidth()) {
                    Text("Done for now")
                }
            }
        }
    }
}

/** A badge earned during the session just finished. */
@Composable
private fun BadgeAward(badge: Badge) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SarthiTheme.colors.successContainer)
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = badge.emoji, style = MaterialTheme.typography.headlineMedium)
        Column {
            Text(
                text = badge.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = SarthiTheme.colors.success
            )
            Text(
                text = badge.earnedMessage,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun SummaryStat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = SarthiTheme.colors.mutedText
        )
    }
}

@Composable
private fun Centered(content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(0.dp)),
        contentAlignment = Alignment.Center
    ) { content() }
}
