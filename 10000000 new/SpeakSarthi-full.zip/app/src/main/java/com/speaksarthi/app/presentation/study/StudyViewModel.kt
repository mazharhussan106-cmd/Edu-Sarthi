package com.speaksarthi.app.presentation.study

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.audio.SpeechPlayer
import com.speaksarthi.app.data.audio.SpeechState
import com.speaksarthi.app.data.illustration.IllustrationLoader
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.domain.model.Chunk
import com.speaksarthi.app.domain.model.PracticeItem
import com.speaksarthi.app.domain.model.ReviewGrade
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.domain.usecase.badges.Badge
import com.speaksarthi.app.domain.usecase.lessons.LessonPlanner
import com.speaksarthi.app.domain.model.WordWithProgress
import com.speaksarthi.app.domain.repository.BadgeRepository
import com.speaksarthi.app.domain.repository.LibraryRepository
import com.speaksarthi.app.domain.repository.StudyRepository
import com.speaksarthi.app.presentation.card.PracticeReveal
import com.speaksarthi.app.presentation.card.PracticeZoneState
import com.speaksarthi.app.presentation.theme.ThemeMode
import com.speaksarthi.app.util.Clock
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** What the study screen is showing right now. */
sealed interface StudyUiState {
    data object Loading : StudyUiState

    /** Nothing is due. Not a failure — it is the normal end of a day's work. */
    data class NothingDue(
        val knownCount: Int,
        val isMistakeReview: Boolean = false
    ) : StudyUiState

    data class Studying(
        val word: Word,
        val chunks: List<Chunk>,
        val examples: List<PracticeItem>,
        val practice: PracticeZoneState,
        val imageUrl: String?,
        val positionInSession: Int,
        val sessionSize: Int,
        val isBookmarked: Boolean
    ) : StudyUiState

    data class Finished(
        val reviewed: Int,
        val correct: Int,
        val secondsSpent: Int,
        val isMistakeReview: Boolean = false,
        /** Non-empty when this was a lesson, so the summary can name it. */
        val lessonTitle: String = ""
    ) : StudyUiState
}

/**
 * Drives one study session.
 *
 * The queue is taken once when the session starts rather than re-queried after
 * each grade. A word graded "Again" is scheduled a day out, so re-querying would
 * drop it from the session the moment the learner said they did not know it —
 * exactly the word they should see again before they stop.
 */
@HiltViewModel
class StudyViewModel @Inject constructor(
    private val library: LibraryRepository,
    private val study: StudyRepository,
    private val badges: BadgeRepository,
    private val illustrations: IllustrationLoader,
    private val speech: SpeechPlayer,
    private val preferences: AppPreferences,
    private val clock: Clock
) : ViewModel() {

    private val _state = MutableStateFlow<StudyUiState>(StudyUiState.Loading)
    val state: StateFlow<StudyUiState> = _state.asStateFlow()

    /** Badges earned during this session, announced once at the end. */
    private val _freshBadges = MutableStateFlow<List<Badge>>(emptyList())
    val freshBadges: StateFlow<List<Badge>> = _freshBadges.asStateFlow()

    /**
     * True when this session is reviewing mistakes rather than working the
     * normal queue. Set by the screen before the session starts.
     */
    private var mistakeReview = false

    /** Non-empty when this session is working one lesson's words. */
    private var lessonWordIds: List<String> = emptyList()
    private var currentLessonId: String = ""
    private var lessonTitle: String = ""

    val speechState: StateFlow<SpeechState> = speech.state

    private var queue: List<WordWithProgress> = emptyList()
    private var index = 0
    private var reviewed = 0
    private var correct = 0
    private var startedAt = 0L

    /** Saving the learner's sentence is debounced to one write per word, not per keystroke. */
    private var sentenceSaveJob: Job? = null

    val themeMode: StateFlow<ThemeMode> = preferences.themeMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ThemeMode.System)

    init {
        startSession()
    }

    /**
     * Switches this session to mistake review and restarts it.
     *
     * A mode rather than a separate screen: the card, the grading and the
     * scheduling are identical, and only the queue differs. Two near-identical
     * screens would drift apart within a month.
     */
    fun reviewMistakes() {
        mistakeReview = true
        lessonWordIds = emptyList()
        currentLessonId = ""
        startSession()
    }

    /**
     * Restricts this session to one lesson's words.
     *
     * Another mode rather than another screen, for the same reason mistake review
     * is: the card, the grading and the scheduling are identical and only the
     * queue differs.
     *
     * Takes the lesson id rather than a word list because a list of twenty ids is
     * not something to push through a navigation route — the plan is derived from
     * the library, so it can be derived again here.
     */
    fun studyLesson(lessonId: String) {
        if (lessonId.isBlank() || lessonId == currentLessonId) return
        currentLessonId = lessonId

        viewModelScope.launch {
            val lesson = LessonPlanner.plan(library.observeWords().first())
                .firstOrNull { it.id == lessonId }

            if (lesson == null) {
                // A lesson id that no longer resolves — content changed under a
                // saved back stack entry. Falling back to the normal queue is
                // better than an empty screen with no explanation.
                currentLessonId = ""
                return@launch
            }

            lessonWordIds = lesson.wordIds
            mistakeReview = false
            lessonTitle = lesson.title
            startSession()
        }
    }

    fun startSession() {
        _state.value = StudyUiState.Loading
        viewModelScope.launch {
            queue = when {
                lessonWordIds.isNotEmpty() ->
                    study.lessonQueue(lessonWordIds, limit = SESSION_SIZE)

                mistakeReview -> study.mistakeQueue(limit = SESSION_SIZE)

                else -> study.dueQueue(limit = SESSION_SIZE)
            }
            index = 0
            reviewed = 0
            correct = 0
            startedAt = clock.nowMillis()

            if (queue.isEmpty()) {
                _state.value = StudyUiState.NothingDue(
                    knownCount = study.observeKnownCount().first(),
                    isMistakeReview = mistakeReview
                )
                return@launch
            }
            showCurrent()
        }
    }

    private suspend fun showCurrent() {
        val entry = queue.getOrNull(index) ?: run { finish(); return }
        val word = entry.word

        val chunks = library.chunks(word.wordId)
        val examples = library.practiceItems(word.wordId)
        val exercise = library.exercise(word.wordId)
        val previousSentence = study.ownSentence(word.wordId)
        val imageUrl = illustrations.urlFor(word.illustration)

        _state.value = StudyUiState.Studying(
            word = word,
            chunks = chunks,
            examples = examples,
            practice = PracticeZoneState(
                exercise = exercise,
                ownSentence = previousSentence,
                previousOwnSentence = previousSentence
            ),
            imageUrl = imageUrl,
            positionInSession = index + 1,
            sessionSize = queue.size,
            isBookmarked = entry.progress.isBookmarked
        )

        prefetchUpcoming()
    }

    /**
     * Warms the next few cards' artwork while the learner reads this one. Without
     * it, on-demand images would mean a visible wait on every single card.
     */
    private fun prefetchUpcoming() {
        val upcoming = queue
            .drop(index + 1)
            .take(IllustrationLoader.PREFETCH_LIMIT)
            .map { it.word.illustration }
        if (upcoming.isEmpty()) return

        viewModelScope.launch { illustrations.prefetch(upcoming) }
    }

    fun grade(grade: ReviewGrade) {
        val current = _state.value as? StudyUiState.Studying ?: return
        viewModelScope.launch {
            flushSentence(current)
            study.grade(
                wordId = current.word.wordId,
                grade = grade,
                chunksSeen = current.chunks.size,
                wasMistakeReview = mistakeReview
            )
            reviewed++
            index++
            showCurrent()
        }
    }

    fun toggleBookmark() {
        val current = _state.value as? StudyUiState.Studying ?: return
        val next = !current.isBookmarked
        _state.value = current.copy(isBookmarked = next)
        viewModelScope.launch { study.setBookmarked(current.word.wordId, next) }
    }

    fun speak(text: String) {
        viewModelScope.launch {
            // Read fresh each time so a speed change takes effect on the very
            // next tap rather than at the next app launch.
            speech.speak(text, rate = preferences.audioSpeed.first())
        }
    }

    fun selectOption(optionIndex: Int) {
        val current = _state.value as? StudyUiState.Studying ?: return
        val exercise = current.practice.exercise ?: return
        if (current.practice.hasAnswered) return

        val wasCorrect = optionIndex == exercise.mcq.answerIndex
        if (wasCorrect) correct++

        _state.value = current.copy(
            practice = current.practice.copy(selectedOption = optionIndex)
        )
        viewModelScope.launch {
            study.recordQuizAnswer(current.word.wordId, optionIndex, wasCorrect)
        }
    }

    fun reveal(which: PracticeReveal) {
        val current = _state.value as? StudyUiState.Studying ?: return
        _state.value = current.copy(
            practice = current.practice.copy(revealed = current.practice.revealed + which)
        )
    }

    fun updateOwnSentence(text: String) {
        val current = _state.value as? StudyUiState.Studying ?: return
        _state.value = current.copy(practice = current.practice.copy(ownSentence = text))

        // Written as the learner types, saved once they pause — a row write per
        // keystroke is pointless work on a cheap phone.
        sentenceSaveJob?.cancel()
        sentenceSaveJob = viewModelScope.launch {
            delay(SENTENCE_SAVE_DELAY_MS)
            study.saveOwnSentence(current.word.wordId, text)
        }
    }

    /** Commits an in-flight sentence before the card goes away. */
    private suspend fun flushSentence(current: StudyUiState.Studying) {
        sentenceSaveJob?.cancel()
        sentenceSaveJob = null
        if (current.practice.ownSentence != current.practice.previousOwnSentence) {
            study.saveOwnSentence(current.word.wordId, current.practice.ownSentence)
        }
    }

    private fun finish() {
        val seconds = ((clock.nowMillis() - startedAt) / 1000).toInt().coerceAtLeast(0)
        _state.value = StudyUiState.Finished(
            reviewed = reviewed,
            correct = correct,
            secondsSpent = seconds,
            isMistakeReview = mistakeReview,
            lessonTitle = lessonTitle
        )
        // Awarded at the end of a session rather than mid-card: a badge popping
        // up while someone is mid-sentence is an interruption, not a reward.
        viewModelScope.launch { _freshBadges.value = badges.award() }
    }

    override fun onCleared() {
        speech.stop()
        super.onCleared()
    }

    companion object {
        /**
         * Words per session. Twenty is roughly ten minutes of honest work —
         * long enough to be worth opening the app, short enough to finish.
         */
        const val SESSION_SIZE = 20

        private const val SENTENCE_SAVE_DELAY_MS = 800L
    }
}
