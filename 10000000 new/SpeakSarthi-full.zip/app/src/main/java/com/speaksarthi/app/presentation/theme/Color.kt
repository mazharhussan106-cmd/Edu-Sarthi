package com.speaksarthi.app.presentation.theme

import androidx.compose.ui.graphics.Color

/**
 * Speak Sarthi's palette.
 *
 * Deliberately not WordMaster's purple — this is a separate brand. The register
 * is professional and calm rather than playful, because the target learner is
 * anxious about speaking and a childish interface undercuts the promise that
 * this is serious practice.
 *
 * Deep teal carries the interface; ochre is the single saturated accent and is
 * spent on one thing per screen. Neutrals are tinted toward the teal so nothing
 * reads as default system grey.
 */

// ---- Brand ----------------------------------------------------------------
val Teal10 = Color(0xFFE6F0EE)
val Teal20 = Color(0xFFC2DCD8)
val Teal40 = Color(0xFF5FA79E)
val Teal60 = Color(0xFF2A9D8F)
val Teal80 = Color(0xFF146A62)
val Teal90 = Color(0xFF0E4F49)
val Teal100 = Color(0xFF0A3A35)

val Ink = Color(0xFF0E2A33)

// ---- Accent ---------------------------------------------------------------
val Ochre40 = Color(0xFFF2C489)
val Ochre60 = Color(0xFFEFA43F)
val Ochre80 = Color(0xFFD98324)
val Ochre90 = Color(0xFFA85F13)

// ---- Semantic -------------------------------------------------------------
/** A correct answer, a clean pronunciation score, a completed goal. */
val SuccessGreen = Color(0xFF1E8E5A)
val SuccessGreenSoft = Color(0xFFE2F3EA)

/** A wrong answer or a sound that needs work. Never the only signal — pair it
 *  with an underline or an icon, per the colour-blind requirement. */
val ErrorRust = Color(0xFFC0442F)
val ErrorRustSoft = Color(0xFFFAE8E4)

/** Attention without failure: a streak about to lapse, a nearly-spent speech budget. */
val WarnAmber = Color(0xFFD98324)

// ---- CEFR level colours ---------------------------------------------------
// Content is organised by difficulty level, so the level needs a consistent
// colour everywhere it appears.
val LevelA1 = Color(0xFF1E8E5A)
val LevelA2 = Color(0xFF2A7FB8)
val LevelB1 = Color(0xFFD98324)
val LevelB2 = Color(0xFFC0442F)

// ---- Neutrals (teal-biased) ----------------------------------------------
val Neutral05 = Color(0xFFF7F9F8)
val Neutral10 = Color(0xFFF2F5F4)
val Neutral20 = Color(0xFFE7EDEB)
val Neutral40 = Color(0xFFCFDAD7)
val Neutral60 = Color(0xFF849699)
val Neutral80 = Color(0xFF5C6B6E)
val Neutral95 = Color(0xFF16323A)

// ---- Dark surfaces --------------------------------------------------------
val DarkBase = Color(0xFF0C1A1E)
val DarkSurface = Color(0xFF122529)
val DarkSurfaceHigh = Color(0xFF172F34)
val DarkLine = Color(0xFF24444B)
val DarkOn = Color(0xFFE8EFED)

// ---- Eye-protection surfaces ---------------------------------------------
// A warm, low-blue variant for night study. Not a dimmed dark theme — it is a
// light theme with the blue channel pulled down and the ground warmed, which is
// what reduces glare when someone is practising at 11pm.
val WarmBase = Color(0xFFF6EFE2)
val WarmSurface = Color(0xFFFBF6EC)
val WarmSurfaceHigh = Color(0xFFF1E7D6)
val WarmLine = Color(0xFFDDCFB8)
val WarmOn = Color(0xFF2E2A21)
val WarmTeal = Color(0xFF1C6B60)
val WarmOchre = Color(0xFFB8701C)
