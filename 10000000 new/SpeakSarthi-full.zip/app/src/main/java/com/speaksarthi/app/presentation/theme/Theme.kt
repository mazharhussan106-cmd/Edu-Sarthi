package com.speaksarthi.app.presentation.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/**
 * Three display modes, not two.
 *
 * [ThemeMode.EyeProtection] is a product requirement, not a variant of dark
 * mode: it is a light scheme with the blue channel pulled down and a warmed
 * ground, for a learner practising late at night.
 */
enum class ThemeMode {
    System,
    Light,
    Dark,
    EyeProtection;

    /** The next mode in the cycle, so all four are reachable from one button. */
    fun next(): ThemeMode = when (this) {
        System -> Light
        Light -> Dark
        Dark -> EyeProtection
        EyeProtection -> System
    }

    companion object {
        fun fromStoredValue(value: String?): ThemeMode =
            entries.firstOrNull { it.name == value } ?: System
    }
}

/**
 * Colours Material 3's own scheme has no slot for but the app needs everywhere:
 * the CEFR level colours, the success/warning pair, and the divider tone.
 * Exposed through a CompositionLocal so screens never hardcode a hex value that
 * only works in one mode.
 */
data class SarthiColors(
    val success: Color,
    val successContainer: Color,
    val warning: Color,
    val divider: Color,
    val levelA1: Color,
    val levelA2: Color,
    val levelB1: Color,
    val levelB2: Color,
    val mutedText: Color
) {
    /** Colour for a CEFR band, falling back to A1's colour for unknown values. */
    fun forLevel(level: String): Color = when (level.uppercase()) {
        "A1" -> levelA1
        "A2" -> levelA2
        "B1" -> levelB1
        "B2", "C1", "C2" -> levelB2
        else -> mutedText
    }
}

val LocalSarthiColors = staticCompositionLocalOf {
    SarthiColors(
        success = SuccessGreen,
        successContainer = SuccessGreenSoft,
        warning = WarnAmber,
        divider = Neutral40,
        levelA1 = LevelA1,
        levelA2 = LevelA2,
        levelB1 = LevelB1,
        levelB2 = LevelB2,
        mutedText = Neutral80
    )
}

private val LightScheme = lightColorScheme(
    primary = Teal80,
    onPrimary = Color.White,
    primaryContainer = Teal10,
    onPrimaryContainer = Teal100,
    secondary = Teal60,
    onSecondary = Color.White,
    secondaryContainer = Teal20,
    onSecondaryContainer = Teal100,
    tertiary = Ochre80,
    onTertiary = Color.White,
    tertiaryContainer = Ochre40,
    onTertiaryContainer = Ochre90,
    background = Neutral10,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Neutral20,
    onSurfaceVariant = Neutral80,
    outline = Neutral40,
    outlineVariant = Neutral20,
    error = ErrorRust,
    onError = Color.White,
    errorContainer = ErrorRustSoft,
    onErrorContainer = ErrorRust
)

private val DarkScheme = darkColorScheme(
    primary = Teal60,
    onPrimary = Teal100,
    primaryContainer = Teal90,
    onPrimaryContainer = Teal10,
    secondary = Teal40,
    onSecondary = Teal100,
    secondaryContainer = Teal90,
    onSecondaryContainer = Teal10,
    tertiary = Ochre60,
    onTertiary = Color(0xFF3A2405),
    tertiaryContainer = Ochre90,
    onTertiaryContainer = Ochre40,
    background = DarkBase,
    onBackground = DarkOn,
    surface = DarkSurface,
    onSurface = DarkOn,
    surfaceVariant = DarkSurfaceHigh,
    onSurfaceVariant = Color(0xFFA2B5B8),
    outline = DarkLine,
    outlineVariant = DarkSurfaceHigh,
    error = Color(0xFFE87C67),
    onError = Color(0xFF3A0F08),
    errorContainer = Color(0xFF5A2318),
    onErrorContainer = Color(0xFFFFD9D1)
)

private val EyeProtectionScheme = lightColorScheme(
    primary = WarmTeal,
    onPrimary = Color(0xFFFBF6EC),
    primaryContainer = Color(0xFFE3EDE5),
    onPrimaryContainer = Color(0xFF123F38),
    secondary = Color(0xFF3F7F74),
    onSecondary = Color(0xFFFBF6EC),
    secondaryContainer = Color(0xFFE8E2D2),
    onSecondaryContainer = Color(0xFF123F38),
    tertiary = WarmOchre,
    onTertiary = Color(0xFFFBF6EC),
    tertiaryContainer = Color(0xFFF0DCBC),
    onTertiaryContainer = Color(0xFF6B3F08),
    background = WarmBase,
    onBackground = WarmOn,
    surface = WarmSurface,
    onSurface = WarmOn,
    surfaceVariant = WarmSurfaceHigh,
    onSurfaceVariant = Color(0xFF6B6153),
    outline = WarmLine,
    outlineVariant = WarmSurfaceHigh,
    error = Color(0xFFA83A26),
    onError = Color(0xFFFBF6EC),
    errorContainer = Color(0xFFF2DED8),
    onErrorContainer = Color(0xFF6B2115)
)

private val LightExtras = SarthiColors(
    success = SuccessGreen,
    successContainer = SuccessGreenSoft,
    warning = WarnAmber,
    divider = Neutral40,
    levelA1 = LevelA1,
    levelA2 = LevelA2,
    levelB1 = LevelB1,
    levelB2 = LevelB2,
    mutedText = Neutral80
)

private val DarkExtras = SarthiColors(
    success = Color(0xFF47C285),
    successContainer = Color(0xFF14412C),
    warning = Ochre60,
    divider = DarkLine,
    levelA1 = Color(0xFF47C285),
    levelA2 = Color(0xFF5CA8DB),
    levelB1 = Ochre60,
    levelB2 = Color(0xFFE87C67),
    mutedText = Color(0xFF7A9094)
)

private val WarmExtras = SarthiColors(
    success = Color(0xFF2F7A50),
    successContainer = Color(0xFFE0EDDF),
    warning = WarmOchre,
    divider = WarmLine,
    levelA1 = Color(0xFF2F7A50),
    levelA2 = Color(0xFF356E93),
    levelB1 = WarmOchre,
    levelB2 = Color(0xFFA83A26),
    mutedText = Color(0xFF6B6153)
)

@Composable
fun SpeakSarthiTheme(
    themeMode: ThemeMode = ThemeMode.System,
    content: @Composable () -> Unit
) {
    val dark = when (themeMode) {
        ThemeMode.System -> isSystemInDarkTheme()
        ThemeMode.Dark -> true
        ThemeMode.Light, ThemeMode.EyeProtection -> false
    }

    val scheme = when {
        themeMode == ThemeMode.EyeProtection -> EyeProtectionScheme
        dark -> DarkScheme
        else -> LightScheme
    }

    val extras = when {
        themeMode == ThemeMode.EyeProtection -> WarmExtras
        dark -> DarkExtras
        else -> LightExtras
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = scheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
        }
    }

    CompositionLocalProvider(LocalSarthiColors provides extras) {
        MaterialTheme(
            colorScheme = scheme,
            typography = SarthiTypography,
            content = content
        )
    }
}

/** Shorthand so screens can write `SarthiTheme.colors.success`. */
object SarthiTheme {
    val colors: SarthiColors
        @Composable get() = LocalSarthiColors.current
}
