package com.speaksarthi.app.presentation.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.speaksarthi.app.presentation.theme.SarthiTheme

/**
 * Phase 1's verification surface: seed the library, then show exactly what is in
 * it. Not a product screen — it is how the build is checked by running it.
 */
@Composable
fun LibraryStatusScreen(
    state: LibraryStatus,
    onRetry: () -> Unit,
    onCycleTheme: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
            when (state) {
                LibraryStatus.Loading -> LoadingState(Modifier.padding(padding))
                is LibraryStatus.Failed -> FailedState(state, onRetry, Modifier.padding(padding))
                is LibraryStatus.Ready -> ReadyState(state, onCycleTheme, Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun LoadingState(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(40.dp)
        )
        Text(
            text = "Preparing your 1,000 words…",
            style = MaterialTheme.typography.bodyLarge,
            color = SarthiTheme.colors.mutedText,
            modifier = Modifier.padding(top = 20.dp)
        )
    }
}

@Composable
private fun FailedState(
    state: LibraryStatus.Failed,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "The word list did not load",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.error
        )
        Text(
            text = "Nothing was written, so retrying is safe.",
            style = MaterialTheme.typography.bodyLarge,
            color = SarthiTheme.colors.mutedText,
            modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
        )
        state.warnings.take(8).forEach { warning ->
            Text(
                text = warning,
                style = MaterialTheme.typography.bodyMedium,
                color = SarthiTheme.colors.mutedText,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }
        Button(onClick = onRetry, modifier = Modifier.padding(top = 20.dp)) {
            Text("Try again")
        }
    }
}

@Composable
private fun ReadyState(
    state: LibraryStatus.Ready,
    onCycleTheme: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = "Library ready",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = if (state.wasImportedThisLaunch) {
                    "Imported on this launch"
                } else {
                    "Already up to date — nothing re-imported"
                },
                style = MaterialTheme.typography.bodyLarge,
                color = SarthiTheme.colors.mutedText,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        CountCard("Words", state.words, "the flashcard library")
        CountCard("Chunks", state.chunks, "collocations, phrasal verbs and patterns")
        CountCard("Speaking prompts", state.practiceItems, "sentences to read aloud")
        CountCard("Exercise sets", state.questions, "five practice exercises per word")
        IllustrationCard(
            configured = state.illustrationsConfigured,
            cacheBytes = state.illustrationCacheBytes
        )

        BreakdownCard("By level", state.byLevel)
        BreakdownCard("By chunk type", state.byChunkType)

        if (state.warnings.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "${state.warnings.size} row(s) skipped",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onErrorContainer
                    )
                    state.warnings.take(10).forEach { warning ->
                        Text(
                            text = warning,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        }

        OutlinedButton(
            onClick = onCycleTheme,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Switch theme (light / dark / eye protection)")
        }

        Text(
            text = "Phase 1 of the build. Flashcards, study sessions and " +
                "pronunciation scoring come next.",
            style = MaterialTheme.typography.bodyMedium,
            color = SarthiTheme.colors.mutedText
        )
    }
}

@Composable
private fun CountCard(label: String, value: Int, caption: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .semantics { contentDescription = "$label: $value, $caption" },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = caption,
                    style = MaterialTheme.typography.bodyMedium,
                    color = SarthiTheme.colors.mutedText
                )
            }
            Text(
                text = "%,d".format(value),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

/**
 * Illustrations are fetched on demand, so there is no count to report until a
 * host is configured — only how much artwork this device has pulled so far.
 */
@Composable
private fun IllustrationCard(configured: Boolean, cacheBytes: Long) {
    val caption = when {
        !configured -> "on demand — no image host configured yet"
        cacheBytes == 0L -> "on demand — nothing cached yet"
        else -> "cached on this device"
    }
    val value = when {
        !configured -> "—"
        cacheBytes < 1024 * 1024 -> "%d KB".format(cacheBytes / 1024)
        else -> "%.1f MB".format(cacheBytes / (1024.0 * 1024.0))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .semantics { contentDescription = "Illustrations: $value, $caption" },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Illustrations",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = caption,
                    style = MaterialTheme.typography.bodyMedium,
                    color = SarthiTheme.colors.mutedText
                )
            }
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = if (configured) {
                    MaterialTheme.colorScheme.primary
                } else {
                    SarthiTheme.colors.mutedText
                }
            )
        }
    }
}

@Composable
private fun BreakdownCard(title: String, rows: List<Pair<String, Int>>) {
    if (rows.isEmpty()) return

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            rows.forEachIndexed { index, (label, count) ->
                if (index > 0) {
                    HorizontalDivider(
                        color = SarthiTheme.colors.divider,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = if (index == 0) 12.dp else 0.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodyLarge,
                        color = if (title == "By level") {
                            SarthiTheme.colors.forLevel(label)
                        } else {
                            MaterialTheme.colorScheme.onSurface
                        }
                    )
                    Text(
                        text = "%,d".format(count),
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}
