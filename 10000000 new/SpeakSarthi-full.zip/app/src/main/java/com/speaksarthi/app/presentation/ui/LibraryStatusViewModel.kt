package com.speaksarthi.app.presentation.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.illustration.IllustrationLoader
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.data.seed.ContentSeeder
import com.speaksarthi.app.domain.repository.LibraryRepository
import com.speaksarthi.app.presentation.theme.ThemeMode
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * State of the library-status screen.
 *
 * This screen exists so phase 1 is verifiable by *running* the app rather than
 * by reading the code: it seeds the database on first launch and then reports
 * exactly what landed. When the flashcard UI arrives in phase 2 it replaces this
 * as the start destination, and this moves to a developer-settings entry.
 */
sealed interface LibraryStatus {
    data object Loading : LibraryStatus

    data class Ready(
        val words: Int,
        val chunks: Int,
        val practiceItems: Int,
        val questions: Int,
        /** Bytes of artwork cached on this device. Zero until a host is configured and cards are seen. */
        val illustrationCacheBytes: Long,
        /** False until an image host is configured, which is the state today. */
        val illustrationsConfigured: Boolean,
        val byLevel: List<Pair<String, Int>>,
        val byChunkType: List<Pair<String, Int>>,
        val wasImportedThisLaunch: Boolean,
        val warnings: List<String>
    ) : LibraryStatus

    data class Failed(val warnings: List<String>) : LibraryStatus
}

@HiltViewModel
class LibraryStatusViewModel @Inject constructor(
    private val seeder: ContentSeeder,
    private val library: LibraryRepository,
    private val illustrations: IllustrationLoader,
    private val preferences: AppPreferences
) : ViewModel() {

    private val _state = MutableStateFlow<LibraryStatus>(LibraryStatus.Loading)
    val state: StateFlow<LibraryStatus> = _state.asStateFlow()

    val themeMode: StateFlow<ThemeMode> = preferences.themeMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ThemeMode.System)

    init {
        load()
    }

    fun retry() = load()

    private fun load() {
        _state.value = LibraryStatus.Loading
        viewModelScope.launch {
            val result = seeder.seedIfNeeded()

            val warnings = when (result) {
                is ContentSeeder.Result.Imported -> result.report.warnings
                is ContentSeeder.Result.Failed -> result.report.warnings
                is ContentSeeder.Result.AlreadyCurrent -> emptyList()
            }

            if (result is ContentSeeder.Result.Failed) {
                _state.value = LibraryStatus.Failed(warnings)
                return@launch
            }

            _state.value = LibraryStatus.Ready(
                words = library.wordCount(),
                chunks = library.chunkCount(),
                practiceItems = library.practiceItemCount(),
                questions = library.exerciseCount(),
                illustrationCacheBytes = illustrations.cacheBytes(),
                illustrationsConfigured = illustrations.urlFor("probe.webp") != null,
                byLevel = library.countsByLevel().toList().sortedBy { it.first },
                byChunkType = library.countsByChunkType().toList().sortedByDescending { it.second },
                wasImportedThisLaunch = result is ContentSeeder.Result.Imported,
                warnings = warnings
            )
        }
    }

    /** Cycles System → Light → Dark → Eye protection, so all four are reachable without a settings screen yet. */
    fun cycleThemeMode() {
        viewModelScope.launch {
            preferences.setThemeMode(preferences.themeMode.first().next())
        }
    }
}
