package com.speaksarthi.app.presentation.util

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

/**
 * Runs [block] every time the screen comes back to the foreground.
 *
 * Needed because some of the app's numbers are computed against a "now" fixed
 * when the query was created — the due count above all. A phone left on the home
 * screen overnight must not still be showing yesterday's.
 *
 * [rememberUpdatedState] keeps the observer pointing at the newest lambda, so a
 * recomposition mid-lifecycle cannot leave a stale one registered.
 */
@Composable
fun OnResume(block: () -> Unit) {
    val owner = LocalLifecycleOwner.current
    val current by rememberUpdatedState(block)

    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) current()
        }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
}
