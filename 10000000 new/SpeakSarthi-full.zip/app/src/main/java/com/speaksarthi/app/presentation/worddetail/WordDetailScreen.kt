package com.speaksarthi.app.presentation.worddetail

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.speaksarthi.app.data.audio.SpeechState
import com.speaksarthi.app.presentation.card.CardPartPractice
import com.speaksarthi.app.presentation.card.CardPartRecognition
import com.speaksarthi.app.presentation.card.CardPartUnderstanding
import com.speaksarthi.app.presentation.theme.SarthiTheme
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

private val PART_TITLES = listOf("Recognise", "Understand", "Practise")

/**
 * One word, on its own, with no grade buttons.
 *
 * Reuses the study card's three parts exactly — a second, slightly different
 * rendering of the same word is how two screens drift apart and how a content
 * fix ends up applied in one place only.
 */
@Composable
fun WordDetailScreen(
    onBack: () -> Unit,
    viewModel: WordDetailViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val speechState by viewModel.speechState.collectAsStateWithLifecycle()
    val canSpeak = speechState !is SpeechState.Unavailable &&
        speechState !is SpeechState.Initialising

    val pagerState = rememberPagerState(pageCount = { PART_TITLES.size })
    val scope = rememberCoroutineScope()

    Scaffold(containerColor = MaterialTheme.colorScheme.background) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when {
                state.isLoading -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) { CircularProgressIndicator() }

                state.notFound || state.word == null -> Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.padding(32.dp)
                    ) {
                        Text(
                            text = "That word is not in the library",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onBackground,
                            textAlign = TextAlign.Center
                        )
                        Button(onClick = onBack) { Text("Back") }
                    }
                }

                else -> Column(modifier = Modifier.fillMaxSize()) {
                    val word = state.word ?: return@Column

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(
                                Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back"
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = word.word,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = scheduleLine(state),
                                style = MaterialTheme.typography.labelMedium,
                                color = SarthiTheme.colors.mutedText
                            )
                        }
                        IconButton(onClick = viewModel::toggleBookmark) {
                            Icon(
                                imageVector = if (state.isBookmarked) {
                                    Icons.Default.Bookmark
                                } else {
                                    Icons.Default.BookmarkBorder
                                },
                                contentDescription = if (state.isBookmarked) {
                                    "Remove bookmark"
                                } else {
                                    "Bookmark this word"
                                },
                                tint = if (state.isBookmarked) {
                                    MaterialTheme.colorScheme.tertiary
                                } else {
                                    SarthiTheme.colors.mutedText
                                }
                            )
                        }
                    }

                    TabRow(
                        selectedTabIndex = pagerState.currentPage,
                        containerColor = MaterialTheme.colorScheme.background,
                        contentColor = MaterialTheme.colorScheme.primary
                    ) {
                        PART_TITLES.forEachIndexed { index, title ->
                            Tab(
                                selected = pagerState.currentPage == index,
                                onClick = { scope.launch { pagerState.animateScrollToPage(index) } },
                                text = { Text(title, style = MaterialTheme.typography.labelLarge) }
                            )
                        }
                    }

                    HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { page ->
                        when (page) {
                            0 -> CardPartRecognition(
                                word = word,
                                imageUrl = state.imageUrl,
                                canSpeak = canSpeak,
                                onSpeak = viewModel::speak
                            )

                            1 -> CardPartUnderstanding(
                                word = word,
                                examples = state.examples,
                                canSpeak = canSpeak,
                                onSpeak = viewModel::speak
                            )

                            else -> CardPartPractice(
                                word = word,
                                chunks = state.chunks,
                                practice = state.practice,
                                canSpeak = canSpeak,
                                onSpeak = viewModel::speak,
                                onSelectOption = viewModel::selectOption,
                                onReveal = viewModel::reveal,
                                onOwnSentenceChanged = viewModel::updateOwnSentence
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Where this word stands in the schedule.
 *
 * Shown because looking a word up and being told "you will see this again on
 * Thursday" is genuinely useful — and because it makes clear that reading it
 * here has not changed anything.
 */
private fun scheduleLine(state: WordDetailUiState): String {
    val progress = state.progress ?: return ""
    return when {
        progress.isNew -> "Not studied yet"
        progress.isKnown -> "Known — next review ${formatDate(progress.nextReviewAt)}"
        progress.nextReviewAt <= 0L -> "Studied"
        else -> "Next review ${formatDate(progress.nextReviewAt)}"
    }
}

private fun formatDate(epochMillis: Long): String =
    Instant.ofEpochMilli(epochMillis)
        .atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("d MMM"))
