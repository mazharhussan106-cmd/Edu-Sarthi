package com.speaksarthi.app.presentation.worddetail

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.speaksarthi.app.data.audio.SpeechPlayer
import com.speaksarthi.app.data.audio.SpeechState
import com.speaksarthi.app.data.illustration.IllustrationLoader
import com.speaksarthi.app.data.preferences.AppPreferences
import com.speaksarthi.app.domain.model.Chunk
import com.speaksarthi.app.domain.model.PracticeItem
import com.speaksarthi.app.domain.model.Progress
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.domain.repository.LibraryRepository
import com.speaksarthi.app.domain.repository.StudyRepository
import com.speaksarthi.app.presentation.card.PracticeReveal
import com.speaksarthi.app.presentation.card.PracticeZoneState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

data class WordDetailUiState(
    val isLoading: Boolean = true,
    val word: Word? = null,
    val chunks: List<Chunk> = emptyList(),
    val examples: List<PracticeItem> = emptyList(),
    val practice: PracticeZoneState = PracticeZoneState(exercise = null),
    val progress: Progress? = null,
    val imageUrl: String? = null,
    val isBookmarked: Boolean = false,
    val notFound: Boolean = false
)

/**
 * One word, opened deliberately rather than served by the queue.
 *
 * The same three card parts as a study session, with one difference that matters:
 * **nothing here grades the word**. Looking a word up because you heard it at
 * work must not tell the spaced-repetition engine you just reviewed it — that
 * would push its next review out on evidence that has nothing to do with whether
 * you remember it.
 */
@HiltViewModel
class WordDetailViewModel @Inject constructor(
    private val library: LibraryRepository,
    private val study: StudyRepository,
    private val illustrations: IllustrationLoader,
    private val speech: SpeechPlayer,
    private val preferences: AppPreferences,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val wordId: String = savedStateHandle[ARG_WORD_ID] ?: ""

    private val _state = MutableStateFlow(WordDetailUiState())
    val state: StateFlow<WordDetailUiState> = _state.asStateFlow()

    val speechState: StateFlow<SpeechState> = speech.state

    private var sentenceSaveJob: Job? = null

    init {
        load()
    }

    private fun load() {
        viewModelScope.launch {
            val word = library.word(wordId)
            if (word == null) {
                _state.value = WordDetailUiState(isLoading = false, notFound = true)
                return@launch
            }

            val progress = study.progress(wordId)
            val previousSentence = study.ownSentence(wordId)

            _state.value = WordDetailUiState(
                isLoading = false,
                word = word,
                chunks = library.chunks(wordId),
                examples = library.practiceItems(wordId),
                practice = PracticeZoneState(
                    exercise = library.exercise(wordId),
                    ownSentence = previousSentence,
                    previousOwnSentence = previousSentence
                ),
                progress = progress,
                imageUrl = illustrations.urlFor(word.illustration),
                isBookmarked = progress.isBookmarked
            )
        }
    }

    fun toggleBookmark() {
        val current = _state.value
        val word = current.word ?: return
        val next = !current.isBookmarked
        _state.value = current.copy(isBookmarked = next)
        viewModelScope.launch { study.setBookmarked(word.wordId, next) }
    }

    fun speak(text: String) {
        viewModelScope.launch {
            speech.speak(text, rate = preferences.audioSpeed.first())
        }
    }

    fun selectOption(optionIndex: Int) {
        val current = _state.value
        val exercise = current.practice.exercise ?: return
        if (current.practice.hasAnswered) return

        val wasCorrect = optionIndex == exercise.mcq.answerIndex
        _state.value = current.copy(
            practice = current.practice.copy(selectedOption = optionIndex)
        )
        // Recorded as a quiz answer — that is what it is — but it never touches
        // the review schedule.
        viewModelScope.launch {
            study.recordQuizAnswer(exercise.wordId, optionIndex, wasCorrect)
        }
    }

    fun reveal(which: PracticeReveal) {
        val current = _state.value
        _state.value = current.copy(
            practice = current.practice.copy(revealed = current.practice.revealed + which)
        )
    }

    fun updateOwnSentence(text: String) {
        val current = _state.value
        val word = current.word ?: return
        _state.value = current.copy(practice = current.practice.copy(ownSentence = text))

        // Debounced exactly as the study card is: a row write per keystroke is
        // pointless work on a cheap phone.
        sentenceSaveJob?.cancel()
        sentenceSaveJob = viewModelScope.launch {
            delay(SENTENCE_SAVE_DELAY_MS)
            study.saveOwnSentence(word.wordId, text)
        }
    }

    override fun onCleared() {
        speech.stop()
        super.onCleared()
    }

    companion object {
        const val ARG_WORD_ID = "wordId"

        private const val SENTENCE_SAVE_DELAY_MS = 800L
    }
}
