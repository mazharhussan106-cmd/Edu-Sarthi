package com.speaksarthi.app.util

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Time, behind an interface.
 *
 * Streaks, the daily goal and the speech budget all turn on "what day is it",
 * and every one of those is painful to test against the real system clock. This
 * exists so tests can hand the repository a fixed date instead of sleeping or
 * mutating the device clock.
 */
interface Clock {
    fun nowMillis(): Long

    /** The learner's local date — a day boundary must mean their midnight, not UTC's. */
    fun today(): LocalDate

    /**
     * Local date and time. Reminders need both: "8am" is meaningless without
     * knowing what time it is now in the learner's own timezone.
     */
    fun nowLocalDateTime(): LocalDateTime
}

@Singleton
class SystemClock @Inject constructor() : Clock {
    override fun nowMillis(): Long = System.currentTimeMillis()
    override fun today(): LocalDate = LocalDate.now(ZoneId.systemDefault())
    override fun nowLocalDateTime(): LocalDateTime = LocalDateTime.now(ZoneId.systemDefault())
}

/** Test double. Advance it by hand to simulate days passing. */
class FakeClock(
    var now: Long = 0L,
    var date: LocalDate = LocalDate.of(2026, 1, 1),
    var timeOfDay: LocalTime = LocalTime.of(9, 0)
) : Clock {
    override fun nowMillis(): Long = now
    override fun today(): LocalDate = date
    override fun nowLocalDateTime(): LocalDateTime = date.atTime(timeOfDay)

    fun advanceDays(days: Long) {
        date = date.plusDays(days)
        now += days * 24L * 60 * 60 * 1000
    }
}
