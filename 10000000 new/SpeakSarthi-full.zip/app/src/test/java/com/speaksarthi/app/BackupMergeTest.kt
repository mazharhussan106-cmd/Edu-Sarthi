package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.data.backup.BackupBadge
import com.speaksarthi.app.data.backup.BackupDailyStat
import com.speaksarthi.app.data.backup.BackupProgress
import com.speaksarthi.app.data.backup.BackupSentence
import com.speaksarthi.app.data.backup.BackupWeakSound
import com.speaksarthi.app.domain.usecase.backup.BackupMerge
import org.junit.Test

/**
 * The merge rules.
 *
 * Backup exists to stop a learner losing work. A merge rule that loses work
 * while restoring would be the most embarrassing possible bug in this feature,
 * so every rule has a test saying which side wins and why.
 */
class BackupMergeTest {

    // ---- progress ----------------------------------------------------------

    @Test
    fun `nothing local means the backup is taken as-is`() {
        val incoming = BackupProgress(wordId = "VRB-001", repetitions = 4)
        assertThat(BackupMerge.mergeProgress(null, incoming)).isEqualTo(incoming)
    }

    @Test
    fun `the more recently reviewed row wins`() {
        val older = BackupProgress("VRB-001", repetitions = 9, lastReviewedAt = 1_000)
        val newer = BackupProgress("VRB-001", repetitions = 2, lastReviewedAt = 5_000)

        assertThat(BackupMerge.mergeProgress(older, newer).repetitions).isEqualTo(2)
    }

    @Test
    fun `recency beats a higher interval, not the other way round`() {
        // A word just rated "Again" has a lower interval and is the truer record
        // of where the learner stands. Taking the higher interval would tell the
        // scheduler they know a word they have just forgotten.
        val local = BackupProgress("VRB-001", intervalDays = 1, lastReviewedAt = 9_000)
        val incoming = BackupProgress("VRB-001", intervalDays = 30, lastReviewedAt = 2_000)

        assertThat(BackupMerge.mergeProgress(local, incoming).intervalDays).isEqualTo(1)
    }

    @Test
    fun `a bookmark on either side survives`() {
        val local = BackupProgress("VRB-001", isBookmarked = true, lastReviewedAt = 1)
        val incoming = BackupProgress("VRB-001", isBookmarked = false, lastReviewedAt = 9)

        assertThat(BackupMerge.mergeProgress(local, incoming).isBookmarked).isTrue()
    }

    @Test
    fun `known on either side survives`() {
        val local = BackupProgress("VRB-001", isKnown = false, lastReviewedAt = 9)
        val incoming = BackupProgress("VRB-001", isKnown = true, lastReviewedAt = 1)

        assertThat(BackupMerge.mergeProgress(local, incoming).isKnown).isTrue()
    }

    @Test
    fun `counters take the larger of the two`() {
        val local = BackupProgress("VRB-001", timesSeen = 12, timesCorrect = 3, lastReviewedAt = 1)
        val incoming = BackupProgress("VRB-001", timesSeen = 4, timesCorrect = 9, lastReviewedAt = 9)

        val merged = BackupMerge.mergeProgress(local, incoming)
        assertThat(merged.timesSeen).isEqualTo(12)
        assertThat(merged.timesCorrect).isEqualTo(9)
    }

    // ---- daily stats -------------------------------------------------------

    @Test
    fun `daily counters take the maximum, never the sum`() {
        // Summing would double every day present on both sides — which is every
        // day, when restoring a backup taken from this same device. A learner who
        // sees 40 words on a day they studied 20 stops trusting every number.
        val local = BackupDailyStat("2026-09-16", wordsStudied = 20, studySeconds = 600)
        val incoming = BackupDailyStat("2026-09-16", wordsStudied = 20, studySeconds = 600)

        val merged = BackupMerge.mergeDailyStat(local, incoming)
        assertThat(merged.wordsStudied).isEqualTo(20)
        assertThat(merged.studySeconds).isEqualTo(600)
    }

    @Test
    fun `each counter is maximised independently`() {
        val local = BackupDailyStat("2026-09-16", wordsStudied = 25, recordingsMade = 0)
        val incoming = BackupDailyStat("2026-09-16", wordsStudied = 10, recordingsMade = 4)

        val merged = BackupMerge.mergeDailyStat(local, incoming)
        assertThat(merged.wordsStudied).isEqualTo(25)
        assertThat(merged.recordingsMade).isEqualTo(4)
    }

    // ---- badges ------------------------------------------------------------

    @Test
    fun `a badge keeps its earliest date`() {
        val local = BackupBadge("streak_7", earnedAt = 9_000)
        val incoming = BackupBadge("streak_7", earnedAt = 2_000)

        assertThat(BackupMerge.mergeBadge(local, incoming).earnedAt).isEqualTo(2_000)
    }

    @Test
    fun `a badge with no date does not overwrite a real one`() {
        val local = BackupBadge("streak_7", earnedAt = 5_000)
        val incoming = BackupBadge("streak_7", earnedAt = 0)

        assertThat(BackupMerge.mergeBadge(local, incoming).earnedAt).isEqualTo(5_000)
    }

    // ---- weak sounds -------------------------------------------------------

    @Test
    fun `the longer phoneme history wins rather than being summed`() {
        val local = BackupWeakSound("v", errorCount = 3, attemptCount = 10)
        val incoming = BackupWeakSound("v", errorCount = 1, attemptCount = 4)

        val merged = BackupMerge.mergeWeakSound(local, incoming)
        assertThat(merged.attemptCount).isEqualTo(10)
        assertThat(merged.errorCount).isEqualTo(3)
    }

    @Test
    fun `merging weak sounds keeps the error rate meaningful`() {
        // Summing would give 4 errors in 14 attempts, which is neither side's
        // real rate and is the number the sounds list ranks by.
        val local = BackupWeakSound("v", errorCount = 8, attemptCount = 10)
        val incoming = BackupWeakSound("v", errorCount = 1, attemptCount = 20)

        val merged = BackupMerge.mergeWeakSound(local, incoming)
        assertThat(merged.errorCount.toFloat() / merged.attemptCount).isWithin(0.001f).of(0.05f)
    }

    // ---- sentences ---------------------------------------------------------

    @Test
    fun `the later sentence edit wins`() {
        val local = BackupSentence("VRB-001", "old", updatedAt = 1)
        val incoming = BackupSentence("VRB-001", "new", updatedAt = 9)

        assertThat(BackupMerge.mergeSentence(local, incoming).text).isEqualTo("new")
    }

    @Test
    fun `an older incoming sentence does not overwrite a newer local one`() {
        val local = BackupSentence("VRB-001", "what I wrote today", updatedAt = 9)
        val incoming = BackupSentence("VRB-001", "what I wrote last month", updatedAt = 1)

        assertThat(BackupMerge.mergeSentence(local, incoming).text)
            .isEqualTo("what I wrote today")
    }

    // ---- whole lists -------------------------------------------------------

    @Test
    fun `merging a list applies the rule per key`() {
        val local = mapOf(
            "A" to BackupProgress("A", repetitions = 5, lastReviewedAt = 9),
            "B" to BackupProgress("B", repetitions = 1, lastReviewedAt = 1)
        )
        val incoming = listOf(
            BackupProgress("A", repetitions = 1, lastReviewedAt = 1),
            BackupProgress("B", repetitions = 7, lastReviewedAt = 9),
            BackupProgress("C", repetitions = 3, lastReviewedAt = 5)
        )

        val merged = BackupMerge
            .mergeAll(local, incoming, { it.wordId }, BackupMerge::mergeProgress)
            .associateBy { it.wordId }

        assertThat(merged.getValue("A").repetitions).isEqualTo(5)
        assertThat(merged.getValue("B").repetitions).isEqualTo(7)
        assertThat(merged.getValue("C").repetitions).isEqualTo(3)
    }

    @Test
    fun `restoring the very same backup twice changes nothing`() {
        // Idempotence matters: a learner who taps restore twice, or restores a
        // file they already restored, must not end up with doubled counters.
        val stats = listOf(
            BackupDailyStat("2026-09-16", wordsStudied = 20, recordingsMade = 3)
        )
        val once = BackupMerge
            .mergeAll(emptyMap(), stats, { it.date }, BackupMerge::mergeDailyStat)
        val twice = BackupMerge
            .mergeAll(once.associateBy { it.date }, stats, { it.date }, BackupMerge::mergeDailyStat)

        assertThat(twice).isEqualTo(once)
    }
}
