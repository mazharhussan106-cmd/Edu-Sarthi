package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.domain.usecase.badges.Badge
import com.speaksarthi.app.domain.usecase.badges.BadgeEvaluator
import com.speaksarthi.app.domain.usecase.badges.BadgeProgress
import org.junit.Test

/**
 * The badge rules are product decisions, so they are pinned here rather than
 * rediscovered later. The two that matter most are at the bottom: a badge is
 * never withdrawn, and none of them can be earned by grinding.
 */
class BadgeEvaluatorTest {

    @Test
    fun `the first word and the first recording are earned immediately`() {
        val progress = BadgeProgress(wordsStudied = 1, recordingsMade = 1)

        assertThat(BadgeEvaluator.isEarned(Badge.FirstWord, progress)).isTrue()
        assertThat(BadgeEvaluator.isEarned(Badge.FirstRecording, progress)).isTrue()
    }

    @Test
    fun `nothing is earned from nothing`() {
        assertThat(BadgeEvaluator.earned(BadgeProgress())).isEmpty()
    }

    @Test
    fun `a seven day streak is not earned on day six`() {
        assertThat(BadgeEvaluator.isEarned(Badge.SevenDayStreak, BadgeProgress(currentStreak = 6)))
            .isFalse()
        assertThat(BadgeEvaluator.isEarned(Badge.SevenDayStreak, BadgeProgress(currentStreak = 7)))
            .isTrue()
    }

    @Test
    fun `a long streak earns both streak badges`() {
        val earned = BadgeEvaluator.earned(BadgeProgress(currentStreak = 31))
        assertThat(earned).containsAtLeast(Badge.SevenDayStreak, Badge.ThirtyDayStreak)
    }

    @Test
    fun `the counting badges need their full count`() {
        assertThat(BadgeEvaluator.isEarned(Badge.HundredKnown, BadgeProgress(knownWords = 99)))
            .isFalse()
        assertThat(BadgeEvaluator.isEarned(Badge.HundredKnown, BadgeProgress(knownWords = 100)))
            .isTrue()
        assertThat(BadgeEvaluator.isEarned(Badge.OwnWords, BadgeProgress(ownSentencesWritten = 25)))
            .isTrue()
        assertThat(BadgeEvaluator.isEarned(Badge.MistakeMender, BadgeProgress(mistakesReviewed = 24)))
            .isFalse()
    }

    @Test
    fun `progress towards a counting badge is the fraction done`() {
        assertThat(BadgeEvaluator.progressTowards(Badge.HundredKnown, BadgeProgress(knownWords = 40)))
            .isWithin(0.001f).of(0.4f)
    }

    @Test
    fun `progress never exceeds one, and an earned badge reads as full`() {
        val overshot = BadgeProgress(currentStreak = 99)
        assertThat(BadgeEvaluator.progressTowards(Badge.SevenDayStreak, overshot)).isEqualTo(1f)
    }

    @Test
    fun `a one-off badge shows no partial progress`() {
        // "Record yourself once" is either done or not; a half-full bar under it
        // would be meaningless.
        assertThat(BadgeEvaluator.progressTowards(Badge.FirstRecording, BadgeProgress()))
            .isEqualTo(0f)
    }

    @Test
    fun `newly earned excludes badges already held`() {
        val progress = BadgeProgress(wordsStudied = 1, recordingsMade = 1)

        val fresh = BadgeEvaluator.newlyEarned(progress, alreadyHeld = setOf(Badge.FirstWord.id))
        assertThat(fresh).containsExactly(Badge.FirstRecording)
    }

    @Test
    fun `an already-earned badge is never announced twice`() {
        val progress = BadgeProgress(wordsStudied = 500, currentStreak = 10)
        val held = BadgeEvaluator.earned(progress).map { it.id }.toSet()

        assertThat(BadgeEvaluator.newlyEarned(progress, held)).isEmpty()
    }

    @Test
    fun `nothing here can be earned by volume alone`() {
        // Studying a thousand words with no streak, no recordings and no mistake
        // review earns exactly one badge — the first one. Grinding is not an
        // achievement; it is having time.
        val grinder = BadgeProgress(wordsStudied = 1_000, chunksSeen = 99)

        assertThat(BadgeEvaluator.earned(grinder)).containsExactly(Badge.FirstWord)
    }

    @Test
    fun `every badge is reachable without a single paid score`() {
        // Scoring is the subscription, so the badge set must not be gated behind
        // it beyond what the free tier allows: one clear sentence and one fixed
        // sound, both inside the daily free allowance.
        val freeTierMaximum = BadgeProgress(
            wordsStudied = 1,
            knownWords = 100,
            chunksSeen = 100,
            currentStreak = 30,
            recordingsMade = 1,
            clearSentences = 1,
            soundsFixed = 1,
            mistakesReviewed = 25,
            ownSentencesWritten = 25
        )
        assertThat(BadgeEvaluator.earned(freeTierMaximum)).hasSize(Badge.entries.size)
    }

    @Test
    fun `badge ids are unique and stable`() {
        // The id is the database key, so a duplicate would silently merge two
        // badges into one row.
        val ids = Badge.entries.map { it.id }
        assertThat(ids).containsNoDuplicates()
        assertThat(Badge.fromId("streak_7")).isEqualTo(Badge.SevenDayStreak)
        assertThat(Badge.fromId("nonsense")).isNull()
    }

    @Test
    fun `every badge has something to say when it is earned`() {
        Badge.entries.forEach { badge ->
            assertThat(badge.title).isNotEmpty()
            assertThat(badge.requirement).isNotEmpty()
            assertThat(badge.earnedMessage).isNotEmpty()
            assertThat(badge.emoji).isNotEmpty()
        }
    }
}
