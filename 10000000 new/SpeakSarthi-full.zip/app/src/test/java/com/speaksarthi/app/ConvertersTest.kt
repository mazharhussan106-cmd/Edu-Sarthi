package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.data.local.converter.Converters
import org.junit.Test

class ConvertersTest {

    @Test
    fun `round trips a simple list`() {
        val input = listOf("comprehend", "grasp", "follow")
        assertThat(Converters.stringToList(Converters.listToString(input))).isEqualTo(input)
    }

    /**
     * The reason the delimiter is a unit separator and not a comma. Chunk and
     * option text is full of commas; splitting on one would silently shred the
     * content into fragments that look almost right, which is the worst kind of
     * data bug to find later.
     */
    @Test
    fun `values containing commas survive the round trip intact`() {
        val input = listOf(
            "understand clearly, fully understand",
            "B) To grasp the meaning of, roughly",
            "Classroom, conversation, instructions"
        )
        assertThat(Converters.stringToList(Converters.listToString(input))).isEqualTo(input)
    }

    @Test
    fun `blank and null inputs produce an empty list`() {
        assertThat(Converters.stringToList(null)).isEmpty()
        assertThat(Converters.stringToList("")).isEmpty()
        assertThat(Converters.stringToList("   ")).isEmpty()
    }

    @Test
    fun `empty entries are dropped in both directions`() {
        assertThat(Converters.listToString(listOf("a", "", "  ", "b")))
            .isEqualTo("a${Converters.DELIMITER}b")

        val padded = "a${Converters.DELIMITER}${Converters.DELIMITER}b"
        assertThat(Converters.stringToList(padded)).containsExactly("a", "b").inOrder()
    }

    @Test
    fun `an empty list becomes an empty string rather than null`() {
        assertThat(Converters.listToString(emptyList())).isEmpty()
        assertThat(Converters.listToString(null)).isEmpty()
    }
}
