package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.domain.model.CreditBalance
import com.speaksarthi.app.domain.model.CreditPack
import com.speaksarthi.app.domain.model.EarnKind
import org.junit.Test

/**
 * The credit model as the app understands it.
 *
 * Deliberately thin, and that thinness is the thing being checked. The app is
 * not supposed to know how many credits a pack contains, what a lesson bonus is
 * worth, or how to add anything to a balance — all of that lives on the server,
 * because a number the app can compute is a number a rooted device can forge.
 *
 * So these tests mostly assert what is *absent*. A test that fails here is
 * usually telling you that pricing logic has crept back into the client.
 */
class CreditModelTest {

    @Test
    fun `an empty balance has no credits`() {
        assertThat(CreditBalance(credits = 0).hasCredits).isFalse()
    }

    @Test
    fun `any credits at all count`() {
        assertThat(CreditBalance(credits = 1).hasCredits).isTrue()
    }

    @Test
    fun `running low is a band, not zero`() {
        // The warning has to arrive while the learner can still act on it. At
        // zero it is not a warning, it is a notification of something that has
        // already happened.
        assertThat(CreditBalance(credits = 0).isRunningLow).isFalse()
        assertThat(CreditBalance(credits = 1).isRunningLow).isTrue()
        assertThat(CreditBalance(credits = CreditBalance.LOW_WATER_MARK).isRunningLow).isTrue()
        assertThat(CreditBalance(credits = CreditBalance.LOW_WATER_MARK + 1).isRunningLow).isFalse()
    }

    @Test
    fun `an unchecked balance is not the same as an empty one`() {
        // These must stay distinguishable. Showing "0 credits" to someone whose
        // balance simply has not loaded yet tells them they are broke when they
        // are not.
        assertThat(CreditBalance.unknown.source).isEqualTo(CreditBalance.Source.Unknown)
        assertThat(CreditBalance.unknown.checkedAt).isEqualTo(0L)
    }

    @Test
    fun `a build with no server is its own state`() {
        // Not an error and not an empty balance: the app works, and saying
        // "you have no credits" would be a lie.
        assertThat(CreditBalance.notConfigured.source)
            .isEqualTo(CreditBalance.Source.NotConfigured)
    }

    @Test
    fun `pack ids are unique`() {
        val ids = CreditPack.entries.map { it.productId }
        assertThat(ids).containsNoDuplicates()
    }

    @Test
    fun `every pack id resolves back to its pack`() {
        // These strings must match the Play Console exactly and cannot change
        // after launch without stranding everyone who bought one.
        CreditPack.entries.forEach { pack ->
            assertThat(CreditPack.forProductId(pack.productId)).isEqualTo(pack)
        }
    }

    @Test
    fun `an unknown product id resolves to nothing`() {
        // A purchase for a product this build does not sell must not be silently
        // treated as one that it does.
        assertThat(CreditPack.forProductId("speak_sarthi_scoring_monthly")).isNull()
        assertThat(CreditPack.forProductId("")).isNull()
    }

    @Test
    fun `the app never states what a pack is worth`() {
        // The load-bearing test in this file. If a credit count ever appears on
        // CreditPack, the app has started deciding what money buys — and the
        // server has stopped being the only thing that can.
        val fields = CreditPack::class.java.declaredFields
            .filterNot { it.isSynthetic }
            .map { it.name }
        assertThat(fields).doesNotContain("credits")
        assertThat(fields).doesNotContain("creditCount")
    }

    @Test
    fun `earn kinds have stable wire names`() {
        // The server keys its daily caps on these strings; renaming one silently
        // turns its cap off.
        assertThat(EarnKind.Lesson.wireName).isEqualTo("lesson")
        assertThat(EarnKind.Streak.wireName).isEqualTo("streak")
    }
}
