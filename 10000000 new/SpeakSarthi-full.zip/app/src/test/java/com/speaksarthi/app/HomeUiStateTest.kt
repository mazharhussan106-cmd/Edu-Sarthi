package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.domain.model.DailyStat
import com.speaksarthi.app.presentation.home.HomeUiState
import com.speaksarthi.app.presentation.theme.ThemeMode
import org.junit.Test

class HomeUiStateTest {

    private fun state(studied: Int, goal: Int) = HomeUiState(
        today = DailyStat(date = "2026-09-15", wordsStudied = studied),
        dailyGoal = goal
    )

    @Test
    fun `progress is the fraction of the goal done`() {
        assertThat(state(studied = 5, goal = 10).goalProgress).isWithin(0.001f).of(0.5f)
    }

    @Test
    fun `going past the goal is not an error`() {
        // Twenty words against a goal of ten is a good day, not a broken progress bar.
        val over = state(studied = 20, goal = 10)
        assertThat(over.goalProgress).isEqualTo(1f)
        assertThat(over.goalMet).isTrue()
    }

    @Test
    fun `a zero goal never shows an unfinishable bar`() {
        assertThat(state(studied = 0, goal = 0).goalProgress).isEqualTo(1f)
    }

    @Test
    fun `nothing studied is zero progress, not a divide by zero`() {
        assertThat(state(studied = 0, goal = 10).goalProgress).isEqualTo(0f)
        assertThat(state(studied = 0, goal = 10).goalMet).isFalse()
    }

    @Test
    fun `theme cycling reaches all four modes and returns to the start`() {
        var mode = ThemeMode.System
        val seen = mutableListOf(mode)
        repeat(4) {
            mode = mode.next()
            seen += mode
        }
        assertThat(seen.toSet()).containsExactlyElementsIn(ThemeMode.entries)
        assertThat(seen.last()).isEqualTo(ThemeMode.System)
    }
}
