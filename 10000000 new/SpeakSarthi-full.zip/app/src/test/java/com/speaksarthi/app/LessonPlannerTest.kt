package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.domain.model.CefrLevel
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.domain.usecase.lessons.Lesson
import com.speaksarthi.app.domain.usecase.lessons.LessonPlanner
import com.speaksarthi.app.domain.usecase.lessons.LessonProgress
import org.junit.Test

class LessonPlannerTest {

    private var nextIndex = 0

    private fun word(
        id: String,
        level: CefrLevel = CefrLevel.A1,
        category: String = "Food",
        order: Int = nextIndex++
    ) = Word(
        wordId = id,
        word = id.lowercase(),
        partOfSpeech = "noun",
        category = category,
        level = level,
        frequency = "",
        importance = "",
        register = "",
        ipa = "",
        syllableBreak = "",
        hindiPronunciation = "",
        hindiMeaning = "",
        simpleMeaning = "",
        plainExplanation = "",
        etymology = "",
        mnemonic = "",
        quickTip = "",
        pronunciationTip = "",
        spellingTip = "",
        wordFamily = emptyList(),
        prefixRootSuffix = "",
        visualAssociation = "",
        tone = "",
        typicalContexts = emptyList(),
        miniConversation = "",
        confusingWords = "",
        relatedWords = emptyList(),
        synonyms = emptyList(),
        antonyms = emptyList(),
        emotionFeel = "",
        commonMistakeWrong = "",
        commonMistakeCorrect = "",
        quickRecallPrompt = "",
        illustration = "",
        orderIndex = order
    )

    private fun words(count: Int, level: CefrLevel = CefrLevel.A1, category: String = "Food") =
        (1..count).map { word("W$it-$category-${level.code}", level, category) }

    @Test
    fun `an empty library plans nothing rather than one empty lesson`() {
        assertThat(LessonPlanner.plan(emptyList())).isEmpty()
    }

    @Test
    fun `every word ends up in exactly one lesson`() {
        val library = words(40, CefrLevel.A1, "Food") + words(30, CefrLevel.A2, "Travel")
        val planned = LessonPlanner.plan(library).flatMap { it.wordIds }

        assertThat(planned).hasSize(library.size)
        assertThat(planned).containsNoDuplicates()
        assertThat(planned.toSet()).isEqualTo(library.map { it.wordId }.toSet())
    }

    @Test
    fun `easier levels come first`() {
        val library = words(20, CefrLevel.B2, "Business") + words(20, CefrLevel.A1, "Food")
        val levels = LessonPlanner.plan(library).map { it.level }

        assertThat(levels.first()).isEqualTo(CefrLevel.A1)
        // Someone placed at A1 must not meet B2 words in lesson two.
        assertThat(levels).isInOrder(compareBy<CefrLevel> { it.order })
    }

    @Test
    fun `a lesson holds one category, so it is about something`() {
        val library = words(20, CefrLevel.A1, "Food") + words(20, CefrLevel.A1, "Travel")

        LessonPlanner.plan(library).forEach { lesson ->
            assertThat(lesson.wordIds.all { it.contains(lesson.category) }).isTrue()
        }
    }

    @Test
    fun `lessons are numbered from one, without gaps`() {
        val library = words(60, CefrLevel.A1, "Food")
        val numbers = LessonPlanner.plan(library).map { it.number }

        assertThat(numbers).isEqualTo((1..numbers.size).toList())
    }

    @Test
    fun `lesson ids are unique`() {
        val library = words(50, CefrLevel.A1, "Food") + words(50, CefrLevel.A2, "Travel")
        assertThat(LessonPlanner.plan(library).map { it.id }).containsNoDuplicates()
    }

    @Test
    fun `a short tail is folded in rather than shipped as a stub lesson`() {
        // 23 words would otherwise be a lesson of 20 and a lesson of 3, and a
        // three-word lesson looks like a bug.
        val groups = LessonPlanner.chunk(words(23))

        assertThat(groups).hasSize(1)
        assertThat(groups.single()).hasSize(23)
    }

    @Test
    fun `a long tail becomes its own lesson`() {
        val groups = LessonPlanner.chunk(words(32))

        assertThat(groups).hasSize(2)
        assertThat(groups.last().size).isAtLeast(LessonPlanner.MINIMUM_SIZE)
    }

    @Test
    fun `no lesson is smaller than the minimum once planned`() {
        val library = words(23, CefrLevel.A1, "Food") + words(45, CefrLevel.A2, "Travel")

        LessonPlanner.plan(library).forEach { lesson ->
            assertThat(lesson.size).isAtLeast(LessonPlanner.MINIMUM_SIZE)
        }
    }

    @Test
    fun `words keep the library's order inside a lesson`() {
        // Which is roughly frequency order, so the most useful words in a
        // category come first.
        val library = words(20, CefrLevel.A1, "Food")
        val lesson = LessonPlanner.plan(library).single()

        assertThat(lesson.wordIds).isEqualTo(library.map { it.wordId })
    }

    @Test
    fun `a blank category does not produce a nameless lesson`() {
        val library = listOf(word("W1", category = "  "), word("W2", category = ""))

        LessonPlanner.plan(library).forEach { lesson ->
            assertThat(lesson.title).isNotEmpty()
            assertThat(lesson.category).isNotEmpty()
        }
    }

    // ---- what to open next -------------------------------------------------

    private fun lesson(number: Int) = Lesson(
        id = "L%03d".format(number),
        number = number,
        title = "Lesson $number",
        subtitle = "",
        level = CefrLevel.A1,
        category = "Food",
        wordIds = List(20) { "W$number-$it" }
    )

    @Test
    fun `a half-finished lesson is offered before a fresh one`() {
        // Finishing things is the entire reason lessons exist next to the queue.
        val progress = listOf(
            LessonProgress(lesson(1), wordsKnown = 20, wordsStarted = 20),
            LessonProgress(lesson(2), wordsKnown = 0, wordsStarted = 0),
            LessonProgress(lesson(3), wordsKnown = 6, wordsStarted = 9)
        )

        assertThat(LessonPlanner.nextLesson(progress)?.lesson?.number).isEqualTo(3)
    }

    @Test
    fun `with nothing started, the first unfinished lesson is offered`() {
        val progress = listOf(
            LessonProgress(lesson(1), wordsKnown = 20, wordsStarted = 20),
            LessonProgress(lesson(2), wordsKnown = 0, wordsStarted = 0)
        )

        assertThat(LessonPlanner.nextLesson(progress)?.lesson?.number).isEqualTo(2)
    }

    @Test
    fun `everything finished means there is nothing to offer`() {
        val progress = listOf(LessonProgress(lesson(1), wordsKnown = 20, wordsStarted = 20))
        assertThat(LessonPlanner.nextLesson(progress)).isNull()
    }

    @Test
    fun `progress fractions stay between zero and one`() {
        val over = LessonProgress(lesson(1), wordsKnown = 99, wordsStarted = 99)
        val empty = LessonProgress(lesson(1), wordsKnown = 0, wordsStarted = 0)

        assertThat(over.fraction).isEqualTo(1f)
        assertThat(over.isComplete).isTrue()
        assertThat(empty.fraction).isEqualTo(0f)
        assertThat(empty.isStarted).isFalse()
    }
}
