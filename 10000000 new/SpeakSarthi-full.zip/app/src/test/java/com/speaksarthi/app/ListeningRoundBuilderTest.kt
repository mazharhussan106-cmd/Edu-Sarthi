package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.domain.model.CefrLevel
import com.speaksarthi.app.domain.model.Word
import com.speaksarthi.app.domain.usecase.listening.ListeningRoundBuilder
import org.junit.Test
import kotlin.random.Random

/**
 * The round builder is where listening practice is either a real test of the ear
 * or a giveaway, so it is tested harder than its size suggests.
 */
class ListeningRoundBuilderTest {

    private fun word(
        id: String,
        text: String,
        syllables: String = "",
        pos: String = "verb"
    ) = Word(
        wordId = id,
        word = text,
        partOfSpeech = pos,
        category = "",
        level = CefrLevel.A1,
        frequency = "",
        importance = "",
        register = "",
        ipa = "",
        syllableBreak = syllables,
        hindiPronunciation = "",
        hindiMeaning = "",
        simpleMeaning = "",
        plainExplanation = "",
        etymology = "",
        mnemonic = "",
        quickTip = "",
        pronunciationTip = "",
        spellingTip = "",
        wordFamily = emptyList(),
        prefixRootSuffix = "",
        visualAssociation = "",
        tone = "",
        typicalContexts = emptyList(),
        miniConversation = "",
        confusingWords = "",
        relatedWords = emptyList(),
        synonyms = emptyList(),
        antonyms = emptyList(),
        emotionFeel = "",
        commonMistakeWrong = "",
        commonMistakeCorrect = "",
        quickRecallPrompt = "",
        illustration = "",
        orderIndex = 0
    )

    private val pool = listOf(
        word("W1", "accept"),
        word("W2", "except"),
        word("W3", "expect"),
        word("W4", "aspect"),
        word("W5", "elephant"),
        word("W6", "banana"),
        word("W7", "computer"),
        word("W8", "window")
    )

    @Test
    fun `every question has four distinct options containing the answer`() {
        val questions = ListeningRoundBuilder.build(
            targets = pool.take(4),
            pool = pool,
            random = Random(7)
        )

        assertThat(questions).hasSize(4)
        questions.forEach { question ->
            assertThat(question.options).hasSize(ListeningRoundBuilder.OPTIONS_PER_QUESTION)
            assertThat(question.options.toSet()).hasSize(ListeningRoundBuilder.OPTIONS_PER_QUESTION)
            assertThat(question.options).contains(question.word.word)
            assertThat(question.options[question.answerIndex]).isEqualTo(question.word.word)
        }
    }

    @Test
    fun `answer is not always in the same position`() {
        // A round where the answer is always option A is not a listening test.
        val questions = ListeningRoundBuilder.build(
            targets = pool,
            pool = pool,
            random = Random(3)
        )
        assertThat(questions.map { it.answerIndex }.toSet().size).isAtLeast(2)
    }

    @Test
    fun `distractors are words that sound close to the target`() {
        val target = word("W1", "accept")
        val questions = ListeningRoundBuilder.build(
            targets = listOf(target),
            pool = pool,
            random = Random(1)
        )

        val options = questions.single().options.toSet()
        // "except" and "expect" are the whole reason this exercise exists for an
        // Indian learner; "banana" is not a plausible mishearing of "accept".
        assertThat(options).containsAnyOf("except", "expect", "aspect")
        assertThat(options).doesNotContain("banana")
    }

    @Test
    fun `a word is never offered as its own distractor`() {
        val duplicateSpelling = pool + word("W9", "Accept")
        val questions = ListeningRoundBuilder.build(
            targets = listOf(word("W1", "accept")),
            pool = duplicateSpelling,
            random = Random(11)
        )
        val options = questions.single().options
        assertThat(options.count { it.equals("accept", ignoreCase = true) }).isEqualTo(1)
    }

    @Test
    fun `too few words yields no round rather than a two-option question`() {
        val questions = ListeningRoundBuilder.build(
            targets = pool.take(2),
            pool = pool.take(2),
            random = Random(5)
        )
        assertThat(questions).isEmpty()
    }

    @Test
    fun `sentences are attached by word id and are optional`() {
        val questions = ListeningRoundBuilder.build(
            targets = listOf(pool[0], pool[1]),
            pool = pool,
            sentences = mapOf("W1" to "I accept your offer."),
            random = Random(2)
        )

        assertThat(questions.first { it.word.wordId == "W1" }.sentence)
            .isEqualTo("I accept your offer.")
        assertThat(questions.first { it.word.wordId == "W2" }.sentence).isEmpty()
    }

    @Test
    fun `confusability rates a near-homophone above an unrelated word`() {
        val target = word("W1", "accept", syllables = "ac·cept")
        val near = word("W2", "except", syllables = "ex·cept")
        val far = word("W6", "banana", syllables = "ba·na·na", pos = "noun")

        assertThat(ListeningRoundBuilder.confusability(target, near))
            .isGreaterThan(ListeningRoundBuilder.confusability(target, far))
    }

    @Test
    fun `matching syllable count counts toward confusability`() {
        val target = word("W1", "rely", syllables = "re·ly")
        val sameShape = word("WX", "deny", syllables = "de·ny")
        val longer = word("WY", "reliability", syllables = "re·li·a·bil·i·ty")

        assertThat(ListeningRoundBuilder.confusability(target, sameShape))
            .isGreaterThan(ListeningRoundBuilder.confusability(target, longer))
    }
}
