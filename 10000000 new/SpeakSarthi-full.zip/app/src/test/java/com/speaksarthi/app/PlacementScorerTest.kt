package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.domain.model.CefrLevel
import com.speaksarthi.app.domain.usecase.placement.PlacementAnswer
import com.speaksarthi.app.domain.usecase.placement.PlacementScorer
import org.junit.Test

class PlacementScorerTest {

    private fun answers(level: CefrLevel, correct: Int, wrong: Int): List<PlacementAnswer> =
        List(correct) { PlacementAnswer(level, true) } +
            List(wrong) { PlacementAnswer(level, false) }

    @Test
    fun `the test starts at the easiest band`() {
        assertThat(PlacementScorer.nextLevel(emptyList())).isEqualTo(CefrLevel.A1)
    }

    @Test
    fun `no answers places the learner at the bottom, not below it`() {
        // There is nothing below A1 to offer and no value in saying so.
        assertThat(PlacementScorer.levelFor(emptyList())).isEqualTo(CefrLevel.A1)
    }

    @Test
    fun `two out of three moves the learner up`() {
        val cleared = answers(CefrLevel.A1, correct = 2, wrong = 1)
        assertThat(PlacementScorer.nextLevel(cleared)).isEqualTo(CefrLevel.A2)
    }

    @Test
    fun `one out of three ends the test there`() {
        val failed = answers(CefrLevel.A1, correct = 1, wrong = 2)
        assertThat(PlacementScorer.nextLevel(failed)).isNull()
        assertThat(PlacementScorer.isComplete(failed)).isTrue()
    }

    @Test
    fun `failing a band does not drag the learner below what they cleared`() {
        val answers = answers(CefrLevel.A1, 3, 0) +
            answers(CefrLevel.A2, 3, 0) +
            answers(CefrLevel.B1, 0, 3)

        assertThat(PlacementScorer.levelFor(answers)).isEqualTo(CefrLevel.A2)
    }

    @Test
    fun `clearing everything places the learner at the top band`() {
        val perfect = PlacementScorer.ladder.flatMap { answers(it, 3, 0) }

        assertThat(PlacementScorer.levelFor(perfect)).isEqualTo(CefrLevel.B2)
        assertThat(PlacementScorer.isComplete(perfect)).isTrue()
    }

    @Test
    fun `a band is not cleared until all three of its questions are answered`() {
        // Two right out of two asked is not yet two out of three: the third
        // question still has to be asked.
        val partial = answers(CefrLevel.A1, correct = 2, wrong = 0)

        assertThat(PlacementScorer.nextLevel(partial)).isEqualTo(CefrLevel.A1)
        assertThat(PlacementScorer.levelFor(partial)).isEqualTo(CefrLevel.A1)
    }

    @Test
    fun `the test climbs rather than sampling`() {
        // Every question asked before the first failure is at or below the
        // learner's own level, which is the whole design: someone who finds this
        // hard mostly sees questions they can answer, and finishes early.
        var answered = emptyList<PlacementAnswer>()
        val asked = mutableListOf<CefrLevel>()

        while (true) {
            val next = PlacementScorer.nextLevel(answered) ?: break
            asked += next
            answered = answered + PlacementAnswer(next, wasCorrect = next == CefrLevel.A1)
        }

        assertThat(asked.first()).isEqualTo(CefrLevel.A1)
        // Three A1 questions, then three A2 questions, then it stops.
        assertThat(asked.count { it == CefrLevel.A1 }).isEqualTo(3)
        assertThat(asked).doesNotContain(CefrLevel.B1)
    }

    @Test
    fun `the longest possible test is short`() {
        // Four bands, three questions each. Twelve questions is about two
        // minutes, which is what the intro promises.
        assertThat(PlacementScorer.maximumQuestions).isEqualTo(12)
    }

    @Test
    fun `no result message is a score or a judgement`() {
        CefrLevel.entries.forEach { level ->
            val message = PlacementScorer.resultMessage(level).lowercase()
            assertThat(message).doesNotContain("%")
            assertThat(message).doesNotContain("score")
            assertThat(message).doesNotContain("test")
            assertThat(message).doesNotContain("fail")
            assertThat(message).isNotEmpty()
        }
    }

    @Test
    fun `the beginner message does not make beginning sound like a problem`() {
        val message = PlacementScorer.resultMessage(CefrLevel.A1)
        assertThat(message).contains("most people start")
    }
}
