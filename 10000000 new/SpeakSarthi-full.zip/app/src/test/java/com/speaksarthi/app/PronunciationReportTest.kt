package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.data.speech.AssessedPhoneme
import com.speaksarthi.app.data.speech.AssessedWord
import com.speaksarthi.app.data.speech.AssessmentCandidate
import com.speaksarthi.app.data.speech.AssessmentResponse
import com.speaksarthi.app.data.speech.AssessmentScores
import com.speaksarthi.app.data.speech.SpeechServiceConfig
import com.speaksarthi.app.data.speech.WordScores
import com.speaksarthi.app.data.speech.toReport
import com.speaksarthi.app.domain.model.PhonemeScore
import com.speaksarthi.app.domain.model.PronunciationReport
import com.speaksarthi.app.domain.model.SpokenWordScore
import com.speaksarthi.app.domain.usecase.pronunciation.PhonemeGuide
import kotlinx.serialization.json.Json
import org.junit.Test

/**
 * Parsing the service response, and the config that decides where it is sent.
 *
 * The parser is tested against hand-written JSON in the shape the service
 * actually sends, including the shapes it sends when something went wrong —
 * those are the ones that turn into crashes if a field is assumed present.
 */
class PronunciationReportTest {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    // ---- parsing -----------------------------------------------------------

    @Test
    fun `a successful response maps to a report`() {
        val body = """
            {
              "RecognitionStatus": "Success",
              "DisplayText": "I drink water every morning.",
              "NBest": [
                {
                  "Display": "I drink water every morning.",
                  "PronunciationAssessment": {
                    "AccuracyScore": 82.0,
                    "FluencyScore": 74.5,
                    "CompletenessScore": 100.0,
                    "PronScore": 79.3
                  },
                  "Words": [
                    {
                      "Word": "water",
                      "PronunciationAssessment": { "AccuracyScore": 41.0, "ErrorType": "Mispronunciation" },
                      "Phonemes": [
                        { "Phoneme": "w", "PronunciationAssessment": { "AccuracyScore": 88.0 } },
                        { "Phoneme": "ɔː", "PronunciationAssessment": { "AccuracyScore": 22.0 } }
                      ]
                    }
                  ]
                }
              ]
            }
        """.trimIndent()

        val report = json.decodeFromString(AssessmentResponse.serializer(), body)
            .toReport("I drink water every morning.")

        assertThat(report).isNotNull()
        assertThat(report!!.accuracy).isWithin(0.01f).of(82f)
        assertThat(report.fluency).isWithin(0.01f).of(74.5f)
        assertThat(report.overall).isWithin(0.01f).of(79.3f)
        assertThat(report.words).hasSize(1)
        assertThat(report.words.single().weakPhonemes.map { it.phoneme }).containsExactly("ɔː")
    }

    @Test
    fun `a silent clip is recognised as nothing heard rather than a parse failure`() {
        val body = """{ "RecognitionStatus": "InitialSilenceTimeout", "Offset": 0, "Duration": 0 }"""
        val response = json.decodeFromString(AssessmentResponse.serializer(), body)

        assertThat(response.heardNothing).isTrue()
        assertThat(response.isSuccess).isFalse()
        // And it does not throw on the way to finding that out.
        assertThat(response.toReport("anything")).isNull()
    }

    @Test
    fun `a success with no assessment block yields no report rather than zeroes`() {
        // Seen in practice when the audio is recognised but too short to assess.
        // Reporting 0% here would tell the learner they failed at something the
        // service never actually judged.
        val body = """
            { "RecognitionStatus": "Success", "NBest": [ { "Display": "water" } ] }
        """.trimIndent()

        val report = json.decodeFromString(AssessmentResponse.serializer(), body)
            .toReport("water")
        assertThat(report).isNull()
    }

    @Test
    fun `unknown fields in the response do not break parsing`() {
        val body = """
            {
              "RecognitionStatus": "Success",
              "SomethingNew": { "nested": true },
              "NBest": [
                {
                  "Display": "water",
                  "AlsoNew": 5,
                  "PronunciationAssessment": { "AccuracyScore": 90.0, "PronScore": 90.0 }
                }
              ]
            }
        """.trimIndent()

        val report = json.decodeFromString(AssessmentResponse.serializer(), body).toReport("water")
        assertThat(report).isNotNull()
        assertThat(report!!.accuracy).isWithin(0.01f).of(90f)
    }

    @Test
    fun `a word with no phoneme detail is kept, just without phonemes`() {
        val response = AssessmentResponse(
            recognitionStatus = "Success",
            nBest = listOf(
                AssessmentCandidate(
                    display = "water",
                    assessment = AssessmentScores(accuracy = 70f, pronunciation = 70f),
                    words = listOf(
                        AssessedWord(word = "water", assessment = WordScores(accuracy = 70f))
                    )
                )
            )
        )
        val report = response.toReport("water")
        assertThat(report!!.words.single().phonemes).isEmpty()
        assertThat(report.weakPhonemes).isEmpty()
    }

    @Test
    fun `a phoneme missing its score reads as zero rather than throwing`() {
        val response = AssessmentResponse(
            recognitionStatus = "Success",
            nBest = listOf(
                AssessmentCandidate(
                    assessment = AssessmentScores(accuracy = 50f, pronunciation = 50f),
                    words = listOf(
                        AssessedWord(
                            word = "very",
                            assessment = WordScores(accuracy = 40f, errorType = "Mispronunciation"),
                            phonemes = listOf(AssessedPhoneme(phoneme = "v", assessment = null))
                        )
                    )
                )
            )
        )
        val report = response.toReport("very")
        assertThat(report!!.words.single().phonemes.single().accuracy).isEqualTo(0f)
    }

    // ---- model behaviour ---------------------------------------------------

    @Test
    fun `weak phonemes come back worst first across the whole sentence`() {
        val report = PronunciationReport(
            referenceText = "very think",
            accuracy = 40f,
            fluency = 60f,
            completeness = 100f,
            overall = 45f,
            words = listOf(
                SpokenWordScore(
                    "very", 35f, "Mispronunciation",
                    listOf(PhonemeScore("v", 30f), PhonemeScore("i", 90f))
                ),
                SpokenWordScore(
                    "think", 30f, "Mispronunciation",
                    listOf(PhonemeScore("θ", 12f))
                )
            )
        )
        assertThat(report.weakPhonemes.map { it.phoneme }).containsExactly("θ", "v").inOrder()
    }

    @Test
    fun `the weak-phoneme threshold is loose enough not to punish an accent`() {
        // 65 on a vowel is intelligible Indian English, not an error worth
        // adding to the learner's list of faults.
        assertThat(PhonemeScore("æ", 65f).isWeak).isFalse()
        assertThat(PhonemeScore("æ", 40f).isWeak).isTrue()
    }

    @Test
    fun `an omitted word is not also counted as mispronounced`() {
        val omitted = SpokenWordScore("water", 0f, "Omission")
        assertThat(omitted.wasSkipped).isTrue()
        assertThat(omitted.wasMispronounced).isFalse()
    }

    // ---- configuration -----------------------------------------------------

    @Test
    fun `nothing configured is a supported state, not an error`() {
        val config = SpeechServiceConfig(proxyUrl = "", azureKey = "", azureRegion = "")
        assertThat(config.isConfigured).isFalse()
        assertThat(config.endpoint()).isEmpty()
    }

    @Test
    fun `a proxy url wins over a compiled-in key`() {
        // If both are present the proxy is used: it is the route that does not
        // ship a credential inside the APK.
        val config = SpeechServiceConfig(
            proxyUrl = "https://api.example.com/score",
            azureKey = "secret",
            azureRegion = "centralindia"
        )
        assertThat(config.usesProxy).isTrue()
        assertThat(config.usesAzureDirectly).isFalse()
        assertThat(config.endpoint()).isEqualTo("https://api.example.com/score")
    }

    @Test
    fun `the direct endpoint carries the region and the locale`() {
        val config = SpeechServiceConfig(
            proxyUrl = "",
            azureKey = "secret",
            azureRegion = "centralindia"
        )
        assertThat(config.endpoint()).contains("centralindia.stt.speech.microsoft.com")
        assertThat(config.endpoint()).contains("language=en-IN")
    }

    @Test
    fun `a key without a region is not treated as configured`() {
        val config = SpeechServiceConfig(proxyUrl = "", azureKey = "secret", azureRegion = "")
        assertThat(config.isConfigured).isFalse()
    }

    // ---- the phoneme guide -------------------------------------------------

    @Test
    fun `the guide covers the sounds Hindi speakers actually struggle with`() {
        listOf("v", "w", "θ", "ð", "z", "ə", "r", "ŋ").forEach { symbol ->
            assertThat(PhonemeGuide.isDescribed(symbol)).isTrue()
            val sound = PhonemeGuide.describe(symbol)
            assertThat(sound.name).isNotEmpty()
            assertThat(sound.how).isNotEmpty()
        }
    }

    @Test
    fun `the v entry explains the v-w confusion rather than just naming the sound`() {
        val sound = PhonemeGuide.describe("v")
        assertThat(sound.example).isEqualTo("very")
        assertThat(sound.note.lowercase()).contains("w")
    }

    @Test
    fun `an unlisted symbol gets a placeholder, never an invented tip`() {
        val sound = PhonemeGuide.describe("ʡ")
        assertThat(PhonemeGuide.isDescribed("ʡ")).isFalse()
        assertThat(sound.example).isEmpty()
        assertThat(sound.how).contains("copy what you hear")
    }
}
