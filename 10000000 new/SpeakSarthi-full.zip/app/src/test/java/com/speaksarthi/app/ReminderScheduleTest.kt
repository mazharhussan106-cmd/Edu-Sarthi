package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.domain.usecase.reminders.Reminder
import com.speaksarthi.app.domain.usecase.reminders.ReminderSchedule
import org.junit.Test
import java.time.LocalDateTime

/**
 * The reminder maths, which is small and easy to get subtly wrong in the one way
 * that matters: firing immediately when the learner saves a setting.
 */
class ReminderScheduleTest {

    private val morning = Reminder(slot = 0, hour = 8, minute = 0, enabled = true)

    private fun at(hour: Int, minute: Int = 0) =
        LocalDateTime.of(2026, 9, 16, hour, minute)

    private val hours = 60L * 60 * 1000

    @Test
    fun `a time later today fires today`() {
        assertThat(ReminderSchedule.delayMillis(morning, at(6))).isEqualTo(2 * hours)
    }

    @Test
    fun `a time already past today fires tomorrow`() {
        // Not in thirteen hours' time by accident, and not immediately.
        assertThat(ReminderSchedule.delayMillis(morning, at(19))).isEqualTo(13 * hours)
    }

    @Test
    fun `saving a reminder for the current minute does not fire it now`() {
        // The learner setting an 8am reminder at 8am means tomorrow. Firing
        // straight away reads as a bug and teaches them the app pings for
        // no reason.
        val delay = ReminderSchedule.delayMillis(morning, at(8, 0))
        assertThat(delay).isEqualTo(24 * hours)
    }

    @Test
    fun `a delay is never negative`() {
        ReminderSchedule.defaults.forEach { reminder ->
            (0..23).forEach { hour ->
                assertThat(ReminderSchedule.delayMillis(reminder.copy(enabled = true), at(hour)))
                    .isAtLeast(0)
            }
        }
    }

    @Test
    fun `reminders survive a round trip through storage`() {
        val set = listOf(
            Reminder(0, 7, 15, enabled = true),
            Reminder(1, 13, 0, enabled = false),
            Reminder(2, 22, 45, enabled = true)
        )
        assertThat(ReminderSchedule.parse(ReminderSchedule.serialise(set))).isEqualTo(set)
    }

    @Test
    fun `an empty or corrupt setting falls back to the defaults`() {
        // Losing your reminder times is annoying; a settings screen that will not
        // open is worse.
        assertThat(ReminderSchedule.parse("")).isEqualTo(ReminderSchedule.defaults)
        assertThat(ReminderSchedule.parse("garbage")).isEqualTo(ReminderSchedule.defaults)
        assertThat(ReminderSchedule.parse("99:00:1,08:00:1,21:00:0"))
            .isEqualTo(ReminderSchedule.defaults)
        assertThat(ReminderSchedule.parse("08:00:1")).isEqualTo(ReminderSchedule.defaults)
    }

    @Test
    fun `the defaults are all switched off`() {
        // Offered, never switched on without being asked.
        assertThat(ReminderSchedule.defaults.none { it.enabled }).isTrue()
        assertThat(ReminderSchedule.defaults).hasSize(ReminderSchedule.MAX_REMINDERS)
    }

    @Test
    fun `each slot gets its own work name`() {
        val names = (0 until ReminderSchedule.MAX_REMINDERS).map(ReminderSchedule::workName)
        assertThat(names).containsNoDuplicates()
    }

    @Test
    fun `times read the way a person would say them`() {
        assertThat(Reminder(0, 8, 0, true).display()).isEqualTo("8:00 am")
        assertThat(Reminder(0, 13, 30, true).display()).isEqualTo("1:30 pm")
        assertThat(Reminder(0, 0, 5, true).display()).isEqualTo("12:05 am")
        assertThat(Reminder(0, 12, 0, true).display()).isEqualTo("12:00 pm")
    }

    @Test
    fun `a reminder with something waiting says what is waiting`() {
        val message = ReminderSchedule.message(slot = 0, dueCount = 12, streakDays = 0)
        assertThat(message).contains("12")
    }

    @Test
    fun `a long streak is mentioned rather than the shortfall`() {
        val message = ReminderSchedule.message(slot = 1, dueCount = 5, streakDays = 9)
        assertThat(message).contains("9 days")
    }

    @Test
    fun `no reminder accuses the learner of anything`() {
        val messages = (0 until ReminderSchedule.MAX_REMINDERS).flatMap { slot ->
            listOf(
                ReminderSchedule.message(slot, dueCount = 0, streakDays = 0),
                ReminderSchedule.message(slot, dueCount = 10, streakDays = 0),
                ReminderSchedule.message(slot, dueCount = 10, streakDays = 12)
            )
        }
        messages.forEach { message ->
            val lower = message.lowercase()
            // "You haven't studied today" is true, unhelpful, and the reason
            // notifications get switched off.
            assertThat(lower).doesNotContain("haven't")
            assertThat(lower).doesNotContain("forgot")
            assertThat(lower).doesNotContain("missed")
            assertThat(lower).doesNotContain("don't lose")
            assertThat(message).isNotEmpty()
        }
    }

    @Test
    fun `the three slots do not all say the same thing`() {
        val quiet = (0 until 3).map { ReminderSchedule.message(it, dueCount = 0, streakDays = 0) }
        assertThat(quiet.toSet()).hasSize(3)
    }
}
