package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.domain.model.Progress
import com.speaksarthi.app.domain.model.ReviewGrade
import com.speaksarthi.app.domain.usecase.spacedrepetition.SM2Algorithm
import org.junit.Test

class SM2AlgorithmTest {

    private val day = 24L * 60 * 60 * 1000
    private val now = 1_700_000_000_000L

    @Test
    fun `first successful review schedules one day out`() {
        val result = SM2Algorithm.review(
            previousEaseFactor = 2.5,
            previousIntervalDays = 0,
            previousRepetitions = 0,
            grade = ReviewGrade.Good,
            nowEpochMillis = now
        )

        assertThat(result.newIntervalDays).isEqualTo(1)
        assertThat(result.newRepetitions).isEqualTo(1)
        assertThat(result.nextReviewDateEpochMillis).isEqualTo(now + day)
    }

    @Test
    fun `second successful review schedules six days out`() {
        val result = SM2Algorithm.review(
            previousEaseFactor = 2.5,
            previousIntervalDays = 1,
            previousRepetitions = 1,
            grade = ReviewGrade.Good,
            nowEpochMillis = now
        )

        assertThat(result.newIntervalDays).isEqualTo(6)
        assertThat(result.newRepetitions).isEqualTo(2)
    }

    @Test
    fun `third review multiplies the interval by the ease factor`() {
        val result = SM2Algorithm.review(
            previousEaseFactor = 2.5,
            previousIntervalDays = 6,
            previousRepetitions = 2,
            grade = ReviewGrade.Good,
            nowEpochMillis = now
        )

        // 6 * 2.5 = 15, and Good nudges ease slightly down to 2.5 - 0.0? -> interval
        // is computed from the *new* ease factor, so assert on the rounded product.
        assertThat(result.newIntervalDays).isEqualTo(15)
        assertThat(result.newRepetitions).isEqualTo(3)
    }

    @Test
    fun `a lapse resets repetitions and reschedules for tomorrow`() {
        val result = SM2Algorithm.review(
            previousEaseFactor = 2.5,
            previousIntervalDays = 30,
            previousRepetitions = 5,
            grade = ReviewGrade.Again,
            nowEpochMillis = now
        )

        assertThat(result.newRepetitions).isEqualTo(0)
        assertThat(result.newIntervalDays).isEqualTo(1)
        assertThat(result.nextReviewDateEpochMillis).isEqualTo(now + day)
    }

    @Test
    fun `ease factor never falls below the floor`() {
        var ease = 2.5
        repeat(20) {
            ease = SM2Algorithm.review(
                previousEaseFactor = ease,
                previousIntervalDays = 1,
                previousRepetitions = 0,
                grade = ReviewGrade.Again,
                nowEpochMillis = now
            ).newEaseFactor
        }

        assertThat(ease).isAtLeast(SM2Algorithm.MIN_EASE_FACTOR)
    }

    @Test
    fun `easy grades raise the ease factor and hard grades lower it`() {
        val easy = SM2Algorithm.review(2.5, 6, 2, ReviewGrade.Easy, now).newEaseFactor
        val hard = SM2Algorithm.review(2.5, 6, 2, ReviewGrade.Hard, now).newEaseFactor

        assertThat(easy).isGreaterThan(2.5)
        assertThat(hard).isLessThan(2.5)
    }

    @Test
    fun `apply updates counters as well as the schedule`() {
        val start = Progress(wordId = "VRB-001")

        val afterGood = SM2Algorithm.apply(start, ReviewGrade.Good, now)
        assertThat(afterGood.timesSeen).isEqualTo(1)
        assertThat(afterGood.timesCorrect).isEqualTo(1)
        assertThat(afterGood.lastReviewedAt).isEqualTo(now)

        val afterAgain = SM2Algorithm.apply(afterGood, ReviewGrade.Again, now + day)
        assertThat(afterAgain.timesSeen).isEqualTo(2)
        // Again is a failure, so the correct count must not move.
        assertThat(afterAgain.timesCorrect).isEqualTo(1)
        assertThat(afterAgain.accuracy).isWithin(0.001f).of(0.5f)
    }

    @Test
    fun `a word is only known after three successes and a week-long interval`() {
        var progress = Progress(wordId = "VRB-001")
        var clock = now

        // rep 1 -> 1 day, rep 2 -> 6 days: neither is enough on its own.
        progress = SM2Algorithm.apply(progress, ReviewGrade.Good, clock)
        assertThat(progress.isKnown).isFalse()

        clock += day
        progress = SM2Algorithm.apply(progress, ReviewGrade.Good, clock)
        assertThat(progress.isKnown).isFalse()

        clock += 6 * day
        progress = SM2Algorithm.apply(progress, ReviewGrade.Good, clock)
        assertThat(progress.repetitions).isEqualTo(3)
        assertThat(progress.intervalDays).isAtLeast(7)
        assertThat(progress.isKnown).isTrue()
    }

    @Test
    fun `a lapse takes a known word out of the known set`() {
        var progress = Progress(wordId = "VRB-001")
        var clock = now
        repeat(3) {
            progress = SM2Algorithm.apply(progress, ReviewGrade.Good, clock)
            clock += progress.intervalDays * day
        }
        assertThat(progress.isKnown).isTrue()

        progress = SM2Algorithm.apply(progress, ReviewGrade.Again, clock)
        assertThat(progress.isKnown).isFalse()
    }

    @Test
    fun `quality outside zero to five is clamped rather than throwing`() {
        val tooHigh = SM2Algorithm.compute(SM2Algorithm.Input(2.5, 6, 2, quality = 99), now)
        val tooLow = SM2Algorithm.compute(SM2Algorithm.Input(2.5, 6, 2, quality = -7), now)

        assertThat(tooHigh.newRepetitions).isEqualTo(3)
        assertThat(tooLow.newRepetitions).isEqualTo(0)
    }
}
