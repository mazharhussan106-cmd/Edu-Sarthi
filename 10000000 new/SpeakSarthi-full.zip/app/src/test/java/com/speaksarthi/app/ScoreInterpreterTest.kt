package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.domain.model.PhonemeScore
import com.speaksarthi.app.domain.model.PronunciationReport
import com.speaksarthi.app.domain.model.SpokenWordScore
import com.speaksarthi.app.domain.usecase.pronunciation.ScoreBand
import com.speaksarthi.app.domain.usecase.pronunciation.ScoreInterpreter
import org.junit.Test

/**
 * The interpreter is the file that stands between a learner who is embarrassed
 * about their English and a raw percentage from a service that is measurably
 * harsher on Indian English than on American English. Its rules are product
 * decisions, so they are pinned by tests rather than left to be re-litigated.
 */
class ScoreInterpreterTest {

    private fun word(
        text: String,
        accuracy: Float,
        errorType: String = "None",
        phonemes: List<Pair<String, Float>> = emptyList()
    ) = SpokenWordScore(
        word = text,
        accuracy = accuracy,
        errorType = errorType,
        phonemes = phonemes.map { PhonemeScore(it.first, it.second) }
    )

    private fun report(
        accuracy: Float = 80f,
        fluency: Float = 80f,
        completeness: Float = 100f,
        overall: Float = 80f,
        words: List<SpokenWordScore> = emptyList(),
        reference: String = "I drink water every morning.",
        recognised: String = "I drink water every morning."
    ) = PronunciationReport(
        referenceText = reference,
        accuracy = accuracy,
        fluency = fluency,
        completeness = completeness,
        overall = overall,
        words = words,
        recognisedText = recognised
    )

    // ---- bands -------------------------------------------------------------

    @Test
    fun `high accuracy reads as clear`() {
        assertThat(ScoreInterpreter.bandFor(report(accuracy = 88f))).isEqualTo(ScoreBand.Clear)
    }

    @Test
    fun `band comes off accuracy, not the service overall`() {
        // Careful, slightly slow delivery tanks the fluency score and with it the
        // service's overall. The sounds were right, and that is what is graded:
        // a nervous reader must not be told their pronunciation is poor.
        val careful = report(accuracy = 85f, fluency = 35f, overall = 58f)
        assertThat(ScoreInterpreter.bandFor(careful)).isEqualTo(ScoreBand.Clear)
    }

    @Test
    fun `middling accuracy reads as understandable, not as a failure`() {
        val band = ScoreInterpreter.bandFor(report(accuracy = 66f))
        assertThat(band).isEqualTo(ScoreBand.Understandable)
        assertThat(band.label).isEqualTo("Understandable")
    }

    @Test
    fun `the lowest band is an instruction rather than a verdict`() {
        val reading = ScoreInterpreter.read(report(accuracy = 20f, overall = 22f))
        assertThat(reading.band).isEqualTo(ScoreBand.HardToFollow)
        assertThat(reading.headline).isEqualTo("Say it again")
        // No "poor", "bad", "fail" anywhere in what the learner reads.
        val shown = (reading.headline + " " + reading.detail).lowercase()
        assertThat(shown).doesNotContain("fail")
        assertThat(shown).doesNotContain("poor")
        assertThat(shown).doesNotContain("bad")
    }

    @Test
    fun `no headline is ever a bare percentage`() {
        listOf(95f, 70f, 50f, 10f).forEach { accuracy ->
            val reading = ScoreInterpreter.read(report(accuracy = accuracy, overall = accuracy))
            assertThat(reading.headline).doesNotContain("%")
            assertThat(reading.headline.toIntOrNull()).isNull()
        }
    }

    @Test
    fun `raw numbers are kept so they can be shown on request`() {
        val reading = ScoreInterpreter.read(
            report(accuracy = 71.6f, fluency = 64.2f, completeness = 100f, overall = 69.4f)
        )
        assertThat(reading.rawAccuracy).isEqualTo(71)
        assertThat(reading.rawFluency).isEqualTo(64)
        assertThat(reading.rawCompleteness).isEqualTo(100)
        assertThat(reading.rawOverall).isEqualTo(69)
    }

    // ---- completeness is a separate problem --------------------------------

    @Test
    fun `skipping words is reported as words missing, not as poor pronunciation`() {
        val reading = ScoreInterpreter.read(
            report(
                accuracy = 90f,
                completeness = 40f,
                words = listOf(
                    word("I", 95f),
                    word("drink", 92f),
                    word("water", 0f, errorType = "Omission"),
                    word("every", 0f, errorType = "Omission")
                )
            )
        )

        assertThat(reading.headline).isEqualTo("Some of the sentence was missing")
        assertThat(reading.skippedWords).containsExactly("water", "every")
        assertThat(reading.detail).contains("left out")
    }

    @Test
    fun `a full sentence is not flagged as incomplete`() {
        val reading = ScoreInterpreter.read(report(completeness = 100f, accuracy = 90f))
        assertThat(reading.skippedWords).isEmpty()
        assertThat(reading.band).isEqualTo(ScoreBand.Clear)
    }

    // ---- the one thing to fix ----------------------------------------------

    @Test
    fun `a low band always comes with one specific fix`() {
        val reading = ScoreInterpreter.read(
            report(
                accuracy = 48f,
                words = listOf(
                    word("very", 40f, "Mispronunciation", listOf("v" to 22f, "e" to 80f)),
                    word("good", 85f, phonemes = listOf("g" to 88f))
                )
            )
        )

        assertThat(reading.band).isEqualTo(ScoreBand.NeedsWork)
        assertThat(reading.nextFix).isNotNull()
        assertThat(reading.nextFix!!.phoneme).isEqualTo("v")
        assertThat(reading.nextFix.inWord).isEqualTo("very")
        // The detail is the fix, not a restatement of the score.
        assertThat(reading.detail).contains("very")
    }

    @Test
    fun `the fix names exactly one sound even when several were weak`() {
        val reading = ScoreInterpreter.read(
            report(
                accuracy = 40f,
                words = listOf(
                    word("think", 30f, "Mispronunciation", listOf("θ" to 15f, "ɪ" to 40f)),
                    word("very", 35f, "Mispronunciation", listOf("v" to 25f))
                )
            )
        )
        assertThat(reading.nextFix).isNotNull()
        // Worst word first, then its worst phoneme.
        assertThat(reading.nextFix!!.inWord).isEqualTo("think")
        assertThat(reading.nextFix.phoneme).isEqualTo("θ")
    }

    @Test
    fun `a weak phoneme inside an otherwise fine word is not the top fix`() {
        val reading = ScoreInterpreter.read(
            report(
                accuracy = 55f,
                words = listOf(
                    word("water", 90f, phonemes = listOf("ɔː" to 55f)),
                    word("very", 38f, "Mispronunciation", listOf("v" to 30f))
                )
            )
        )
        assertThat(reading.nextFix!!.inWord).isEqualTo("very")
    }

    @Test
    fun `no phoneme detail means no invented fix`() {
        val reading = ScoreInterpreter.read(report(accuracy = 50f, words = listOf(word("very", 40f))))
        assertThat(reading.nextFix).isNull()
        // But there is still something to do.
        assertThat(reading.detail).isNotEmpty()
    }

    @Test
    fun `advice for a known trouble sound describes a mouth movement`() {
        val advice = ScoreInterpreter.adviceFor(
            PhonemeScore("v", 20f),
            word("very", 30f, "Mispronunciation")
        )
        assertThat(advice).contains("very")
        assertThat(advice.lowercase()).contains("teeth")
        // Not phonetic terminology.
        assertThat(advice.lowercase()).doesNotContain("fricative")
    }

    @Test
    fun `an unknown sound gets an honest line rather than a made-up one`() {
        val advice = ScoreInterpreter.adviceFor(
            PhonemeScore("ʔ", 20f),
            word("uh-oh", 30f)
        )
        assertThat(advice).contains("unclear")
        assertThat(advice).contains("Play the model")
    }

    // ---- what was heard ----------------------------------------------------

    @Test
    fun `hearing a different word is flagged`() {
        val reading = ScoreInterpreter.read(
            report(
                reference = "The wine is cold.",
                recognised = "The vine is cold."
            )
        )
        assertThat(reading.heardSomethingElse).isTrue()
    }

    @Test
    fun `punctuation and case differences are not flagged as mishearings`() {
        val reading = ScoreInterpreter.read(
            report(
                reference = "I drink water every morning.",
                recognised = "i drink water every morning"
            )
        )
        assertThat(reading.heardSomethingElse).isFalse()
    }

    @Test
    fun `an empty transcript is not treated as a mishearing`() {
        assertThat(ScoreInterpreter.heardSomethingElse(report(recognised = ""))).isFalse()
    }

    // ---- marking -----------------------------------------------------------

    @Test
    fun `words to mark cover both mispronounced and skipped words, lowercased`() {
        val reading = ScoreInterpreter.read(
            report(
                accuracy = 55f,
                completeness = 80f,
                words = listOf(
                    word("Very", 30f, "Mispronunciation", listOf("v" to 20f)),
                    word("Water", 0f, errorType = "Omission"),
                    word("cold", 92f)
                )
            )
        )
        assertThat(reading.wordsToMark).containsExactly("very", "water")
    }

    @Test
    fun `the reading carries the sentence so the screen can mark it up`() {
        val reading = ScoreInterpreter.read(report(reference = "I drink water every morning."))
        assertThat(reading.reference).isEqualTo("I drink water every morning.")
    }

    @Test
    fun `a clear but halting attempt gets coaching on flow, not a lower band`() {
        val reading = ScoreInterpreter.read(report(accuracy = 90f, fluency = 40f))
        assertThat(reading.band).isEqualTo(ScoreBand.Clear)
        assertThat(reading.detail).contains("halting")
    }
}
