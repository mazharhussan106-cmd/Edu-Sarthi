package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.domain.usecase.pronunciation.SpeechBudget
import org.junit.Test

/**
 * What a clip counts for in the daily statistics.
 *
 * Much smaller than it used to be, because this object used to be the paywall
 * and is not any more — the gate moved to the server, where the app cannot talk
 * its way past it. The tests that covered the old local cap were deleted rather
 * than adapted: they tested a control that no longer exists, and a passing test
 * for a rule nobody enforces is worse than no test at all.
 */
class SpeechBudgetTest {

    @Test
    fun `a whole number of seconds counts as itself`() {
        assertThat(SpeechBudget.costOf(5_000)).isEqualTo(5)
    }

    @Test
    fun `a part second rounds up`() {
        // A statistic that rounds effort down discourages the person reading it.
        assertThat(SpeechBudget.costOf(1_200)).isEqualTo(2)
        assertThat(SpeechBudget.costOf(14_100)).isEqualTo(15)
    }

    @Test
    fun `the shortest possible clip still counts for a second`() {
        assertThat(SpeechBudget.costOf(1)).isEqualTo(SpeechBudget.MINIMUM_COST_SECONDS)
    }

    @Test
    fun `a negative duration cannot produce a negative count`() {
        // Not hypothetical: a clock adjustment mid-recording has produced one
        // before, and a negative here would subtract from the day's total.
        assertThat(SpeechBudget.costOf(-5_000)).isEqualTo(SpeechBudget.MINIMUM_COST_SECONDS)
    }
}
