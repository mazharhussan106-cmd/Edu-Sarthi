package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.domain.model.DailyStat
import com.speaksarthi.app.domain.usecase.stats.StatsCalculator
import org.junit.Test
import java.time.LocalDate

class StatsCalculatorTest {

    private val today = LocalDate.of(2026, 9, 16)

    private fun day(daysAgo: Int, words: Int = 0, seconds: Int = 0, recordings: Int = 0) =
        DailyStat(
            date = today.minusDays(daysAgo.toLong()).toString(),
            wordsStudied = words,
            studySeconds = seconds,
            recordingsMade = recordings
        )

    @Test
    fun `the window always has a row for every day, including empty ones`() {
        val summary = StatsCalculator.summarise(listOf(day(0, words = 5)), today)

        assertThat(summary.days).hasSize(StatsCalculator.WINDOW_DAYS)
        // A chart that silently drops the days you did nothing shows an unbroken
        // run of effort that never happened.
        assertThat(summary.days.count { !it.isActive }).isEqualTo(StatsCalculator.WINDOW_DAYS - 1)
    }

    @Test
    fun `days come back oldest first, ending on today`() {
        val summary = StatsCalculator.summarise(emptyList(), today)

        assertThat(summary.days.last().date).isEqualTo(today)
        assertThat(summary.days.first().date)
            .isEqualTo(today.minusDays((StatsCalculator.WINDOW_DAYS - 1).toLong()))
    }

    @Test
    fun `this week means the last seven days, not a calendar week`() {
        // A learner opening this on a Monday morning must not be told they have
        // done nothing this week.
        val stats = (0..6).map { day(it, words = 2) } + (7..13).map { day(it, words = 10) }
        val summary = StatsCalculator.summarise(stats, today)

        assertThat(summary.wordsThisWeek).isEqualTo(14)
        assertThat(summary.wordsLastWeek).isEqualTo(70)
    }

    @Test
    fun `week on week change is a fraction of last week`() {
        val stats = (0..6).map { day(it, words = 10) } + (7..13).map { day(it, words = 5) }
        val summary = StatsCalculator.summarise(stats, today)

        // 70 against 35.
        assertThat(summary.weekOnWeekChange).isWithin(0.001f).of(1f)
    }

    @Test
    fun `a first week has nothing to compare against rather than a made-up figure`() {
        val summary = StatsCalculator.summarise(listOf(day(0, words = 10)), today)

        assertThat(summary.weekOnWeekChange).isNull()
    }

    @Test
    fun `an empty history produces zeroes rather than a crash`() {
        val summary = StatsCalculator.summarise(emptyList(), today)

        assertThat(summary.hasAnyActivity).isFalse()
        assertThat(summary.wordsThisWeek).isEqualTo(0)
        assertThat(summary.accuracy).isEqualTo(0f)
        assertThat(summary.bestDayWords).isEqualTo(0)
        assertThat(summary.weekOnWeekChange).isNull()
    }

    @Test
    fun `accuracy is quizzes right over quizzes answered, and never divides by zero`() {
        val stats = listOf(
            DailyStat(date = today.toString(), quizzesAnswered = 10, quizzesCorrect = 7)
        )
        assertThat(StatsCalculator.summarise(stats, today).accuracy).isWithin(0.001f).of(0.7f)
        assertThat(StatsCalculator.summarise(emptyList(), today).accuracy).isEqualTo(0f)
    }

    @Test
    fun `minutes come from seconds, rounded down`() {
        val summary = StatsCalculator.summarise(listOf(day(0, seconds = 599)), today)
        assertThat(summary.minutesThisWeek).isEqualTo(9)
    }

    @Test
    fun `rows outside the window are ignored rather than folded in`() {
        val stats = listOf(day(0, words = 3), day(40, words = 500))
        val summary = StatsCalculator.summarise(stats, today)

        assertThat(summary.bestDayWords).isEqualTo(3)
        assertThat(summary.days.sumOf { it.wordsStudied }).isEqualTo(3)
    }

    @Test
    fun `active days counts any kind of activity, not just words`() {
        val stats = listOf(day(0, recordings = 1), day(1, words = 4))
        val summary = StatsCalculator.summarise(stats, today)

        assertThat(summary.activeDaysThisWeek).isEqualTo(2)
    }
}
