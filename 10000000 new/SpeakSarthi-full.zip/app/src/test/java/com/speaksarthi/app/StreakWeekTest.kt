package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.domain.usecase.credits.StreakWeek
import org.junit.Test
import java.time.LocalDate

/**
 * Which week a streak bonus belongs to.
 *
 * Worth testing because both ways of being wrong are silent and both are about
 * money: a reference that changes too often pays a weekly bonus several times a
 * week, and one that changes too rarely stops paying it at all.
 */
class StreakWeekTest {

    @Test
    fun `every day of one week shares a reference`() {
        // Monday 14 September 2026 through Sunday the 20th.
        val week = (14..20).map { StreakWeek.reference(LocalDate.of(2026, 9, it)) }

        assertThat(week.distinct()).hasSize(1)
    }

    @Test
    fun `the next week gets a different reference`() {
        val sunday = StreakWeek.reference(LocalDate.of(2026, 9, 20))
        val monday = StreakWeek.reference(LocalDate.of(2026, 9, 21))

        assertThat(monday).isNotEqualTo(sunday)
    }

    @Test
    fun `the turn of the year does not reuse a reference`() {
        // The trap. Under ISO rules, 31 December 2025 falls in week 1 — of 2026,
        // not 2025. Pairing that week number with the calendar year would emit
        // "2025-W1" in December and again in early January, and the server,
        // having already paid "2025-W1", would never pay the second one.
        val december = StreakWeek.reference(LocalDate.of(2025, 12, 31))
        val january = StreakWeek.reference(LocalDate.of(2026, 1, 1))

        assertThat(december).isEqualTo("2026-W1")
        assertThat(january).isEqualTo("2026-W1")
        // Same ISO week, so the same reference — correct, and exactly one
        // payment for one week of practice.
        assertThat(december).isEqualTo(january)
    }

    @Test
    fun `a week in the previous year keeps that year`() {
        val earlyJanuary = StreakWeek.reference(LocalDate.of(2027, 1, 1))

        // 1 January 2027 is a Friday, still in ISO week 53 of 2026.
        assertThat(earlyJanuary).isEqualTo("2026-W53")
    }

    @Test
    fun `a bonus is due only after a full week`() {
        assertThat(StreakWeek.isDue(6)).isFalse()
        assertThat(StreakWeek.isDue(7)).isTrue()
        assertThat(StreakWeek.isDue(70)).isTrue()
    }

    @Test
    fun `a broken streak is not due`() {
        assertThat(StreakWeek.isDue(0)).isFalse()
    }
}
