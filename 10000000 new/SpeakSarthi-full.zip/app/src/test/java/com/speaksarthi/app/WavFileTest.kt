package com.speaksarthi.app

import com.google.common.truth.Truth.assertThat
import com.speaksarthi.app.data.audio.WavFile
import org.junit.Test
import java.io.File

/**
 * The WAV header is hand-written, and a header that is wrong by one field
 * produces a file that plays perfectly on the phone and is rejected by the
 * scoring service with a generic error — the worst possible failure mode,
 * because it looks like the service is broken. So it is checked byte by byte.
 */
class WavFileTest {

    private fun int32At(bytes: ByteArray, offset: Int): Int =
        (bytes[offset].toInt() and 0xFF) or
            ((bytes[offset + 1].toInt() and 0xFF) shl 8) or
            ((bytes[offset + 2].toInt() and 0xFF) shl 16) or
            ((bytes[offset + 3].toInt() and 0xFF) shl 24)

    private fun int16At(bytes: ByteArray, offset: Int): Int =
        (bytes[offset].toInt() and 0xFF) or ((bytes[offset + 1].toInt() and 0xFF) shl 8)

    private fun asciiAt(bytes: ByteArray, offset: Int, length: Int): String =
        String(bytes, offset, length, Charsets.US_ASCII)

    @Test
    fun `header is exactly 44 bytes`() {
        assertThat(WavFile.header(dataBytes = 1000)).hasLength(WavFile.HEADER_BYTES)
    }

    @Test
    fun `chunk identifiers are in the right places`() {
        val header = WavFile.header(dataBytes = 0)
        assertThat(asciiAt(header, 0, 4)).isEqualTo("RIFF")
        assertThat(asciiAt(header, 8, 4)).isEqualTo("WAVE")
        assertThat(asciiAt(header, 12, 4)).isEqualTo("fmt ")
        assertThat(asciiAt(header, 36, 4)).isEqualTo("data")
    }

    @Test
    fun `format block describes 16 kHz mono 16-bit PCM`() {
        val header = WavFile.header(dataBytes = 0)

        assertThat(int32At(header, 16)).isEqualTo(16)   // fmt chunk size
        assertThat(int16At(header, 20)).isEqualTo(1)    // PCM
        assertThat(int16At(header, 22)).isEqualTo(1)    // mono
        assertThat(int32At(header, 24)).isEqualTo(16_000)
        assertThat(int16At(header, 34)).isEqualTo(16)   // bits per sample
    }

    @Test
    fun `byte rate and block align follow from the format`() {
        val header = WavFile.header(dataBytes = 0)
        // 16000 samples x 1 channel x 2 bytes.
        assertThat(int32At(header, 28)).isEqualTo(32_000)
        assertThat(int16At(header, 32)).isEqualTo(2)
    }

    @Test
    fun `the two length fields are consistent with the payload`() {
        val payload = 4_096L
        val header = WavFile.header(dataBytes = payload)

        // RIFF size is everything after that field: 36 + payload.
        assertThat(int32At(header, 4)).isEqualTo((payload + WavFile.HEADER_BYTES - 8).toInt())
        assertThat(int32At(header, 40)).isEqualTo(payload.toInt())
    }

    @Test
    fun `multi-byte fields are little-endian`() {
        // 16000 is 0x00003E80. Little-endian puts 0x80 first; a big-endian
        // header would put 0x00 there and the service would read the sample
        // rate as something absurd.
        val header = WavFile.header(dataBytes = 0)
        assertThat(header[24]).isEqualTo(0x80.toByte())
        assertThat(header[25]).isEqualTo(0x3E.toByte())
    }

    @Test
    fun `finalise corrects the lengths and returns the payload size`() {
        val file = File.createTempFile("clip", ".wav")
        try {
            WavFile.writePlaceholderHeader(file)
            assertThat(file.length()).isEqualTo(WavFile.HEADER_BYTES.toLong())

            // One second of silence.
            file.appendBytes(ByteArray(WavFile.bytesPerSecond()))

            val payload = WavFile.finalise(file)
            assertThat(payload).isEqualTo(WavFile.bytesPerSecond().toLong())

            val header = file.readBytes().copyOfRange(0, WavFile.HEADER_BYTES)
            assertThat(int32At(header, 40)).isEqualTo(WavFile.bytesPerSecond())
        } finally {
            file.delete()
        }
    }

    @Test
    fun `placeholder header overwrites whatever was there before`() {
        val file = File.createTempFile("clip", ".wav")
        try {
            file.writeBytes(ByteArray(9_000) { 7 })
            WavFile.writePlaceholderHeader(file)
            assertThat(file.length()).isEqualTo(WavFile.HEADER_BYTES.toLong())
        } finally {
            file.delete()
        }
    }

    @Test
    fun `duration comes from the file size`() {
        val file = File.createTempFile("clip", ".wav")
        try {
            WavFile.writePlaceholderHeader(file)
            file.appendBytes(ByteArray(WavFile.bytesPerSecond() * 3))
            WavFile.finalise(file)

            assertThat(WavFile.durationMillis(file)).isEqualTo(3_000)
        } finally {
            file.delete()
        }
    }

    @Test
    fun `a file with only a header has no duration and no payload`() {
        val file = File.createTempFile("clip", ".wav")
        try {
            WavFile.writePlaceholderHeader(file)
            assertThat(WavFile.finalise(file)).isEqualTo(0)
            assertThat(WavFile.durationMillis(file)).isEqualTo(0)
        } finally {
            file.delete()
        }
    }

    @Test
    fun `a truncated file does not produce a negative duration`() {
        val file = File.createTempFile("clip", ".wav")
        try {
            file.writeBytes(ByteArray(10))
            assertThat(WavFile.finalise(file)).isEqualTo(0)
            assertThat(WavFile.durationMillis(file)).isEqualTo(0)
        } finally {
            file.delete()
        }
    }

    @Test
    fun `the recording cap converts to a byte count`() {
        // Fifteen seconds is the product cap; at 32 kB a second that is 480 kB,
        // which is what the recorder stops at.
        assertThat(WavFile.byteCountFor(15_000)).isEqualTo(15 * 32_000)
    }
}
