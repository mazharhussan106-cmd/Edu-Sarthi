#!/usr/bin/env python3
"""
Speak Sarthi — seed data builder.

Reads the finished 1000-word rich flashcard workbook produced for WordMaster
(`WordMaster1000_FlashcardTemplate_COMPLETE_1000words.xlsx`, 54 columns x 1000
rows) and emits the JSON seed files the Android app imports on first run.

Four outputs, all keyed on the workbook's stable `Word ID` (VRB-001, PHR-042…):

    words.json          one row per word, the flashcard's parts 1 and 2
    chunks.json         derived — collocations, phrasal expressions, grammar
                        patterns, split out as individually learnable units
    practice_items.json derived — every example sentence and usage line, i.e.
                        the prompts a learner records for pronunciation scoring
    quiz_items.json     derived — the MCQ, fill-in-the-blank, find-and-fix and
                        translation exercises already written per word

Nothing here invents content. Every field is lifted from the workbook; the only
transformations are splitting delimited cells, parsing the A/B/C/D option block,
and separating the `**marker**` emphasis from clean sentence text.

Usage:
    python3 build_seed.py [--workbook PATH] [--out DIR]
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

try:
    import openpyxl
except ImportError:  # pragma: no cover
    sys.exit("openpyxl is required:  pip install openpyxl --break-system-packages")


DEFAULT_WORKBOOK = Path(
    "/home/claude/wm1000_build/WordMaster1000_FlashcardTemplate_COMPLETE_1000words.xlsx"
)
DEFAULT_OUT = Path(__file__).resolve().parent.parent / "app/src/main/assets/seed"

SHEET = "1000 Words"
HEADER_ROW = 2  # row 1 is the merged section banner

# Artwork is produced separately and dropped in later; see docs/ILLUSTRATIONS.md.
# WebP because it is roughly a third the size of PNG at the same quality, which
# matters when the audience is on budget Android phones.
ILLUSTRATION_EXTENSION = ".webp"

# Workbook column header -> our field name. Anything not listed is intentionally
# dropped (the banner row, and the informational "Spaced Repetition Plan" column,
# which the SM-2 engine supersedes).
WORD_FIELDS = {
    "Word ID": "wordId",
    "Word": "word",
    "Part of Speech": "partOfSpeech",
    "Category": "category",
    "CEFR Level (AI-est.)": "cefrLevel",
    "Frequency (AI-est.)": "frequency",
    "Importance (AI-est.)": "importance",
    "Register": "register",
    "IPA": "ipa",
    "Syllable Break & Stress": "syllableBreak",
    "Hindi Pronunciation": "hindiPronunciation",
    "Hindi Meaning": "hindiMeaning",
    "Simple Meaning": "simpleMeaning",
    "Plain Explanation": "plainExplanation",
    "Etymology": "etymology",
    "Mnemonic": "mnemonic",
    "Quick Tip": "quickTip",
    "Pronunciation Tip": "pronunciationTip",
    "Spelling Tip": "spellingTip",
    "Word Family": "wordFamily",
    "Prefix / Root / Suffix": "prefixRootSuffix",
    "Visual Association": "visualAssociation",
    "Tone": "tone",
    "Typical Contexts": "typicalContexts",
    "Mini Conversation": "miniConversation",
    "Confusing Words": "confusingWords",
    "Related Words": "relatedWords",
    "Synonyms": "synonyms",
    "Antonyms": "antonyms",
    "Emotion / Feel": "emotionFeel",
    "Common Mistake (Wrong)": "commonMistakeWrong",
    "Common Mistake (Correct)": "commonMistakeCorrect",
    "Quick-Recall Prompt (Reverse)": "quickRecallPrompt",
}

# Sentence columns that become recordable speaking prompts, in the order a
# learner should meet them: the simple one first, then the harder variants,
# then the three register-specific usage lines.
PRACTICE_COLUMNS = [
    ("Example Sentence (Simple)", "EXAMPLE", 0),
    ("Example Sentence 1", "EXAMPLE", 1),
    ("Example Sentence 2", "EXAMPLE", 2),
    ("Example Sentence 3", "EXAMPLE", 3),
    ("Everyday Scene", "EVERYDAY", 4),
    ("News/Media Style", "NEWS", 5),
    ("Casual Conversation", "CASUAL", 6),
]

MARKER = re.compile(r"\*\*(.+?)\*\*")
OPTION_LINE = re.compile(r"^\s*([A-D])\s*[\)\.\:]\s*(.+?)\s*$")


def clean(value) -> str:
    """Normalise a cell to a trimmed string. Blank cells become empty strings."""
    if value is None:
        return ""
    return str(value).replace("\r\n", "\n").replace("\r", "\n").strip()


def split_list(value: str) -> list[str]:
    """Split a delimited cell into parts. The workbook mixes ';' and ',' — both are used."""
    if not value:
        return []
    parts = re.split(r"[;,]", value) if ";" in value or "," in value else [value]
    return [p.strip() for p in parts if p.strip()]


def strip_markers(text: str) -> tuple[str, str]:
    """Return (clean_text, highlighted_term). `I **understand** it` -> ('I understand it', 'understand')."""
    if not text:
        return "", ""
    found = MARKER.search(text)
    highlight = found.group(1) if found else ""
    return MARKER.sub(r"\1", text).strip(), highlight


def parse_mcq(question: str, option_block: str, answer_letter: str) -> dict | None:
    """Parse the `A) …\\nB) …` option block into a list plus a zero-based answer index."""
    if not question or not option_block:
        return None

    options: list[str] = []
    letters: list[str] = []
    for line in option_block.split("\n"):
        match = OPTION_LINE.match(line)
        if match:
            letters.append(match.group(1))
            options.append(match.group(2))

    if len(options) < 2:
        return None

    letter = (answer_letter or "").strip().upper()[:1]
    answer_index = letters.index(letter) if letter in letters else 0

    return {"question": question, "options": options, "answerIndex": answer_index}


def build(workbook_path: Path, out_dir: Path) -> dict:
    workbook = openpyxl.load_workbook(workbook_path, read_only=True, data_only=True)
    if SHEET not in workbook.sheetnames:
        sys.exit(f"Sheet {SHEET!r} not found. Sheets present: {workbook.sheetnames}")

    sheet = workbook[SHEET]
    rows = sheet.iter_rows(min_row=HEADER_ROW, values_only=True)
    header = [clean(h) for h in next(rows)]
    index = {name: position for position, name in enumerate(header)}

    missing = [column for column in WORD_FIELDS if column not in index]
    if missing:
        sys.exit(f"Workbook is missing expected columns: {missing}")

    def cell(row, column_name: str) -> str:
        position = index.get(column_name)
        return clean(row[position]) if position is not None else ""

    words: list[dict] = []
    chunks: list[dict] = []
    practice: list[dict] = []
    quizzes: list[dict] = []
    seen_ids: set[str] = set()
    warnings: list[str] = []

    for row_number, row in enumerate(rows, start=HEADER_ROW + 1):
        word_id = cell(row, "Word ID")
        surface = cell(row, "Word")

        if not word_id or not surface:
            warnings.append(f"row {row_number}: missing Word ID or Word — skipped")
            continue
        if word_id in seen_ids:
            warnings.append(f"row {row_number}: duplicate Word ID {word_id} — skipped")
            continue
        seen_ids.add(word_id)

        # ---- the word itself -------------------------------------------------
        record = {field: cell(row, column) for column, field in WORD_FIELDS.items()}

        # Synonyms/antonyms/related are lists everywhere they are shown, so split
        # them once here rather than in five different places in the app.
        for field, column in (
            ("synonyms", "Synonyms"),
            ("antonyms", "Antonyms"),
            ("relatedWords", "Related Words"),
            ("wordFamily", "Word Family"),
            ("typicalContexts", "Typical Contexts"),
        ):
            record[field] = split_list(cell(row, column))

        # Illustration filename by convention: VRB-001 -> VRB-001.webp. Emitted
        # for every word even though no artwork exists yet, so the card can
        # reserve the right space now and the images can be dropped in later
        # without a content regeneration or a schema change.
        record["illustration"] = f"{word_id}{ILLUSTRATION_EXTENSION}"

        record["orderIndex"] = len(words)
        words.append(record)

        # ---- chunks ----------------------------------------------------------
        # These three columns are what makes this a *spoken* English app rather
        # than a vocabulary list: the learner memorises the block, not the word.
        for column, chunk_type in (
            ("Collocations", "COLLOCATION"),
            ("Phrasal / Related Expressions", "PHRASAL"),
        ):
            for position, text in enumerate(split_list(cell(row, column))):
                chunks.append(
                    {
                        "wordId": word_id,
                        "chunkId": f"{word_id}-{chunk_type[:4]}-{position + 1:02d}",
                        "text": text,
                        "type": chunk_type,
                        "orderIndex": position,
                    }
                )

        pattern = cell(row, "Grammar Pattern")
        if pattern:
            # Kept whole — a grammar pattern reads as one unit and splitting it
            # on its commas would shred the worked examples in the parentheses.
            chunks.append(
                {
                    "wordId": word_id,
                    "chunkId": f"{word_id}-PATT-01",
                    "text": pattern,
                    "type": "PATTERN",
                    "orderIndex": 0,
                }
            )

        # ---- speaking prompts ------------------------------------------------
        for column, prompt_type, order in PRACTICE_COLUMNS:
            raw = cell(row, column)
            if not raw:
                continue
            text, highlight = strip_markers(raw)
            practice.append(
                {
                    "wordId": word_id,
                    "itemId": f"{word_id}-SPK-{order:02d}",
                    "text": text,
                    "highlight": highlight or surface,
                    "type": prompt_type,
                    "orderIndex": order,
                }
            )

        conversation = cell(row, "Mini Conversation")
        if conversation:
            practice.append(
                {
                    "wordId": word_id,
                    "itemId": f"{word_id}-SPK-07",
                    "text": conversation,
                    "highlight": surface,
                    "type": "CONVERSATION",
                    "orderIndex": 7,
                }
            )

        # ---- quiz items ------------------------------------------------------
        quiz = {"wordId": word_id}

        mcq = parse_mcq(
            cell(row, "Multiple Choice Question"),
            cell(row, "Multiple Choice Options"),
            cell(row, "MCQ Answer"),
        )
        if mcq:
            quiz["mcq"] = mcq
        else:
            warnings.append(f"row {row_number} ({word_id}): MCQ could not be parsed")

        blank_prompt = cell(row, "Fill in the Blank")
        blank_answer = cell(row, "Fill-in-the-Blank Answer")
        if blank_prompt and blank_answer:
            quiz["fillBlank"] = {"prompt": blank_prompt, "answer": blank_answer}

        wrong = cell(row, "Find & Fix (Wrong)")
        corrected = cell(row, "Find & Fix (Corrected)")
        if wrong and corrected:
            quiz["findFix"] = {"wrong": wrong, "corrected": corrected}

        hindi_prompt = cell(row, "Translate to English (Hindi prompt)")
        translation = cell(row, "Translate Answer")
        if hindi_prompt and translation:
            quiz["translate"] = {"prompt": hindi_prompt, "answer": translation}

        # The fifth practice-zone exercise. Open-ended — there is no answer to
        # check, so the app stores what the learner writes and shows it back on
        # the next review rather than grading it.
        own_sentence = cell(row, "Write-Your-Own-Sentence Prompt")
        if own_sentence:
            quiz["writeYourOwn"] = own_sentence

        if len(quiz) > 1:
            quizzes.append(quiz)

    out_dir.mkdir(parents=True, exist_ok=True)
    payloads = {
        "words.json": words,
        "chunks.json": chunks,
        "practice_items.json": practice,
        "quiz_items.json": quizzes,
    }
    for filename, payload in payloads.items():
        target = out_dir / filename
        target.write_text(
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
            encoding="utf-8",
        )

    return {
        "words": len(words),
        "chunks": len(chunks),
        "practice": len(practice),
        "quizzes": len(quizzes),
        "warnings": warnings,
        "files": {name: (out_dir / name).stat().st_size for name in payloads},
        "cefr": _tally(words, "cefrLevel"),
        "pos": _tally(words, "partOfSpeech"),
        "chunk_types": _tally(chunks, "type"),
    }


def _tally(rows: list[dict], field: str) -> dict:
    counts: dict[str, int] = {}
    for row in rows:
        counts[row.get(field, "")] = counts.get(row.get(field, ""), 0) + 1
    return dict(sorted(counts.items(), key=lambda pair: -pair[1]))


def main() -> None:
    parser = argparse.ArgumentParser(description="Build Speak Sarthi seed data")
    parser.add_argument("--workbook", type=Path, default=DEFAULT_WORKBOOK)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()

    if not args.workbook.exists():
        sys.exit(f"Workbook not found: {args.workbook}")

    result = build(args.workbook, args.out)

    print(f"words            {result['words']:>6}")
    print(f"chunks           {result['chunks']:>6}   {result['chunk_types']}")
    print(f"practice prompts {result['practice']:>6}")
    print(f"quiz sets        {result['quizzes']:>6}")
    print()
    print("CEFR:", result["cefr"])
    print("POS :", result["pos"])
    print()
    for name, size in result["files"].items():
        print(f"  {name:<22} {size / 1024:8.1f} KB")
    if result["warnings"]:
        print(f"\n{len(result['warnings'])} warning(s):")
        for warning in result["warnings"][:25]:
            print("  -", warning)
    else:
        print("\nno warnings")


if __name__ == "__main__":
    main()
