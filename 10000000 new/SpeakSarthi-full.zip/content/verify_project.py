#!/usr/bin/env python3
"""
Static checks for the Speak Sarthi scaffold.

There is no Android toolchain in this sandbox (dl.google.com and
repo.maven.apache.org are not reachable), so the project cannot be compiled
here. These checks catch the classes of mistake that would otherwise only
surface on the first real build:

  1. Seed JSON keys must match the serializable DTO fields exactly. kotlinx
     .serialization is configured to ignore unknown keys, so a renamed field
     would not throw — it would silently import blank strings for every word,
     which is far worse than a crash.
  2. Every column named in a Room @Query must exist on the entity for that
     table. Room catches this at compile time, but catching it here saves a
     round trip through Android Studio.
  3. Brace, paren and bracket balance per Kotlin file.
  4. Entity/DAO/database registration consistency.
  5. Every `import com.speaksarthi.app.…` resolves to a real declaration.
     This is the check that catches a screen calling a view-model method
     that was renamed, or a composable moved between files.
  6. No fully-qualified app types in code — a style rule, but one that hides
     exactly the dangling reference check 5 looks for.
  7. Every `viewModel::method` a screen binds exists on that view model.
  8. Every named argument passed to an app composable is a parameter it has,
     and every parameter without a default is actually passed.
  9. Every interface Hilt injects has a @Binds or @Provides.
 10. No unused imports.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "app/src/main/java/com/speaksarthi/app"
SEED = ROOT / "app/src/main/assets/seed"

failures: list[str] = []
notes: list[str] = []


def fail(message: str) -> None:
    failures.append(message)


def note(message: str) -> None:
    notes.append(message)


# ---------------------------------------------------------------- 1. seed keys
def dto_fields(source: str, class_name: str) -> set[str]:
    match = re.search(
        rf"data class {class_name}\((.*?)\n\)", source, re.DOTALL
    )
    if not match:
        return set()
    return set(re.findall(r"val\s+(\w+)\s*:", match.group(1)))


def check_seed_against_dtos() -> None:
    dto_source = (SRC / "data/seed/SeedDtos.kt").read_text(encoding="utf-8")

    pairs = [
        ("words.json", "WordDto"),
        ("chunks.json", "ChunkDto"),
        ("practice_items.json", "PracticeItemDto"),
        ("quiz_items.json", "QuizItemDto"),
    ]

    for filename, dto in pairs:
        path = SEED / filename
        if not path.exists():
            fail(f"seed file missing: {filename}")
            continue

        rows = json.loads(path.read_text(encoding="utf-8"))
        if not rows:
            fail(f"{filename} is empty")
            continue

        json_keys: set[str] = set()
        for row in rows[:500]:
            json_keys.update(row.keys())

        fields = dto_fields(dto_source, dto)
        if not fields:
            fail(f"could not parse {dto} out of SeedDtos.kt")
            continue

        unknown = json_keys - fields
        if unknown:
            fail(f"{filename}: keys with no matching {dto} field: {sorted(unknown)}")

        unused = fields - json_keys
        if unused:
            note(f"{filename}: {dto} fields not present in the data: {sorted(unused)}")

        note(f"{filename}: {len(rows)} rows, {len(json_keys)} keys, all mapped to {dto}")

    # The nested MCQ shape is the one place a mismatch would be silent and fatal
    # to the quiz feature, so it gets checked explicitly.
    quiz = json.loads((SEED / "quiz_items.json").read_text(encoding="utf-8"))
    mcq_fields = dto_fields(dto_source, "McqDto")
    for row in quiz[:200]:
        mcq = row.get("mcq")
        if not mcq:
            continue
        unknown = set(mcq.keys()) - mcq_fields
        if unknown:
            fail(f"quiz_items.json mcq: keys with no McqDto field: {sorted(unknown)}")
            break
    note(f"quiz_items.json: nested mcq keys match McqDto {sorted(mcq_fields)}")


# ------------------------------------------------------------ 2. room columns
def entity_columns() -> dict[str, set[str]]:
    """table name -> column names, read from the @Entity data classes."""
    tables: dict[str, set[str]] = {}
    for path in (SRC / "data/local/entity").glob("*.kt"):
        source = path.read_text(encoding="utf-8")
        for match in re.finditer(
            r'@Entity\((?:[^)]*?)tableName\s*=\s*"(\w+)"(?:.*?)\)\s*data class \w+\((.*?)\n\)',
            source,
            re.DOTALL,
        ):
            table, body = match.group(1), match.group(2)
            tables[table] = set(re.findall(r"val\s+(\w+)\s*:", body))
    return tables


KNOWN_SQL_WORDS = {
    "select", "from", "where", "order", "by", "asc", "desc", "limit", "and", "or",
    "not", "null", "is", "count", "avg", "sum", "min", "max", "as", "on", "inner",
    "left", "join", "group", "insert", "into", "values", "conflict", "do", "update",
    "set", "delete", "distinct", "case", "when", "then", "else", "end", "like",
    "escape", "exists", "coalesce", "random", "in", "0", "1", "abs",
}


def check_room_queries() -> None:
    tables = entity_columns()
    if not tables:
        fail("no @Entity tables were parsed")
        return
    note(f"entities: {', '.join(sorted(tables))}")

    all_columns = set().union(*tables.values())

    for path in (SRC / "data/local/dao").glob("*.kt"):
        source = path.read_text(encoding="utf-8")
        for match in re.finditer(r'@Query\(\s*"""(.*?)"""', source, re.DOTALL):
            check_sql(match.group(1), path.name, tables, all_columns)
        for match in re.finditer(r'@Query\(\s*"([^"]+)"\s*\)', source):
            check_sql(match.group(1), path.name, tables, all_columns)


def check_sql(sql: str, filename: str, tables: dict, all_columns: set) -> None:
    referenced = set(re.findall(r"\bFROM\s+(\w+)|\bJOIN\s+(\w+)|\bINTO\s+(\w+)", sql, re.I))
    names = {name for group in referenced for name in group if name}
    for name in names:
        if name not in tables:
            fail(f"{filename}: query references unknown table '{name}'")

    # Column identifiers: bare words that are not SQL keywords, bind params,
    # string literals, table names or numbers.
    stripped = re.sub(r"'[^']*'", " ", sql)
    stripped = re.sub(r":\w+", " ", stripped)
    candidates = set(re.findall(r"\b([a-zA-Z_]\w*)\b", stripped))
    candidates -= {c for c in candidates if c.lower() in KNOWN_SQL_WORDS}
    candidates -= set(tables.keys())
    # Table aliases used in the DAO's joins, plus computed result columns.
    candidates -= {"w", "p", "m", "e", "total", "COALESCE"}

    for candidate in candidates:
        if candidate not in all_columns:
            fail(f"{filename}: query references unknown column '{candidate}' in: {' '.join(sql.split())[:90]}")


# -------------------------------------------------------------- 3. balance
def _templates(literal: str) -> str:
    """The `${...}` expressions inside a string literal, as bare code.

    A template expression is Kotlin, not text: `"${count.roundToInt()}%"` is a
    real use of `roundToInt`. Blanking the whole literal hid those and marked a
    dozen live imports as unused.
    """
    # The `""` marker is kept whatever is inside: without it a plain string
    # argument blanks to whitespace, and a positional string argument then looks
    # like no argument at all.
    return '"" ' + " ".join(re.findall(r"\$\{([^{}]*)\}", literal))


def strip_literals(source: str) -> str:
    """Blank out comments, strings and char literals, keeping everything else.

    Written as a scanner rather than a chain of regexes because the regex
    version got this wrong in a way that took a while to see: stripping line
    comments first ate the closing quote of any string containing "//", such as
    a URL, after which every later quote paired up one position out and braces
    inside real strings started counting. A left-to-right pass cannot make that
    mistake, because it always knows which construct it is inside.
    """
    out: list[str] = []
    index = 0
    length = len(source)

    while index < length:
        rest = source[index:]

        if rest.startswith("/*"):
            end = source.find("*/", index + 2)
            stop = length if end == -1 else end + 2
            # Newlines are kept so line numbers reported later are still true.
            out.append("\n" * source.count("\n", index, stop))
            index = stop
            continue

        if rest.startswith("//"):
            end = source.find("\n", index)
            index = length if end == -1 else end
            out.append(" ")
            continue

        if rest.startswith('"""'):
            end = source.find('"""', index + 3)
            stop = length if end == -1 else end + 3
            out.append(" " + _templates(source[index:stop]) + " ")
            out.append("\n" * source.count("\n", index, stop))
            index = stop
            continue

        if rest.startswith('"'):
            start = index
            index += 1
            while index < length and source[index] != '"':
                index += 2 if source[index] == "\\" else 1
            index += 1
            out.append(" " + _templates(source[start:index]) + " ")
            continue

        if rest.startswith("`"):
            # A backtick-quoted identifier — Kotlin test names are full of them,
            # and they contain apostrophes ("the library's order"). Without this
            # the apostrophe reads as a char literal and swallows everything up to
            # the next one, braces included.
            end = source.find("`", index + 1)
            stop = length if end == -1 else end + 1
            out.append("name")
            index = stop
            continue

        if rest.startswith("'"):
            index += 1
            while index < length and source[index] != "'":
                index += 2 if source[index] == "\\" else 1
            index += 1
            out.append(" '' ")
            continue

        out.append(source[index])
        index += 1

    return "".join(out)


def check_balance() -> None:
    pairs = {"(": ")", "[": "]", "{": "}"}
    closing = {v: k for k, v in pairs.items()}

    for path in sorted(ROOT.rglob("*.kt")):
        source = strip_literals(path.read_text(encoding="utf-8"))

        stack: list[str] = []
        for char in source:
            if char in pairs:
                stack.append(char)
            elif char in closing:
                if not stack or stack[-1] != closing[char]:
                    fail(f"{path.relative_to(ROOT)}: unbalanced '{char}'")
                    break
                stack.pop()
        else:
            if stack:
                fail(f"{path.relative_to(ROOT)}: {len(stack)} unclosed '{stack[-1]}'")


# ------------------------------------------------------ 4. database wiring
def check_database_registration() -> None:
    db_source = (SRC / "data/local/SpeakSarthiDatabase.kt").read_text(encoding="utf-8")
    registered = set(re.findall(r"(\w+Entity)::class", db_source))

    # @Entity annotations contain nested parens (foreignKeys, indices), so a
    # regex cannot reliably balance them. Instead, walk each `data class` and
    # look back at the text since the previous declaration: if an @Entity
    # annotation appears in that gap, this class is an entity.
    declared: set[str] = set()
    for path in (SRC / "data/local/entity").glob("*.kt"):
        source = path.read_text(encoding="utf-8")
        previous_end = 0
        for match in re.finditer(r"\bdata class (\w+)\s*\(", source):
            gap = source[previous_end:match.start()]
            if "@Entity" in gap:
                declared.add(match.group(1))
            previous_end = match.end()

    missing = declared - registered
    if missing:
        fail(f"entities declared but not registered in the database: {sorted(missing)}")

    phantom = registered - declared
    if phantom:
        fail(f"database registers entities that do not exist: {sorted(phantom)}")

    note(f"database registers all {len(registered)} entities")

    # Every DAO the database exposes must be a real interface.
    dao_types = set(re.findall(r"abstract fun \w+\(\): (\w+)", db_source))
    dao_source = "\n".join(
        p.read_text(encoding="utf-8") for p in (SRC / "data/local/dao").glob("*.kt")
    )
    defined = set(re.findall(r"interface (\w+)", dao_source))
    missing_daos = dao_types - defined
    if missing_daos:
        fail(f"database exposes DAOs with no definition: {sorted(missing_daos)}")
    note(f"DAOs wired: {', '.join(sorted(dao_types))}")



# ------------------------------------------------- 5. internal imports resolve
DECL_RE = re.compile(
    r"^(?:@\w+(?:\([^\n]*\))?\s*)*"
    r"(?:public |internal |private |abstract |open |sealed |data |enum |value |annotation |inline |expect |actual )*"
    r"(?:class|interface|object|fun|val|var|typealias)\s+"
    r"(?:<[^>]*>\s*)?"
    r"([A-Za-z_][A-Za-z0-9_]*)",
    re.MULTILINE,
)


def declared_names() -> dict[str, set[str]]:
    """Top-level declarations per package, plus every nested/enum-entry name."""
    by_package: dict[str, set[str]] = {}
    for path in SRC.rglob("*.kt"):
        source = path.read_text(encoding="utf-8")
        match = re.search(r"^package\s+([\w.]+)", source, re.MULTILINE)
        if not match:
            fail(f"{path.name}: no package declaration")
            continue
        package = match.group(1)
        names = by_package.setdefault(package, set())

        for line in source.splitlines():
            stripped = line.strip()
            if stripped.startswith(("import ", "package ", "//", "*", "/*")):
                continue
            # Extension functions first: `fun WordEntity.toDomain(): Word` is
            # imported as `toDomain`, not as its receiver, and the generic
            # declaration pattern below would otherwise claim the receiver name.
            extension = re.match(
                r"^(?:internal |private |public )?fun\s+[^(=]*?\.([A-Za-z_]\w*)\s*\(", stripped
            )
            if extension:
                names.add(extension.group(1))
                continue
            found = DECL_RE.match(stripped)
            if found:
                names.add(found.group(1))

        # Enum entries and companion constants are imported by name too, and are
        # not top-level declarations, so they are collected separately rather
        # than reported as unresolved.
        for entry in re.findall(r"^\s{4,}([A-Z][A-Z0-9_]{2,})\s*(?:[,;(]|=)", source, re.MULTILINE):
            names.add(entry)
    return by_package


# Types the build generates rather than the source declaring: there is no file
# to find them in, and a missing one is a build error, not a dangling reference.
GENERATED_TYPES = {
    "com.speaksarthi.app.BuildConfig",
    "com.speaksarthi.app.R",
}


def check_internal_imports() -> None:
    by_package = declared_names()
    known = {f"{pkg}.{name}" for pkg, names in by_package.items() for name in names}
    known |= GENERATED_TYPES
    unresolved: list[str] = []
    checked = 0

    for path in sorted(SRC.rglob("*.kt")) + sorted((ROOT / "app/src/test").rglob("*.kt")) + sorted(
        (ROOT / "app/src/androidTest").rglob("*.kt")
    ):
        source = path.read_text(encoding="utf-8")
        for imported in re.findall(r"^import\s+(com\.speaksarthi\.app\.[\w.]+)", source, re.MULTILINE):
            checked += 1
            if imported in known:
                continue
            # A member import: pkg.Owner.MEMBER — the owner is what must exist.
            owner = imported.rsplit(".", 1)[0]
            if owner in known:
                continue
            unresolved.append(f"{path.name}: import {imported}")

    if unresolved:
        for item in unresolved:
            fail(f"import does not resolve to any declaration — {item}")
    note(f"internal imports resolved: {checked}")


# ------------------------------------------- 6. no fully-qualified app types
def check_no_fully_qualified() -> None:
    offenders: list[str] = []
    for path in sorted(SRC.rglob("*.kt")):
        for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
            stripped = line.strip()
            if stripped.startswith(("import ", "package ", "*", "//")):
                continue
            if "com.speaksarthi.app." in stripped:
                offenders.append(f"{path.name}:{number}")
    if offenders:
        fail(
            "fully-qualified app types in code (use an import instead): "
            + ", ".join(offenders)
        )
    else:
        note("no fully-qualified app types in code")



# ------------------------------------------- 7. screens call real VM methods
def check_viewmodel_references() -> None:
    """A screen calling `viewModel::renamedMethod` compiles nowhere but reads fine."""
    members: dict[str, set[str]] = {}
    for path in SRC.rglob("*ViewModel.kt"):
        source = path.read_text(encoding="utf-8")
        for name in re.finditer(
            r"^\s{4}(?:(?:public|internal|private|protected)\s+)?"
            r"(?:override\s+)?(?:suspend\s+)?(?:fun|val|var)\s+([A-Za-z_]\w*)",
            source,
            re.MULTILINE,
        ):
            members.setdefault(path.stem, set()).add(name.group(1))

    dangling: list[str] = []
    checked = 0
    for path in sorted(SRC.rglob("*.kt")):
        source = strip_literals(path.read_text(encoding="utf-8"))

        # A file can declare more than one view model — the nav host declares
        # several. Each `viewModel.x` belongs to the nearest declaration above it,
        # not to whichever one happens to appear first in the file.
        bindings = [
            (match.start(), match.group(1))
            for match in re.finditer(r"viewModel:\s*([A-Za-z_]\w*ViewModel)", source)
        ]
        if not bindings:
            continue

        for owner in {name for _, name in bindings}:
            if owner not in members:
                fail(f"{path.name}: refers to {owner}, which has no source file")

        for use in re.finditer(r"viewModel(?:::|\.)([A-Za-z_]\w*)", source):
            earlier = [name for start, name in bindings if start < use.start()]
            owner = earlier[-1] if earlier else bindings[0][1]
            known = members.get(owner)
            if known is None:
                continue

            checked += 1
            if use.group(1) not in known:
                dangling.append(f"{path.name}: viewModel.{use.group(1)} not on {owner}")

    for item in dangling:
        fail(f"screen calls a method the view model does not have — {item}")
    note(f"view-model references checked: {checked}")


# ------------------------------------- 8. composable arguments match signatures
def _balanced(source: str, open_index: int) -> str:
    """Text inside the parentheses that start at [open_index]."""
    depth = 0
    for position in range(open_index, len(source)):
        character = source[position]
        if character == "(":
            depth += 1
        elif character == ")":
            depth -= 1
            if depth == 0:
                return source[open_index + 1 : position]
    return ""


def _split_top_level(text: str) -> list[str]:
    """Split on commas that are not inside nested brackets or a lambda.

    Arrow types are blanked first: without that, the `>` in `() -> Unit` reads as
    a closing bracket, the depth goes negative, and every parameter after the
    first callback is silently lost — which looked exactly like a real error.
    """
    text = text.replace("->", "  ")
    pieces: list[str] = []
    depth = 0
    current = ""
    for character in text:
        if character in "([{":
            depth += 1
        elif character in ")]}":
            depth -= 1
        if character == "," and depth == 0:
            pieces.append(current)
            current = ""
        else:
            current += character
    pieces.append(current)
    return pieces


def composable_signatures() -> tuple[dict, dict]:
    """Composable parameter names, split into private-per-file and public.

    Keyed this way because two files can each hold a `private fun Question(...)`
    with different parameters — and a single name-keyed map let one overwrite the
    other and then reported the survivor's call site as passing arguments that do
    not exist. A private composable is only visible in its own file, so that is
    where it is looked up.
    """
    private_by_file: dict[tuple[str, str], tuple[set[str], set[str]]] = {}
    public_by_name: dict[str, tuple[set[str], set[str]]] = {}

    for path in SRC.rglob("*.kt"):
        # Comments stripped first: a KDoc block between two parameters would
        # otherwise be read as part of the parameter after it, and that parameter
        # then reported as not existing at every call site that passes it.
        source = strip_literals(path.read_text(encoding="utf-8"))
        for match in re.finditer(
            r"@Composable\s+(private\s+|internal\s+)?fun\s+([A-Z]\w*)\s*\(", source
        ):
            visibility, name = match.group(1), match.group(2)
            names: set[str] = set()
            required: set[str] = set()
            for piece in _split_top_level(_balanced(source, match.end() - 1)):
                piece = piece.strip()
                named = re.match(r"^([A-Za-z_]\w*)\s*:", piece)
                if not named:
                    continue
                names.add(named.group(1))
                # No `=` after the type means no default, so a call must pass it.
                if "=" not in piece.split(":", 1)[1]:
                    required.add(named.group(1))

            if visibility and visibility.strip() == "private":
                private_by_file[(str(path), name)] = (names, required)
            else:
                public_by_name[name] = (names, required)

    return private_by_file, public_by_name


def check_composable_calls() -> None:
    private_by_file, public_by_name = composable_signatures()
    problems: list[str] = []
    checked = 0

    for path in sorted(SRC.rglob("*.kt")):
        source = strip_literals(path.read_text(encoding="utf-8"))
        for match in re.finditer(r"(?<![\w.])([A-Z]\w*)\s*\(", source):
            name = match.group(1)
            # A private composable in this file shadows a public one elsewhere.
            signature = private_by_file.get((str(path), name)) or public_by_name.get(name)
            if signature is None:
                continue
            all_names, required = signature
            # Skip the declaration itself.
            preceding = source[max(0, match.start() - 60) : match.start()]
            if re.search(r"fun\s+$", preceding):
                continue

            arguments = _balanced(source, match.end() - 1)
            given = set()
            for piece in _split_top_level(arguments):
                named = re.match(r"^\s*([A-Za-z_]\w*)\s*=(?!=)", piece)
                if named:
                    given.add(named.group(1))
            # A call with arguments but none of them named is positional, and this
            # cannot tell which parameter is which. A call with NO arguments at
            # all is still worth checking — that is exactly the case where a
            # required parameter has been forgotten.
            has_arguments = bool(arguments.strip())
            if has_arguments and not given:
                continue
            checked += 1
            line = source[: match.start()].count("\n") + 1

            unknown = given - all_names
            if unknown:
                problems.append(
                    f"{path.name}:{line}: {name}({', '.join(sorted(unknown))}=…) — "
                    f"no such parameter"
                )

            # Missing required arguments, but only where every argument is named
            # and nothing trails the call. A positional argument or a trailing
            # lambda supplies a parameter this cannot see, and guessing there
            # would produce noise rather than findings.
            pieces = [piece for piece in _split_top_level(arguments) if piece.strip()]
            # One past the closing paren: the open paren sits at match.end() - 1,
            # the arguments run to len(arguments) after it, and the `)` is the
            # character after those — so what follows the call starts two later.
            after_call = match.end() + len(arguments) + 1
            trailing = source[after_call : after_call + 40].lstrip()
            if len(pieces) == len(given) and not trailing.startswith("{"):
                absent = required - given
                if absent:
                    problems.append(
                        f"{path.name}:{line}: {name}(…) — missing required "
                        f"{', '.join(sorted(absent))}"
                    )

    for item in problems:
        fail(f"composable called with an argument it does not take — {item}")
    note(f"composable call sites checked: {checked}")



# ------------------------------------------------ 9. the Hilt graph is complete
def check_hilt_graph() -> None:
    """Every interface Hilt is asked to inject must have a binding.

    A missing one is a build failure with a message that names a generated class
    rather than the thing that is actually wrong, so it is worth catching here.
    Concrete classes with an `@Inject constructor` bind themselves and need
    nothing; interfaces do not.
    """
    interfaces: set[str] = set()
    for path in SRC.rglob("*.kt"):
        source = strip_literals(path.read_text(encoding="utf-8"))
        for match in re.finditer(r"^\s*(?:sealed\s+)?interface\s+(\w+)", source, re.MULTILINE):
            # Sealed interfaces are state hierarchies, never injected.
            if "sealed" not in match.group(0):
                interfaces.add(match.group(1))

    module = (SRC / "di/AppModule.kt").read_text(encoding="utf-8")
    bound = set(re.findall(r"(?:@Binds[\s\S]{0,200}?:\s*|fun\s+provide\w*\([^)]*\)\s*:\s*)(\w+)", module))
    bound |= set(re.findall(r"@Binds\s+(?:@\w+\s+)*abstract\s+fun\s+\w+\([^)]*\)\s*:\s*(\w+)", module))

    # Types Hilt supplies itself, or that come from another module's @Provides.
    builtin = {
        "Context", "Application", "CoroutineDispatcher", "CoroutineScope",
        "SavedStateHandle", "WorkerParameters", "Json", "OkHttpClient", "ImageLoader",
    }

    needed: dict[str, set[str]] = {}
    for path in SRC.rglob("*.kt"):
        source = strip_literals(path.read_text(encoding="utf-8"))
        for match in re.finditer(r"@Inject\s+constructor\s*\(", source):
            params = _balanced(source, match.end() - 1)
            for piece in _split_top_level(params):
                typed = re.search(r":\s*(\w+)", piece)
                if typed:
                    needed.setdefault(typed.group(1), set()).add(path.name)

    missing = sorted(
        name for name in needed
        if name in interfaces and name not in bound and name not in builtin
    )
    for name in missing:
        fail(
            f"interface {name} is injected (by {', '.join(sorted(needed[name]))}) "
            f"but has no @Binds or @Provides in AppModule"
        )
    note(f"Hilt: {len(bound)} bindings cover every injected interface")


# --------------------------------------------------------- 10. unused imports
DELEGATION_OPERATORS = {"getValue", "setValue", "provideDelegate"}


def check_unused_imports() -> None:
    """Unused imports are warnings, not errors — but they mark dead code.

    An import left behind after a refactor usually means something was removed
    and its replacement was not, which is worth a look even when the compiler
    does not care.
    """
    offenders: list[str] = []
    checked = 0

    for path in sorted(SRC.rglob("*.kt")) + sorted((ROOT / "app/src/test").rglob("*.kt")):
        raw = path.read_text(encoding="utf-8")
        body = strip_literals(raw)
        # Everything after the import block is where a use would be.
        lines = body.splitlines()
        code = "\n".join(line for line in lines if not line.strip().startswith("import "))

        for imported in re.findall(r"^import\s+([\w.]+)(?:\s+as\s+(\w+))?\s*$", raw, re.MULTILINE):
            full, alias = imported
            if full.endswith(".*"):
                continue
            name = alias or full.rsplit(".", 1)[-1]
            # `by remember { }` needs getValue/setValue imported, and neither ever
            # appears by name — the delegation syntax calls them.
            if name in DELEGATION_OPERATORS:
                continue
            checked += 1
            # Word boundaries only — NOT "not preceded by a dot". Kotlin calls
            # every extension after one (`20.dp`, `_state.asStateFlow()`), so
            # excluding dotted uses marks half the imports in the project unused.
            # The trailing boundary is what stops `Row` matching `RowScope`.
            if not re.search(rf"(?<!\w){re.escape(name)}(?![\w])", code):
                offenders.append(f"{path.name}: {full}")

    if offenders:
        for item in offenders:
            fail(f"unused import — {item}")
    note(f"imports checked for use: {checked}")


def main() -> None:
    check_seed_against_dtos()
    check_room_queries()
    check_balance()
    check_database_registration()
    check_internal_imports()
    check_no_fully_qualified()
    check_viewmodel_references()
    check_composable_calls()
    check_hilt_graph()
    check_unused_imports()

    kt_files = list(ROOT.rglob("*.kt"))
    print(f"Kotlin files: {len(kt_files)}")
    print()
    for message in notes:
        print(f"  · {message}")
    print()
    if failures:
        print(f"{len(failures)} PROBLEM(S):")
        for message in failures:
            print(f"  ✗ {message}")
        sys.exit(1)
    print("All static checks passed.")


if __name__ == "__main__":
    main()
