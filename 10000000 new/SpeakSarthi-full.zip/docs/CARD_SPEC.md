# The three-part card

Derived from the reference card supplied on 15 Sep 2026. Every field below is
traced to the database column that feeds it, so phase 2 is a layout job rather
than a content hunt.

The reference card has two sides. Part three is new: it takes the **Practice
Zone** off the back of the reference card and joins it with the **chunks**, which
gives each part one coherent job — **recognise**, then **understand**, then
**practise**.

---

## Part 1 — Recognition

What the learner sees before they know the word.

| On the card | Source |
|---|---|
| Word ID badge | `words.wordId` |
| The word | `words.word` |
| Pronunciation (IPA) + speaker button | `words.ipa` |
| Syllable break and stress | `words.syllableBreak` |
| Indian pronunciation (Devanagari) | `words.hindiPronunciation` |
| Part of speech | `words.partOfSpeech` |
| Category | `words.category` |
| CEFR level | `words.level` |
| Frequency | `words.frequency` |
| Importance (1–5 stars) | `words.importance` |
| Register | `words.register` |
| Etymology | `words.etymology` |
| Quick tip | `words.quickTip` |
| Pronunciation tip | `words.pronunciationTip` |
| Spelling tip | `words.spellingTip` |
| Mnemonic story | `words.mnemonic` |
| Illustration | `words.illustration` — the filename; artwork added later |

The speaker button needs generated audio, which is phase 2 work: pre-generate
every clip once with neural TTS and ship the files. It is a one-time cost of
roughly ₹200 for the whole library, not a per-play API call.

## Part 2 — Understanding and usage

| On the card | Source |
|---|---|
| Meaning (simple) | `words.simpleMeaning` |
| Hindi meaning | `words.hindiMeaning` |
| Plain explanation | `words.plainExplanation` |
| Example (simple) | `practice_items` where `type = EXAMPLE`, `orderIndex = 0` |
| Example sentences | `practice_items` where `type = EXAMPLE`, `orderIndex` 1–3 |
| Synonyms | `words.synonyms` |
| Antonyms | `words.antonyms` |
| Common mistakes (wrong / right) | `words.commonMistakeWrong`, `words.commonMistakeCorrect` |
| Memory trick | `words.mnemonic` |
| Word family | `words.wordFamily` |
| Prefix / root / suffix | `words.prefixRootSuffix` |
| Register and tone | `words.register`, `words.tone` |
| Contexts | `words.typicalContexts` |
| Mini conversation | `words.miniConversation` |
| Confusing words | `words.confusingWords` |
| Related words | `words.relatedWords` |
| Movie / TV line | `practice_items` where `type = EVERYDAY` |
| News / article line | `practice_items` where `type = NEWS` |
| Real-life conversation | `practice_items` where `type = CASUAL` |
| Emotion / feel | `words.emotionFeel` |
| Visual association | `words.visualAssociation` (a text description, not an image) |
| Quick recall (reverse) | `words.quickRecallPrompt` |

**On the "examples in real life" block.** These three lines are written in the
*style* of a film scene, a news report and a casual conversation. They are
original and are not quotes from any real film, outlet or person, and the UI must
not present them as such — no attribution, no "as seen in". Real dialogue and
published prose are protected work and Play Store takedowns over this are
routine.

## Part 3 — Chunks and practice

The new page. Two halves.

### Chunks

Pulled from `chunks`, grouped by `type`:

| Group | Type | Count across the library |
|---|---|---|
| Collocations | `COLLOCATION` | 3,718 |
| Phrasal / related expressions | `PHRASAL` | 2,335 |
| Grammar pattern | `PATTERN` | 1,000 |

Around seven chunks per word. These are the point of a *spoken* English app: the
learner memorises the block, not the word.

### Practice zone

All five exercises, one row per word in `exercises`:

| # | Exercise | Columns |
|---|---|---|
| 1 | Multiple choice | `mcqQuestion`, `mcqOptions`, `mcqAnswerIndex` |
| 2 | Fill in the blank | `fillBlankPrompt`, `fillBlankAnswer` |
| 3 | Sentence correction | `findFixWrong`, `findFixCorrected` |
| 4 | Translate (Hindi → English) | `translatePrompt`, `translateAnswer` |
| 5 | Write your own sentence | `writeYourOwnPrompt` |

All 1,000 words carry all five; an instrumented test asserts it.

Exercise 5 is open-ended and has no answer to check. The app keeps what the
learner writes and shows it back at the next review rather than marking it —
worth protecting, because the learner this product is for is specifically afraid
of being wrong.

---

## One deliberate difference from the reference card

The reference card prints a fixed review plan: **Day 1 → 3 → 7 → 15 → 30**. The
app does not use it. A printed card has no choice but to show the same schedule
to everyone; the app knows how this learner actually did on this word and
schedules accordingly through SM-2. What the card shows instead is the real next
review date and how many days away it is.

The workbook's "Spaced Repetition Plan" column is therefore not imported. This is
the one place the app deliberately improves on the reference rather than
reproducing it.

---

## The illustration frame

Decided: **the illustration matters, so the space is reserved now and the artwork
is added later.** Everything needed for that is already in place.

- Every word carries its filename in `words.illustration`, by convention
  `<wordId>.webp`. All 1,000 are populated.
- Artwork is **fetched on demand and cached**, never bundled in the APK.
  `IllustrationLoader` builds the URL from a configurable host, and prefetches
  the next five cards so the download is not felt.
- Until a host is configured — the state today — every card renders the text
  fallback, which is a supported state rather than a broken one.
- Illustrations are the one part of the app that needs a network. Everything
  else works offline.

**Layout requirement for phase 2:** the frame is a fixed **4:3 landscape** box,
and it is the same size whether or not the artwork exists. When it is missing,
the frame holds the word's `visualAssociation` text set in the card's own type.
The layout must not shift when an image arrives — a learner should not be able to
tell which words have been drawn and which are still waiting.

Full brief — dimensions, format, style, and how to add the files — is in
[ILLUSTRATIONS.md](ILLUSTRATIONS.md).

## Open questions

**Memory trick vs mnemonic story.** The reference card shows these as two
separate blocks — a story on the front, a trick on the back. The workbook has one
`mnemonic` column feeding both. Either show it once, or the content needs a
second column written for all 1,000 words.
