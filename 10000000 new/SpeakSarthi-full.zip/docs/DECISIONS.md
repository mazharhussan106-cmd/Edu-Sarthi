# Decisions

Settled 2026-09-17. Twenty questions, twenty answers. This is the record of what
was decided, what each decision unblocks, and what is still open.

Where a decision changes code that already exists, it is listed under **Changes
this forces** at the end. None of it has been applied yet.

---

## Settled

| # | Decision | Answer |
|---|---|---|
| 1 | Purpose | A real commercial product |
| 2 | Timeline | In front of learners within a month |
| 3 | Name | **Speak Sarthi** — locked. `applicationId` stays `com.speaksarthi.app` |
| 4 | Publisher | Individual, not a company |
| 5 | Monetisation | **Credits, not a subscription** |
| 6 | Earning credits | Finishing lessons, weekly streaks |
| 7 | Speech proxy | Built here, deployed by you |
| 8 | Hosting | Cloudflare Workers |
| 9 | Pack prices | ₹99 / ₹249 / ₹499 |
| 10 | Welcome grant | 50 credits, all up front |
| 11 | At zero credits | Recording and playback keep working; only the AI score stops |
| 12 | Anti-abuse | Google sign-in when credits run low |
| 13 | Azure | No account yet — free F0 tier is the starting point |
| 14 | Contact address | `mazharhussan106@gmail.com` as a placeholder, to be replaced before the public listing |

### The name is now permanent-ish

`com.speaksarthi.app` stays. It is still a safe find-and-replace **until the
first Play Store upload** and permanent after it. Nothing else about the name
needs deciding, but the launcher icon is still a placeholder.

### Why credits rather than a subscription

Scoring costs money per use, so the price should too. A subscription is a bet
that the average subscriber uses less than they pay for; get it wrong and a heavy
user costs more than they bring in, and as an individual publisher that bill
lands on you personally. Credits lock the margin on every sale.

It is also less untested code between here and launch — the subscription renewal
path (mandates, grace periods, dunning) has never run, and a consumable purchase
has far fewer states. And "recharge" is a mental model the audience already has.

Two answers from the earlier rounds are **superseded** by this and are recorded
only so the reasoning is not lost: "raise the paid cap and trust the average" and
"offer an annual plan at a discount" both assumed a subscription.

---

## Open, and what each blocks

**The unit cost of one scored attempt.** Everything about pack sizing rests on a
working figure of ₹1.50/minute — roughly ₹0.40 per 15-second attempt — that has
never been measured. Azure's pricing page renders its figures in JavaScript and
could not be read, and pronunciation assessment appears to be billed as an add-on
on top of speech-to-text rather than at a flat rate. **Measure this first**, with
the free F0 tier's 5 audio hours a month, before fixing any credit counts.

**How many credits each pack contains.** The prices are settled; the counts are
not, because they follow from the cost above. One tension to resolve when setting
them: a 50-credit welcome grant next to a ₹99 entry pack of 60 credits is a weak
ladder — a learner who just got 50 free has little reason to buy 60 more. The
entry pack should land well above the grant. A provisional shape, to be corrected
once the real cost is known:

| Pack | Price | Net after GST + Play |
|---|---|---|
| Entry | ₹99 | ~₹71 |
| Standard | ₹249 | ~₹179 |
| Large | ₹499 | ~₹359 |

**The band thresholds.** `ScoreInterpreter` decides what counts as "Clear" or
"Say it again". Those boundaries are reasoned, never measured. Put twenty real
recordings through the service and check them before anyone is told their English
is not clear enough.

**A real feedback inbox.** The placeholder is the account address above. Fine for
a beta, wrong on a public listing.

**The privacy policy blanks.** Legal name and address — now known to be an
individual, not a company — plus the speech processor named, and a qualified read.
Blocks the Play listing, not the build.

**The launcher icon.** Still the placeholder speech bubble.

---

## Not in this launch

**The live test with a real person.** Passing a spoken test with a human, earning
credits for it. Strong idea, different business: it needs a person on the other
end, scheduling, and a way to pay them. It is a tutoring marketplace attached to
a vocabulary app, and it cannot ship in a month. Recorded here so it is not lost.

**Rewarded ads.** Declined by omission rather than debated. Worth knowing it was
available: an ad SDK would collect data from every install and change both the
privacy policy and the Data Safety form.

---

## Changes this forces — **all applied 2026-09-17**

Every item below is now done. None of it has been compiled: Maven is unreachable
from the environment this was built in, so the whole app remains statically
checked and never built. See [FIRST_BUILD.md](FIRST_BUILD.md).

1. ✅ **Replaced the subscription with credits.** `SpeechAllowance` currently
   expresses the paywall as two per-day second caps (75 free, 120 subscriber).
   That whole model goes: a credit balance replaces a daily allowance, and
   `Tier`/`Entitlement` become a balance rather than a status.

2. ✅ **Moved the balance to the server.** This is the load-bearing one. A credit
   count kept on the phone is editable on a rooted device in about two minutes,
   and every edit spends your Azure money. The Worker meters and holds the
   balance; the app displays it. `docs/SERVER_CONTRACT.md` needs rewriting around
   this.

3. ✅ **Swapped the Play Billing products** from a subscription
   (`speak_sarthi_scoring_monthly`) to three consumables, and handle consumption
   so a pack can be bought again. The PENDING state still matters — UPI one-time
   payments sit unconfirmed too.

4. ✅ **Added Google sign-in**, triggered when credits run low rather than at first
   launch. The anonymous-profile design already in place is what makes this
   possible without losing anyone's progress.

5. ✅ **Rewrote the paywall screen** — packs and a balance, not a subscription pitch.

6. ✅ **Credit-earning hooks added** on lesson completion and weekly streaks, granted by
   the Worker, not the app.

7. ✅ **The feedback address**, one constant in `FeedbackScreen`.

8. ✅ **The illustration brief** — drop the recurring character, keep the style. A
   generative model holds a style across a large set but not a character, and the
   brief's own warning about inconsistency is the reason to change the
   requirement rather than fight it.

---

## Illustrations

Generated with Higgsfield, at **2.5 credits per image**. The balance available is
1,639 credits — enough for roughly 655 images, not the full 1,000.

Recraft V4.1 in `vector` mode takes the app palette as a parameter and generates
native 4:3, which is unusually close to the brief. Output needs resizing to
1200×900 and converting to WebP under 45 KB, which is a local step.

Agreed approach: **a trial batch of ten first** (25 credits), covering different
word types, to settle the style before generating at scale.

They still need a host. Cloudflare R2 is the obvious choice now that the Worker
lives there — one origin for both.
