# The first build

## Two wrapper bugs were fixed on 2026-09-17

If you cloned this before that date, take the current `gradlew` and
`gradle/wrapper/gradle-wrapper.jar`.

`./gradlew` used to fail immediately with `Could not find or load main class
"-Xmx64m"` — the script expanded its quoted JVM options unquoted, so Java got the
quote characters as part of the argument. It also built its argument list and
then threw it away. Both are fixed, and the script is back to the upstream form.

The wrapper jar was also incomplete: it held `org/gradle/wrapper/` but not the
`org.gradle.cli` and `org.gradle.internal.file.locking` classes those call into,
so it failed with `NoClassDefFoundError` once the script was working. Rebuilt
from a Gradle 8.14.3 distribution.

Neither was ever caught before because the build has never run anywhere.

This project has never been compiled. Not "compiled with warnings" — the Android
plugin cannot be resolved in the sandbox it was written in, so no Kotlin compiler
has ever looked at these 111 files. Everything was checked statically instead
(`content/verify_project.py`, ten checks), which catches missing files, bad
imports, wrong composable arguments and gaps in the Hilt graph, but cannot catch
a type error or a library API that changed shape.

So expect the first build to fail, probably more than once. That is the normal
state of a project this size on its first compile, and almost everything it
throws will be a one-line fix. This document exists so that you can tell an
ordinary first-build error from something actually wrong.

---

## 1. What you need

| | | |
|---|---|---|
| **Android Studio** | Koala (2024.1.1) or newer | The project uses Android Gradle Plugin 8.5.2. Older Studio versions refuse to open it rather than failing halfway. Ladybug or newer is a safer floor. |
| **JDK 17** | exactly 17 | Not 11, not 21. Android Studio ships its own JDK 17 (JetBrains Runtime) and uses it by default — this only matters if you build from a terminal. |
| **A phone or emulator** | API 24+ | A real, cheap phone is worth far more than an emulator here. This is an app for someone on a ₹9,000 handset. |
| **Disk** | ~8 GB free | Gradle distribution, the Android SDK, dependency cache and build output. |
| **RAM** | 8 GB, 16 comfortable | `gradle.properties` asks Gradle for 4 GB (`-Xmx4096m`). Annotation processing across 111 files is the memory-hungry part. |
| **Network** | for the first build only | Gradle and the dependencies download once. After that everything builds offline, and the app itself needs no network at all except for illustrations. |

You do **not** need an Azure key, a Play Console account, or a server to build and
run. All three are blank by default and blank is a supported state.

---

## 2. The short path

Open Android Studio → **Open** → select the `SpeakSarthi` folder → wait for
"Gradle sync finished" → press **Run**.

That is genuinely it, if the sync succeeds. Studio writes `local.properties` with
your SDK path, downloads Gradle 8.7 and every dependency, and offers to install
`compileSdk 34` if you don't have it. The first sync takes 5–15 minutes on a
normal connection; later ones take seconds.

From a terminal instead:

```bash
cd SpeakSarthi
./gradlew assembleDebug
```

If you go this route and have never opened the project in Studio, create
`local.properties` yourself first — Gradle cannot find the Android SDK without
it:

```properties
sdk.dir=/Users/you/Library/Android/sdk        # macOS
# sdk.dir=/home/you/Android/Sdk               # Linux
# sdk.dir=C\:\\Users\\you\\AppData\\Local\\Android\\Sdk   # Windows, escaped
```

The file is gitignored, which is deliberate — it is also where the speech
credentials go later, and neither your SDK path nor a key belongs in a repository.

---

## 3. What the first build is actually doing

A ten-minute silence looks like a hang. It usually isn't. In order:

1. **Downloading Gradle 8.7** (~130 MB) — once, ever.
2. **Resolving dependencies** — Compose, Room, Hilt, WorkManager, Billing, OkHttp,
   Coil. Several hundred MB, cached afterwards.
3. **KSP annotation processing** — the slow part, and the part that fails. Room
   generates a DAO implementation per DAO and validates every `@Query` against
   the entities; Hilt builds the whole injection graph. On a first build with a
   cold cache this alone can take two to four minutes.
4. **Kotlin compilation** — 111 files.
5. **Packaging** — the APK, including ~4.8 MB of seed JSON.

If a step appears stuck for more than about ten minutes, run
`./gradlew assembleDebug --info` and look at the last task name rather than
assuming a crash.

---

## 4. Errors you will probably see

Grouped by the stage they appear in, because the stage tells you what kind of
problem it is.

### During Gradle sync — configuration problems, not code problems

**`SDK location not found`**
`local.properties` is missing. Section 2 above.

**`Unsupported class file major version 65` / `... requires Java 17`**
Your JDK is wrong. In Studio: Settings → Build, Execution, Deployment → Build
Tools → Gradle → Gradle JDK → choose the bundled JetBrains Runtime 17. From a
terminal, point `JAVA_HOME` at a JDK 17.

**`The project is using an incompatible version of the Android Gradle plugin`**
Android Studio is older than Koala. Update Studio; do not downgrade AGP, because
the version set here is the one this dependency set is known to work with.

**`Failed to install the following SDK components: platforms;android-34`**
Accept the licence Studio offers, or `sdkmanager --licenses` from a terminal.

**`Build was configured to prefer settings repositories`**
Something added a `repositories { }` block to `app/build.gradle.kts`.
`settings.gradle.kts` sets `FAIL_ON_PROJECT_REPOS`, so repositories go there and
nowhere else. This is worth keeping — it is what stops a stray repository quietly
becoming a supply-chain surface.

### During compilation — the real risk

Nothing here has been type-checked, so this is where the genuine bugs are.

**`Unresolved reference: X`**
The most likely error by far, and almost always trivial: a missing import, or a
function that lives somewhere other than where the call assumes. Studio's
Alt+Enter usually offers the right import. If `X` is a Material 3 or Compose
symbol, check it exists at the pinned versions before adding a dependency —
`material3:1.2.1`, Compose BOM `2024.06.00`, Kotlin `1.9.24`.

**`None of the following functions can be called with the arguments supplied`**
A library API that changed signature between the version in the author's head and
the version pinned here. Read the expected signature in the error, or Ctrl+click
the function to see the real one, and adjust the call. Do **not** bump the library
version to make one call site compile — that ripples.

**Room errors naming a DAO method**
For example `There is a problem with the query` or
`Not sure how to convert a Cursor to this method's return type`. These are precise
and local: the named method's SQL does not match the entity, or a return type
needs a `@TypeConverter`. Fix the method the error names.

**Hilt errors naming a class you did not write** — `Hilt_MainActivity`,
`DaggerSpeakSarthiApp_HiltComponents`, `...MissingBinding`
Hilt reports failures against generated code, which makes the message look far
worse than the problem. Scroll to the line that starts with the *interface* name:
it means something is injected that has no `@Binds` or `@Provides` in
`AppModule.kt`. `verify_project.py` check 9 covers this statically and currently
passes over 40 bindings, so a survivor here is likely a construction Hilt sees
differently than the checker does.

**`OutOfMemoryError` / `Daemon will be stopped`**
Raise the Gradle heap in `gradle.properties`:
`org.gradle.jvmargs=-Xmx6144m`, and close Chrome.

**`@Composable invocations can only happen from ... @Composable function`**
A composable called from a lambda that isn't composable — usually a callback.
Local fix, at the line named.

### On first launch — expected behaviour, not bugs

**The first launch is slow.** The importer writes 1,000 words, 1,000 quiz items,
8,000 practice items and 7,053 chunks into Room. That is a one-off on first
install and nowhere else.

**"Scoring is not set up."** Correct. The speech credentials are blank. Recording
and playing yourself back work regardless; only the scored band needs a key.
`docs/SERVER_CONTRACT.md` and section 2 of `docs/LAUNCH_CHECKLIST.md` cover that.

**Listening practice says there is no English voice.** The phone's TTS engine has
no `en` voice installed. Install Google Text-to-Speech and an English voice. This
varies by handset, which is exactly why it is worth testing on a cheap one.

**Every card shows text instead of an illustration.** There is no artwork yet. The
frame is reserved and the fallback is the word's `visualAssociation` text. See
`docs/ILLUSTRATIONS.md`.

---

## 5. When it builds

**Commit `app/schemas/`.** The build writes `app/schemas/2.json` — Room's record of
the database shape. It is the only record of what a released database looked like,
and every future migration is written and tested against it. Commit it the moment
it appears.

To make the three skipped `MigrationTest` tests run, you also need
`app/schemas/1.json`, which only exists if you build at database version 1.
Temporarily set `version = 1` in `SpeakSarthiDatabase`, build, keep the file it
writes, set it back to 2. Do this once, now, while it is cheap.

**The debug app installs as `com.speaksarthi.app.debug`** — `applicationIdSuffix`
lets a debug and a release build sit on one phone at the same time. If you are
hunting for it in the app drawer, that is why there may be two.

**`./gradlew assembleRelease` produces an unsigned APK.** There is no signing
config, because there is no keystore yet. Item 8 of the launch checklist.

Then run the tests:

```bash
./gradlew test                  # 15 JVM test classes, seconds
./gradlew connectedAndroidTest  # instrumented, needs a device, minutes
python3 content/verify_project.py
```

---

## 6. The ten-minute smoke test

Building is not the same as working. When the app first runs, in this order:

1. The privacy notice appears, then the placement test. Skip it — skipping must
   cost nothing.
2. Home shows a due count, today's goal and a streak of zero.
3. Open a study session. Swipe all three parts of a card. Grade it **Good**.
4. Go back to Home. The due count went down by one.
5. Listening practice: a word is spoken and four options appear.
6. Speaking practice: record, play yourself back. Scoring will say it is not set up.
7. Settings → switch to dark mode. Every screen still readable.
8. Settings → set the system font to its largest size and reopen a card. This is
   the test that most often finds a layout bug, and the learners who need it are
   exactly the ones this app is for.

If all eight hold, the app works. Everything after that is on
`docs/LAUNCH_CHECKLIST.md`.

---

## 7. If you get stuck

Bring back the **full error text**, not a summary — the first fifteen lines of a
Gradle failure carry the task name, the file and the line, and a paraphrase loses
all three. `./gradlew assembleDebug --stacktrace` when the message alone is not
enough.
