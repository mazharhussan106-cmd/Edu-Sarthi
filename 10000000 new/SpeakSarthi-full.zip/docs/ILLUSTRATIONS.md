# Illustrations

The card reserves space for a drawing on part 1. The artwork does not exist yet;
this is the brief for making it and the mechanics for adding it.

Nothing in the app needs to change when the images arrive. Every word already
carries its filename (`words.illustration`, e.g. `VRB-001.webp`), the card
already reserves the frame, and `IllustrationLoader` already knows how to
fetch and cache. Upload the files, point the app at the host, they appear.

---

## The file spec

| | |
|---|---|
| Format | WebP, quality 80 |
| Aspect ratio | **4 : 3 landscape** |
| Dimensions | **1200 × 900 px** |
| Target size | 45 KB or less per file |
| Filename | `<WordId>.webp` — exactly, case-sensitive |
| Examples | `VRB-001.webp`, `PHR-042.webp`, `ADJ-250.webp` |

The word IDs are in `app/src/main/assets/seed/words.json` under `wordId`, and in
the source workbook's "Word ID" column. There are 1,000 of them: VRB-001…250,
PHR-001…150, ADJ-001…250, ADV-001…090, NUM-001…080, PRN-001…050, PRP-001…070,
CNJ-001…060.

1200 × 900 covers a 3× phone screen at the card's frame size with room to spare.
WebP rather than PNG because it is roughly a third the size at the same quality,
and the audience is on budget Android phones with limited storage.

## Style brief

- **One consistent world.** The same line weight, the same flat-colour
  treatment, the same level of detail across all 1,000. A thousand images that
  each look fine alone but different from each other reads as cheaper than no
  images at all.
- **No recurring character.** This started out asking for one and the
  requirement was dropped on purpose. A generative model will hold a *style*
  across a large set but not a *character* — the face drifts, and by image 200
  it is visibly a different person. Objects and scenes carry the memory hook
  just as well and are achievable at this scale. If a mascot is ever wanted, it
  needs a human illustrator, not a bigger prompt.
- **Use the app palette.** Teal `#146A62`, ochre `#D98324`, ink `#0E2A33`,
  paper `#F2F5F4`. Warm accent colours are fine; avoid purple, which belongs to
  WordMaster.
- **Show the meaning, not the word.** The drawing is a memory hook. The
  `visualAssociation` field already describes one per word — "A lightbulb
  switching on above someone's head" for *understand* — and is a good starting
  point for whoever draws.
- **Leave breathing room at the edges.** The frame has rounded corners; keep
  anything essential away from the outer 5%.

## One thing to decide before drawing starts

**No text inside the illustrations.** The reference card's drawing has "I'll do
it TOMORROW" written on a sticky note. It is charming, and it causes three
problems:

1. It ignores the learner's font-size setting, so someone using large text gets
   everything scaled up except the words baked into the picture.
2. A screen reader cannot read it.
3. It cannot be translated if the app ever adds another interface language.

The recommendation is to carry that idea through pose and expression instead —
the slumped posture and the clock already say "putting it off" without a word of
copy. If a scene genuinely needs text, put it in the caption below the frame,
where it is real text the app controls.

---

## How the app gets them: on demand, never bundled

Decided: **nothing ships inside the APK.** The app downloads each drawing the
first time a learner reaches that word and keeps it on disk afterwards.

Bundling all 1,000 would add roughly 40 MB to the download, and most learners
will only ever see a few hundred words. On-demand means the install stays small
and nobody pays for artwork they never see.

### Hosting

Upload the files to any static host — a bucket, a CDN, a folder on your server —
so that each one is reachable at `<base URL>/<filename>`:

```
https://cdn.example.com/art/VRB-001.webp
https://cdn.example.com/art/PHR-042.webp
```

Then set the base URL once, via `AppPreferences.setIllustrationBaseUrl(...)`. It
is stored rather than hardcoded, so the host can move — or point at a staging
bucket during testing — without shipping a new build.

Requirements on the host: plain HTTPS GET, no auth, permissive CORS not needed
(this is a native app, not a browser). Long cache headers are fine but not
required; the app caches on disk itself and does not re-validate.

### Caching

Coil holds the downloaded files in `cacheDir/illustrations`, capped at **64 MB**
— comfortably more than the whole library at the target file size, so in practice
nothing is ever evicted, while still bounding what the app takes from a phone
that is short on space.

### Prefetching

While a learner is reading one card, the next five cards' drawings are already
being fetched (`IllustrationLoader.prefetch`). That is what stops on-demand from
feeling like waiting. Five, not fifty: every unnecessary fetch spends the
learner's mobile data on a word they may never reach.

---

## The trade this makes

**Illustrations are the one part of this app that needs a network.** Words,
chunks, exercises and spaced repetition all work entirely offline; the artwork
does not.

A learner studying on a train with no signal sees the reserved frame with its
text fallback. That is a degraded card, never a broken one, and the drawing
appears the next time they are online. Worth knowing, because "works offline" is
otherwise true of everything else in the app.

## Before any artwork exists

Which is the state today, and for a while yet.

A word with no artwork — or the whole library, when no host is configured —
renders the reserved frame with the word's `visualAssociation` text set inside
it, in the card's own type. The frame is the same size either way, so the layout
never shifts and a half-illustrated library does not look half-finished.

The library-status screen shows how much artwork this device has cached, and says
plainly when no host is configured yet.


---

## The 10-image trial (2026-09-17)

Ten drawings generated with **Recraft V4.1 in vector mode**, 2.5 credits each,
25 credits of the 1,639 available. Words chosen to span the easy and the hard:
`VRB-001 understand`, `PHR-001 wake up`, `ADJ-001 difficult`, `ADV-001 always`,
`NUM-001 several`, `PRN-001 I`, `PRP-014 between`, `PRP-041 under`,
`CNJ-001 and`, `CNJ-007 although`.

Half of those are abstract on purpose. Roughly 250 of the 1,000 words are
pronouns, prepositions and conjunctions, and a trial made only of *drink* and
*mountain* would prove nothing about them.

### What the run established

**The palette is a parameter, not a hope.** Recraft takes the four app colours
as an input and constrains the output to them, so palette drift across 1,000
images is not a risk that needs managing.

**The output is SVG, not raster.** Vector mode returns true vector files. That
is better than the brief assumed: rasterising to 1200 × 900 is lossless, the
originals can be re-rendered at any future density, and the source files are
small. Worth considering whether the app should ship SVG directly — Coil needs
an extra decoder for it, and the spec above says WebP, so this is a decision
rather than an obvious win.

**Generated size is 1024 × 768**, not the 1200 × 900 the spec asks for. Harmless
given vector output; the conversion step renders at the right size.

### Conversion

`to_webp.py` (delivered alongside) takes the SVGs to spec: rasterise to
1200 × 900, flatten onto the paper colour, then search downward from quality 90
for the highest setting that still fits 45 KB, reporting anything that does not.
The cap is a *result*, not a setting — quality 80 lands anywhere from 12 KB to
90 KB depending on how busy the drawing is, and a flat run would silently ship
files at twice the budget.

`trial_map.csv` maps the generated filenames to word IDs.

### Found while picking the words

**21 of the 1,000 `visualAssociation` fields described text inside the picture** (since fixed) —
`VRB-043 define` ("a dictionary page with one word circled"), `PHR-117 fill out`
("writing information into the blank lines of a printed form"), and 13 others.
The brief forbids text in the artwork for three good reasons, so these need
rewriting before generating at scale or the model will bake words in. Some are
borderline and fine — illegible or blurred text reads as texture rather than
content — but each of the 15 needs a look.

`PRP-001 about` was going to be in this trial until its visual association
turned out to be "a speech bubble surrounding a single topic word". It was
swapped for `PRP-014 between`.

### Still to judge

Whether the style actually holds across the set, and whether the abstract words
read as their meaning, are **human judgements that have not been made**. See the
note in the session record about why.


### Realistic photo style — tested 2026-09-17

One photorealistic image generated for comparison (`PHR-001 wake up`), Recraft
V4.1 `model_type: standard`, **1.25 credits — half the vector price**.

It is the cheaper option and it looks good on a word like *wake up*. Three
things argue against it as the house style anyway:

1. **Consistency gets worse, not better.** Flat vector holds together because
   the palette is a parameter and the style has few variables. Photographs drift
   on lighting, room, camera angle and colour temperature all at once — a
   thousand of them read as a thousand different photographers. That is exactly
   the failure the style brief opens by warning about.
2. **File size roughly triples.** Flat colour and hard edges are what let a
   1200 × 900 WebP land at 45 KB. A photograph carries texture and gradients
   everywhere and lands nearer 80–150 KB at the same size. On the audience's
   phones and mobile data, that is a real cost.
3. **The abstract quarter has no photograph.** You can photograph *wake up* and
   *under*. There is no photograph of *although*, *however*, *between* or *and*,
   and those word types are about 250 of the 1,000. A realistic library would
   have to fall back to illustration for a quarter of the words, which is a
   mixed style — worse than either done consistently.

**Cost, for the record:** realistic 1,000 × 1.25 = 1,250 credits, which the
current balance covers. Vector 1,000 × 2.5 = 2,500 credits, which it does not.
That is the one clear argument in favour, and it is worth weighing against the
three above rather than dismissing.


---

## Generating these yourself

`tools/HIGGSFIELD_GUIDE.md` is the standalone playbook: model, settings, the
exact prompt, the gotchas, and what to do with the files afterwards. It does not
depend on this document or on anyone's help.

`tools/prompts_1000.csv` holds a ready prompt for every one of the 1,000 words,
built from the `visualAssociation` field already in `words.json`. Verified: 1,000
rows, ids match the dataset exactly, no empty scenes, and **one single style
block across every row** — that last one matters, because a style block that
changes partway through produces two libraries that do not match each other.

`tools/build_prompts.py` rebuilds that CSV after any scene is edited, and
re-flags the ones that describe text in the picture. There are currently **none** — 16 were rewritten and 5 cleared by hand.
