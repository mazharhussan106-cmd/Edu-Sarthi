# Launch checklist

Phases 1–5 are built. **Nothing left on this list is code**, which is the point of
writing it down — the remaining work is decisions, accounts and one small server,
and none of it gets easier by being discovered during a Play Store review.

**Superseded by [ROADMAP.md](ROADMAP.md) (2026-09-17).** That file is ordered by
what actually blocks what, accounts for the Play Console 12-tester rule, and
reflects the credit model. This checklist is kept for its per-item detail, but
where the two disagree the roadmap is current — several items here still
describe the subscription that no longer exists.

---

## 1. Decide the name — blocks everything

`namespace` and `applicationId` are `com.speaksarthi.app`. Changing them is a
find-and-replace **right up until the first Play Store upload**, and permanent
after it. Google will not let you change an applicationId, ever; a new name after
launch means a new listing and losing every install and review.

Also settle: the launcher icon (the current one is a placeholder), and whether
"Speak Sarthi" is free of trademark conflict in your categories.

---

## 2. The speech proxy — blocks any public release

The app can hold an Azure key in `BuildConfig`. **That key can be pulled out of
the APK in about ten minutes, and the quota it unlocks is billed to you.**

`docs/SERVER_CONTRACT.md` has the endpoint. It is one POST that authenticates the
caller, checks their daily usage, adds the real key and forwards the request. The
app already speaks the protocol — set `SPEECH_PROXY_URL` and nothing else
changes.

A closed beta with trusted testers can ship without it. A public listing cannot.

**Before that, get an Azure Speech key** (free tier F0 is 5 audio hours a month)
and put roughly twenty real recordings through it. The band thresholds in
`ScoreInterpreter` are reasoned from how the service is known to treat Indian
English; they have never been measured, and they are the difference between the
app encouraging someone and quietly discouraging them.

---

## 3. Play Console setup — blocks the subscription

- Create the subscription product with id **`speak_sarthi_scoring_monthly`** and
  base plan **`monthly`**, priced at ₹249. The ids are in
  `BillingRepository` and must match exactly; they cannot be changed later
  without stranding existing subscribers.
- Add licence testers and test a purchase end to end, **including a pending one**
  — UPI mandates and net banking sit unconfirmed for hours, and that path has
  code written for it that has never run.
- Test **restore purchases** on a fresh install. It is the first thing anyone who
  paid and changed phone will look for.
- Set up the merchant account and tax details. India-specific: GST registration
  affects what Play remits to you, and the ₹179 net figure the whole business
  model rests on assumes 18% GST plus Play's 15%.

---

## 4. Privacy policy — blocks the listing

`docs/PRIVACY_POLICY.md` is a draft written against what the app actually does.
It needs:

- Company name, address and a **real contact inbox** filled in
- The speech processor **named** — Azure, or your proxy and where it is hosted
- Review by someone qualified, then publishing at a public URL
- The Play **Data Safety form** filled in to match it. Where the form and the
  policy disagree, Google believes the form.

India's DPDP Act treats voice as personal data. The draft anticipates what it
asks for; it does not remove the need for someone to check it.

---

## 5. A feedback inbox

`FeedbackScreen` sends to `feedback@example.com`. One constant, one line, and it
is how you hear about the bugs your beta finds.

---

## 6. The illustrations

The frame is reserved on every card, the loader, cache and prefetch are built,
and the brief is written (`docs/ILLUSTRATIONS.md`): WebP, 4:3, 1200×900, under
45 KB, named `<WordId>.webp`. You need the artwork and any static host. Until
then every card shows its text fallback, which is a supported state, not a
broken one.

---

## 7. Decisions still open

- **Analytics.** The event list is written and the call sites exist; nothing is
  connected. Wiring Firebase means a third-party SDK phoning home from every
  install — your decision, and it changes the privacy policy.
- **Memory trick vs mnemonic story.** One `mnemonic` field, two blocks on the
  reference card. Either show it once or write a second column for all 1,000.
- **Which reading of "5,000 users".** Installs (~₹45k/month at 5% conversion) or
  paying subscribers (~₹9 lakh/month). Different businesses.
- **Neural audio.** The app speaks with the phone's own TTS, which is free and
  offline but varies by handset — and this is a pronunciation app. Roughly ₹200
  one-time buys the whole library pre-generated. Test on a cheap phone and decide.

---

## 8. Before the beta build

**Item zero: make it compile.** Nothing on this list can be verified until the
project builds, and it never has — see [FIRST_BUILD.md](FIRST_BUILD.md) for what
to expect and how to read the errors.

- [ ] `./gradlew assembleDebug` succeeds and the app launches on a real phone
- [ ] `./gradlew test` and `./gradlew connectedAndroidTest` both green
- [ ] **Commit `app/schemas/`** — build once and check it in. It is the only
      record of what a released database looked like, and the migration tests
      skip without it
- [ ] `python3 content/verify_project.py` clean
- [ ] Run on a genuinely cheap phone, not an emulator: check TTS quality,
      recording, and how the card reads at the largest system font size
- [ ] Turn on a reminder and confirm it fires the next day, not immediately
- [ ] Export a backup, uninstall, reinstall, restore — the whole point of that
      feature is the path nobody tests until they need it
- [ ] Release build with R8 on, then test recording and scoring again —
      serialization and Room are the usual casualties of minification
- [ ] Sign it, and **keep the keystore somewhere you will still have in five
      years**. A lost upload key is a lost app

---

## What you are shipping

An app where all 1,000 words, every phrase, the flashcards, listening practice,
recording and playing yourself back, mistake review, lessons, badges, statistics
and backup are free forever — and the subscription buys more AI pronunciation
scoring, which is the only thing that costs money per use.

That line is worth holding. It is honest, it is the only split the arithmetic
supports, and it means nobody who pays feels misled.
