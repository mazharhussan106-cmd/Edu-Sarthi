# Privacy policy — DRAFT

**Updated 2026-09-17 for the credit model, the server, and Google sign-in. It is
not legal advice, and it must be reviewed by someone qualified before it is
published.** Two things still have to be filled in:

- `[YOUR FULL LEGAL NAME]` and `[YOUR ADDRESS]` — Speak Sarthi is published by an
  individual, not a company, so this is **your own name and address**, and it
  will be public. If that matters to you, the usual answer is a registered
  business address rather than a home one; that is a decision to make before
  publishing, not after.
- The **effective date**, set on the day it goes live.

The Play Store will not accept a data-collecting app without a published policy
at a public URL, and the Data Safety form has to match this document. Where they
disagree, Google believes the form — so fill the form in from this, not from
memory.

---

## What this app is

Speak Sarthi helps you learn spoken English. You study words, practise sentences
aloud, and — optionally — send a recording to be scored for pronunciation.

The short version of this policy: **your learning stays on your phone.** Every
word you have studied, every score, every recording and every sentence you write
is on your device and nowhere else.

Two things do leave it, and both are listed in full below: a voice clip at the
moment you tap to score it, and — because scoring costs real money — a small
record on our server of how many scoring credits you have left.

---

## What is stored on your device

All of this lives in the app's own private storage. It is not readable by other
apps, it is not sent anywhere, and it is deleted when you uninstall the app.

| What | Why |
|---|---|
| Which words you have studied, and when they are next due | So spaced repetition can schedule them |
| Your bookmarks, your level, your daily goal | Your settings |
| Sentences you write in the "write your own" exercise | Shown back to you at the next review |
| Your streak and daily counts | Statistics and badges |
| Your voice recordings | So you can play yourself back |
| Pronunciation scores and which sounds you find hard | The "sounds to work on" list |
| An anonymous identifier for this installation | See below |

### The anonymous identifier

On first launch the app generates a random identifier for this installation. It
is a random number. It is **not** derived from your device, your phone number,
your Google account or anything else about you, and it cannot be linked back to
you by us or by anyone else.

It exists so your progress belongs to something, which is what makes it possible
to back it up and restore it later.

---

## What leaves your device

### Voice recordings sent for pronunciation scoring

When — and only when — you tap **Score it** on a recording, that audio clip is
sent to a speech-analysis service to be scored for pronunciation. What comes back
is a set of numbers: how accurate each sound was, how fluently you spoke, and how
much of the sentence you said.

- The clip is sent for scoring and is not used to train anything.
- We do not keep a copy on our servers.
- Recording a clip does **not** send it. Only scoring does.
- You can use the entire app, including recording and playing yourself back,
  without ever sending anything.

**Who processes it, and where.** The clip is sent first to our own server, run
on Cloudflare Workers, which adds the credentials for the speech service and
passes the audio straight on. It is not stored there. The speech service is
**Microsoft Azure AI Speech (Pronunciation Assessment)**, and the audio is
processed in Microsoft's `[AZURE REGION]` region.

> **[CONFIRM BEFORE PUBLISHING]** Replace `[AZURE REGION]` with the region you
> actually create the Speech resource in — `centralindia` if you follow the
> default in this project. Under India's DPDP Act you have to be able to answer
> "who processed my voice and where", and naming the wrong region is the same as
> not answering.

### Buying credits

Scoring is paid for with credits. Everything else in the app — all 1,000 words,
the flashcards, listening practice, recording and playing yourself back — is free
and always will be.

If you buy a credit pack, the payment is handled entirely by Google Play. **We
never see your card, your UPI id, or your bank details.** Google gives us a
purchase token, we ask Google whether that purchase is real, and we add the
credits. We keep the token so the same purchase cannot be redeemed twice.

### Your credit balance

Because each score costs us money, your balance is kept on our server rather than
on your phone — a number stored on a device can be edited on that device.

What the server holds against your installation:

| What | Why |
|---|---|
| The random installation identifier described above | To know which balance is yours |
| Your credit balance, and the history of how it changed | So it is correct, and so a disputed balance can be explained |
| Purchase tokens from Google Play | So one purchase cannot be redeemed twice |
| A session token for this installation | So the app does not have to re-introduce itself every time |

It does **not** hold your recordings, your progress, which words you have
studied, your scores, or anything you have written.

### Signing in with Google — only if you choose to

The app never asks you to sign in to use it. It offers to, once, when your
credits are running low, and declining costs you nothing.

If you do sign in, Google confirms to our server that the account is yours, and
we store **your Google account identifier and your email address** so your
credits survive a new phone. That is the whole reason it exists — without it,
credits live only on the device that bought them.

That email address is the one piece of information in this app that identifies
you personally. It is not used for marketing, is not shared with anyone, and you
can ask us to delete it (see below).

### Crash and usage information

> **[TO COMPLETE BEFORE PUBLISHING]** As shipped, the app collects **no** analytics
> and contains **no** third-party analytics SDK — the code is written for one but
> nothing is connected. If you connect Firebase, Amplitude or anything similar,
> this section has to describe it honestly: what is collected, who gets it, and
> how to opt out. Do not ship an SDK and leave this paragraph as-is.

---

## What we never collect

- Your name, phone number or address — the app never asks
- Your contacts, photos, location, or any other app's data
- Anything at all, if you never tap "Score it"

The microphone permission is used only while you are recording, and only after
you have granted it. Notification permission is asked for only when you switch on
a reminder.

---

## Backups

The app can export everything it knows about your learning to a single file that
**you** choose where to put — your own Drive, a memory card, anywhere.

That file is yours. We never see it and it is never uploaded anywhere by the app.
Where you put it, and who can then read it, is up to you. It contains your
progress, your streak, your badges and the sentences you wrote; it does **not**
contain your voice recordings.

---

## Children

This app is not directed at children under 13, and we do not knowingly collect
anything from them. If you believe a child has used the app and sent recordings,
write to `[CONTACT EMAIL]` and we will delete what we can.

---

## Your choices, and how to exercise them

| You want to | How |
|---|---|
| Delete your recordings | Settings → Your recordings → Delete all recordings |
| Stop sending anything anywhere | Simply do not tap "Score it" — everything else works |
| Delete everything | Uninstall the app. All of it is on your device, so it goes with it |
| Take your progress elsewhere | Settings → Backup → Export |
| Delete the account and its credits | Write to `[CONTACT EMAIL]` — we will delete the account, the balance and the email address |
| Ask what we hold about you | Write to `[CONTACT EMAIL]` |

**If you have not signed in**, what we hold is a random installation identifier
and a credit balance against it. Nothing there points at a person.

**If you have signed in**, we also hold your Google account identifier and email
address. That does identify you, and you can ask for it to be deleted. Deleting
it also deletes the credits attached to it, including any you have paid for —
which is a real consequence and why it is not a button in the app.

---

## Changes to this policy

If what the app does changes, this changes with it, and the app will show you the
notice again rather than quietly updating it.

**One change has already happened**, and this document was rewritten for it
rather than quietly amended: optional Google sign-in, and a credit balance held
on a server. Both are described above.

**Two further changes are possible and would require the same treatment:**

1. **Cloud sync of your learning.** Today your progress is only ever on your
   phone. If that changed, this document would stop being true as written, and
   the notice would be shown again.
2. **Human review of recordings.** An idea for later would have a real person
   listen to a clip and reply. A person hearing your voice is a materially
   different thing from a service scoring it, and it needs its own explicit
   consent — not a paragraph added quietly to this one.

---

## Contact

`[YOUR FULL LEGAL NAME]`
`[YOUR ADDRESS]`
`[CONTACT EMAIL]`

> `[CONTACT EMAIL]` is `mazharhussan106@gmail.com` in the app today. Worth
> replacing with a dedicated address before publishing, so that it survives your
> personal address changing and so the listing does not show a personal Gmail.

**Effective:** `[DATE]`

---

## Notes for whoever finalises this

**The Play Data Safety form.** Fill it in from what the app does, and re-check it
every time the answer changes. As shipped: audio is collected and transferred for
app functionality, not linked to identity, not used for tracking, and users can
request deletion. If analytics is connected later, the form changes.

**India's DPDP Act, 2023.** Voice is personal data. What it asks of you that this
draft already anticipates: a clear purpose stated before collection (the app
states it at the point of recording), no collection beyond that purpose, a named
grievance contact, and the ability to withdraw consent as easily as it was given
— which here means the app must keep working when someone stops scoring, and it
does.

**If you add a server.** The moment progress leaves the device, most of this
document is wrong. Rewrite it then, rather than appending to it — a privacy
policy with three years of appended paragraphs is one nobody can follow, including
you.
