# Pronunciation scoring

How the audit engine works, how to switch it on, and the one thing about it that
must change before the app is published.

---

## What it does

The learner reads a sentence aloud. The app records 16 kHz mono PCM, wraps it in
a WAV header, and posts it to Azure Speech's **Pronunciation Assessment** with the
sentence as the reference text. What comes back is not a transcript — it is four
scores plus a breakdown to the level of individual sounds:

| | |
|---|---|
| **Accuracy** | how close each sound was to the expected one |
| **Fluency** | pacing and pausing |
| **Completeness** | how much of the sentence was actually said |
| **PronScore** | the service's own weighted overall |
| **Per word** | accuracy, and an error type: None, Mispronunciation, Omission, Insertion |
| **Per phoneme** | accuracy for each sound inside each word |

The per-phoneme layer is the whole reason this service was chosen over cheaper
transcription APIs. "Your /v/ keeps coming out as /w/" is something a learner can
act on this week. "72%" is not.

---

## Switching it on

Three values, read at build time from `local.properties` (gitignored) or from the
environment. All three are blank in a fresh checkout, and **blank is a supported
state**: recording, playback and everything else work, and the speaking screen
says plainly that scoring is not switched on.

```properties
# local.properties — never commit this file

# Route A — production. The app holds only this address.
SPEECH_PROXY_URL=https://api.yourdomain.com/v1/pronunciation

# Route B — development only. See the warning below.
AZURE_SPEECH_KEY=your-key-here
AZURE_SPEECH_REGION=centralindia
```

If `SPEECH_PROXY_URL` is set it wins; the key is ignored. Rebuild after changing
either — these are compiled into `BuildConfig`, not read at runtime.

To get a key: Azure Portal → Create a resource → Speech service. The free tier
(F0) gives 5 audio hours a month, which is plenty for development. Pick a region
close to your learners; `centralindia` is the obvious one here.

---

## ⚠️ The key cannot ship in the APK

A key compiled into an Android app can be extracted from it in about ten minutes
with public tooling. The quota it unlocks is billed to whoever published the app.
Route B exists so the feature can be tested against real audio before there is a
server; **it must not be the route a released build uses.**

The daily cap inside the app (`AppPreferences.dailySpeechSecondsCap`, enforced by
`SpeechBudget`) is a courtesy to the learner and a first line of defence. It is
not security. Anyone can edit a client, and a caller with the extracted key does
not need the client at all.

What the proxy has to do — it is genuinely small:

1. Authenticate the caller as one of your users.
2. Look up how much scoring that user has spent today and refuse them past the
   cap. **This is the check that actually protects the bill.**
3. Forward the audio body and the `Pronunciation-Assessment` header to Azure with
   the real key attached, and return Azure's response unchanged.

Point 3 matters: the app already sends the assessment header and expects Azure's
response shape back, so a transparent pass-through needs no app changes at all.

---

## The audio format

Azure reads the sample rate from the `Content-Type` header, **not** from the WAV
header, and it wants uncompressed PCM:

```
Content-Type: audio/wav; codecs=audio/pcm; samplerate=16000
```

Which is why the app captures with `AudioRecord` and writes the WAV header by
hand (`WavFile`) rather than using `MediaRecorder`. `MediaRecorder` produces AAC
or AMR in an MP4 or 3GP container, which is either rejected outright or
transcoded somewhere and then scored against audio that is not quite what the
learner said.

`WavFileTest` checks that header field by field, including endianness. A header
wrong by one field produces a file that plays perfectly on the phone and is
rejected by the service with a generic error — the worst failure mode available,
because it looks like the service is broken.

Other deliberate capture choices, in `AudioRecordVoiceRecorder`:

- **`VOICE_RECOGNITION` audio source**, not `MIC`. The platform applies
  speech-tuned noise suppression and, importantly, skips the automatic gain
  control `MIC` applies — AGC flattens exactly the loudness variation the service
  reads as fluency.
- **Buffer four times the reported minimum.** A cheap phone under load can be
  slow returning for the next read, and a buffer that runs dry drops samples
  mid-word. Dropped samples score as mispronunciation.
- **15-second cap.** Product decision and cost decision at once: scoring is billed
  per minute, and one short sentence said carefully teaches more than a rambling
  paragraph. It is also far less frightening.

---

## How a score becomes something a learner reads

`ScoreInterpreter` is the only thing allowed to decide what appears on screen.
Four rules, each enforced there and pinned by tests:

1. **A band, not a number.** The raw scores are kept and shown behind a tap, but
   never as the headline.
2. **The band comes off accuracy, not the service's overall.** The overall folds
   in fluency, and fluency punishes the careful, slightly slow delivery of
   someone nervous about speaking — which is this app's entire audience. Their
   sounds being right is what is graded; their pacing is coaching.
3. **Completeness is read separately.** Skipping three words is a different
   problem from mispronouncing one, and telling someone their pronunciation is
   poor when they simply stopped early is just wrong.
4. **A low band never appears alone.** It always carries one specific sound to
   fix, in one specific word, described as a mouth movement — "top teeth on your
   bottom lip, not a w", never "labiodental fricative".

And the lowest band is called **"Say it again"**, not "Poor". It is an
instruction, not a verdict.

### The thresholds are deliberately low

```kotlin
CLEAR_FROM = 78f
UNDERSTANDABLE_FROM = 62f
NEEDS_WORK_FROM = 45f
```

Lower than a native-speaker product would use. The service is measurably harsher
on Indian English than on American English — retroflex consonants, syllable-timed
rhythm, a different vowel inventory, none of which make a speaker harder to
understand in the rooms they will actually be in. At default thresholds a
perfectly intelligible speaker lands mid-band on almost every sentence, which
teaches them nothing except that the app disapproves of how they talk.

The same reasoning sets `PhonemeScore.WEAK_THRESHOLD = 60` rather than 75: a
higher bar fills the weak-sound list with vowels nobody would misunderstand.

### The locale is `en-IN`

Scoring an Indian learner against `en-US` marks their own variety of English
wrong. `en-IN` measures whether they are intelligible in the English they are
learning to speak, which is the thing worth measuring.

If a learner is specifically preparing for IELTS or a US employer, `en-US` is the
better reference for them. That is a setting worth adding — it is not a default
worth imposing on everyone.

---

## The speech budget

`SpeechBudget` holds the rule, and it is checked **before** anything leaves the
device.

The arithmetic: ₹249/month, minus 18% GST, minus Play's 15%, leaves roughly ₹179
net. A quarter of that is ₹45, which at about ₹1.50/minute buys around 30 minutes
a month — a minute a day. Hence:

```kotlin
DEFAULT_FREE_SPEECH_SECONDS = 75    // about five 15-second attempts
SUBSCRIBER_SPEECH_SECONDS  = 120    // about eight
```

Three properties worth keeping:

- **Clip cost rounds up.** The service bills per unit of audio; rounding down
  would quietly let the cap pass more than it promises, and that is the one
  direction it must not err in.
- **A failed call costs nothing.** No network, a 500, a clip with no speech in it
  — none of them spend the learner's day.
- **The recording is always saved.** Over budget, offline, not configured: the
  learner still has their own voice to play back against the model. They did the
  work; they keep it.

`SpeakingRepositoryTest` proves the gate with a fake scorer that counts how many
times it was actually called. "The check is in there somewhere" is not good
enough for the only thing standing between a few heavy users and a bill larger
than the revenue.

---

## Weak sounds

Every phoneme the service scores counts as an **attempt**; the ones under the
threshold also count as an **error**. The list ranks by error *rate*.

Ranking by raw error count would put /t/ at the top for every learner alive,
because /t/ appears in more English words than anything else. The rate is what
says something about the speaker.

`PhonemeGuide` turns each IPA symbol into a name, an example word and a mouth
movement, covering the sounds that actually trouble Hindi and Urdu speakers. An
unlisted symbol gets an honest placeholder rather than an invented tip — a
confidently wrong pronunciation tip is worse than none, because the learner will
go and practise it.

---

## Where recordings live

`filesDir/recordings/`, private app storage. Not `cacheDir`, which the system
clears without asking, and the learner's own voice is the one thing in this app
they cannot get back.

Nothing is uploaded in v1. `RecordingEntity.uploadedAt` exists as the hook for the
v2 human-review tier, and stays null. **When that ships, the privacy policy has
to change with it** — recordings leaving the device is a materially different
product to describe.
