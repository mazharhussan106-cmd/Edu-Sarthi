# The server contract

**Rewritten 2026-09-17** for the credit model. The previous version specified a
server for a subscription app; that model is gone (see [DECISIONS.md](DECISIONS.md)).

The server now **exists** — it is in [`worker/`](../worker/), it is tested, and
its own [README](../worker/README.md) is the reference for deploying and calling
it. This file is the Android side of the same contract: what the app must send,
what it must do with each answer, and which of those paths has never run.

---

## Why there is a server at all

Three things the app cannot be trusted with, not because it is badly written but
because it runs on hardware its owner controls:

| | |
|---|---|
| The Azure key | Extractable from an APK in minutes; the quota is billed to the publisher |
| The credit balance | A number on the phone is editable on a rooted device in about two minutes |
| Whether a purchase happened | The app saying so is just a string it typed |

Everything else stays on the phone. Words, progress, streaks, review schedules
and recordings never leave it, which is what keeps the app working offline and
keeps the privacy policy short.

---

## What the app has to do

### On first launch, and on every cold start

`POST /v1/session` with the app's own persistent local id. Back comes a bearer
token and the balance. The token lasts 30 days; on a 401, call this again.

The local id already exists — it is `Profile.localId`, generated on first launch
and never changed, including when signing in. That property is load-bearing:
every progress row was earned under it.

### Before showing the speak screen

Use the balance from the session call. Do not ask again per card — the score
response carries the new balance in `X-Credits-Remaining`, which is enough to
keep the display honest without a request per card.

### To score a recording

`POST /v1/score?text=<reference>` with the raw WAV as the body. The app already
produces exactly this: 16 kHz mono PCM with a hand-written RIFF header.

The response is Azure's own, unchanged, so `AssessmentResponse` and every test
in `PronunciationReportTest` keep working untouched. Only the destination URL
and the auth header change.

Three answers to handle:

- **200** — parse as now. Update the balance from `X-Credits-Remaining`.
- **402 `no_credits`** — show the packs. Recording and playback keep working;
  only the AI score stops. This is a decision, not a limitation: recording costs
  nothing to provide, and taking it away would punish a learner for being broke.
- **502 `scoring_unavailable`** — say scoring could not be completed and offer
  to try again. **The credit has already been given back**; do not decrement
  anything locally.

### To buy credits

Play Billing, three consumable products. On a successful purchase, send
`POST /v1/purchase` with the product id and purchase token, then **consume** the
purchase through Play so the pack can be bought again.

Order matters: grant first, consume second. Consuming before the server has
recorded the grant loses the purchase if the network drops in between, and the
learner has paid for nothing.

`state: "pending"` is a normal answer in India, not an edge case — a UPI mandate
can sit unconfirmed for hours and may never complete. Say plainly that the
payment is waiting and check again later. Do not grant anything locally.

`granted: false` with `state: "purchased"` means this token was already redeemed.
That is success, not an error: show the balance and move on.

### To claim a bonus

`POST /v1/earn` with `{ kind, ref }` on finishing a lesson (`kind: "lesson"`,
`ref`: the lesson id) or completing a 7-day streak (`kind: "streak"`, `ref`: the
ISO week). Each pays once and each kind is capped daily.

Fire and forget. If it fails, the learner keeps the lesson; the credits are a
bonus, not a payment, and retrying forever is not worth the battery.

### To sign in

**When credits run low, not at first launch.** Someone nervous about their
English, asked to create an account before they have seen anything, leaves.

`POST /v1/link` with the Google ID token. Back comes a **new** session token —
the account id can change when two accounts merge — so replace the stored one.

Signing in never loses credits and never creates them. Two phones on one Google
account share one balance.

---

## Product ids

These must match the Play Console exactly, and cannot be changed later without
stranding people who bought them. The credit counts live on the server, so they
can be corrected without an app release.

| Product id | Price |
|---|---|
| `credits_entry` | ₹99 |
| `credits_standard` | ₹249 |
| `credits_large` | ₹499 |

**The counts are provisional.** They assume roughly ₹0.40 per scored attempt, a
figure that has never been measured against a real Azure bill. Measure it with
the free F0 tier before launch, then set `PACKS` in `worker/src/catalog.ts`.

---

## What has never run

Honest list, because all of it looks finished and none of it is proven.

- **The Google sign-in check.** `verifyGoogleIdToken` verifies the signature
  against Google's published keys. It has never seen a real token.
- **Play verification.** `verifyPurchase` and `acknowledgePurchase` need a
  signed build and configured products. Every state is written; none has
  executed.
- **The Azure call itself.** The protocol matches what the app already sends,
  but no clip has been through the live service from here.
- **The Android side of all of this.** Now written (2026-09-17) and statically
  checked, but **never compiled** — Maven is unreachable from the environment it
  was built in. Every line of it is unproven in a way that only a real build and
  a real device can fix.

The credit rules themselves *are* tested, against real SQLite, with every test
proved by injecting the fault it catches. That is the one part of this you can
currently trust.

---

## Not this server's job

Sync, accounts-as-a-feature, leaderboards, and human review of recordings. Each
would mean holding learner content rather than metering a meter, and each changes
the privacy policy. When the live-test-with-a-real-person idea comes back
(roadmap, not launch), it starts here — and it starts with a lawyer.
