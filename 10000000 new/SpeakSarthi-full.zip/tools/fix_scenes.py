#!/usr/bin/env python3
"""
Rewrite the visual associations that ask for readable text in the picture.

These strings do double duty: they are the illustration prompt, *and* they are
what a learner sees inside the frame when a word has no artwork yet. So a
rewrite has to work as English a learner reads, not only as a prompt.

Run:  python3 tools/fix_scenes.py app/src/main/assets/seed/words.json
"""
import json
import sys

# wordId -> new scene.
#
# Each replaces a description that asked for words, letters or a readable label
# inside the drawing. The style brief rules those out: baked-in text ignores the
# learner's font-size setting, a screen reader cannot read it, and it cannot be
# translated if the app ever adds a second interface language.
REWRITES = {
    # Was: a dictionary page with one word circled in red.
    "VRB-043": "A magnifying glass held over one object, holding it sharp while everything around it stays blurred.",
    # Was: glasses over blurry text, bringing it into focus.
    "VRB-045": "A pair of glasses held up, turning a blurred shape behind them into a clear one.",
    # Was: an open book with eyes scanning the lines of text.
    "VRB-114": "An open book with a pair of eyes above it, tracking steadily across the page.",
    # Was: repeating flashcards until the words stick.
    "VRB-126": "A stack of cards being turned one by one, with an arrow looping back to the start.",
    # Was: squinting at blurry, distant text.
    "PHR-024": "Squinting eyes, and a distant blurred shape slowly resolving into a clear outline.",
    # Was: writing information into the blank lines of a printed form.
    "PHR-117": "A hand holding a pen above a clipboard of empty ruled lines.",
    # Was: writing a name on a clipboard sign-up sheet.
    "PHR-143": "A hand holding a pen above a clipboard, adding one more tick to a short list.",
    # Was: a visitor writing their name and time of arrival on a clipboard.
    "PHR-144": "A hand placing a visitor badge onto a front desk, a clock on the wall behind.",
    # Was: writing a name and time next to "departure" on a clipboard.
    "PHR-145": "A hand returning a visitor badge to a tray, the clock behind showing a later hour.",
    # Was: a checkbox on a form left unchecked and free to skip.
    "ADJ-141": "A row of three boxes, two of them ticked and the third left deliberately empty.",
    # Was: a newspaper headline with the word "AMAZING" in bold letters.
    "ADJ-145": "One bright star standing far above a row of small, identical ones.",
    # Was: a daily planner with the same activity written in almost every box.
    "ADV-007": "Seven suns in a row for the days of a week, with a single cloud among them.",
    # Was: a single word in bold capitals, underlined twice for emphasis.
    "ADV-077": "A container filled right to the very brim, with no space left anywhere in it.",
    # Was: a tag with your own name written on it.
    "PRN-013": "A hand resting firmly on top of a bag, holding it close.",
    # Was: a label tied to a branch reading 'its leaves.'
    "PRN-016": "A tree with an arrow curving out from its trunk and back to its own leaves.",
    # Was: a speech bubble surrounding a single topic word.
    "PRP-001": "A speech bubble with one small object floating at its centre.",
}


def main(path: str) -> int:
    words = json.load(open(path, encoding="utf-8"))
    by_id = {w["wordId"]: w for w in words}

    missing = [wid for wid in REWRITES if wid not in by_id]
    if missing:
        sys.exit(f"These word ids are not in the dataset: {missing}")

    changed = 0
    for wid, scene in REWRITES.items():
        word = by_id[wid]
        if word.get("visualAssociation") != scene:
            print(f"{wid:9} {word['word']:12}")
            print(f"  was: {word.get('visualAssociation','')}")
            print(f"  now: {scene}")
            word["visualAssociation"] = scene
            changed += 1

    if changed:
        # ensure_ascii=False so the curly apostrophes and dashes in the rest of
        # the dataset survive the round trip rather than turning into escapes.
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(words, fh, ensure_ascii=False, indent=2)
            fh.write("\n")

    print(f"\n{changed} scenes rewritten in {path}")
    return 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    raise SystemExit(main(sys.argv[1]))
