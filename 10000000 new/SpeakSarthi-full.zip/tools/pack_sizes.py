#!/usr/bin/env python3
"""
Turn a measured cost per scored attempt into credit pack sizes.

    python3 pack_sizes.py --cost-per-attempt 0.40

Everything about pricing in this project waits on one number that has never been
measured: what a single scored attempt actually costs. Once you have it from a
real Azure bill, this works out what each pack can contain.

It is arithmetic, not advice. The margin you choose is a business decision.
"""
import argparse

# Settled in docs/DECISIONS.md. Prices, not credit counts.
PACKS = [("credits_entry", 99), ("credits_standard", 249), ("credits_large", 499)]

GST = 0.18          # charged on the sale price in India
PLAY_CUT = 0.15     # Google's cut at the small-business rate
WELCOME_CREDITS = 50


def net_of(price: float) -> float:
    """What actually reaches you from a rupee of sale price."""
    # GST comes out of the price, then Play takes its cut of the rest.
    ex_gst = price / (1 + GST)
    return ex_gst * (1 - PLAY_CUT)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cost-per-attempt", type=float, required=True,
                    help="Rupees per scored attempt, MEASURED not guessed")
    ap.add_argument("--margin", type=float, default=0.60,
                    help="Share of net revenue kept as margin (default 0.60)")
    args = ap.parse_args()

    cost = args.cost_per_attempt
    if cost <= 0:
        raise SystemExit("cost-per-attempt must be above zero")

    print(f"Measured cost per attempt : Rs {cost:.3f}")
    print(f"Target margin             : {args.margin:.0%} of net revenue")
    print(f"Free welcome grant costs   : Rs {WELCOME_CREDITS * cost:.2f} per install\n")

    print(f"{'pack':20} {'price':>7} {'net':>8} {'spend':>8} {'credits':>9}")
    print("-" * 56)

    sizes = {}
    for product, price in PACKS:
        net = net_of(price)
        spendable = net * (1 - args.margin)
        credits = int(spendable / cost)
        sizes[product] = credits
        print(f"{product:20} {price:7.0f} {net:8.2f} {spendable:8.2f} {credits:9d}")

    entry = sizes["credits_entry"]
    print()
    if entry <= WELCOME_CREDITS:
        # The ladder problem flagged in DECISIONS.md, made concrete.
        print(f"WARNING: the entry pack is {entry} credits against a {WELCOME_CREDITS}-credit")
        print("free grant. Nobody who just received 50 free buys 60 more. Either cut the")
        print("grant, raise the entry price, or accept a thinner margin on the entry pack")
        print("and treat it as the thing that starts the habit rather than the thing that")
        print("earns.")
    else:
        ratio = entry / WELCOME_CREDITS
        print(f"Entry pack is {ratio:.1f}x the free grant.", end=" ")
        print("Comfortable." if ratio >= 2 else "Thin — 2x or better is a clearer ladder.")

    print("\nPaste into worker/src/catalog.ts:\n")
    print("export const PACKS: Record<string, number> = {")
    for product, _ in PACKS:
        print(f"  {product}: {sizes[product]},")
    print("};")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
