"""Render an Android vector drawable to PNG so it can actually be looked at.

In a vector drawable the *attributes* are namespaced but the element names are
not — `path`, not `{android}path`. Getting that wrong produces a valid, empty
SVG and a blank image, which is a very quiet way to ship a broken icon.
"""
import sys
import xml.etree.ElementTree as ET
import cairosvg

NS = '{http://schemas.android.com/apk/res/android}'

def to_svg(vd_path: str, bg: str) -> str:
    root = ET.parse(vd_path).getroot()
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108">',
           f'<rect width="108" height="108" fill="{bg}"/>']
    paths = root.findall('path')
    if not paths:
        sys.exit(f"{vd_path}: no <path> elements found — nothing would render")
    for p in paths:
        d = p.get(f'{NS}pathData')
        fill = p.get(f'{NS}fillColor') or 'none'
        if fill == '#00000000':
            fill = 'none'
        stroke = p.get(f'{NS}strokeColor')
        attrs = f'd="{d}" fill="{fill}"'
        if stroke:
            attrs += (f' stroke="{stroke}" stroke-width="{p.get(NS+"strokeWidth")}"'
                      f' stroke-linecap="round" stroke-linejoin="round"')
        out.append(f'<path {attrs}/>')
    out.append('</svg>')
    return ''.join(out)

if __name__ == '__main__':
    vd, bg, png, size = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
    svg = to_svg(vd, bg)
    open('/tmp/_icon.svg', 'w').write(svg)
    cairosvg.svg2png(url='/tmp/_icon.svg', write_to=png, output_width=size, output_height=size)
    print(f"{png} ({size}px) from {len(svg)} bytes of SVG")
