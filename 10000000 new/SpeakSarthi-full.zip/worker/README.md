# The Speak Sarthi server

One Cloudflare Worker. It does three jobs and deliberately no others:

1. **Holds the Azure Speech key.** A key compiled into an APK can be extracted
   from it in minutes, and the quota it unlocks is billed to whoever published
   the app.
2. **Owns the credit balance.** A number kept on the phone is editable on a
   rooted device in about two minutes, and every edit spends real money.
3. **Proves a purchase happened**, by asking Google rather than believing the app.

Everything else — words, progress, streaks, review schedules — stays on the
phone, where it works offline and belongs to the learner.

---

## Setting it up

```bash
cd worker
npm install
npx wrangler login

# The credit ledger
npx wrangler d1 create speak-sarthi          # put the id in wrangler.toml
npx wrangler kv namespace create CACHE       # put the id in wrangler.toml
npm run db:remote                            # apply schema.sql

# Secrets — never in wrangler.toml, never in git
npx wrangler secret put AZURE_SPEECH_KEY
npx wrangler secret put SESSION_SIGNING_KEY     # any long random string
npx wrangler secret put GOOGLE_OAUTH_CLIENT_ID  # the Android OAuth client id
npx wrangler secret put PLAY_SERVICE_ACCOUNT    # the service-account JSON

npm run deploy
```

Then put the deployed URL into the app's `SPEECH_PROXY_URL` and nothing else
about the app changes.

### Running it locally

```bash
npm run db:local       # schema into the local D1
npm run dev            # http://localhost:8787
npm test               # the credit rules
npm run typecheck
```

For local work put non-secret values in `.dev.vars` (gitignored) and set
`DEV_TRUST_CLIENT_PURCHASES = "1"` in `wrangler.toml` to skip Play verification.
**Never deploy with that set** — it grants credits to anyone who asks.

---

## The endpoints

All responses are JSON. Errors carry `{ "error": "<code>", "message": "..." }`.

### `POST /v1/session`

The first call an install ever makes. Anonymous — no account needed.

```json
{ "localId": "the app's own persistent id" }
→ { "token": "...", "balance": 50, "signedIn": false }
```

Creates the account if it is new and grants the welcome credits, once. The
token goes in `Authorization: Bearer ...` on everything below.

### `GET /v1/balance`

```json
→ { "balance": 47, "signedIn": false }
```

### `POST /v1/link`

Attaches a Google identity. Asked for when credits run low, not at first launch.

```json
{ "idToken": "the Google ID token from the app" }
→ { "token": "...", "balance": 197, "signedIn": true, "email": "..." }
```

Merges anything that Google account already had. **Signing in never loses
credits and never creates them** — including the welcome grant, which is counted
once however many devices are merged. The session token is reissued because the
account id can change.

### `POST /v1/score?text=<reference text>`

The request body is the raw WAV, exactly as the app already records it: 16 kHz
mono PCM, up to 15 seconds.

Returns Azure's assessment response **unchanged**, so the app's existing parser
and its tests keep working. `X-Credits-Remaining` carries the new balance.

- `402` with `no_credits` if the balance is empty.
- `502` if the speech service failed — **and the credit is given back**. A
  learner never pays for a request that did not come back.

### `POST /v1/purchase`

```json
{ "productId": "credits_entry", "purchaseToken": "..." }
→ { "state": "purchased", "granted": true, "balance": 197 }
```

The token is checked against Google's own record before a single credit is
granted. `state` may be `pending` — a UPI mandate can sit unconfirmed for hours
and may never complete, so credits are granted only on `purchased`. Redeeming
the same token again returns `granted: false` and changes nothing.

Purchases are acknowledged immediately. Play refunds anything unacknowledged
after three days, by which time the credits are spent.

### `POST /v1/earn`

```json
{ "kind": "lesson", "ref": "L001" }
→ { "granted": true, "balance": 49 }
```

`kind` is `lesson` or `streak`. Each `ref` pays once, and each kind has a daily
cap.

---

## Two things worth understanding before changing anything

**The ledger is the truth; the balance is a cache.** Every mutation ends by
recomputing `accounts.balance` as the sum of that account's ledger rows, in the
same transaction. It costs one aggregate over a few hundred rows, and in return
the balance cannot drift, a half-applied write corrects itself on the next one,
and a disputed balance can be explained line by line.

**A grant with a `ref` can only ever happen once**, and that is enforced by the
unique index `ledger_once`, not by application logic — which a retry or a race
would eventually get past. One welcome grant per account, one per purchase
token, one per lesson, one refund per reservation.

Scoring **reserves** a credit before calling Azure and refunds it on failure.
Charging afterwards instead would mean a crash mid-request handed out free
scoring; not refunding would mean the learner paid for Azure's bad day.

---

## Tests

```bash
npm test     # 16 tests
```

They run against **real SQLite**, not a mock, because the rules that matter are
enforced by the database: the unique index, the `balance >= 0` check, and the
conditional `INSERT ... SELECT` that makes checking the balance and deducting
from it one indivisible step. A mock would agree with whatever the code believed
and prove nothing.

Each test has been proved by injecting the fault it claims to catch:

| Injected | Caught by |
|---|---|
| `balance >= ?` guard weakened in `reserve` | 7 tests, including "refuses to reserve when the balance is empty" |
| `refund` allowed to run on a spent reservation | "does not refund a reservation that was already spent" |
| `INSERT OR IGNORE` → `INSERT` in `grant` | "grants a purchase once, however many times it is redeemed" |

## What is not covered by tests

`auth.ts` and `play.ts` both call out to Google and are exercised only by
deploying. The riskiest line in either is the signature check in
`verifyGoogleIdToken` — decoding a Google token without verifying it is easy to
do by accident, since the payload is plain base64, and would let anyone claim
any identity by typing it. Read that function before trusting it.
