-- Speak Sarthi credit ledger.
--
-- The shape of this schema is decided by one rule: the balance is the only
-- thing standing between a learner and money spent on the owner's Azure
-- account, so every change to it must be atomic and every grant must be
-- impossible to claim twice.

-- An account owns a balance. It starts anonymous and may later be linked to
-- a Google identity; the row survives that, so nothing is lost on sign-in.
CREATE TABLE IF NOT EXISTS accounts (
  id          TEXT PRIMARY KEY,
  google_sub  TEXT UNIQUE,                -- null until the learner signs in
  balance     INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0),
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL
);

-- Installs. Several devices may point at one account once signed in; an
-- anonymous install points at an account nobody else can reach.
CREATE TABLE IF NOT EXISTS devices (
  local_id    TEXT PRIMARY KEY,
  account_id  TEXT NOT NULL REFERENCES accounts(id),
  created_at  INTEGER NOT NULL,
  last_seen   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS devices_account ON devices(account_id);

-- Every movement, ever. `accounts.balance` is a cache of the sum of this
-- table, kept in step inside the same transaction. Keeping the history means
-- a disputed balance can be explained rather than argued about.
CREATE TABLE IF NOT EXISTS ledger (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id  TEXT NOT NULL REFERENCES accounts(id),
  delta       INTEGER NOT NULL,
  reason      TEXT NOT NULL,              -- welcome|purchase|earn|score|refund|adjust
  ref         TEXT,                       -- purchase token, lesson id, reservation id
  created_at  INTEGER NOT NULL
);

-- The idempotency key, and the most load-bearing line in this file.
-- One welcome grant per account; one grant per purchase token; one bonus per
-- lesson; one refund per reservation. A retried request cannot pay twice.
CREATE UNIQUE INDEX IF NOT EXISTS ledger_once
  ON ledger(account_id, reason, ref) WHERE ref IS NOT NULL;

CREATE INDEX IF NOT EXISTS ledger_account_time ON ledger(account_id, created_at);

-- A credit held while the speech service is called. Reserving first means a
-- crash mid-call cannot hand out free scoring; refunding on failure means a
-- learner never pays for a request that did not come back.
CREATE TABLE IF NOT EXISTS reservations (
  id          TEXT PRIMARY KEY,
  account_id  TEXT NOT NULL REFERENCES accounts(id),
  state       TEXT NOT NULL,              -- held|committed|refunded
  created_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS reservations_stale ON reservations(state, created_at);

-- Play purchases. The primary key is the purchase token, which is what makes
-- replaying one impossible: the second insert collides.
CREATE TABLE IF NOT EXISTS purchases (
  token       TEXT PRIMARY KEY,
  account_id  TEXT NOT NULL REFERENCES accounts(id),
  product_id  TEXT NOT NULL,
  credits     INTEGER NOT NULL,
  state       TEXT NOT NULL,              -- pending|granted
  created_at  INTEGER NOT NULL,
  updated_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS purchases_account ON purchases(account_id);
