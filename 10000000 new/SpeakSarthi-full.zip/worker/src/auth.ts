import { unauthorized, type Env } from "./types";

/**
 * Who is calling.
 *
 * Two different things are verified here and they should not be confused.
 *
 * A **session token** is issued by this Worker and says "this request is the
 * device I already know about". It is signed, not encrypted — it carries no
 * secret, only an account id, and its whole job is to stop one device spending
 * another's credits.
 *
 * A **Google ID token** is issued by Google and says "this really is that
 * person's Google account". It is only ever checked when linking, and its
 * signature is verified against Google's published keys. Decoding it without
 * verifying — which is easy to do by accident, since the payload is plain
 * base64 — would let anyone claim any identity by typing it.
 */

const encoder = new TextEncoder();

const b64urlEncode = (bytes: Uint8Array): string => {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};

const b64urlDecode = (value: string): Uint8Array => {
  const padded = value.replace(/-/g, "+").replace(/_/g, "/");
  const binary = atob(padded + "=".repeat((4 - (padded.length % 4)) % 4));
  return Uint8Array.from(binary, (c) => c.charCodeAt(0));
};

const hmacKey = (secret: string) =>
  crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );

export interface Session {
  accountId: string;
  localId: string;
  expiresAt: number;
}

const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

export async function issueSession(
  secret: string,
  accountId: string,
  localId: string,
): Promise<string> {
  const payload: Session = {
    accountId,
    localId,
    expiresAt: Date.now() + SESSION_TTL_MS,
  };
  const body = b64urlEncode(encoder.encode(JSON.stringify(payload)));
  const signature = await crypto.subtle.sign(
    "HMAC",
    await hmacKey(secret),
    encoder.encode(body),
  );
  return `${body}.${b64urlEncode(new Uint8Array(signature))}`;
}

export async function readSession(
  secret: string,
  token: string | null,
): Promise<Session> {
  if (!token) throw unauthorized("No session token");

  const [body, signature] = token.split(".");
  if (!body || !signature) throw unauthorized("Malformed session token");

  // crypto.subtle.verify is constant-time, which a string comparison of the
  // two signatures would not be.
  const valid = await crypto.subtle.verify(
    "HMAC",
    await hmacKey(secret),
    b64urlDecode(signature),
    encoder.encode(body),
  );
  if (!valid) throw unauthorized("Bad session token");

  let session: Session;
  try {
    session = JSON.parse(new TextDecoder().decode(b64urlDecode(body)));
  } catch {
    throw unauthorized("Unreadable session token");
  }

  if (!session.accountId || session.expiresAt < Date.now()) {
    throw unauthorized("Session expired");
  }
  return session;
}

export const bearerToken = (request: Request): string | null => {
  const header = request.headers.get("Authorization");
  if (!header?.startsWith("Bearer ")) return null;
  return header.slice(7).trim() || null;
};

// ---- Google ID tokens ------------------------------------------------------

const GOOGLE_CERTS = "https://www.googleapis.com/oauth2/v3/certs";
const GOOGLE_ISSUERS = new Set(["accounts.google.com", "https://accounts.google.com"]);
const JWKS_CACHE_KEY = "google:jwks";

interface Jwk {
  kid: string;
  n: string;
  e: string;
  alg?: string;
  kty: string;
}

async function googleKeys(env: Env): Promise<Jwk[]> {
  const cached = await env.CACHE.get(JWKS_CACHE_KEY, "json");
  if (cached) return cached as Jwk[];

  const response = await fetch(GOOGLE_CERTS);
  if (!response.ok) throw unauthorized("Could not reach Google to verify sign-in");
  const body = (await response.json()) as { keys: Jwk[] };

  // Google rotates these. An hour is well inside their rotation window and
  // keeps the common path off the network.
  await env.CACHE.put(JWKS_CACHE_KEY, JSON.stringify(body.keys), {
    expirationTtl: 3600,
  });
  return body.keys;
}

export interface GoogleIdentity {
  sub: string;
  email?: string;
  name?: string;
}

/**
 * Verifies a Google ID token and returns who it says the person is.
 *
 * Checks the signature against Google's current keys, then the issuer, the
 * audience and the expiry. All four matter: a valid signature on a token
 * minted for a different app is still not permission to use this one.
 */
export async function verifyGoogleIdToken(
  env: Env,
  idToken: string,
): Promise<GoogleIdentity> {
  const [headerPart, payloadPart, signaturePart] = idToken.split(".");
  if (!headerPart || !payloadPart || !signaturePart) {
    throw unauthorized("Malformed Google token");
  }

  const header = JSON.parse(new TextDecoder().decode(b64urlDecode(headerPart))) as {
    kid?: string;
    alg?: string;
  };
  if (header.alg !== "RS256") throw unauthorized("Unexpected token algorithm");

  const key = (await googleKeys(env)).find((candidate) => candidate.kid === header.kid);
  if (!key) throw unauthorized("Unknown Google signing key");

  const publicKey = await crypto.subtle.importKey(
    "jwk",
    { kty: key.kty, n: key.n, e: key.e, alg: "RS256", ext: true },
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["verify"],
  );

  const verified = await crypto.subtle.verify(
    "RSASSA-PKCS1-v1_5",
    publicKey,
    b64urlDecode(signaturePart),
    encoder.encode(`${headerPart}.${payloadPart}`),
  );
  if (!verified) throw unauthorized("Google token signature does not verify");

  const claims = JSON.parse(new TextDecoder().decode(b64urlDecode(payloadPart))) as {
    iss?: string;
    aud?: string;
    sub?: string;
    exp?: number;
    email?: string;
    name?: string;
  };

  if (!claims.iss || !GOOGLE_ISSUERS.has(claims.iss)) {
    throw unauthorized("Google token has the wrong issuer");
  }
  if (claims.aud !== env.GOOGLE_OAUTH_CLIENT_ID) {
    throw unauthorized("Google token was issued for a different app");
  }
  if (!claims.exp || claims.exp * 1000 < Date.now()) {
    throw unauthorized("Google token has expired");
  }
  if (!claims.sub) throw unauthorized("Google token carries no subject");

  return { sub: claims.sub, email: claims.email, name: claims.name };
}

export const __testing = { b64urlEncode, b64urlDecode };
