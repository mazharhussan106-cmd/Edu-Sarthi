import type { Env } from "./types";

/**
 * The one call this whole server exists to make.
 *
 * The protocol here must match what the app already sends and parses — the
 * Android side has tests written against these exact response shapes, so this
 * forwards rather than reinterprets. What it adds is the key, which is the
 * entire point: a key compiled into an APK can be pulled out of it in minutes,
 * and the quota it unlocks is billed to whoever published the app.
 */

export interface ScoreRequest {
  audio: ArrayBuffer;
  referenceText: string;
}

export interface ScoreOutcome {
  ok: boolean;
  status: number;
  body: string;
}

const assessmentHeader = (referenceText: string): string => {
  const config = {
    ReferenceText: referenceText,
    GradingSystem: "HundredMark",
    Granularity: "Phoneme",
    PhonemeAlphabet: "IPA",
    EnableMiscue: true,
    Dimension: "Comprehensive",
  };
  // The header is base64 of the JSON, per the Speech REST contract.
  const json = new TextEncoder().encode(JSON.stringify(config));
  let binary = "";
  for (const byte of json) binary += String.fromCharCode(byte);
  return btoa(binary);
};

export const endpointFor = (region: string, locale: string): string =>
  `https://${region}.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1` +
  `?language=${encodeURIComponent(locale)}&format=detailed`;

/**
 * Forwards one clip for assessment.
 *
 * Returns the outcome rather than throwing, because the caller has a credit
 * held and needs to decide whether to commit or refund it. A 5xx from Azure is
 * not the learner's fault and must not cost them anything.
 */
export async function score(env: Env, request: ScoreRequest): Promise<ScoreOutcome> {
  const response = await fetch(endpointFor(env.AZURE_REGION, env.AZURE_LOCALE), {
    method: "POST",
    headers: {
      "Ocp-Apim-Subscription-Key": env.AZURE_SPEECH_KEY,
      // Azure reads the sample rate from this header, not from the WAV header
      // inside the body. Getting it wrong produces confident nonsense rather
      // than an error, which is why it is spelled out rather than inferred.
      "Content-Type": "audio/wav; codecs=audio/pcm; samplerate=16000",
      "Pronunciation-Assessment": assessmentHeader(request.referenceText),
      Accept: "application/json",
    },
    body: request.audio,
  });

  return {
    ok: response.ok,
    status: response.status,
    body: await response.text(),
  };
}
