/**
 * What money buys, and what effort earns.
 *
 * These numbers live on the server on purpose. They are the ones most likely
 * to change once the real cost of a scored attempt is known, and changing them
 * here takes effect immediately — no app release, no learner left on old terms.
 *
 * IMPORTANT: the credit counts below are provisional. They assume roughly ₹0.40
 * per scored attempt, a figure that has never been measured against a real
 * Azure bill. Measure first (the free F0 tier gives 5 audio hours a month),
 * then set these. See docs/DECISIONS.md.
 */

/** Credits granted once, on an account's first sight. */
export const WELCOME_CREDITS = 50;

/** Play product id -> credits. The ids must match the Play Console exactly. */
export const PACKS: Record<string, number> = {
  credits_entry: 150, // ₹99  — comfortably above the welcome grant, on purpose
  credits_standard: 450, // ₹249
  credits_large: 1000, // ₹499
};

/**
 * Ways to earn credits without paying.
 *
 * Each has a cap, because the app asserting "I finished a lesson" cannot be
 * verified by the server without syncing the whole progress model. These are
 * bounded-loss, not secure: a determined person can claim every lesson bonus
 * once. The cap is what makes that bounded — and the reward is small enough
 * that forging it is more work than it is worth.
 */
export const EARN_RULES = {
  /** One bonus per lesson, ever. 50 lessons is 100 credits over the whole course. */
  lesson: { credits: 2, perDay: 6 },
  /** One a week, claimed on a 7-day streak. */
  streak: { credits: 5, perDay: 1 },
} as const;

export type EarnKind = keyof typeof EARN_RULES;

export const isEarnKind = (value: string): value is EarnKind =>
  Object.prototype.hasOwnProperty.call(EARN_RULES, value);

/** One scored attempt costs one credit. Kept as a constant so it is never implied. */
export const CREDITS_PER_SCORE = 1;

/** Longest clip the proxy will forward, in bytes. 15 s of 16 kHz mono PCM is ~480 KB. */
export const MAX_AUDIO_BYTES = 600 * 1024;
