import { WELCOME_CREDITS, CREDITS_PER_SCORE, EARN_RULES, type EarnKind } from "./catalog";
import { paymentRequired, type Account, type LedgerReason } from "./types";

/**
 * The credit ledger.
 *
 * Two rules shape everything here.
 *
 * **The ledger is the truth and the balance is a cache.** Every mutation ends
 * by recomputing `accounts.balance` as the sum of that account's ledger rows,
 * inside the same transaction. It costs one extra aggregate on a table with a
 * few hundred rows per account, and in exchange the balance cannot drift: a
 * half-applied write corrects itself on the next one, and a disputed balance
 * can be explained line by line rather than argued about.
 *
 * **A grant with a `ref` can only ever happen once.** The unique index
 * `ledger_once` over (account_id, reason, ref) is what enforces it — not
 * application logic, which a retry or a race would eventually get past. One
 * welcome grant per account, one grant per purchase token, one bonus per
 * lesson, one refund per reservation.
 */

const now = () => Date.now();

const uuid = () => crypto.randomUUID();

/** Recomputes the cached balance from the ledger. Appended to every mutation. */
const recompute = (db: D1Database, accountId: string) =>
  db
    .prepare(
      `UPDATE accounts
          SET balance = (SELECT COALESCE(SUM(delta), 0) FROM ledger WHERE account_id = ?1),
              updated_at = ?2
        WHERE id = ?1`,
    )
    .bind(accountId, now());

export async function getAccount(
  db: D1Database,
  accountId: string,
): Promise<Account | null> {
  return db
    .prepare(`SELECT * FROM accounts WHERE id = ?`)
    .bind(accountId)
    .first<Account>();
}

/**
 * Finds or creates the account behind a device, granting the welcome credits
 * the first time only.
 *
 * Reinstalling gets a new local id and therefore a new grant — which is why
 * sign-in is required before topping up, and why the grant is the only thing
 * an anonymous install can ever receive.
 */
export async function accountForDevice(
  db: D1Database,
  localId: string,
): Promise<Account> {
  const existing = await db
    .prepare(
      `SELECT a.* FROM accounts a
         JOIN devices d ON d.account_id = a.id
        WHERE d.local_id = ?`,
    )
    .bind(localId)
    .first<Account>();

  if (existing) {
    await db
      .prepare(`UPDATE devices SET last_seen = ?1 WHERE local_id = ?2`)
      .bind(now(), localId)
      .run();
    return existing;
  }

  const accountId = uuid();
  const at = now();

  await db.batch([
    db
      .prepare(
        `INSERT INTO accounts (id, google_sub, balance, created_at, updated_at)
         VALUES (?1, NULL, 0, ?2, ?2)`,
      )
      .bind(accountId, at),
    db
      .prepare(
        `INSERT INTO devices (local_id, account_id, created_at, last_seen)
         VALUES (?1, ?2, ?3, ?3)`,
      )
      .bind(localId, accountId, at),
    db
      .prepare(
        `INSERT OR IGNORE INTO ledger (account_id, delta, reason, ref, created_at)
         VALUES (?1, ?2, 'welcome', 'welcome', ?3)`,
      )
      .bind(accountId, WELCOME_CREDITS, at),
    recompute(db, accountId),
  ]);

  const created = await getAccount(db, accountId);
  if (!created) throw new Error("account vanished immediately after creation");
  return created;
}

/**
 * Adds credits, at most once for a given (reason, ref).
 *
 * Returns whether this call was the one that granted them. A `false` is not an
 * error — it is a retry, a replayed purchase, or a lesson bonus already taken,
 * and the caller should treat it as success with nothing to add.
 */
export async function grant(
  db: D1Database,
  accountId: string,
  credits: number,
  reason: LedgerReason,
  ref: string,
): Promise<{ granted: boolean; balance: number }> {
  const inserted = await db
    .prepare(
      `INSERT OR IGNORE INTO ledger (account_id, delta, reason, ref, created_at)
       VALUES (?1, ?2, ?3, ?4, ?5)`,
    )
    .bind(accountId, credits, reason, ref, now())
    .run();

  await recompute(db, accountId).run();

  const account = await getAccount(db, accountId);
  return {
    granted: (inserted.meta.changes ?? 0) > 0,
    balance: account?.balance ?? 0,
  };
}

/**
 * Holds one credit while the speech service is called.
 *
 * Reserving before the call rather than charging after it is deliberate: a
 * crash, a timeout or a killed worker mid-request cannot hand out free
 * scoring. The cost is that a failed call must be refunded, which `refund`
 * does — so a learner never pays for a request that did not come back.
 *
 * The balance check and the deduction are one statement guarded by
 * `balance >= n`, so two phones on one account cannot both spend the last credit.
 */
export async function reserve(
  db: D1Database,
  accountId: string,
  credits = CREDITS_PER_SCORE,
): Promise<string> {
  const reservationId = uuid();
  const at = now();

  const results = await db.batch([
    db
      .prepare(
        `INSERT INTO reservations (id, account_id, state, created_at)
         SELECT ?1, ?2, 'held', ?3 FROM accounts WHERE id = ?2 AND balance >= ?4`,
      )
      .bind(reservationId, accountId, at, credits),
    db
      .prepare(
        `INSERT OR IGNORE INTO ledger (account_id, delta, reason, ref, created_at)
         SELECT ?2, -?4, 'score', ?1, ?3
          WHERE EXISTS (SELECT 1 FROM reservations WHERE id = ?1)`,
      )
      .bind(reservationId, accountId, at, credits),
    recompute(db, accountId),
  ]);

  const held = (results[0]?.meta.changes ?? 0) > 0;
  if (!held) throw paymentRequired();
  return reservationId;
}

/** Marks a held reservation spent. The credit was already deducted by `reserve`. */
export async function commit(db: D1Database, reservationId: string): Promise<void> {
  await db
    .prepare(`UPDATE reservations SET state = 'committed' WHERE id = ?1 AND state = 'held'`)
    .bind(reservationId)
    .run();
}

/**
 * Returns a held credit after a failed call.
 *
 * Safe to call twice: the state guard stops the second attempt, and the unique
 * index on (account_id, 'refund', reservationId) stops it again if it somehow
 * gets past.
 */
export async function refund(
  db: D1Database,
  reservationId: string,
  credits = CREDITS_PER_SCORE,
): Promise<void> {
  const reservation = await db
    .prepare(`SELECT account_id, state FROM reservations WHERE id = ?`)
    .bind(reservationId)
    .first<{ account_id: string; state: string }>();

  if (!reservation || reservation.state !== "held") return;

  await db.batch([
    db
      .prepare(`UPDATE reservations SET state = 'refunded' WHERE id = ?1 AND state = 'held'`)
      .bind(reservationId),
    db
      .prepare(
        `INSERT OR IGNORE INTO ledger (account_id, delta, reason, ref, created_at)
         VALUES (?1, ?2, 'refund', ?3, ?4)`,
      )
      .bind(reservation.account_id, credits, reservationId, now()),
    recompute(db, reservation.account_id),
  ]);
}

/**
 * Claims an earned bonus.
 *
 * `ref` identifies the thing achieved — a lesson id, or the week number for a
 * streak — so each can only ever pay once. The daily cap is the second bound,
 * because the app asserting "I finished a lesson" is not something the server
 * can verify without syncing the whole progress model. This is bounded loss by
 * design, not security, and the bound is what makes it acceptable.
 */
export async function claimEarned(
  db: D1Database,
  accountId: string,
  kind: EarnKind,
  ref: string,
): Promise<{ granted: boolean; balance: number }> {
  const rule = EARN_RULES[kind];
  const dayAgo = now() - 24 * 60 * 60 * 1000;

  const today = await db
    .prepare(
      `SELECT COUNT(*) AS n FROM ledger
        WHERE account_id = ?1 AND reason = 'earn' AND created_at > ?2`,
    )
    .bind(accountId, dayAgo)
    .first<{ n: number }>();

  if ((today?.n ?? 0) >= rule.perDay) {
    const account = await getAccount(db, accountId);
    return { granted: false, balance: account?.balance ?? 0 };
  }

  return grant(db, accountId, rule.credits, "earn", `${kind}:${ref}`);
}

/**
 * Attaches a Google identity, merging anything that account already had.
 *
 * The rule is that signing in never loses credits and never creates them. When
 * both sides exist, the ledger rows move across; rows that would collide on the
 * unique index are dropped rather than duplicated, which is exactly right for
 * the welcome grant — you do not get a second one by signing in.
 */
export async function linkGoogle(
  db: D1Database,
  accountId: string,
  googleSub: string,
  localId: string,
): Promise<Account> {
  const existing = await db
    .prepare(`SELECT * FROM accounts WHERE google_sub = ?`)
    .bind(googleSub)
    .first<Account>();

  if (!existing) {
    await db
      .prepare(`UPDATE accounts SET google_sub = ?1, updated_at = ?2 WHERE id = ?3`)
      .bind(googleSub, now(), accountId)
      .run();
    const linked = await getAccount(db, accountId);
    if (!linked) throw new Error("account vanished during linking");
    return linked;
  }

  if (existing.id === accountId) return existing;

  await db.batch([
    // OR IGNORE: a row that would collide (a second welcome grant) is dropped.
    db
      .prepare(`UPDATE OR IGNORE ledger SET account_id = ?1 WHERE account_id = ?2`)
      .bind(existing.id, accountId),
    db
      .prepare(`UPDATE reservations SET account_id = ?1 WHERE account_id = ?2`)
      .bind(existing.id, accountId),
    db
      .prepare(`UPDATE purchases SET account_id = ?1 WHERE account_id = ?2`)
      .bind(existing.id, accountId),
    db
      .prepare(`UPDATE devices SET account_id = ?1 WHERE account_id = ?2`)
      .bind(existing.id, accountId),
    db.prepare(`DELETE FROM ledger WHERE account_id = ?1`).bind(accountId),
    db.prepare(`DELETE FROM accounts WHERE id = ?1`).bind(accountId),
    recompute(db, existing.id),
  ]);

  await db
    .prepare(`UPDATE devices SET account_id = ?1, last_seen = ?2 WHERE local_id = ?3`)
    .bind(existing.id, now(), localId)
    .run();

  const merged = await getAccount(db, existing.id);
  if (!merged) throw new Error("account vanished during merge");
  return merged;
}
