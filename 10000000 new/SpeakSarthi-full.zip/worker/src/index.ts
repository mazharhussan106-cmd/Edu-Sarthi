import { bearerToken, issueSession, readSession, verifyGoogleIdToken } from "./auth";
import { score } from "./azure";
import { CREDITS_PER_SCORE, MAX_AUDIO_BYTES, PACKS, isEarnKind } from "./catalog";
import {
  accountForDevice,
  claimEarned,
  commit,
  getAccount,
  grant,
  linkGoogle,
  refund,
  reserve,
} from "./credits";
import { acknowledgePurchase, verifyPurchase } from "./play";
import { enforceRateLimit } from "./ratelimit";
import { ApiError, badRequest, unauthorized, type Env } from "./types";

/**
 * Speak Sarthi's server.
 *
 * It does three jobs and deliberately no others: it holds the speech key, it
 * owns the credit balance, and it proves that a purchase really happened. Every
 * one of those is something the app cannot be trusted to do for itself — not
 * because the app is badly written, but because it runs on a device its owner
 * controls, and a number kept there is editable in about two minutes.
 *
 * Learning progress, streaks, review schedules and everything else stay on the
 * phone, where they work offline and belong to the learner.
 */

const json = (body: unknown, status = 200): Response =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });

const readJson = async <T>(request: Request): Promise<T> => {
  try {
    return (await request.json()) as T;
  } catch {
    throw badRequest("bad_json", "Body is not valid JSON");
  }
};

/** Resolves the caller, or refuses. Every endpoint but /v1/session goes through here. */
async function requireSession(request: Request, env: Env) {
  const session = await readSession(env.SESSION_SIGNING_KEY, bearerToken(request));
  const account = await getAccount(env.DB, session.accountId);
  if (!account) throw unauthorized("That account no longer exists");
  return { session, account };
}

async function handle(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname;

  if (path === "/health") return json({ ok: true });

  // ---- session: an anonymous device says hello ---------------------------
  if (path === "/v1/session" && request.method === "POST") {
    const body = await readJson<{ localId?: string }>(request);
    const localId = body.localId?.trim();
    if (!localId || localId.length < 8 || localId.length > 128) {
      throw badRequest("bad_local_id", "localId must be 8-128 characters");
    }

    await enforceRateLimit(env, `session:${localId}`, 30, 3600);

    const account = await accountForDevice(env.DB, localId);
    return json({
      token: await issueSession(env.SESSION_SIGNING_KEY, account.id, localId),
      balance: account.balance,
      signedIn: account.google_sub !== null,
    });
  }

  // ---- balance ------------------------------------------------------------
  if (path === "/v1/balance" && request.method === "GET") {
    const { account } = await requireSession(request, env);
    return json({ balance: account.balance, signedIn: account.google_sub !== null });
  }

  // ---- link a Google identity --------------------------------------------
  if (path === "/v1/link" && request.method === "POST") {
    const { session, account } = await requireSession(request, env);
    const body = await readJson<{ idToken?: string }>(request);
    if (!body.idToken) throw badRequest("missing_id_token", "No Google token supplied");

    await enforceRateLimit(env, `link:${account.id}`, 10, 3600);

    const identity = await verifyGoogleIdToken(env, body.idToken);
    const merged = await linkGoogle(env.DB, account.id, identity.sub, session.localId);

    // The account id may have changed by merging, so the session is reissued.
    return json({
      token: await issueSession(env.SESSION_SIGNING_KEY, merged.id, session.localId),
      balance: merged.balance,
      signedIn: true,
      email: identity.email ?? null,
    });
  }

  // ---- score a clip -------------------------------------------------------
  if (path === "/v1/score" && request.method === "POST") {
    const { account } = await requireSession(request, env);

    const referenceText = url.searchParams.get("text")?.trim();
    if (!referenceText) {
      throw badRequest("missing_text", "No reference text supplied");
    }

    const audio = await request.arrayBuffer();
    if (audio.byteLength === 0) throw badRequest("empty_audio", "No audio supplied");
    if (audio.byteLength > MAX_AUDIO_BYTES) {
      throw badRequest("audio_too_large", "That clip is longer than the app should send");
    }

    await enforceRateLimit(env, `score:${account.id}`, 60, 3600);

    // Held first: a crash between here and the response cannot give away
    // scoring, and a failure below gives the credit back.
    const reservation = await reserve(env.DB, account.id, CREDITS_PER_SCORE);

    let outcome;
    try {
      outcome = await score(env, { audio, referenceText });
    } catch (error) {
      await refund(env.DB, reservation, CREDITS_PER_SCORE);
      throw error;
    }

    if (!outcome.ok) {
      // Azure's problem, not the learner's. They do not pay for it.
      await refund(env.DB, reservation, CREDITS_PER_SCORE);
      return json(
        { error: "scoring_unavailable", message: "Scoring could not be completed" },
        502,
      );
    }

    await commit(env.DB, reservation);
    const after = await getAccount(env.DB, account.id);

    return new Response(outcome.body, {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "X-Credits-Remaining": String(after?.balance ?? 0),
      },
    });
  }

  // ---- redeem a purchase --------------------------------------------------
  if (path === "/v1/purchase" && request.method === "POST") {
    const { account } = await requireSession(request, env);
    const body = await readJson<{ productId?: string; purchaseToken?: string }>(request);

    const productId = body.productId ?? "";
    const purchaseToken = body.purchaseToken ?? "";
    const credits = PACKS[productId];

    if (credits === undefined) throw badRequest("unknown_product", "No such credit pack");
    if (!purchaseToken) throw badRequest("missing_token", "No purchase token supplied");

    await enforceRateLimit(env, `purchase:${account.id}`, 20, 3600);

    if (env.DEV_TRUST_CLIENT_PURCHASES === "1") {
      // Development only. wrangler.toml says why this must never ship enabled.
      const result = await grant(env.DB, account.id, credits, "purchase", purchaseToken);
      return json({ state: "purchased", ...result, dev: true });
    }

    const verified = await verifyPurchase(env, productId, purchaseToken);

    if (verified.state === "pending") {
      const current = await getAccount(env.DB, account.id);
      return json({ state: "pending", granted: false, balance: current?.balance ?? 0 });
    }
    if (verified.state !== "purchased") {
      throw badRequest("purchase_not_valid", "That purchase is not active");
    }

    const result = await grant(env.DB, account.id, credits, "purchase", purchaseToken);

    if (!verified.acknowledged) {
      // Three days, then Google refunds it automatically and the credits are
      // already spent. Worth failing loudly if it does not work.
      await acknowledgePurchase(env, productId, purchaseToken);
    }

    return json({ state: "purchased", ...result });
  }

  // ---- claim an earned bonus ---------------------------------------------
  if (path === "/v1/earn" && request.method === "POST") {
    const { account } = await requireSession(request, env);
    const body = await readJson<{ kind?: string; ref?: string }>(request);

    if (!body.kind || !isEarnKind(body.kind)) {
      throw badRequest("unknown_earn_kind", "Not something credits are given for");
    }
    if (!body.ref) throw badRequest("missing_ref", "No reference supplied");

    await enforceRateLimit(env, `earn:${account.id}`, 40, 3600);

    const result = await claimEarned(env.DB, account.id, body.kind, body.ref);
    return json(result);
  }

  return json({ error: "not_found" }, 404);
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    try {
      return await handle(request, env);
    } catch (error) {
      if (error instanceof ApiError) {
        return json({ error: error.code, message: error.message }, error.status);
      }
      // Anything unexpected is logged for us and generic for the caller: an
      // error message is a fine place to accidentally publish a key.
      console.error("unhandled", error);
      return json({ error: "internal", message: "Something went wrong" }, 500);
    }
  },
} satisfies ExportedHandler<Env>;
