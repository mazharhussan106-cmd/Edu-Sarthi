import { badRequest, type Env } from "./types";

/**
 * Verifying that a purchase actually happened.
 *
 * The app sends a purchase token. On its own that is just a string the app
 * claimed — so it is checked against Google's own record before a single credit
 * is granted. Skipping this step is the difference between selling credits and
 * giving them to anyone who can edit an HTTP request.
 *
 * Authenticating to the Play Developer API needs a service-account JWT signed
 * with RS256 and exchanged for an access token. That token is cached, because
 * it lasts an hour and minting one costs a round trip and an RSA signature.
 */

const TOKEN_URL = "https://oauth2.googleapis.com/token";
const TOKEN_CACHE_KEY = "play:access_token";
const SCOPE = "https://www.googleapis.com/auth/androidpublisher";

interface ServiceAccount {
  client_email: string;
  private_key: string;
}

const b64url = (bytes: Uint8Array): string => {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};

const pemToPkcs8 = (pem: string): ArrayBuffer => {
  const body = pem
    .replace(/-----BEGIN PRIVATE KEY-----/, "")
    .replace(/-----END PRIVATE KEY-----/, "")
    .replace(/\s+/g, "");
  return Uint8Array.from(atob(body), (c) => c.charCodeAt(0)).buffer;
};

async function accessToken(env: Env): Promise<string> {
  const cached = await env.CACHE.get(TOKEN_CACHE_KEY);
  if (cached) return cached;

  const account = JSON.parse(env.PLAY_SERVICE_ACCOUNT) as ServiceAccount;
  const issued = Math.floor(Date.now() / 1000);

  const header = b64url(new TextEncoder().encode(JSON.stringify({ alg: "RS256", typ: "JWT" })));
  const claims = b64url(
    new TextEncoder().encode(
      JSON.stringify({
        iss: account.client_email,
        scope: SCOPE,
        aud: TOKEN_URL,
        iat: issued,
        exp: issued + 3600,
      }),
    ),
  );

  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToPkcs8(account.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    key,
    new TextEncoder().encode(`${header}.${claims}`),
  );

  const response = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: `${header}.${claims}.${b64url(new Uint8Array(signature))}`,
    }),
  });
  if (!response.ok) {
    throw new Error(`Play auth failed: ${response.status} ${await response.text()}`);
  }

  const token = (await response.json()) as { access_token: string; expires_in: number };
  await env.CACHE.put(TOKEN_CACHE_KEY, token.access_token, {
    // A minute short of the real expiry, so a token is never used as it dies.
    expirationTtl: Math.max(60, token.expires_in - 60),
  });
  return token.access_token;
}

export type PurchaseState = "purchased" | "pending" | "cancelled";

export interface VerifiedPurchase {
  state: PurchaseState;
  productId: string;
  acknowledged: boolean;
}

/**
 * Asks Google what really happened with this purchase token.
 *
 * `pending` is a real and common answer in India, not an edge case — a UPI
 * mandate can sit unconfirmed for hours and may never complete. Credits are
 * granted only on `purchased`; the app is told plainly that it is waiting,
 * which is a different thing from being told no.
 */
export async function verifyPurchase(
  env: Env,
  productId: string,
  purchaseToken: string,
): Promise<VerifiedPurchase> {
  const url =
    `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/` +
    `${encodeURIComponent(env.ANDROID_PACKAGE)}/purchases/products/` +
    `${encodeURIComponent(productId)}/tokens/${encodeURIComponent(purchaseToken)}`;

  const response = await fetch(url, {
    headers: { Authorization: `Bearer ${await accessToken(env)}` },
  });

  if (response.status === 404) {
    throw badRequest("unknown_purchase", "Google has no record of that purchase");
  }
  if (!response.ok) {
    throw new Error(`Play lookup failed: ${response.status} ${await response.text()}`);
  }

  const body = (await response.json()) as {
    purchaseState?: number; // 0 purchased, 1 cancelled, 2 pending
    acknowledgementState?: number; // 0 not acknowledged, 1 acknowledged
  };

  const state: PurchaseState =
    body.purchaseState === 0 ? "purchased" : body.purchaseState === 2 ? "pending" : "cancelled";

  return {
    state,
    productId,
    acknowledged: body.acknowledgementState === 1,
  };
}

/**
 * Acknowledges a purchase so Google does not automatically refund it.
 *
 * Play gives three days. An unacknowledged purchase past that window is
 * refunded to the buyer and the credits are already spent — so this runs
 * immediately after granting, and its failure is logged rather than swallowed.
 */
export async function acknowledgePurchase(
  env: Env,
  productId: string,
  purchaseToken: string,
): Promise<void> {
  const url =
    `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/` +
    `${encodeURIComponent(env.ANDROID_PACKAGE)}/purchases/products/` +
    `${encodeURIComponent(productId)}/tokens/${encodeURIComponent(purchaseToken)}:acknowledge`;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${await accessToken(env)}`,
      "Content-Type": "application/json",
    },
    body: "{}",
  });

  if (!response.ok && response.status !== 400) {
    // 400 usually means "already acknowledged", which is fine.
    throw new Error(`Play acknowledge failed: ${response.status}`);
  }
}
