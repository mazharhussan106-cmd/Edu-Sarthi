import { tooManyRequests, type Env } from "./types";

/**
 * A coarse per-account limit, in KV.
 *
 * This is not the thing that protects the Azure bill — credits do that, and
 * they are exact. This is the cheaper guard in front of them: it stops a broken
 * client in a retry loop, or someone probing the sign-in endpoint, from costing
 * anything at all. KV's eventual consistency makes it approximate, which is
 * fine for a backstop and would not be fine for a balance.
 */
export async function enforceRateLimit(
  env: Env,
  key: string,
  limit: number,
  windowSeconds: number,
): Promise<void> {
  const bucket = `rate:${key}:${Math.floor(Date.now() / 1000 / windowSeconds)}`;
  const current = Number((await env.CACHE.get(bucket)) ?? "0");

  if (current >= limit) throw tooManyRequests();

  await env.CACHE.put(bucket, String(current + 1), {
    expirationTtl: Math.max(60, windowSeconds * 2),
  });
}
