/** Bindings declared in wrangler.toml, plus the secrets set with `wrangler secret put`. */
export interface Env {
  DB: D1Database;
  CACHE: KVNamespace;

  // vars
  AZURE_REGION: string;
  AZURE_LOCALE: string;
  ANDROID_PACKAGE: string;
  DEV_TRUST_CLIENT_PURCHASES: string;

  // secrets
  AZURE_SPEECH_KEY: string;
  SESSION_SIGNING_KEY: string;
  GOOGLE_OAUTH_CLIENT_ID: string;
  PLAY_SERVICE_ACCOUNT: string;
}

export interface Account {
  id: string;
  google_sub: string | null;
  balance: number;
  created_at: number;
  updated_at: number;
}

export type LedgerReason =
  | "welcome"
  | "purchase"
  | "earn"
  | "score"
  | "refund"
  | "adjust";

/** Thrown for anything the caller could have avoided. Carries its own status. */
export class ApiError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
  ) {
    super(message);
  }
}

export const badRequest = (code: string, message: string) =>
  new ApiError(400, code, message);
export const unauthorized = (message = "Sign in required") =>
  new ApiError(401, "unauthorized", message);
export const paymentRequired = (message = "No credits left") =>
  new ApiError(402, "no_credits", message);
export const tooManyRequests = (message = "Slow down") =>
  new ApiError(429, "rate_limited", message);
