import { describe, expect, it, beforeEach } from "vitest";
import { balanceOf, createTestDb, ledgerSum } from "./d1";
import {
  accountForDevice,
  claimEarned,
  commit,
  getAccount,
  grant,
  linkGoogle,
  refund,
  reserve,
} from "../src/credits";
import { EARN_RULES, WELCOME_CREDITS } from "../src/catalog";
import { ApiError } from "../src/types";

/**
 * The credit rules, tested against real SQLite.
 *
 * Every test here is about money leaving the owner's Azure account, so they are
 * written as claims about what can never happen rather than as walkthroughs of
 * the happy path.
 */
describe("credits", () => {
  let db: D1Database;

  beforeEach(() => {
    db = createTestDb();
  });

  it("gives a new device the welcome grant", async () => {
    const account = await accountForDevice(db, "device-00000001");
    expect(account.balance).toBe(WELCOME_CREDITS);
  });

  it("does not give it twice to the same device", async () => {
    const first = await accountForDevice(db, "device-00000001");
    const second = await accountForDevice(db, "device-00000001");

    expect(second.id).toBe(first.id);
    expect(second.balance).toBe(WELCOME_CREDITS);
  });

  it("charges exactly one credit for a scored attempt", async () => {
    const account = await accountForDevice(db, "device-00000001");
    const reservation = await reserve(db, account.id);
    await commit(db, reservation);

    expect(await balanceOf(db, account.id)).toBe(WELCOME_CREDITS - 1);
  });

  it("refuses to reserve when the balance is empty", async () => {
    const account = await accountForDevice(db, "device-00000001");
    for (let i = 0; i < WELCOME_CREDITS; i++) {
      await commit(db, await reserve(db, account.id));
    }
    expect(await balanceOf(db, account.id)).toBe(0);

    // The whole point of the server. Without this the Azure bill is unbounded.
    await expect(reserve(db, account.id)).rejects.toBeInstanceOf(ApiError);
  });

  it("gives the credit back when scoring fails", async () => {
    const account = await accountForDevice(db, "device-00000001");
    const reservation = await reserve(db, account.id);
    expect(await balanceOf(db, account.id)).toBe(WELCOME_CREDITS - 1);

    await refund(db, reservation);
    expect(await balanceOf(db, account.id)).toBe(WELCOME_CREDITS);
  });

  it("does not refund the same reservation twice", async () => {
    // A retried error handler must not become a credit printer.
    const account = await accountForDevice(db, "device-00000001");
    const reservation = await reserve(db, account.id);

    await refund(db, reservation);
    await refund(db, reservation);
    await refund(db, reservation);

    expect(await balanceOf(db, account.id)).toBe(WELCOME_CREDITS);
  });

  it("does not refund a reservation that was already spent", async () => {
    const account = await accountForDevice(db, "device-00000001");
    const reservation = await reserve(db, account.id);
    await commit(db, reservation);
    await refund(db, reservation);

    expect(await balanceOf(db, account.id)).toBe(WELCOME_CREDITS - 1);
  });

  it("grants a purchase once, however many times it is redeemed", async () => {
    // Replaying a purchase token is the cheapest attack available, so it is
    // stopped by the unique index rather than by remembering to check.
    const account = await accountForDevice(db, "device-00000001");

    const first = await grant(db, account.id, 150, "purchase", "token-abc");
    const second = await grant(db, account.id, 150, "purchase", "token-abc");
    const third = await grant(db, account.id, 150, "purchase", "token-abc");

    expect(first.granted).toBe(true);
    expect(second.granted).toBe(false);
    expect(third.granted).toBe(false);
    expect(await balanceOf(db, account.id)).toBe(WELCOME_CREDITS + 150);
  });

  it("pays a lesson bonus once per lesson", async () => {
    const account = await accountForDevice(db, "device-00000001");

    const first = await claimEarned(db, account.id, "lesson", "L001");
    const again = await claimEarned(db, account.id, "lesson", "L001");

    expect(first.granted).toBe(true);
    expect(again.granted).toBe(false);
    expect(await balanceOf(db, account.id)).toBe(
      WELCOME_CREDITS + EARN_RULES.lesson.credits,
    );
  });

  it("caps how much can be earned in a day", async () => {
    // The app claiming "I finished a lesson" cannot be verified without syncing
    // the whole progress model, so the cap is what makes the loss bounded.
    const account = await accountForDevice(db, "device-00000001");

    for (let i = 0; i < EARN_RULES.lesson.perDay + 5; i++) {
      await claimEarned(db, account.id, "lesson", `L${i}`);
    }

    const earned = (await balanceOf(db, account.id)) - WELCOME_CREDITS;
    expect(earned).toBe(EARN_RULES.lesson.perDay * EARN_RULES.lesson.credits);
  });

  it("keeps the cached balance equal to the ledger, whatever happens", async () => {
    const account = await accountForDevice(db, "device-00000001");
    await grant(db, account.id, 150, "purchase", "token-abc");
    await claimEarned(db, account.id, "lesson", "L001");
    await commit(db, await reserve(db, account.id));
    await refund(db, await reserve(db, account.id));
    await grant(db, account.id, 150, "purchase", "token-abc");

    expect(await balanceOf(db, account.id)).toBe(await ledgerSum(db, account.id));
  });

  describe("signing in", () => {
    it("keeps the credits earned while anonymous", async () => {
      const account = await accountForDevice(db, "device-00000001");
      await grant(db, account.id, 150, "purchase", "token-abc");

      const linked = await linkGoogle(db, account.id, "google-sub-1", "device-00000001");

      expect(linked.balance).toBe(WELCOME_CREDITS + 150);
      expect(linked.google_sub).toBe("google-sub-1");
    });

    it("adds up both sides when the account already existed", async () => {
      const oldPhone = await accountForDevice(db, "device-00000001");
      await grant(db, oldPhone.id, 150, "purchase", "token-old");
      await linkGoogle(db, oldPhone.id, "google-sub-1", "device-00000001");

      const newPhone = await accountForDevice(db, "device-00000002");
      await grant(db, newPhone.id, 450, "purchase", "token-new");

      const merged = await linkGoogle(db, newPhone.id, "google-sub-1", "device-00000002");

      // Both purchases survive; the welcome grant is counted once, not twice.
      expect(merged.balance).toBe(WELCOME_CREDITS + 150 + 450);
    });

    it("does not hand out a second welcome grant", async () => {
      const first = await accountForDevice(db, "device-00000001");
      await linkGoogle(db, first.id, "google-sub-1", "device-00000001");

      const second = await accountForDevice(db, "device-00000002");
      const merged = await linkGoogle(db, second.id, "google-sub-1", "device-00000002");

      expect(merged.balance).toBe(WELCOME_CREDITS);
    });

    it("leaves both devices pointing at the one account", async () => {
      const first = await accountForDevice(db, "device-00000001");
      await linkGoogle(db, first.id, "google-sub-1", "device-00000001");
      const second = await accountForDevice(db, "device-00000002");
      const merged = await linkGoogle(db, second.id, "google-sub-1", "device-00000002");

      expect((await accountForDevice(db, "device-00000001")).id).toBe(merged.id);
      expect((await accountForDevice(db, "device-00000002")).id).toBe(merged.id);
      expect(await getAccount(db, second.id)).toBeNull();
    });

    it("spends from one balance however many phones are signed in", async () => {
      const a = await accountForDevice(db, "device-00000001");
      await linkGoogle(db, a.id, "google-sub-1", "device-00000001");
      const b = await accountForDevice(db, "device-00000002");
      const merged = await linkGoogle(db, b.id, "google-sub-1", "device-00000002");

      await commit(db, await reserve(db, merged.id));
      expect(await balanceOf(db, merged.id)).toBe(WELCOME_CREDITS - 1);
    });
  });
});
