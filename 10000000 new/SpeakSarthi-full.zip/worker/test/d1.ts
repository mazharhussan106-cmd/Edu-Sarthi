import { readFileSync } from "node:fs";
import { createRequire } from "node:module";

// Loaded through createRequire rather than a static import: Vite's resolver
// does not yet know `node:sqlite` is a builtin and tries to find it on disk.
const nodeRequire = createRequire(import.meta.url);
const { DatabaseSync } = nodeRequire("node:sqlite") as {
  DatabaseSync: new (path: string) => {
    exec(sql: string): void;
    prepare(sql: string): {
      run(...args: unknown[]): { changes: number | bigint };
      get(...args: unknown[]): unknown;
      all(...args: unknown[]): unknown[];
    };
  };
};

/**
 * A D1 stand-in backed by real SQLite.
 *
 * The point of testing against the actual engine rather than a mock is that the
 * rules this server depends on are enforced *by the database*, not by the code:
 * the unique index that makes a grant unrepeatable, the CHECK that forbids a
 * negative balance, and the conditional INSERT...SELECT that makes the balance
 * check and the deduction one indivisible step. A mock would happily agree with
 * whatever the code believed and prove nothing.
 */
export function createTestDb(schemaPath = "./schema.sql"): D1Database {
  const sqlite = new DatabaseSync(":memory:");
  sqlite.exec("PRAGMA foreign_keys = ON;");
  sqlite.exec(readFileSync(schemaPath, "utf8"));

  const statement = (sql: string, args: unknown[] = []) => ({
    bind: (...next: unknown[]) => statement(sql, next),
    run: async () => {
      const result = sqlite.prepare(sql).run(...(args as never[]));
      return { meta: { changes: Number(result.changes) } };
    },
    first: async <T>() => (sqlite.prepare(sql).get(...(args as never[])) ?? null) as T | null,
    all: async <T>() => ({ results: sqlite.prepare(sql).all(...(args as never[])) as T[] }),
    raw: async () => [],
  });

  return {
    prepare: (sql: string) => statement(sql),
    batch: async (statements: { run: () => Promise<{ meta: { changes: number } }> }[]) => {
      // D1's batch is one transaction. Reproducing that matters: several of the
      // operations under test are only correct because a partial application is
      // impossible.
      sqlite.exec("BEGIN");
      try {
        const results = [];
        for (const one of statements) results.push(await one.run());
        sqlite.exec("COMMIT");
        return results;
      } catch (error) {
        sqlite.exec("ROLLBACK");
        throw error;
      }
    },
    dump: async () => new ArrayBuffer(0),
    exec: async (sql: string) => {
      sqlite.exec(sql);
      return { count: 0, duration: 0 };
    },
  } as unknown as D1Database;
}

/** Reads the cached balance — the thing every test is really asking about. */
export async function balanceOf(db: D1Database, accountId: string): Promise<number> {
  const row = await db
    .prepare("SELECT balance FROM accounts WHERE id = ?")
    .bind(accountId)
    .first<{ balance: number }>();
  return row?.balance ?? -1;
}

/** Sums the ledger directly, to prove the cache agrees with the truth. */
export async function ledgerSum(db: D1Database, accountId: string): Promise<number> {
  const row = await db
    .prepare("SELECT COALESCE(SUM(delta), 0) AS total FROM ledger WHERE account_id = ?")
    .bind(accountId)
    .first<{ total: number }>();
  return row?.total ?? 0;
}
